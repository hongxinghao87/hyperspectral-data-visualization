/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPISELECT4_H_
#define MGAPISELECT4_H_
/* @doc EXTERNAL SELECTFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#include "mgapidecl.h"
#include "mgapistd.h"
#include "mgapimatrix.h"

/*============================================================================*\
	public constants
\*============================================================================*/

/*============================================================================*\
	private types
\*============================================================================*/

// @type mgreclist | Abstract type used to represent a general record list.
// @desc This node list is used for select lists and construct lists.
// @desc The node list maintains a list of node records and a traversal pointer
// to keep track of which node in the list is next to be traversed by 
// <f mgGetNextRecInList>.
// @see <f mgGetSelectList>, <f mgGetConstructList>
typedef struct mgselectlist_t* mgreclist;

/* @deprecated mgselectlist | Use <t mgreclist> */
typedef mgreclist mgselectlist;

/*============================================================================*\
	public types
\*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgreclist | mgGetSelectList | gets the current modeling select list
	@desc <f mgGetSelectList> creates a new record list containing all the 
	currently selected nodes in the specified database <p db>.  The traversal
	pointer of the record list returned is set to the first item in the list.

	@desc This function returns a record list object that reflects the state
	of the select list when it was called.  Typically call this function,
	examine the contents of the record list returned and then dispose of the 
	record list when you are done.  If you retain the record list, its contents
	is not guaranteed to be valid if the modeler subsequently changes the 
	select list in Creator or deletes an item that your record list 
	contains.

	@desc When you are done accessing the record list returned by this
	function, you should dispose of it using <f mgFreeRecList>.

	@ex The following example gets the select list for database <p db>
	and traverses each node it contains |
   mgrec* rec;
   mgmatrix selectMatrix;
   mgreclist selectList = mgGetSelectList ( db );

   rec = mgGetNextRecInList ( selectList, &selectMatrix );
   while ( rec )
   {
      // do something with rec
      rec = mgGetNextRecInList ( selectList, &selectMatrix );
   }
   mgFreeRecList ( selectList );

	@return record list object containing all the currently selected
	nodes in database, <m MG_NULL> if nothing is currently selected.

	@access Level 4
	@see <f mgreclist>, <f mgFreeRecList>,
	<f mgResetRecList>, <f mgGetNextRecInList>, <f mgGetNthRecInList> 
*/
extern MGAPIFUNC(mgreclist) mgGetSelectList (
	mgrec* db			// @param the database to get the select list for.
	);

/* @deprecated mgNewSelectList | Use <f mgGetSelectList> */
extern MGAPIFUNC(mgselectlist) mgNewSelectList (
	mgrec* db
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgFreeRecList | free a record (select) list
	@desc <f mgFreeRecList> frees the contents of a record (select) list
	allocated by a call to <f mgGetSelectList> or <f mgGetConstructList>.
	When you are done accessing a record (select) list, dispose of it using
	this function.

	@desc Only the internal contents of the record list is disposed.  This
	function does not affect the actual nodes that were contained in the list.

	@access Level 4
	@see <f mgGetSelectList>, <f mgResetRecList>, <f mgGetNextRecInList>,
	<f mgGetNthRecInList>, <f mgGetConstructList>
*/
extern MGAPIFUNC(void) mgFreeRecList (
	mgreclist recList		// @param the record list to free
	);

/* @deprecated mgFreeSelectList | Use <f mgFreeRecList> */
extern MGAPIFUNC(void) mgFreeSelectList (
	mgselectlist selectList
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func void | mgResetRecList | resets the traversal pointer of a record
	(select) list to the first item in the list.
	@desc <f mgResetRecList> resets the internal traversal pointer of the
	specified record (select) list <p recList> to the first item in the list.  

	@desc The traversal pointer of a record (select) list keeps track of the item
	in the list that is returned by the next call to <f mgGetNextRecInList>.
	Calling this function insures that the next call to <f mgGetNextRecInList>
	returns the first item in the record (select) list.

	@access Level 4
	@see <f mgGetNextRecInList>, <f mgGetNthRecInList>
*/
extern MGAPIFUNC(void) mgResetRecList (
	mgreclist recList			// @param the record (select) list to reset
	);

/* @deprecated mgResetSelectList | Use <f mgResetRecList> */
extern MGAPIFUNC(void) mgResetSelectList (
	mgselectlist selectList
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetNextRecInList | returns the next item in the record
	(select) list
	@desc <f mgGetNextRecInList> returns the item in the specified record 
	(select) list <p recList> that corresponds to the current position of
	the traversal pointer.  

	@desc Before this function returns, it advances the position of the traversal
	pointer of the record (select) list so that the next call to <f mgGetNextRecInList>
	returns the proper list node.

	@return Returns the next item in the record (select) list, <m MG_NULL> if
	no more items are in the list.  If an item is returned, the output parameter
	<p matrix> is loaded with the composite matrix representing the cumulative
	transformations applied to this item.

	@access Level 4
	@see <f mgResetRecList>, <f mgGetNthRecInList>
*/
extern MGAPIFUNC(mgrec*) mgGetNextRecInList (
	mgreclist recList,				// @param the record (select) list to traverse
	mgmatrix* matrix					// @param the address of a matrix to receive
											// the composite of all transformations above
											// the returned record (select) list item
	);

/* @deprecated mgGetNextSelected | Use <f mgGetNextRecInList> */
extern MGAPIFUNC(mgrec*) mgGetNextSelected (
	mgselectlist selectList,
	mgmatrix* matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetNthRecInList | returns the nth item in the record
	(select) list
	@desc <f mgGetNthRecInList> returns the item in the specified record
	(select) list
	<p recList> that is at position <p nth>.  The first item is at position 1.

	@desc This function does not affect the traversal pointer of the record
	(select) list.

	@return Returns the next item in the record (select) list, <m MG_NULL>
	if no more items are in the list.  If an item is returned, the output
	parameter <p matrix> is loaded with the composite matrix representing
	the cumulative transformations applied to this item.

	@access Level 4
	@see <f mgResetRecList>, <f mgGetNextRecInList>
*/
extern MGAPIFUNC(mgrec*) mgGetNthRecInList (
	mgreclist recList,				// @param the record (select) list to traverse
	mgmatrix* matrix,					// @param the address of a matrix to receive
											// the composite of all transformations above
											// the returned record (select) list item
	int nth								// @param the position in the list of the 
											// item to get, 1 (one) is the first item
	);

/* @deprecated mgGetNthSelected | Use <f mgGetNthRecInList> */
extern MGAPIFUNC(mgrec*) mgGetNthSelected (
	mgselectlist selectList,
	mgmatrix* matrix,
	int nth
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSelectOne | select a bead type node
	@desc <f mgSelectOne> selects the specified bead type node <p rec>. 

	@desc If selecting the specified node would result in a recursive
	select list (that is either an ancestor or descendent of <p rec> is
	already selected), the selection is not allowed. 
 
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgDeselectOne>, <f mgIsSelected>, <f mgDeselectAll>
*/
extern MGAPIFUNC(mgstatus) mgSelectOne (
	mgrec* rec							// @param the node to select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDeselectOne | deselect a bead type node.
	@desc <f mgDeselectOne> deselects the specified bead type node <p rec>. 
 
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSelectOne>, <f mgIsSelected>, <f mgDeselectAll>
*/
extern MGAPIFUNC(mgstatus) mgDeselectOne (
	mgrec* rec							// @param the node to de-select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDeselectAll | deselects all bead type nodes.
	@desc <f mgDeselectAll> deselects all bead type nodes for the specified
	database <p db>. 
 
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSelectOne>, <f mgDeselectOne>, <f mgIsSelected>
*/
extern MGAPIFUNC(mgstatus) mgDeselectAll (
	mgrec* db							// @param the database to de-select all for
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIsSelected | determines if a node is selected.
	@desc <f mgIsSelected> determines if the specified bead type node
	<p rec> is currently selected.
 
	@return Returns <e mgbool.MG_TRUE> if node is selected, <e mgbool.MG_FALSE> otherwise.

	@access Level 4
	@see <f mgSelectOne>, <f mgDeselectOne>, <f mgDeselectAll>
*/
extern MGAPIFUNC(mgbool) mgIsSelected (
	mgrec* rec							// @param the node to check for selection
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetRecListCount | counts the number of items in a record
	(select) list.
	@desc <f mgGetRecListCount> returns the number of items contained in the
	specified record (select) list <p recList>.
 
	@return Returns the number of items in the record (select) list,
	and returns 0 if list is empty.

	@access Level 4
	@see <f mgGetSelectList>, <f mgGetConstructList>,
	<f mgSelectOne>, <f mgDeselectOne>, <f mgIsSelected>
*/
extern MGAPIFUNC(int) mgGetRecListCount (
	mgreclist recList		// @param the record (select) list to count items for
	);

/* @deprecated mgGetSelectListCount | Use <f mgGetRecListCount> */
extern MGAPIFUNC(int) mgGetSelectListCount (
	mgselectlist selectList
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcode | mgGetRecListLevel | returns the level of the record
	(select) list.
	@desc <f mgGetRecListLevel> returns the node level of the first item
	in the specified record (select) list <p recList>.

	@desc Nodes contained in a record (select) list are not guaranteed to
	all be of the same level.  This level returned by this function may
	not be indicative of all nodes contained in the record (select) list.
 
	@return Returns the node level of the first item in the list, and returns
	0 if list is empty.

	@access Level 4
	@see <f mgGetRecListCount>
*/
extern MGAPIFUNC(mgcode) mgGetRecListLevel (
	mgreclist recList			// @param the record (select) list to get level
	);

/* @deprecated mgGetSelectListLevel | Use <f mgGetRecListLevel> */
extern MGAPIFUNC(mgcode) mgGetSelectListLevel (
	mgselectlist selectList
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgselectlist | mgGetConstructList | gets the construction
	vertices and edges in a database

	@desc <f mgGetConstructList> creates a new node list containing all
	the construction vertex and edge nodes in the specified database <p db>.  
	The traversal pointer of the list returned is set to the first
	item in the list.

	@desc This function returns a list object that reflects the state
	of the database constructions when it was called.  Typically call
	this function, examine the contents of the list returned and then
	dispose of the list when you are done.  If you retain the list, its
	contents are not guaranteed to be valid if the modeler subsequently
	adds or deletes a construction vertex or edge.
	
	@desc When you are done accessing the list returned by this
	function, you should dispose of it using <f mgFreeRecList>.

	@ex The following example gets the construction list for a
	database <p db> and traverses each node it contains |
   mgrec* rec;
   mgmatrix constructMatrix;
   mgreclist constructList = mgGetConstructList ( db );

   rec = mgGetNextRecInList ( constructList, &constructMatrix );
   while ( rec )
   {
      // do something with rec
      if ( mgGetNext ( rec ) ) {
         // rec is an "edge"
      }
      else {
         // rec is a "vertex"
      }
      // get next construct rec in list
      rec = mgGetNextRecInList ( constructList, &constructMatrix );
   }
   mgFreeRecList ( constructList );

	@return record list object containing all the construction nodes
	in database, <m MG_NULL> if no construction nodes found.

	@access Level 4
	@see <f mgreclist>, <f mgFreeRecList>, <f mgResetRecList>,
	<f mgGetNextRecInList>, <f mgGetNthRecInList> 
*/
extern MGAPIFUNC(mgreclist) mgGetConstructList (
	mgrec* db			// @param the database to get the construction list for.
	);
/*                                                                            */
/*============================================================================*/

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPISELECT4_H_ */
/* DON'T ADD STUFF AFTER THIS #endif */


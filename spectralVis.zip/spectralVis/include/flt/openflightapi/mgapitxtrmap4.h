/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPITXTRMAP4_H_
#define MGAPITXTRMAP4_H_
/* @doc EXTERNAL TXTRMAPFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentTextureMapping | returns index of current modeling
	texture mapping.

	@desc <f mgGetCurrentTextureMapping> returns the <p index> of the current 
	modeling texture mapping selected for database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if current modeling texture mapping for <p db>
	could be determined, <e mgbool.MG_FALSE> otherwise.  If successful, 
	the output parameter <p index> is filled in with the corresponding
	value, otherwise it is undefined.

	@see <f mgSetCurrentTextureMapping>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentTextureMapping (
	mgrec* db,			// @param the database
	int* index			// @param address of value to receive index of current 
						// modeling texture mapping.
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetCurrentTextureMapping | sets the current modeling texture
	mapping index.

	@desc <f mgSetCurrentTextureMapping> sets the current modeling texture mapping
	palette <p index> for database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if current modeling texture mapping for <p db>
	could be set, <e mgbool.MG_FALSE> otherwise.

	@see <f mgGetCurrentTextureMapping>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgSetCurrentTextureMapping (
	mgrec* db,			// @param the database
	int index			// @param index to set current modeling texture mapping
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

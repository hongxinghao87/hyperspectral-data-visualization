/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIATTR3_H_
#define MGAPIATTR3_H_
/* @doc EXTERNAL ATTRIBUTEFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapiplugin.h"
						
/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/* Property List Functions */

/* @type mgpropertyname | A string type used to name user defined data  */
/*	@desc Each user defined data item has a unique <t mgpropertyname>.   */
typedef char* mgpropertyname;

/* @type mgpropertyvalue | An opaque pointer type used to hold user defined data */
/*	@desc Each user defined data item should be cast to type <t mgpropertyvalue>. */
typedef void* mgpropertyvalue;

/* Property List for mgrec */

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgRecPutProperty | associates user defined data with a record.

	@desc <f mgRecPutProperty> allows plug-in writers to associate data of any type, 
	<p propValue>, with any node record.  The user-defined data is associated with
	a record, <p rec>, along with a property name string, <p propName>, 
	allowing any number of data records to be associated with the node record, 
	as long as all property names are unique.

	@return <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 3
	@see <f mgRecGetProperty>, <f mgRecDeleteProperty>, <f mgSetUserData>
*/
extern MGAPIFUNC(mgbool) mgRecPutProperty	(
	mgplugintool pluginTool,		// @param the plug-in tool handle
	mgrec* rec,							// @param the record to put property on
	mgpropertyname propName,		// @param the name of the property to assign
	mgpropertyvalue propValue		// @param the value of the property to assign
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgpropertyvalue | mgRecGetProperty | retrieves user defined data 
	associated with a record.

	@desc Use <f mgRecGetProperty> to retrieve the data named <p propName> 
	that was associated with the record <p rec> using <f mgRecPutProperty>.

	@return Upon success, the user-defined data is returned, otherwise
	the return value is <m MG_NULL>.

	@access Level 3
	@see <f mgRecPutProperty>, <f mgRecDeleteProperty>, <f mgGetUserData>
*/
extern MGAPIFUNC(mgpropertyvalue) mgRecGetProperty	(
	mgplugintool pluginTool,		// @param the plug-in tool handle
	mgrec* rec,							// @param the record to get property for
	mgpropertyname propName			// @param the name of the property to get
	);
/*                                                                            */
/*============================================================================*/

 
/*============================================================================*/
/*                                                                            */
/* @func void | mgRecDeleteProperty | deletes user defined data 
	associated with a record.

	@desc Use <f mgRecDeleteProperty> to delete the data named <p propName> 
	that was associated with the record <p rec> using <f mgRecPutProperty>.

	@access Level 3
	@see <f mgRecPutProperty>, <f mgRecGetProperty>
*/
extern MGAPIFUNC(void) mgRecDeleteProperty (	
	mgplugintool pluginTool,		// @param the plug-in tool handle
	mgrec* rec,							// @param the record 
	mgpropertyname propName			// @param the name of the property to delete
	);
/*                                                                            */
/*============================================================================*/

 
/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */



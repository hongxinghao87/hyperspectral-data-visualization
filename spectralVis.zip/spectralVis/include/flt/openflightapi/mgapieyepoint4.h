/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIEYEPOINT4_H_
#define MGAPIEYEPOINT4_H_
// @doc EXTERNAL EYEFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"
#include "mgapiplugin.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentEyePoint | returns the attributes of the current 
	eyepoint.

	@desc <f mgGetCurrentEyePoint> copies the current eyepoint into the eyepoint 
	record <p eyeRec>.  <p eyeRec> must have previously been obtained by a call
	to <f mgGetNewEyePoint>

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise. 
	If successful, the <flt fltEyePoint> record <p eyeRec> is filled with the 
	attributes of the current eyepoint.

	@see <f mgSetCurrentEyePoint>. <f mgGetNewEyePoint>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentEyePoint ( 
			mgrec* db,				// @param the database
			mgrec* eyeRec			// @param the address of the record to 
										// receive the eyepoint record
			);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetCurrentEyePoint | sets the current eyepoint

	@desc <f mgSetCurrentEyePoint> sets the current eyepoint and refreshes the
	scene.  The <flt fltEyePoint> record <p eyeRec> must have previously been 
	obtained by <f mgGetNewEyePoint> or <f mgGetEyePoint>

	@return Returns <e mgbool.MG_TRUE> if the current eyepoint for <p db>
	could be set, <e mgbool.MG_FALSE> otherwise.

	@see <f mgGetCurrentEyePoint>, <f mgGetEyePoint>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgSetCurrentEyePoint ( 
			mgrec* db,			// @param the database
			mgrec* eyeRec		// @param the eyepoint record to set
			);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentLookAt | returns the current eyepoint in 
	"look at" form.  

	@desc <f mgGetCurrentLookAt> returns the current eyepoint using "look at"
	style parameters.  The "look at" parameters include 3 sets of values.  
	The first set, <p eyex>, <p eyey>, and <p eyez> is the position of 
	the eye point. 
	The second set, <p centerx>, <p centery>, <p centerz> is the position
	of the reference point.  
	The third set, <p upx>, <p upy>, and <p upz> is the direction of the up vector.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise. 

	@see <f mgSetCurrentLookAt>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentLookAt ( 
			mgrec* db,			// @param the database
			double* eyex,		// @param the x component of the eyepoint position
			double* eyey,		// @param the y component of the eyepoint position
			double* eyez,		// @param the z component of the eyepoint position
			double* centerx,	// @param the x component of the reference point
			double* centery,	// @param the y component of the reference point
			double* centerz,	// @param the z component of the reference point
			double* upx,		// @param the i component of the up vector
			double* upy,		// @param the j component of the up vector
			double* upz			// @param the k component of the up vector
			);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetCurrentLookAt | sets the current eyepoint in 
	"look at" form.  

	@desc <f mgSetCurrentLookAt> sets the current eyepoint using "look at"
	style parameters and refreshes the scene.  The "look at" parameters include
	3 sets of values.  
	The first set, <p eyex>, <p eyey>, and <p eyez> is the position of 
	the eye point. 
	The second set, <p centerx>, <p centery>, <p centerz> is the position
	of the reference point.  
	The third set, <p upx>, <p upy>, and <p upz> is the direction of the 
	up vector.

  	@desc This function sets the current eyepoint as derived from an eye
	point, a reference point indicating the center of the scene, and an 
	up vector.  The up vector must not be parallel to the line of sight from 
	the eye to the reference point. 

	@return Returns <e mgbool.MG_TRUE> if the current eyepoint for <p db>
	could be set, <e mgbool.MG_FALSE> otherwise.

	@see <f mgGetCurrentLookAt>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgSetCurrentLookAt (
			mgrec* db,			// @param the database
			double eyex,		// @param the x component of the eyepoint position
			double eyey,		// @param the y component of the eyepoint position
			double eyez,		// @param the z component of the eyepoint position
			double centerx,	// @param the x component of the reference point
			double centery,	// @param the y component of the reference point
			double centerz,	// @param the z component of the reference point
			double upx,			// @param the i component of the up vector
			double upy,			// @param the j component of the up vector
			double upz			// @param the k component of the up vector
			);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

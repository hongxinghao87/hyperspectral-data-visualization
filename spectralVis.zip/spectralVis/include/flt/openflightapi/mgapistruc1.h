/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPISTRUC1_H_
#define MGAPISTRUC1_H_
// @doc EXTERNAL STRUCFUNC
/*----------------------------------------------------------------------------*/

#include "mgapibase.h"
#include "mgapixform.h"
#include "mgapimatrix.h"


#define MWALK_NEXT			0x00000001			// @msg MWALK_NEXT | mgWalk flag Walk Next
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to visit siblings of the top node being walked as well as the
															// children of these siblings.
															// @desc By default, siblings are not visited.
															// @see <m MWALK_VERTEX><nl>
															// <m MWALK_MASTER><nl> <m MWALK_MASTERALL><nl>
															// <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_ON				0x00000002			// @msg MWALK_ON | mgWalk flag Walk On
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to visit only nodes that are currently <m On>.  Nodes are
															// <m Off> if they are not part of the current
															// level of detail or if they have been explicitly
															// "toggled off" by the modeler.
															// @desc By default, all nodes are visited whether
															// they are <m On> or <m Off>.
															// @see <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl>
															// <m MWALK_MASTER><nl> <m MWALK_MASTERALL><nl>
															// <m MWALK_NORDONLY><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_MASTER			0x00000004			// @msg MWALK_MASTER | mgWalk flag Walk Master
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to visit referenced nodes.  If you set this mask without
															// setting <m MWALK_MASTERALL>, referenced nodes will
															// only be visited one time no matter how many times
															// they are referenced in the database.
															// @desc Set <m MWALK_MASTERALL> to visit referenced
															// nodes once each time they are referenced.
															// @desc By default, referenced nodes are not visited.
															// @see <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl>
															// <m MWALK_MASTERALL><nl>
															// <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_NORDONLY		0x00000008			// @msg MWALK_NORDONLY | mgWalk flag Walk No Read Only
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to not visit read-only nodes (external nodes, for example). 
															// @desc By default, read-only nodes are visited. 
															// @see <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl>
															// <m MWALK_MASTER><nl> <m MWALK_MASTERALL><nl>
															// <m MWALK_ON><nl><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_VERTEX			0x00000010			// @msg MWALK_VERTEX | mgWalk flag Walk Vertices
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to visit vertex nodes. 
															// @desc By default, vertex nodes are not visited.
															// @see <m MWALK_NEXT><nl>
															// <m MWALK_MASTER><nl> <m MWALK_MASTERALL><nl>
															// <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_MASTERALL		0x00000020			// @msg MWALK_MASTERALL | mgWalk flag Walk Master All
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to visit referenced nodes once each time they are referenced.
															// @desc By default, referenced nodes are not visited.
															// @see <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl>
															// <m MWALK_MASTER><nl>
															// <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_ATTR			0x00000040			// @msg MWALK_ATTR | mgWalk flag Walk Attributes
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to visit attribute nodes.  
															// @desc By default, attribute nodes are not visited.
															// @desc This flag is not yet implemented.
															// @see <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl>
															// <m MWALK_MASTER><nl> <m MWALK_MASTERALL><nl>
															// <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
															// <m MWALK_MATRIXSTACK>

#define MWALK_MATRIXSTACK	0x00000080			// @msg MWALK_MATRIXSTACK | mgWalk flag Walk Matrix Stack
															// @desc Setting this mask causes <f mgWalk> and <f mgWalkEx>
															// to accumulate a matrix stack while visiting the nodes. 
															// This matrix stack can be accessed during either of the
															// walk actions functions to return the using the function <f mgWalkGetMatrix>.
															// @see <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl>
															// <m MWALK_MASTER><nl> <m MWALK_MASTERALL><nl>
															// <m MWALK_ON><nl> <m MWALK_NORDONLY>


/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

// @cb mgbool | mgwalkfunc | Walk callback function
// @desc This is the signature for walk callback functions.
// When you call <f mgWalk> or <f mgWalkEx>, you can specify a
// pre-visit function and/or a post-visit function of this form. 
// These functions are called before and after a node is visited,
// respectively.
// @return Return <e mgbool.MG_TRUE> to continue traversal, 
// <e mgbool.MG_FALSE> to terminate.
// @see <f mgWalk>  
typedef mgbool	( *mgwalkfunc ) ( 
	mgrec* db,				// @param the database node of the database being walked
	mgrec* parent,			// @param the parent of the node being visited (<m MG_NULL> if <p rec> is <p db>)
	mgrec* rec,				// @param the node currently being visited
	void* userData			// @param user defined data specified in call to <f mgWalk> or <f mgWalkEx>
	);


/*============================================================================*/

/* @func char* | mgRec2Filename | gets the database name from any node of a database
	@desc Given any node in a database, <p rec>, <f mgRec2Filename> returns the 
	database file name.  If a node is not associated with any database, a null string is 
	returned.  The file name returned has a path if it was opened or created in a remote 
	directory.

	@desc Storage for the file name is dynamically allocated by <f mgRec2Filename>.
	The user is responsible for deallocating the dynamically allocated memory with 
	<f mgFree>.

	@desc Note: Forward slashes "/" are used as directory delimiters in the path
	of the file returned.  Also, if the database being queried has not yet been
	saved to disk, the name returned will be a "temporary" name.  You can use the
	function <f mgIsDbUntitled> to check this.

	@return Returns the file name if successful, or <m MG_NULL> if no node is found.	
	@access Level 1
	@see <f mgGetCurrentDb>, <f mgRec2Db>, <f mgIsDbUntitled>
*/
extern MGAPIFUNC(char*) mgRec2Filename (
	mgrec* rec					// @param the node in a database
	);

/*============================================================================*/

/* @func mgbool | mgIsDbUntitled | checks if a database has a valid name
	@desc <f mgIsDbUntitled> determines whether the database <p db> has yet
	been "named".  In Creator, when a user creates a new database, it does not
	have a valid name until it has been saved to disk.

	@desc Prior to being saved, the name of the database (returned by 
	<f mgRec2Filename>) is a "temporary" one and should not be used for
	locating relative textures and external references.  Only after a
	database has been saved to an explicit file will its name be valid.

	@desc Note: This function is only applicable in the Creator modeler environment.
	Since databases in the stand alone application environment are always explicitly
	named, this function will always return <e mgbool.MG_FALSE> when called by a
	stand-alone application.

	@return Returns <e mgbool.MG_TRUE> if the specified database has not yet
	been named, <e mgbool.MG_FALSE> otherwise.

	@access Level 4
	@see <f mgRec2Filename> 
*/

extern MGAPIFUNC(mgbool) mgIsDbUntitled (
	mgrec* db					// @param the database to check
	);

/* @func void | mgSetCurrentDb | sets a database as the current database
	@desc Given a database node, <p db>, <f mgSetCurrentDb> sets 
	this database as the current database.  If the database is a new current
	database, the color palette associated with this database is loaded.

	@desc Note: This function is for use in stand alone applications only, 
	and should never be called from inside a plug-in.  Doing so may yield
	undefined results.

	@access Level 1
	@see <f mgGetCurrentDb>, <f mgRec2Db>
*/
extern MGAPIFUNC(void) mgSetCurrentDb (
	mgrec* db					// @param the database node to make current
	);

/* @func mgrec* | mgGetCurrentDb | gets the current database
	@desc returns the top node of the current database.
	@return top node of the current database, <m MG_NULL> if there is 
	no current database.
	@access Level 1
	@see <f mgSetCurrentDb>, <f mgRec2Db>
*/
extern MGAPIFUNC(mgrec*) mgGetCurrentDb (void);

/* @func mgrec* | mgRec2Db | gets the database node from any node of a database
	@desc <f mgRec2db> returns the database node corresponding to the specified
	node <p rec>.  If the node is not associated with any database, the database 
	node of the current database is returned.
	@return Returns the database node of the database that contains the node.	
	@ex The following example prints a message if a polygon node, <p poly> 
	belongs to the current database. |
   mgrec* curDb;
   mgrec* polyDb;
   curDb = mgGetCurrentDb ();
   polyDb = mgRec2Db ( poly );
   if ( polyDb == curDb )
      printf ( "poly belongs to current database" );
	@access Level 1
	@see <F mgGetCurrentDb>, <f mgRec2Filename>
*/
extern MGAPIFUNC(mgrec*) mgRec2Db ( 
	mgrec* rec			// @param the node to check
	);	

/* @func int | mgCountChild | gets the number of immediate children of a node
	@desc <f mgCountChild> returns the number of children directly below the
	specified node <p rec>.  Descendents of the children are not counted in 
	the total.   
	@return Returns the number of child nodes immediately below the node. 
	@access Level 1 
	@see <f mgGetChildNth>, <f mgCountNestedChild>, <f mgCountAttrChild>
*/
extern MGAPIFUNC(int) mgCountChild ( 
	mgrec* rec			// @param the node to count children
	);	

/* @func int | mgCountNestedChild | gets the number of nested children of a node
	@desc <f mgCountNestedChild> returns the number of nested children directly
	below the specified node <p rec>.  Descendents of the nested children are
	not counted in the total.   
	@return Returns the number of nested child nodes immediately below the node. 
	@access Level 1 
	@see <f mgCountChild>, <f mgCountAttrChild>
*/
extern MGAPIFUNC(int) mgCountNestedChild ( 
	mgrec* rec			// @param the node to count nested children
	);	

/* @func int | mgCountAttrChild | gets the number of attribute children of a node
	@desc <f mgCountAttrChild> returns the number of attribute children directly
	below the specified node <p rec>.  Descendents of the attribute children are
	not counted in the total.   
	@return Returns the number of attribute child nodes immediately below the node. 
	@access Level 1 
	@see <f mgCountChild>, <f mgCountNestedChild>
*/
extern MGAPIFUNC(int) mgCountAttrChild ( 
	mgrec* rec			// @param the node to count attribute children
	);	

/* @func mgrec* | mgGetChildNth | gets the nth child of a node
	@desc <f mgGetChildNth> returns the nth child node of the
	specified node <f parent>.  The first child is indicated by <p nth> is 1. 
	@return Returns the <p nth> child node if it exists, <m MG_NULL> otherwise. 
	@ex |
   mgrec *db, *node, *parent, *child;
   int i;
   db = mgOpenDb ( "file1.flt" );
   node = UserGetNodeRecFunc ( db );
   parent = mgGetParent ( node );
   for ( i = 1 ; child = mgGetChildNth ( parent, i ); i++ ) {
      if ( child == node ) {
         printf ( "node is the %dth child of parent", i+1 );
         return;
      }
   }
   printf ( "node is not a child of parent" );
	@access Level 1 
	@see <f mgCountChild>, <f mgGetChild>, <f mgGetNext>, <f mgGetParent>
*/
extern MGAPIFUNC(mgrec*) mgGetChildNth ( 
		mgrec* parent,			// @param the parent node 
		int nth					// @param which child to return from the list of children 
		);

/* @func mgrec* | mgGetRecByName | finds a node by identifier
	@desc <f mgGetRecByName> searches the specified database <p db>, and locates 
	the node in the database that has identifier <p name>. Each node has a unique
	case-sensitive identifier hence there is a one-to-one correspondence between 
	the identifier <p name> and the node returned. 
	@return Returns the node if found, <m MG_NULL> otherwise. 
	@access Level 1 
	@see <f mgGetName>
*/
extern MGAPIFUNC(mgrec*) mgGetRecByName ( 
	mgrec* db,		// @param the database node
	char* name		// @param the identifier of the node to find 
	);

/* @func mgrec* | mgGetNext | gets the next immediate sibling of a node
	@desc <f mgGetNext> returns the next immediate sibling of the
	specified node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetPrevious>
*/
extern MGAPIFUNC(mgrec*) mgGetNext ( 
	mgrec* rec				// @param the node to get next sibling
	);

/* @func mgrec* | mgGetPrevious | gets the previous immediate sibling of a node
	@desc <f mgGetPrevious> returns the previous immediate sibling of the
	specified node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetNext>
*/
extern MGAPIFUNC(mgrec*) mgGetPrevious (  
	mgrec* rec				// @param the node to get previous sibling
	);

/* @func mgrec* | mgGetParent | gets the parent of a node
	@desc <f mgGetParent> returns the parent of the specified node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetChild>, <f mgGetChildNth>, <f mgGetAttrChild>
*/
extern MGAPIFUNC(mgrec*) mgGetParent (  
	mgrec* rec				// @param the node to get parent for
	);

/* @func mgrec* | mgGetChild | gets the first child of a node
	@desc <f mgGetChild> returns the first child of the specified 
	node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetChildNth>, <f mgGetParent>, <f mgGetAttrChild>
*/
extern MGAPIFUNC(mgrec*) mgGetChild (  
	mgrec* rec				// @param the node to get first child for
	);

/* @func mgrec* | mgGetNestedParent | gets the nested parent of a polygon node
	@desc <f mgGetNestedParent> returns the nested parent of the specified 
	polygon node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetNestedChild>, <f mgGetParent>
*/
extern MGAPIFUNC(mgrec*) mgGetNestedParent (  
	mgrec* rec				// @param the node to get nested parent for
	);

/* @func mgrec* | mgGetNestedChild | gets the nested child of a polygon node
	@desc <f mgGetNestedChild> returns the nested child of the specified 
	polygon node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetNestedParent>, <f mgGetChild>, <f mgGetChildNth>
*/
extern MGAPIFUNC(mgrec*) mgGetNestedChild (  
	mgrec* rec				// @param the node to get nested child for
	);

/* @func mgrec* | mgGetAttrChild | gets the attribute child of a node
	@desc <f mgGetAttrChild> returns the attribute child of the specified 
	node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgGetChild>, <f mgGetChildNth>
*/
extern MGAPIFUNC(mgrec*) mgGetAttrChild (  
	mgrec* rec				// @param the node to get attribute child for
	);

/* @func mgrec* | mgGetReference | finds the reference node for an instance node
	@desc <f mgGetReference> returns the reference node for the specified instance
	node <p rec>.
	@return Returns the node if found, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgIsInstance>
*/
extern MGAPIFUNC(mgrec*) mgGetReference (  
	mgrec* rec				// @param the node to get reference for
	);

/* @func mgrec* | mgGetFirstInstance | gets the first instance node of a reference node
	@desc Instancing is a technique in which one node is a child of several parent nodes. 
	The child is said to be a <m reference> node and each parent node is an <m instance> node
	of the child. A parent node can have either a regular child or a reference child, but
	not both. 
	@desc <f mgGetFirstInstance> returns the first instance node of the specified
	reference node <p ref>.
	@return Returns the first instance node of the reference node, if found.  If <p ref> is not
	a reference node, <m MG_NULL> is returned.
	@ex |
   mgrec* ref;
   mgrec* inst;
   inst = mgGetFirstInstance ( ref );
   while ( inst ) {
      // Do something with inst
      inst = mgGetNextInstance ( inst );
   }
	@access Level 1
	@see <f mgIsFirstInstance>, <f mgGetNextInstance>
*/
extern MGAPIFUNC(mgrec*) mgGetFirstInstance (  
	mgrec* ref				// @param the reference node to get first instance for
	);

/* @func mgrec* | mgGetNextInstance | gets successive instance nodes of a reference node
	@desc <f mgGetNextInstance> returns the instance that follows the specified
	instance node <p inst>.  If node <p inst> is an instance of a reference node, this
	function will return the next instance of that reference node.
	
	@return Returns the instance node if found.  If <p inst> is not
	an instance node, <m MG_NULL> is returned.
	@access Level 1
	@see <f mgIsFirstInstance>, <f mgGetFirstInstance>
*/
extern MGAPIFUNC(mgrec*) mgGetNextInstance ( 
	mgrec* inst				// @param the instance node to get next instance for
	);

/* @func mgbool | mgWalk | walks the database hierarchy and performs an action at each node.
	@desc <f mgWalk> iterates from any node <p noderec> down the hierarchy and visits the
	nodes within the tree using a depth-first search. The types of nodes visited are based
	on traversal modifiers specified in <p flags>.  The descriptions of the individual flags
	specify how each affects traversal.
	
	@desc At each node visited, two user-provided
	functions (<p preaction> and <p postaction>) are invoked to perform necessary tasks.
	The <p preaction> function is invoked before the node�s children are traversed,
	and <p postaction> is invoked after the node�s children have been traversed. As an option, 
	the traversal can be terminated by either the <p preaction> or <p postaction> function
	returning <e mgbool.MG_FALSE>. 
	
	@desc Specifying <m MG_NULL> for either <p preaction> or <p postaction> is valid.

	@return Returns <e mgbool.MG_TRUE> upon successful completion, returns <e mgbool.MG_FALSE>
	if unsuccessful or if terminated by one of the action functions. 

	@access Level 1
	@see <f mgWalkEx>, <f mgWalkGetMatrix>, <f mgGetNext>, <f mgGetPrevious>, 
	<f mgGetParent>, <f mgGetChild>, 
	<f mgGetNestedParent>, <f mgGetNestedChild>, <f mgGetReference>, 
	<f mgGetChildNth>, <f mgGetAttrChild>
*/
extern MGAPIFUNC(mgbool) mgWalk ( 
	mgrec* noderec,				// @param the starting node of the traversal
	mgwalkfunc preaction,		// @param the function that is invoked
										// before any of the node's children have been visited
	mgwalkfunc postaction,		// @param the function that is invoked
										// after all the node's children have been visited
	void* userData,				// @param pointer to user defined data that will be passed to 
										// <p preaction> and <p postaction> callback functions
	int flags						// @param traversal modifiers that allow you to select
										// certain types of nodes for visiting.  
										// This parameter is the bitwise combination of the following masks:<nl> 
										// <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl> <m MWALK_MASTER><nl> 
										// <m MWALK_MASTERALL><nl> <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
										// <m MWALK_MATRIXSTACK>
	);


/* @func mgbool | mgWalkEx | walks the database hierarchy and performs an action at each node.
	@desc <f mgWalkEx> performs the same function as <f mgWalk>, but in addition, it allows you
	to specify a starting matrix, <p startMatrix>, to use when accumulating a matrix stack during
	the traversal.

  	@desc Note: If <p flags> does not specify <m MWALK_MATRIXSTACK>, <p startMatrix> is ignored
	and no matrix stack is accumulated during traversal.

   @desc For a complete description of <f mgWalkEx>, see <f mgWalk>.

	@return Returns <e mgbool.MG_TRUE> upon successful completion, returns <e mgbool.MG_FALSE>
	if unsuccessful or if terminated by one of the action functions. 

	@access Level 1
	@see <f mgWalk>, <f mgWalkGetMatrix>, <f mgGetNext>, <f mgGetPrevious>, 
	<f mgGetParent>, <f mgGetChild>, <f mgGetNestedParent>, <f mgGetNestedChild>,
	<f mgGetReference>, <f mgGetChildNth>, <f mgGetAttrChild>
*/
extern MGAPIFUNC(mgbool) mgWalkEx (
	mgrec* noderec,				// @param the starting node of the traversal
	mgmatrix startMatrix,		// @param the starting matrix to use when accumulating a matrix
										// stack during the traversal - ignored if <m MWALK_MATRIXSTACK>
										// is not specified in <p flags>
	mgwalkfunc preaction,		// @param the function that is invoked
										// before any of the node's children have been visited
	mgwalkfunc postaction,		// @param the function that is invoked
										// after all the node's children have been visited
	void* userData,				// @param pointer to user defined data that will be passed to 
										// <p preaction> and <p postaction> callback functions
	int flags						// @param traversal modifiers that allow you to select
										// certain types of nodes for visiting.  
										// This parameter is the bitwise combination of the following masks:<nl> 
										// <m MWALK_NEXT><nl> <m MWALK_VERTEX><nl> <m MWALK_MASTER><nl> 
										// <m MWALK_MASTERALL><nl> <m MWALK_ON><nl> <m MWALK_NORDONLY><nl>
										// <m MWALK_MATRIXSTACK>
	);

/* @func mgbool | mgWalkGetMatrix | returns the current matrix accumulated so far during
	an <f mgWalk> or <f mgWalkEx> traversal.
	@desc <f mgWalkGetMatrix> calculates and returns the current matrix accumulated 
	during a traversal initiated by either <f mgWalk> or <f mgWalkEx> with flags that include
	<m MWALK_MATRIXSTACK>.
	
	@desc The matrix accumulated is formed by multiplying together all the matrices of the nodes
	contained in the path from the root of the traversal to the current node of the traversal.  
	When you use <f mgWalkEx> to traverse, you can specify the starting or "root" matrix of the
	traversal.

	@desc Note: This function can only be called from within the users preaction or postaction
	callback during <f mgWalk> or <f mgWalkEx>.  If you call this function in any other context,
	or call this function without having specified <m MWALK_MATRIXSTACK> when you called 
	<f mgWalk> or <f mgWalkEx>, it will fail.

	@desc If <f mgWalkGetMatrix> is called during the preaction callback, it includes the matrix
	applied to the current node (if any).  If called during the postaction callback, it does not 
	include the matrix applied to the current node.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the parameter <p matrix> is loaded with the matrix representing
	the cumulative transformations applied to this point during the traversal.

	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <m MWALK_MATRIXSTACK>
*/

extern MGAPIFUNC(mgbool) mgWalkGetMatrix (
	void* userdata,				// @param pointer passed to <f mgWalk> or <f mgWalkEx> identifying
										// the user defined data
	mgmatrix* matrix				// @param the address of a matrix to receive
										// the composite of all transformations accumulated thus
										// far during the traversal
	);
/* @func mgbool | mgHasXform | determines whether a node has a transformation associated with it
	@desc <f mgHasXform> determines whether a node <p rec> has a transformation associated with it.
	@return returns <e mgbool.MG_TRUE> if there is at least one associated transformation,
	<e mgbool.MG_FALSE> otherwise. 
	@access Level 1
	@see <f mgGetXform>, <f mgGetXformType>
*/
extern MGAPIFUNC(mgbool) mgHasXform ( 
	mgrec* rec						// @param the node to check for transformations
	);

/* @func mgrec* | mgGetXform | gets the first transformation of a node.
	@desc <f mgGetXform> returns the first transformation of the specified 
	node <p rec>.  To get successive transformations of a node, use <f mgGetNext>.
	@return Returns the first transformation node if found, <m MG_NULL> otherwise
	@ex The following example traverses each transformation associated to 
	node <p rec> |
   mgrec* xForm;
   mgxfllcode xType;
   if ( mgHasXform ( rec ) )
   {
      xForm = mgGetXform ( rec );
      while ( xForm )
      {
         // Do something with xForm
         xType = mgGetXformType ( xForm );
         xForm = mgGetNext ( xForm );
      }
   }
	@access Level 1
	@see <f mgGetXform>, <f mgGetXformType>, <f mgGetNext>
*/
extern MGAPIFUNC(mgrec*) mgGetXform ( 
	mgrec* rec					// @param the node to get first transformation for
	);


/* @func mgxfllcode | mgGetXformType | determines the type of a transformation node
	@desc <f mgGetXformType> determines the type of the specified transformation node,
	<p rec>.  The returned transformation type will be one of the following: 
	<e mgxfllcode.MXLL_TRANSLATE>, <e mgxfllcode.MXLL_SCALE>, <e mgxfllcode.MXLL_ROTEDGE>,
	<e mgxfllcode.MXLL_ROTPT>, <e mgxfllcode.MXLL_PUT>, <e mgxfllcode.MXLL_TOPOINT>, 
	<e mgxfllcode.MXLL_GENERAL>
	@return Returns the type of the transformation node.
	@ex The following example examines the first transformation (and its type) 
	associated to node <p rec> |
   mgrec* xForm;
   mgxfllcode xType;
   if ( mgHasXform ( rec ) ) 
   {
      xForm = mgGetXform ( rec );
      xType = mgGetXformType ( xForm );
   }
	@access Level 1
	@see <f mgHasXform>, <t mgxfllcode>
*/
extern MGAPIFUNC(mgxfllcode) mgGetXformType ( 
	mgrec* rec				// @param the transformation node
	);

/* @func mgrec* | mgGetMorphVertex | gets the morph vertex for a given vertex.
	@desc <f mgGetMorphVertex> returns the morph vertex node corresponding to 
	the specified vertex node <p rec>.
	@return the morph vertex of <p rec> if it has one, <m MG_NULL> otherwise.
	@access Level 1
	@see <f mgWalk>, <f mgWalkEx>, <f mgAttach>
*/
extern MGAPIFUNC(mgrec*) mgGetMorphVertex (
	mgrec* rec				// @param the vertex node
	);

/* @func mgbool | mgMoreDetail | changes a database�s Level of Detail (LOD) to the next higher level. 
	@desc <f mgMoreDetail> sorts the switch-in distances from the LOD records in database node <p db>, 
	retrieves the database�s current switch-in distance, changes the current switch-in value to the 
	next lower distance (the next higher LOD), and unsets the on flag for each of the LOD records� 
	children, except for ones with the new current switch-in distance. Subsequent calls change the 
	current switch-in value further, and set the LOD records� on flags. The return value is <e mgbool.MG_FALSE> 
	if there is no higher Level of Detail. If the database does not have any LOD records, the first 
	call to <f mgMoreDetail> returns <e mgbool.MG_TRUE>, while subsequent calls return <e mgbool.MG_FALSE>
	@return <e mgbool.MG_TRUE> upon successful completion, <e mgbool.MG_FALSE> if there is no higher level 
	of detail.
	@ex |
   mgLeastDetail ( db );
   while ( mgMoreDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
   mgMostDetail ( db ); // should already be at most LOD
   while (mgLessDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
	@access Level 1
	@see <f mgLeastDetail>, <f mgLessDetail>, <f mgMostDetail>, <f mgWalk>, <f mgWalkEx> 
*/
extern MGAPIFUNC(mgbool) mgMoreDetail ( 
	mgrec* db			// @param the database node
	);

/* @func mgbool | mgLessDetail | changes a database's Level of Detail (LOD) to the next lower level
	@desc <f mgLessDetail> sorts the switch-in distances from all LOD records in database <p db>, retrieves 
	the database�s current switch-in distance, changes the current switch-in value to the next 
	higher distance (the next lower LOD), and unsets the on flag for each of the LOD records� 
	children, except for ones with the new current switch-in distance. Subsequent calls change the current 
	switch-in value further and set the LOD records� on flags. The return value is <e mgbool.MG_FALSE> if 
	there is no lower level of detail. If the database has does not have any LOD records, the first 
	call to <f mgLessDetail> returns <e mgbool.MG_TRUE>, while subsequent calls return <e mgbool.MG_FALSE>.
	@return Returns <e mgbool.MG_TRUE> upon successful completion, and returns <e mgbool.MG_FALSE> if there is no lower level of detail.
	@ex |
   mgLeastDetail ( db );
   while ( mgMoreDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
   mgMostDetail ( db ); // should already be at most LOD
   while (mgLessDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
	@access Level 1
	@see <f mgLeastDetail>, <f mgMoreDetail>, <f mgMostDetail>, <f mgWalk>, <f mgWalkEx>
*/
extern MGAPIFUNC(mgbool) mgLessDetail ( 
	mgrec* db			// @param the database node
	);

/* @func mgbool | mgMostDetail | changes a database�s Level of Detail (LOD) to the highest level.
	@desc <f mgMostDetail> sorts the switch-in distances from all LOD records in database node <p db>,
	changes the current switch-in value to the lowest distance (the highest LOD), and unsets the 
	on flag for each of the LOD records� children, except for ones with the lowest switch-in 
	distance.  If there are no LOD records or if there is only one LOD record in the database, 
	<f mgMostDetail> does nothing and returns <e mgbool.MG_TRUE>, since the database is already at 
	the most detail.
	@return <e mgbool.MG_TRUE> upon successful completion, <e mgbool.MG_FALSE> if there is no 
	lower level of detail.
	@ex |
   mgLeastDetail ( db );
   while ( mgMoreDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
   mgMostDetail ( db ); // should already be at most LOD
   while (mgLessDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
	@access Level 1
	@see <f mgLeastDetail>, <f mgMoreDetail>, <f mgLessDetail>, <f mgWalk>, <f mgWalkEx>
*/
extern MGAPIFUNC(mgbool) mgMostDetail ( 
	mgrec* db			// @param the database node
	);

/* @func mgbool | mgLeastDetail | changes a database's Level of Detail (LOD) to the lowest level
	@desc <f mgLeastDetail> sorts the switch-in distances from all LOD records in database node <p db>, 
	changes the current switch-in value to the highest distance (the lowest LOD), and unsets the 
	on flag for each of the LOD records� children, except for ones with the highest switch-in 
	distance. If the database does not have any LOD records, or if there is only one LOD record, 
	<f mgLeastDetail> does nothing and returns <e mgbool.MG_TRUE>, since the database is already at 
	the least detail.
	@return Returns <e mgbool.MG_TRUE> upon successful completion, <e mgbool.MG_FALSE> otherwise.
	@ex |
   mgLeastDetail ( db );
   while ( mgMoreDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
   mgMostDetail ( db ); // should already be at most LOD
   while ( mgLessDetail ( db ) )
      mgWalk ( db, UserPrintNodeNameFunc, MG_NULL, MG_NULL, MWALK_ON );
	@access Level 1
	@see <f mgLessDetail>, <f mgMoreDetail>, <f mgMostDetail>, <f mgWalk>, <f mgWalkEx>
*/
extern MGAPIFUNC(mgbool) mgLeastDetail ( 
	mgrec* db			// @param the database node
	);

/* @func mgbool | mgIsReference | determines if a node is a reference node
	@desc <f mgIsReference> determines if a node <p rec> is a reference node. 
	A reference node is one that is referenced by other nodes.
	@return Returns <e mgbool.MG_TRUE> if the node is a reference, <e mgbool.MG_FALSE> otherwise.
	@access Level 2
	@see <f mgGetReference>, <f mgReference>, <f mgDeReference>, <f mgIsInstance>, 
	<f mgIsFirstInstance>, <f mgGetFirstInstance>, <f mgGetNextInstance>
*/
extern MGAPIFUNC(mgbool) mgIsReference ( 
	mgrec* rec			// @param the node in question
	);

/* @func mgbool | mgIsInstance | determines if a node is an instance node
	@desc <f mgIsInstance> determines if the node <p rec> is one of the instance nodes
	of a reference node.
	@return Returns <e mgbool.MG_TRUE> if the node is an instance, <e mgbool.MG_FALSE> otherwise.
	@access Level 1
	@see <f mgGetReference>, <f mgReference>, <f mgDeReference>, <f mgIsReference>, 
	<f mgIsFirstInstance>, <f mgGetFirstInstance>, <f mgGetNextInstance>
*/
extern MGAPIFUNC(mgbool) mgIsInstance ( 
	mgrec* rec			// @param the node in question
	);

/* @func mgbool | mgIsFirstInstance | determines if a node is the first instance of 
	its referenced node
	@desc <f mgIsFirstInstance> determines if a node <p rec> is the 
	first instance node of its reference node.  This routine is useful when used
	with <f mgGetFirstInstance> and <f mgGetNextInstance> to visit all instances
	of a node, or when used by itself to visit only the first instance.
	@return Returns <e mgbool.MG_TRUE> if <p rec> is the first instance of its referenced node, 
	<e mgbool.MG_FALSE> otherwise.
	@access Level 1
	@see <f mgReference>, <f mgDeReference>, <f mgGetFirstInstance>, 
	<f mgGetNextInstance>
*/
extern MGAPIFUNC(mgbool) mgIsFirstInstance ( 
	mgrec* rec			// @param an instance node
	);

/* @func mgbool | mgIsFlagOn | determines if a node is <p On>
	@desc <f mgIsFlagOn> determines if the node <p rec> is <p On>.
	Nodes are turned <p On> and <p Off> to distinguish between
	different levels of detail.  Nodes belonging to the current
	level of detail are, by default, <p On>. Additionally, nodes can be 
	explicitly toggled <p On> and <p Off> by the modeler using the 
	<m Toggle Display> command.
	@return Returns <e mgbool.MG_TRUE> if the node is <p On>,
	<e mgbool.MG_FALSE> otherwise.
	@access Level 1
	@see <f mgMoreDetail>, <f mgLessDetail>, <f mgMostDetail>, 
	<f mgLeastDetail>, <f mgWalk>, <f mgWalkEx>
*/
extern MGAPIFUNC(mgbool) mgIsFlagOn ( 
	mgrec* rec			// @param the node to check
	);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

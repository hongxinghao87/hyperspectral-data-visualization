/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIMATERIAL2_H_
#define MGAPIMATERIAL2_H_
/* @doc EXTERNAL MATERIALFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgNewMaterial | allocates a new record for an entry 
	into a database�s material palette.
	@desc Given a database node <p db> and a material entry name <p name>, 
	<f mgNewMaterial> allocates a record containing a new material palette 
	entry, adds it to the database�s material palette, and returns the record.  
	The index of the new material entry is returned in <p index>.  
	The material properties can be set by using <f mgSetAttList> with 
	the returned material record.  

	@return Returns the index of the new material palette entry record. 

	@access Level 2
	@see <f mgDeleteMaterial>
*/
extern MGAPIFUNC(mgrec*) mgNewMaterial (
		mgrec* db,			// @param the database node
		char* name,			// @param the name of the new material 
								// (may be <e mgbool.MG_NULL> )
		int* index			// @param pointer to receive the index assigned to the 
								// new material palette entry record
		); 
   
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgWriteMaterialFile | writes a database�s material 
	palette as a disk file
	@desc Given a database node, <p db>, <f mgWriteMaterialFile> 
	writes the database�s material palette to disk with the file  
	name <p fileName>.  

	@return Returns <e mgbool.MG_TRUE> if the material palette file was 
	written successfully, otherwise <e mgbool.MG_FALSE>. 

	@see <f mgReadMaterialFile>

	@access Level 2
*/
extern MGAPIFUNC(mgbool) mgWriteMaterialFile (
		mgrec* db,			// @param the database node that contains the material 
								// palette to write
		char* fileName		// @param the material palette file name
		);
 
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgDeleteMaterial | deletes an entry, defined by the 
	material�s index, from a database�s material palette.

	@desc <f mgDeleteMaterial> deletes the entry defined by the material�s 
	index, <p index>, from the material palette associated with database 
	node <p db>. If no material entry is found matching <p index>, the material 
	palette remains unchanged.  

	@return Returns <e mgbool.MG_TRUE> if material entry was deleted
	successfully, otherwise <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgDeleteMaterialByName>, <f mgIndexOfMaterial>
*/
extern MGAPIFUNC(mgbool) mgDeleteMaterial (
		mgrec* db,			// @param the database node
		int index			// @param the index of material to delete
		); 
/* @deprecated mgDelMaterial | Use <f mgDeleteMaterial> */

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgDeleteMaterialByName | deletes a material entry from a 
	database�s material palette.
	@desc <f mgDeleteMaterialByName> deletes the material entry defined 
	by <p name> from the material palette associated with database 
	node <p db>. If no material entry is found matching <p name>, the 
	material palette remains unchanged.

	@return Returns <e mgbool.MG_TRUE> if material entry was deleted
	successfully, otherwise <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgDeleteMaterial>, <f mgNameOfMaterial>
*/
extern MGAPIFUNC(mgbool) mgDeleteMaterialByName (															 
		mgrec* db,			// @param the database node
		char* name			// @param the name of the material to delete
		);
/* @deprecated mgDelMaterialByName | Use <f mgDeleteMaterialByName> */

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

#pragma once
#ifndef MGAPISTD_H_
#define MGAPISTD_H_

/* @doc EXTERNAL BASEFUNC*/

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

/*============================================================================*\
	public constants
\*============================================================================*/

/* @contents1:(MAIN) API Version | 2.6.0 */
/* @msg MVERSION_API | API Version number */
#define MVERSION_API				"2.6.0"

#define MVERSION_TOOLS			"2.6"

/* @contents1:(MAIN) OpenFlight Format Version | 1580 */
/* @msg MVERSION_OPENFLIGHT | OpenFlight Format Version number */
#define MVERSION_OPENFLIGHT	"1580"

/* @type mgstatus | return value used by certain API functions
	@desc The return value must be checked for success using the macro <f MSTAT_ISOK>
	or tested for equality with <m MSTAT_OK>. 
*/
typedef int							mgstatus;

/* @msg MSTAT_OK | denotes a successful return value for return values of type <t mgstatus>
	@see <f MSTAT_ISOK>
*/
#define MSTAT_OK					0x00000000

/* @macro int | MSTAT_ISOK | checks return value for success
	@desc If an API function returns a value of type <t mgstatus>, you should use
	this macro to check return value for success.
	@param | status | the return value
	@return 1 if success; 0, otherwise
*/
#define MSTAT_ISOK(status)		((status)==MSTAT_OK)

// @msg MG_NULL | Same as NULL
#define MG_NULL		0
#define mgNULL			MG_NULL		/* @deprecated mgNULL | Use <m MG_NULL> */

// @enumtype mgbool | mgbool | A simple true or false data type
typedef enum mgbool {
	MG_FALSE = 0,	// @emem Represents the boolean value false
	MG_TRUE = 1		// @emem Represents the boolean value true
} mgbool;

#define mgFALSE		MG_FALSE		/* @deprecated mgFALSE | Use <e mgbool.MG_FALSE> */
#define mgTRUE			MG_TRUE		/* @deprecated mgTRUE  | Use <e mgbool.MG_TRUE>  */

// @enumtype tagtype | mgtagtype | Tag Types
typedef enum tagtype {
	MTYPE_NULL   = 0,       /* @emem undefined */
	MTYPE_CHAR   = 1,       /* @emem signed character */
	MTYPE_UCHAR  = 2,       /* @emem unsigned character */
	MTYPE_SHORT  = 3,       /* @emem signed short */
	MTYPE_USHORT = 4,       /* @emem unsigned short */
	MTYPE_INT    = 5,       /* @emem signed int */
	MTYPE_UINT   = 6,       /* @emem unsigned int */
	MTYPE_FLOAT  = 7,       /* @emem float */
	MTYPE_DOUBLE = 8,       /* @emem double */
	MTYPE_FLAG   = 9,       /* @emem flag */
	MTYPE_ENUM   = 10,      /* @emem bit integer */
	MTYPE_TEXT   = 11,      /* @emem text string */
	MTYPE_ROOT   = 12,      /* @emem db header */
	MTYPE_BEAD   = 13,      /* @emem has ifmt bead */
	MTYPE_REC    = 14,      /* @emem generic record */
	MTYPE_DATA   = 15,      /* @emem data buffer */
	MTYPE_XFORM  = 16       /* @emem: (INTERNAL) xformll record (MultiGen internal) */
} mgtagtype;		

typedef mgtagtype tagtype;							/* @deprecated tagtype | Use <t mgtagtype> */

#define mgtype_null			MTYPE_NULL			/* @deprecated mgtype_null  | Use <e mgtagtype.MTYPE_NULL>   */
#define mgtype_cval			MTYPE_CHAR			/* @deprecated mgtype_cval  | Use <e mgtagtype.MTYPE_CHAR>   */
#define mgtype_ucval			MTYPE_UCHAR			/* @deprecated mgtype_ucval | Use <e mgtagtype.MTYPE_UCHAR>  */
#define mgtype_sval			MTYPE_SHORT			/* @deprecated mgtype_sval  | Use <e mgtagtype.MTYPE_SHORT>  */
#define mgtype_usval			MTYPE_USHORT		/* @deprecated mgtype_usval | Use <e mgtagtype.MTYPE_USHORT> */
#define mgtype_ival			MTYPE_INT			/* @deprecated mgtype_ival  | Use <e mgtagtype.MTYPE_INT>    */
#define mgtype_uival			MTYPE_UINT			/* @deprecated mgtype_uival | Use <e mgtagtype.MTYPE_UINT>   */
#define mgtype_fval			MTYPE_FLOAT			/* @deprecated mgtype_fval  | Use <e mgtagtype.MTYPE_FLOAT>  */
#define mgtype_dval			MTYPE_DOUBLE		/* @deprecated mgtype_dval  | Use <e mgtagtype.MTYPE_DOUBLE> */
#define mgtype_flag			MTYPE_FLAG			/* @deprecated mgtype_flag  | Use <e mgtagtype.MTYPE_FLAG>   */
#define mgtype_enum			MTYPE_ENUM			/* @deprecated mgtype_enum  | Use <e mgtagtype.MTYPE_ENUM>   */
#define mgtype_text			MTYPE_TEXT			/* @deprecated mgtype_text  | Use <e mgtagtype.MTYPE_TEXT>   */
#define mgtype_root			MTYPE_ROOT			/* @deprecated mgtype_root  | Use <e mgtagtype.MTYPE_ROOT>   */
#define mgtype_bead			MTYPE_BEAD			/* @deprecated mgtype_bead  | Use <e mgtagtype.MTYPE_BEAD>   */
#define mgtype_rec			MTYPE_REC			/* @deprecated mgtype_rec   | Use <e mgtagtype.MTYPE_REC>    */
#define mgtype_data			MTYPE_DATA			/* @deprecated mgtype_data  | Use <e mgtagtype.MTYPE_DATA>   */
#define mgtype_xfm			MTYPE_XFORM			/* @deprecated: (INTERNAL) mgtype_xfm   | Use <e mgtagtype.MTTYPE_XFORM> */

/*============================================================================*\
	private types
\*============================================================================*/

// @type mgrec | Generic type used to access any type of record accessible by the API
// @desc API users do not need to manipulate the internal fields of this structure directly; 
// simply pass the structure into API functions instead.  Variables of type <t mgrec> are referred to as records.
typedef struct mgrec mgrec;

/*============================================================================*\
	public types
\*============================================================================*/

// @type mgcode | An integer code used to specify a record's type
// @desc Each record type has a unique <t mgcode>
typedef int mgcode;	

/*============================================================================*\
	public methods
\*============================================================================*/

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPISTD_H */
/* DON'T ADD STUFF AFTER THIS #endif */

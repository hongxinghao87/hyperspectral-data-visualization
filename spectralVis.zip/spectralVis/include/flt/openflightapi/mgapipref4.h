/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIPREF4_H_
#define MGAPIPREF4_H_

/* @doc EXTERNAL PREFFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapibase.h"
						
/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

#define MPREFD_MATCHVERTEXTOLERANCE			"KER:MatchTolerance"	
// @msg MPREFD_MATCHVERTEXTOLERANCE | Modeling Preference Key <p Match Vertex Tolerance>
// @desc This key specifies the Creator Modeling Preference "Match Vertex Tolerance".
// See the Creator User's Guide for a description of this value.
// @see <f mgModelingPrefGetDouble>
															 															 
#define MPREFD_COPLANARTOLERANCE				"KER:CoplanTolerance"	
// @msg MPREFD_COPLANARTOLERANCE | Modeling Preference Key <p Coplanar Tolerance>
// @desc This key specifies the Creator Modeling Preference "Coplanar Tolerance".
// See the Creator User's Guide for a description of this value.
// @see <f mgModelingPrefGetDouble>

#define MPREFD_COALIGNEDVERTEXTOLERANCE	"KER:CoalignVtxTolerance"
// @msg MPREFD_COALIGNEDVERTEXTOLERANCE | Modeling Preference Key <p Coaligned Vertex Tolerance>
// @desc This key specifies the Creator Modeling Preference "Coaligned Vertex Tolerance".
// See the Creator User's Guide for a description of this value.
// @see <f mgModelingPrefGetDouble>
															 															 
#define MPREFI_AUTOAPPLYMATERIAL				"KER:AutoApplyMat"	
// @msg MPREFI_AUTOAPPLYMATERIAL | Modeling Preference Key <p Auto Apply Material>
// @desc This key specifies the Creator Modeling Preference "Auto Apply Material".
// See the Creator User's Guide for a description of this value.
// @see <f mgModelingPrefGetInteger>

#define MPREFI_AUTOAPPLYALTCOLOR				"KER:AutoApplyAltColor"	
// @msg MPREFI_AUTOAPPLYALTCOLOR | Modeling Preference Key <p Auto Apply Alternate Color>
// @desc This key specifies the Creator Modeling Preference "Auto Apply Alternate Color".
// See the Creator User's Guide for a description of this value.
// @see <f mgModelingPrefGetInteger>

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgModelingPrefGetInteger | gets an integer preference
	value from the modeling preferences.
	@desc <f mgModelingPrefGetInteger> retrieves an integer value from a 
	named preference key, <p prefName>, and stores it in <p prefValue>.
	If the key <p prefName> does not exist, the value specified by
	<p defaultValue> is used. 

   @desc Currently only a small subset of the modeling preference values
	are accessible.  They are: <nl>
	<m MPREFD_MATCHVERTEXTOLERANCE><nl>
	<m MPREFD_COPLANARTOLERANCE><nl>
	<m MPREFD_COALIGNEDVERTEXTOLERANCE><nl>
	<m MPREFI_AUTOAPPLYMATERIAL><nl>
	<m MPREFI_AUTOAPPLYALTCOLOR>

	@desc Note that the prefix of the key, either <m MPREFD> or <m MPREFI>,
	indicates whether the corresponding preference value is double or integer,
	respectively.
	
	@return Returns <e mgbool.MG_TRUE> if the key <p prefName> represents a 
	valid modeling preference and the value can be represented by an integer
	value, <e mgbool.MG_FALSE> otherwise.  If successful, the parameter
	<p prefValue> will contain	the preference value, otherwise it will contain
	<p defaultValue>.

	@access Level 4
	@see <f mgModelingPrefGetDouble>
*/
extern MGAPIFUNC(mgbool) mgModelingPrefGetInteger (
		const char* prefName,		// @param the preference key name 
		int* prefValue,			  	// @param storage location for the preference value
		int defaultValue				// @param default value returned if <p prefValue>
											// not found
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgModelingPrefGetDouble | gets a double preference
	value from the modeling preferences.
	@desc <f mgModelingPrefGetDouble> retrieves a double value from a 
	named preference key, <p prefName>, and stores it in <p prefValue>.
	If the key <p prefName> does not exist, the value specified by
	<p defaultValue> is used. 
	
   @desc Currently only a small subset of the modeling preference values
	are accessible.  They are: <nl>
	<m MPREFD_MATCHVERTEXTOLERANCE><nl>
	<m MPREFD_COPLANARTOLERANCE><nl>
	<m MPREFD_COALIGNEDVERTEXTOLERANCE><nl>
	<m MPREFI_AUTOAPPLYMATERIAL><nl>
	<m MPREFI_AUTOAPPLYALTCOLOR>

	@desc Note that the prefix of the key, either <m MPREFD> or <m MPREFI>,
	indicates whether the corresponding preference value is double or integer,
	respectively.
	
	@return Returns <e mgbool.MG_TRUE> if the key <p prefName> represents a 
	valid modeling preference and the value can be represented by a double
	value, <e mgbool.MG_FALSE> otherwise.  If successful, the parameter
	<p prefValue> will contain	the preference value, otherwise it will contain
	<p defaultValue>.

	@access Level 4
	@see <f mgModelingPrefGetInteger>
*/
extern MGAPIFUNC(mgbool) mgModelingPrefGetDouble (
		const char* prefName,		// @param the preference key name 
		double* prefValue,			// @param storage location for the preference value
		double defaultValue			// @param default value returned if <p prefValue>
											// not found
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */



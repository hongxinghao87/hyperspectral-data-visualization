/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPITXTRMAP1_H_
#define MGAPITXTRMAP1_H_
// @doc EXTERNAL TXTRMAPFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/


/*============================================================================*/


/*----------------------------------------------------------------------------*\
	Get Texture Mapping Info
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec * | mgGetTextureMapping | gets an entry record from a 
	database�s texture mapping palette.
	@desc <f mgGetTextureMapping> gets the texture mapping entry record
	defined by <p index> from the texture mapping palette of database
	node <p db>.   

	@return  Returns the texture mapping entry record if found,  
	otherwise <m MG_NULL>. 

	@access Level 1
	@see <f mgIndexOfTextureMapping>, <f mgNewTextureMapping>
*/
extern MGAPIFUNC(mgrec *) mgGetTextureMapping ( 
		mgrec* db,		// @param the database node
		int index		// @param the texture mapping palette index
		);

/*============================================================================*/
/*                                                                            */
/* @func int | mgIndexOfTextureMapping | gets the index of a named 
	texture mapping palette entry.
	@desc <p mgIndexOfTextureMapping> returns the index of the texture mapping
	palette entry record named <p name> in the texture mapping table of database
	node <p db>.  

	@return  Returns the index of the named texture mapping palette entry, 
	or -1 if no entry is found. 

	@access Level 1
	@see <f mgGetTextureMapping>, <f mgNewTextureMapping>
*/
extern MGAPIFUNC(int) mgIndexOfTextureMapping (
		mgrec* db,		// @param the database node
		char* name		// @param the name of the texture mapping entry to search for
		);
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgGetTextureMappingCount | gets the number of entries in a 
	database�s texture mapping palette.
	@desc Given a database node, <p db>, <f mgGetTextureMappingCount> gets
	the number of entries in the database�s texture mapping palette.

	@param mgrec * | db | the database node

	@return Returns the number of entries in the database�s texture
	mapping palette. 

	@access Level 1
	@see <f mgGetFirstTextureMapping>, <f mgGetNextTextureMapping>
*/
extern MGAPIFUNC(int) mgGetTextureMappingCount (
		mgrec* db		// @param the database node
		);

/*============================================================================*/
/*                                                                            */
/*	@func char* | mgGetTextureMappingName | gets the name of a texture mapping.

	@desc Given a database node <p db>, and an index into the database�s 
	texture mapping palette, <p index>, <f mgGetTextureMappingName> returns 
	a copy of the name of the texture mapping defined by <p index>.  
	The name string is allocated dynamically by <f mgGetTextureMappingName> 
	and it is the user�s responsibility to deallocate the memory with <f mgFree>.  

	@return Returns a copy of the mapping name if a mapping is found and 
	the mapping has a name; <m MG_NULL> otherwise.

	@access Level 1
	@see <f mgGetTextureMappingType>
*/
extern MGAPIFUNC(char*) mgGetTextureMappingName (
	mgrec* db,			// @param the database node
	int index			// @param the index of the texture mapping entry
	);

/*============================================================================*/
/*                                                                            */
/*	@func int | mgGetTextureMappingType | gets the type of a texture mapping.

	@desc Given a database node, <p db>, and an index into the database�s 
	texture mapping palette, <f mgGetTextureMappingType> gets the texture 
	mapping type of the mapping defined by <p index>.  The possible types are:
	@indent	0 = Error <nl>
	1 = 3 point put <nl>
	2 = 4 point put <nl>
	4 = Spherical project <nl>
	5 = Radial project <nl>
	6 = Environment <nl>

	@return  Returns the mapping type if a texture is found; otherwise returns 0.

	@access Level 1
	@see <f mgGetTextureMappingName>
*/
extern MGAPIFUNC(int) mgGetTextureMappingType (
	mgrec* db,			// @param the database node
	int index			// @param the index of the mapping
	);

/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgGetTextureMappingMatrix | gets the matrix of a 3-point put 
	or 4-point put texture mapping.

	@desc <f mgGetTextureMappingMatrix> gets the mapping defined by <p index>, 
	and puts the mapping�s matrix into <p matrix>. The result is suitable for 
	use with OpenGL�s <f glTexGen> function linear mappings.  The matrix is 
	only valid for 3-point put and 4-point put mappings.

	@return  Returns <e mgbool.MG_TRUE> if a valid matrix is found, 
	<e mgbool.MG_FALSE> otherwise.

	@ex | 
   int index;
   mgrec* db;
   mgmatrix matrix;
   if ((mgGetTextureMappingType ( db, index ) == 1 ) ||
       (mgGetTextureMappingType ( db, index ) == 2 ))
   {
      if( mgGetTextureMappingMatrix ( db, index, matrix ) )
      {
         // Do Stuff
      }
   }

	@access Level 1
	@see <f mgGetTextureMappingName>
*/
extern MGAPIFUNC(mgbool) mgGetTextureMappingMatrix (
	mgrec* db,									// @param the database node
	int index,									// @param the index of the mapping
	mgmatrix* textureMappingMatrix		// @param the matrix of the 3-point 
													// put or 4-point put texture mapping.
	);


/*----------------------------------------------------------------------------*\
	Texture Mapping Palette Query
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgIsTextureMappingInPalette |   determines if a texture 
	mapping is in a database�s palette.

	@desc Given a database node, <p db>, and an index into the database�s 
	texture mapping palette, <p index>, <f mgIsTextureMappingInPalette> 
	reports when a mapping with the given index is in the database�s texture 
	mapping palette.

	@ex |
   int index;
   mgrec* db;
   if ( mgIsTextureMappingInPalette ( db, index ) )
   {
      // Do Stuff
   }

	@access Level 1
	@see <f mgGetFirstTextureMapping>, <f mgGetNextTextureMapping>
*/
extern MGAPIFUNC(mgbool) mgIsTextureMappingInPalette (
	mgrec* db,			// @param the database node
	int index			// @param the index of the mapping
	);


/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgGetFirstTextureMapping |   gets the first texture 
	mapping in a database�s palette.

	@desc <f mgGetFirstTextureMapping> gets the index and name of the first 
	texture mapping in a database�s palette

   @ex This example traverses each texture mapping for database <p db> |
   int index;
   char name [ 200 ];
   mgbool gotOne;

   gotOne = mgGetFirstTextureMapping ( db, &index, name );
   while ( gotOne ) {
      // Do something with the texture mapping
      gotOne = mgGetNextTextureMapping ( db, &index, name );
   }

	@access Level 1
	@see <f mgGetTextureMappingName>
*/
extern MGAPIFUNC(mgbool) mgGetFirstTextureMapping (
	mgrec* db,							// @param the database node
	int* index,							// @param pointer to the index of the first texture mapping
	char* textureMappingName		// @param the name of the first texture mapping
	);


/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgGetNextTextureMapping |   gets the next texture 
	mapping in a database�s palette.

	@desc <f mgGetNextTextureMapping> gets the index and name of the first 
	texture mapping in a database�s palette

	@ex |
   int index;
   mgrec* db;
   char name [ 200 ];
   if ( mgGetFirstTextureMapping ( db, &index, name ) ) {
      while ( mgGetNextTextureMapping ( db, &index, name ) ) {
         // Do something
      }
   }

	@access Level 1
	@see <f mgGetTextureMappingName>
*/
extern MGAPIFUNC(mgbool) mgGetNextTextureMapping (
	mgrec* db,							// @param the database node
	int* index,							// @param pointer to the index of the next texture mapping
	char* textureMappingName		// @param the name of the next texture mapping
	);


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadTextureMappingFile | reads in a texture mapping file
	as  a database�s current texture mapping palette.
	@desc Given a database node, <p db>, and a texture mapping file <p fileName>,
	<f mgReadTextureMappingFile> reads the texture mapping entries contained in
	the file and replaces the database's texture mapping palette with those
	entries read.

	@desc Existing texture mapping records all become invalid.

	@return Returns <e mgbool.MG_TRUE> if the texture mapping palette file was 
	read successfully, otherwise <e mgbool.MG_FALSE>. 

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgReadTextureMappingFile ( 
			mgrec* db,			// @param the database node
			char* fileName		// @param the texture mapping file name
			);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

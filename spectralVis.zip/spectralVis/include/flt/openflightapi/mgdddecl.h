/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

#ifndef MGDDDECL_H_
#define MGDDDECL_H_

#ifdef _Ix86

#ifdef DD
#define DDFUNC(retype)		_declspec(dllexport) retype
#else
#define DDFUNC(retype)		retype
#endif

#else

#define DDFUNC(retype)		retype

#endif	/* _WIN32 */

#endif
/*eof*/

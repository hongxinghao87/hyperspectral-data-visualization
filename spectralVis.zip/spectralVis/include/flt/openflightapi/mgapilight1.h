/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPILIGHT1_H_
#define MGAPILIGHT1_H_
// @doc EXTERNAL LIGHTSOURCEFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetLightSource | gets an entry record from a 
	database�s light source palette
	@desc <f mgGetLightSource> gets light source entry record defined 
	by <p index> from the light source palette of <p db>. The record is 
	returned.  If the requested light source does not exist, 
	<m MG_NULL> is returned.

	@param mgrec* | db | the database node. 
	@param int | index | the palette index of the requested light 
	source palette entry. 

	@return  Returns the light source palette entry record, <m MG_NULL>
	if unsuccessful.

	@ex The following example gets the type of the light source
	palette element at index 5 in the light source palette. |
   int lighttype;
	mgrec* db;
   mgrec* ltsrec;
   db = mgOpenDb ( "anyfile.flt" );
   if ( ltsrec = mgGetLightSource ( db, 5 ) ) {
      mgGetAttList ( ltsrec, fltLtspType, &lighttype, MG_NULL );
   }

	@access Level 1
	@see <f mgGetLightSourceCount>, <f mgGetFirstLightSource>, 
	<f mgGetNextLightSource>

*/
extern MGAPIFUNC(mgrec*) mgGetLightSource ( mgrec* db, int index );
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgIndexOfLightSource | gets the index of a named light 
	source palette entry
	@desc <f mgIndexOfLightSource> returns the index of the light source 
	entry record named <p name> in the light source palette of  <p db>. 
	If the named light source is not found, -1 is returned. 

	@param mgrec* | db | the database node
	@param char* | name | the name of the light source entry for which 
	to search

	@return   Returns the index of the named light source palette entry 
	or -1 if no entry is found.

	@access Level 1
	@see <f mgGetLightSource>, <f mgNameOfLightSource>

*/
extern MGAPIFUNC(int) mgIndexOfLightSource ( mgrec* db, char* name );
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func char* | mgNameOfLightSource | gets the name of a light 
	source palette entry

	@desc <f mgNameOfLightSource> returns a pointer to the name of light 
	source entry record <p index> in the light source palette of <p db>.  
	If the light source with that index is not found, <m MG_NULL> is returned.  
	Storage for the name is dynamically allocated by <f mgNameOfLightSource>.

	@desc Note: The user is responsible for deallocating the dynamically 
	allocated memory using <f mgFree>.

	@param mgrec* | db | the database node 
	@param int | index | the index of the light source entry to be  
	searched for

	@return   Returns a pointer to the light source entry name, 
	otherwise returns <m MG_NULL>.

	@access Level 1
	@see <f mgGetLightSource>, <f mgIndexOfLightSource>

*/
extern MGAPIFUNC(char*) mgNameOfLightSource ( mgrec* db, int index );
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgGetLightSourceCount | gets the number of entries in a 
	database�s light source palette.
	@desc <f mgGetLightSourceCount> gets the number of light source entries 
	for a given database <p db>.

	@param mgrec* | db | the database node 

  @return   Returns the number of light source entries.

	@access Level 1
	@see <f mgGetLightSource>, <f mgGetFirstLightSource>, 
	<f mgGetNextLightSource>

*/
extern MGAPIFUNC(int) mgGetLightSourceCount ( mgrec* db );
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetFirstLightSource | gets the first entry record 
	from a database�s light source palette.

	@desc Given a database node <p db>, <f mgGetFirstLightSource> gets the 
	database�s first light source entry record. If successful, the record is 
	returned.  If unsuccessful, <m MG_NULL> is returned. The index of the light 
	source in the palette is returned in index.

	@param mgrec* | db | the database node 
	@param int * | index | the returned index of the entry if there 
	is one, otherwise returns -1.

	@return   Returns the light source palette entry record, 
	or <m MG_NULL> if unsuccessful.

	@ex | 
   mgrec* ltsrec;
   mgrec* nextrec;
   mgrec* db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   ltsrec = mgGetFirstLightSource ( db, &index );
   nextrec = mgGetNextLightSource ( ltsrec, &index );

	@access Level 1
	@see <f mgGetLightSource>, <f mgGetNextLightSource>

*/
extern MGAPIFUNC(mgrec*) mgGetFirstLightSource ( mgrec* db, int *index );
/* 
 * Find and return the first light source entry in the light source table, MG_NULL if not found.
 * Also return index (if passed in) of the light source in the table, -1 if not found.
 */
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetNextLightSource | gets the next entry record 
	from a database�s light source palette

	@desc Given a light source entry record, <p ltsrec>, <f mgGetNextLightSource> 
	returns the light source entry record following <p ltsrec> in the light 
	source palette. The index of the next light source in the palette is 
	returned in <p index>, if there is one. If there is no next light source 
	entry record, <m MG_NULL> is returned.

	@param mgrec* | ltsrec | the pointer to the light source palette entry.
	@param int * | index | the index of the next light source, if there is one, 
	otherwise returns -1.

	@return   Returns the next light source palette entry record, 
	or <m MG_NULL> if there is none.

	@ex | 
   mgrec* ltsrec;
   mgrec* nextrec;
   mgrec* db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   ltsrec = mgGetFirstLightSource ( db, index );
   nextrec = mgGetNextLightSource ( ltsrec, index );

	@access Level 1
	@see <f mgGetLightSource>, <f mgGetFirstLightSource>

*/
extern MGAPIFUNC(mgrec*) mgGetNextLightSource ( mgrec* ltsrec, int* index );
/* 
 * Find and return the next light source entry after the one in rec, MG_NULL if not found.
 * Also return index (if passed in) of the next light source entry in the table, -1 if not found;
 */
/*                                                                            */
/*============================================================================*/
 

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

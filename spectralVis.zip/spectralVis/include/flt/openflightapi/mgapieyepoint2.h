/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIEYEPOINT2_H_
#define MGAPIEYEPOINT2_H_
/* @doc EXTERNAL EYEFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#include "mgapibase.h"

/*============================================================================*\
	public constants
\*============================================================================*/

/*============================================================================*\
	private types
\*============================================================================*/

/*============================================================================*\
	public types
\*============================================================================*/

/*============================================================================*\
	public methods
\*============================================================================*/

/* @func mgrec* | mgSetEyePoint | stores an eyepoint record into the database
	@desc <f mgSetEyePoint> stores the eyepoint record <p eyerec> in the position
	defined by <p index> in the database node <p db>, <p index> must be between 1 
	and 9.  Eyepoint 0 is reserved for use by MultiGen.
	@desc Note: The attribute <flt fltEyeActive> must be set for the eyepoint
	to be considered valid.  
	@access Level 2
	@see <f mgGetEyePoint>
*/
extern MGAPIFUNC(void) mgSetEyePoint ( 
		mgrec* db,		// @param the database record
		int index,		// @param index into the eyepoint palette
		mgrec* eyerec	// @param an <flt fltEyePoint> record
		);

/* @func mgrec* | mgGetNewEyePoint | returns a new eyepoint record
	@desc <f mgGetNewEyePoint> returns a new eyepoint record that must solely be
	used as a parameter to <f mgGetCurrentEyePoint> and <f mgSetCurrentEyePoint>.
	@desc Use <f mgFreeNewEyePoint> when you are done with the record.
	@access Level 4
	@see <f mgCopyEyePoint>, <f mgFreeNewEyePoint>
*/
extern MGAPIFUNC(mgrec) *mgGetNewEyePoint ( 
		mgrec* db		// @param the database
		);

/* @func mgbool | mgCopyEyePoint | copies from one eyepoint record to another
	@desc <f mgCopyEyePoint> copies all the eyepoint attributes from <p from> to
	<p to>. 
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	@access Level 2
*/
extern MGAPIFUNC(mgbool) mgCopyEyePoint ( 
		mgrec* to,		// @param the original <flt fltEyePoint> record
		mgrec* from		// @param the new <flt fltEyePoint> record
		);

/* @func mgbool | mgFreeNewEyePoint | frees an eyepoint record
	@desc <f mgFreeEyePoint> frees the memory associated with an eyepoint record
	previously obtained by <f mgGetNewEyePoint>.
	@desc Do not use <f mgFreeNewEyePoint> on an eyepoint record obtained from 
	<f mgGetEyePoint>.
	@access Level 2
	@see <f mgGetNewEyePoint>
*/
extern MGAPIFUNC(mgbool) mgFreeNewEyePoint ( 
		mgrec* db,		// @param the database
		mgrec* eyerec	// @param the eyepoint record to be freed
		);


/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPIEYEPOINT2_H_ */
/* DON'T ADD STUFF AFTER THIS #endif */


/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

#ifndef MGAPIDECL_H_
#define MGAPIDECL_H_
/* @doc EXTERNAL BASEFUNC */

// @macro | MGAPIFUNC | exports a symbol from an API library module.
// @desc This is a macro used <m ONLY> by the API to export symbols 
// (functions or variables) from API library modules. All exported functions
// in the API are declared using this macro in corresponding include files. 
// @desc Third party developers should <m NOT> use this macro to declare
// symbols in their plug-in modules or stand alone applications.  Instead, the
// macro <m MGPIDECLARE> macro should be used to export symbols from
// third party developed plug-in modules.
//	@param | type | the return type (for function symbols) or object type
//	(for variables) exported by the API.   


#ifdef _Ix86

#ifdef API
#undef MGAPIFUNC
#define MGAPIFUNC(retype)		_declspec(dllexport) retype
#else
#undef MGAPIFUNC
#define MGAPIFUNC(retype)		retype
#endif

#else

#undef MGAPIFUNC
#define MGAPIFUNC(retype)		retype

#endif


// @macro | MGPIDECLARE | exports a symbol from a plug-in module.
// @desc When you declare symbols (functions or variables) in the source
// code for your plug-in module that need to be exported from
// your plug-in module library, you should use this macro to do so.
// Using this macro ensures that your code is portable between the
// different platforms supported by the API.
//	@param | type | the return type (for function symbols) or object type
//	(for variables) you are exporting.   
// @ex The following shows how you would use this macro to export
// your plug-in initialization function, <f mgpInit> in a portable fashion. | 
// MGPIDECLARE(mgbool) mgpInit ( mgplugin plugin, int* argc, char* argv [] )
// {
//    // your plug-in initialization processing goes here   
// }

#ifdef _WIN32

#ifdef __cplusplus
#define MGPIDECLARE(retype)   extern "C" _declspec(dllexport) retype
#else
#define MGPIDECLARE(retype)	_declspec(dllexport) retype
#endif

#else

#ifdef __cplusplus
#define MGPIDECLARE(retype)	extern "C" retype
#else
#define MGPIDECLARE(retype)	extern retype
#endif

#endif
#endif

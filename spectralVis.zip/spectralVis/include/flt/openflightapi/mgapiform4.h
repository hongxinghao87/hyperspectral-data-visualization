/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

// ----- Form Stuff -----
#define MOVE_X								0x00000001
#define MOVE_Y								0x00000002
#define MOVE_R								0x00000004
#define MOVE_B								0x00000008
#define MOVE_XY							(MOVE_X|MOVE_Y)
#define MOVE_RB							(MOVE_R|MOVE_B)
#define DECLARE_FORM_CONTROL(_n,_s)	{(_n),(_s),0,0,0,0}
#define DECLARE_FORM_CONTROLS			static mgmoverec moveRecs [] =

#define DECLARE_FORM									\
   static mgformrec formRec = {					\
      MG_FALSE,										\
      sizeof(moveRecs) / sizeof(mgmoverec),	\
      moveRecs }										\

#define MAKE_FORM							mgMakeForm (dialog, &formRec)
#define POSITION_CONTROLS				mgPositionControls (dialog, &formRec)

typedef struct mgmoverec_t {
	// static fields
	mgcontrolid			controlId;
	int					moveMask;
	// dynamic fields (filled in when dialog created)
	int					deltaX;
	int					deltaY;
	int					deltaW;
	int					deltaH;
} mgmoverec;

typedef struct mgformrec_t {
	mgbool				inited;
	int					numControls;
	mgmoverec*			moveRecs;	
} mgformrec;

#ifdef __cplusplus
extern "C" {
#endif

extern MGAPIFUNC(void) mgPositionControls (mggui dialog, mgformrec* formRec);
extern MGAPIFUNC(void) mgMakeForm (mggui dialog, mgformrec* formRec);

#ifdef __cplusplus
}
#endif
// ----- Form Stuff -----

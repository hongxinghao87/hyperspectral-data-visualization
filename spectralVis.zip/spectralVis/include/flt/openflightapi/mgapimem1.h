/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIMEM1_H_
#define MGAPIMEM1_H_
// @doc EXTERNAL MEMORYFUNC

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/*	@func void * | mgMalloc |  allocates a dynamic memory buffer
	@desc Given the number of bytes to allocate, <p byte_size>, <f mgMalloc> 
	returns a pointer to a memory buffer of that size. All of the bytes of 
	the buffer are preset to zero. The data type of the returned buffer is 
	a void pointer. The calling function should use a cast statement to 
	convert the buffer to the desired data type. When the buffer is no longer 
	needed, use the function <f mgFree> to deallocate it.  

	@param unsigned int | byte_size | the number of bytes to allocate.

	@return  Returns the pointer to the allocated and zeroed buffer. 

	@access Level 1
	@see <f mgFree>
*/
extern MGAPIFUNC(void) *mgMalloc ( unsigned int byte_size );
/*                                                                            */
/*============================================================================*/
 
   
/*============================================================================*/
/*                                                                            */
/*	@func void | mgFree |  deallocates a dynamic memory buffer
	@desc Given a pointer to a dynamic memory buffer, <p ptr>, <f mgFree> 
	deallocates it. Use <f mgMalloc> to allocate dynamic memory buffers. 
	It is a serious error to attempt to free a memory block that is already 
	deallocated. In this case, <f mgFree> displays the message 
	�attempt to free a free block <at><lt> address <gt>".  

	@param void * | ptr | the pointer to the dynamic memory buffer

	@access Level 1
	@see <f mgMalloc>
*/
extern MGAPIFUNC(void) mgFree ( void *ptr );
/*                                                                            */
/*============================================================================*/
 
   

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIEYEPOINT1_H_
#define MGAPIEYEPOINT1_H_
/* @doc EXTERNAL EYEFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#include "mgapibase.h"

/*============================================================================*\
	public constants
\*============================================================================*/

/*============================================================================*\
	private types
\*============================================================================*/

/*============================================================================*\
	public types
\*============================================================================*/

/*============================================================================*\
	public methods
\*============================================================================*/

/*----------------------------------------------------------------------------*\
	Get Eyepoint Info
\*----------------------------------------------------------------------------*/

/* @func mgrec* | mgGetEyePoint | gets an eyepoint record from the database
   @return The eyepoint record, if successful, <m MG_NULL> otherwise.
	@desc <f mgGetEyePoint> gets the eyepoint record defined by <p index>
	from the database node <p db>, <p index> must be between 1 and 9.
	Eyepoint 0 is reserved for use by MultiGen.
	@access Level 1
	@see <f mgSetEyePoint>, <f mgSetAttList>
*/
extern MGAPIFUNC(mgrec*) mgGetEyePoint ( 
		mgrec* db,			// @param the database
		int index			// @param the index of the eyepoint to get
		);

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPIEYEPOINT1_H_ */
/* DON'T ADD STUFF AFTER THIS #endif */

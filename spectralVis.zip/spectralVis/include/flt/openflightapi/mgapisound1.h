/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPISOUND1_H_
#define MGAPISOUND1_H_
// @doc EXTERNAL SOUNDFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/


/* @func mgrec * | mgGetSound |   gets an entry record from a database�s sound palette
	@desc <f mgGetSound> returns the sound entry record defined by <p index> from the sound 
	palette of <p db>. If the requested sound does not exist, <m MG_NULL> is returned.

	@return Returns the sound palette entry record, <m MG_NULL> if unsuccessful.

	@ex |
   int sndindex;
   mgrec *snd_rec, *db;
   db = mgOpenDb ( "anyfile.flt" );
   if ( snd_rec = mgGetSound ( db, 0 ) ) {
      mgGetAttList ( snd_rec, fltSndIndex, &sndindex, MG_NULL );
   }

	@access Level 1
	@see <f mgGetSoundCount>, <f mgGetFirstSound>, <f mgGetNextSound>

*/
extern MGAPIFUNC(mgrec *) mgGetSound ( 
										mgrec *db, // @param the database
										int index  // @param the index of the sound to retrieve
										);

/* @func int | mgIndexOfSound |   gets the index of a named sound palette entry
	@desc <f mgIndexOfSound> returns the index of the sound 
	entry record named <p name> in the sound palette of <p db>. 
	If the named sound is not found,  -1 is returned. 

	@return Returns the index of the named sound palette entry or -1 if no entry is found.

	@access Level 1
	@see <f mgGetSound>, <f mgNameOfSound>

*/
extern MGAPIFUNC(int) mgIndexOfSound ( 
										mgrec* db, // @param the database
										char* name // @param the name of the sound entry
										);

/* @func char * | mgNameOfSound |   gets the name of a sound palette entry
	@desc <f mgNameOfSound> returns a pointer to the name of sound entry record with
	<p index> in the sound palette of <p db>. If the sound with that index is not 
	found, <m MG_NULL> is returned. Storage for the name is dynamically allocated 
	by <f mgNameOfSound>.

	@desc Note: the user is responsible for deallocating the dynamically 
	allocated memory using <f mgFree>.

	@return   Returns a pointer to the sound entry name, 
	otherwise <m MG_NULL>.

	@access Level 1
	@see <f mgGetSound>, <f mgIndexOfSound>

*/
extern MGAPIFUNC(char) *mgNameOfSound ( 
										mgrec* db, // @param the database
										int index  // @param the index of the sound entry
										);

/* @func int | mgGetSoundCount | gets the number of entries in a 
	database�s sound palette
	@desc <f mgGetSoundCount> gets the number of sound entries 
	for a given database <p db>.

	@return   Returns the number of sound entries

	@access Level 1
	@see <f mgGetSound>, <f mgGetFirstSound>, <f mgGetNextSound>

*/
extern MGAPIFUNC(int) mgGetSoundCount ( 
										mgrec *db // the database 
										);

/* @func mgrec * | mgGetFirstSound |   gets the first sound entry
	from a database�s sound palette

	@desc Given a database node <p db>, <f mgGetFirstSound> gets the database�s 
	first sound entry record. If successful, the record is returned.  If 
	unsuccessful, <m MG_NULL> is returned. The index of the sound record
	in the palette is returned in index.

	@return Returns the first sound palette entry record, or <m MG_NULL> if unsuccessful.

	@ex | 
   mgrec *snd_rec;
   mgrec *nextrec;
   mgrec *db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   snd_rec = mgGetFirstSound ( db, index );
   nextrec = mgGetNextSound ( snd_rec, index );

	@access Level 1
	@see <f mgGetSound>, <f mgGetNextSound>

*/
extern MGAPIFUNC(mgrec) *mgGetFirstSound ( 
										mgrec *db, // @param the database
										int *index // @param the index of the returned sound palette entry
										);

/* @func mgrec * | mgGetNextSound |   gets the next entry record 
	from a database�s sound palette

	@desc Given a sound entry record, <p sndrec>, <f mgGetNextSound> 
	returns the sound entry record following <p sndrec> in the sound
	palette. The index of the next sound in the palette is 
	returned in <p index>, if there is one. If there is no next sound 
	entry record, <m MG_NULL> is returned.

	@return Returns the next sound palette entry record, or <m MG_NULL> if there is none.

	@ex | 
   mgrec *sndrec;
   mgrec *nextrec;
   mgrec *db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   sndrec = mgGetFirstSound ( db, index );
   nextrec = mgGetNextSound ( sndrec, index );

	@access Level 1
	@see <f mgGetSound>, <f mgGetFirstSound>

*/
extern MGAPIFUNC(mgrec) *mgGetNextSound ( 
										mgrec *sndrec, // @param the sound record
										int *index		// @param the index of the next sound record
										);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

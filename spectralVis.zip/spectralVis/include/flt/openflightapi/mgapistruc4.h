/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPISTRUC4_H_
#define MGAPISTRUC4_H_
/* @doc EXTERNAL STRUCFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgRemove | temporarily deletes a bead type record
	from a database.
	@desc <f mgRemove> temporarily deletes the specified bead type record 
	<p rec>.  Bead type records that have been temporarily deleted in this
	way may be un-deleted later using the function <f mgUnRemove>.  
	This is useful for editor class plug-in tools to implement undo.

	@desc Records that have been temporarily deleted using this function
	is detached and appears to be completely deleted from the database. 
	After <p rec> has been removed in this way, the only API
	functions that accept <p rec> are <f mgUnRemove> which 
	un-removes it and <f mgDelete> which permanently deletes it.

	@desc This function is only applicable for bead type records in
	the Creator modeler environment.  Calling this function in the
	stand alone application environment does nothing.

	@return Returns <e mgbool.MG_TRUE> if <p rec> was successfully removed,
	<e mgbool.MG_FALSE> otherwise.

	@access Level 4
	@see <f mgDelete>, <f mgDetach>, <f mgUnRemove>
*/
extern MGAPIFUNC(mgbool) mgRemove (
	mgrec* rec		// @param the record to remove
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgUnRemove | unremoves a bead type record that was
	temporarily delete using <f mgRemove>.
	@desc <f mgRemove> unremoves the specified bead type record 
	<p rec> that was previously removed by calling <f mgRemove>. 

	@desc Records that are unremoved in this way cannot be re-attached 
	in the database.  It is the caller's responsibility to attach the record
	back into the hierarchy at the appropriate place.

	@return If the <p rec> could be successfully unremoved, this function
	returns the value of <p rec>, <m MG_NULL> otherwise.

	@access Level 4
	@see <f mgRemove>, <f mgDelete>, <f mgDetach>
*/
extern MGAPIFUNC(mgrec*) mgUnRemove (
	mgrec* rec		// @param the record to unremove
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

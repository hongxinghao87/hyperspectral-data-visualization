/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPILIGHT4_H_
#define MGAPILIGHT4_H_
/* @doc EXTERNAL LIGHTSOURCEFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentLightSource | returns index of current modeling
	light source.

	@desc <f mgGetCurrentLightSource> returns the <p index> of the current 
	modeling light source selected for database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if current modeling light source for <p db>
	could be determined, <e mgbool.MG_FALSE> otherwise.  If successful, 
	the output parameter <p index> is filled in with the corresponding
	value, otherwise it is undefined.

	@see <f mgSetCurrentLightSource>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentLightSource (
	mgrec* db,			// @param the database
	int* index			// @param address of value to receive index of current 
							// modeling light source.
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetCurrentLightSource | sets the current modeling light source
	index.

	@desc <f mgSetCurrentLightSource> sets the current modeling light source
	palette <p index> for database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if current modeling light source for <p db>
	could be set, <e mgbool.MG_FALSE> otherwise.

	@see <f mgGetCurrentLightSource>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgSetCurrentLightSource (
	mgrec* db,			// @param the database
	int index			// @param index to set current modeling light source
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPI_DEPRECATED_H_
#define MGAPI_DEPRECATED_H_

/* @doc EXTERNAL */

/*############################################################################*/
/*############################################################################*/
/*###                                                                         */
/*###   The function definitions and other information defined in this header */
/*###   file are unsupported and may be removed in future releases.           */
/*###                                                                         */
/*############################################################################*/
/*############################################################################*/

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

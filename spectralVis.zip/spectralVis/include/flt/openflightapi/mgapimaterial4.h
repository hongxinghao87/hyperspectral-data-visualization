/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIMATERIAL4_H_
#define MGAPIMATERIAL4_H_
/* @doc EXTERNAL MATERIALFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentMaterial | returns index of current modeling
	material.

	@desc <f mgGetCurrentMaterial> returns the <p index> of the current 
	modeling material selected for database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if current modeling material for <p db>
	could be determined, <e mgbool.MG_FALSE> otherwise.  If successful, 
	the output parameter <p index> is filled in with the corresponding
	value, otherwise it is undefined.

	@see <f mgSetCurrentMaterial>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentMaterial (
	mgrec* db,			// @param the database
	int* index			// @param address of value to receive index of current 
							// modeling material.
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetCurrentMaterial | sets the current modeling material
	index.

	@desc <f mgSetCurrentMaterial> sets the current modeling material
	palette <p index> for database <p db>. 

	@return <e mgbool.MG_TRUE> if current modeling material for <p db>
	could be set, <e mgbool.MG_FALSE> otherwise.

	@see <f mgGetCurrentMaterial>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgSetCurrentMaterial (
	mgrec* db,			// @param the database
	int index			// @param index to set current modeling material
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

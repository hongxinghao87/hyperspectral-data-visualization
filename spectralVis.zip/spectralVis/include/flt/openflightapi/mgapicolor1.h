/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPICOLOR1_H_
#define MGAPICOLOR1_H_
/* @doc EXTERNAL COLORFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIndex2RGB | returns red, green, and blue values for a 
	given color palette index and intensity.

	@desc Given a database node <p db>, color palette index, <p index>, 
	and intensity, <p intensity>, <f mgIndex2RGB> returns the red <p r>, 
	green <p g>, and blue <p b> values associated with them in the database�s 
	color palette.  

	@desc The color components returned will range from 0 to 255.

	@return Returns <e mgbool.MG_TRUE> if the index could be converted successfully,
	<e mgbool.MG_FALSE> otherwise.  If successful, the output parameters <p r>, <p g>
	and <p b> are filled in with the corresponding values, otherwise they are undefined.

	@access Level 1
	@see <f mgRGB2Index>
*/
extern MGAPIFUNC(mgbool) mgIndex2RGB (
	mgrec* db,				// @param the database node
	unsigned int index,	// @param the index into the color palette 
	float intensity,		// @param the intensity component of the color (0.0-1.0) 
	short* r, 				// @param address of value to receive red component of color
	short* g, 				// @param address of value to receive green component of color
	short* b					// @param address of value to receive blue component of color
	);



/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgRGB2Index | finds the color palette entry and intensity 
	which most closely matches RGB values.
	@desc Given a database node <p db>, and red, green, and blue values 
	<p r>, <p g>, and <p b>, <f mgRGB2Index> returns the index, <p palIndex>, 
	and intensity, <p intensity>, of the closest match in the database�s color 
	palette. The best match is determined by the least sum of squares method.  

	@desc The color components supplied must range from 0 to 255.  The intensity
	value returned will range from 0.0-1.0.

	@return Returns <e mgbool.MG_TRUE> if an index and intensity could be
	matched, <e mgbool.MG_FALSE> otherwise.  If successful, the output parameters 
	<p index> and <p intensity> are filled in with the corresponding values, 
	otherwise they are undefined.

	@access Level 1
	@see <f mgIndex2RGB>
*/
extern MGAPIFUNC(mgbool) mgRGB2Index (
	mgrec* db,						// @param the database node
	short r,							// @param the red value, which ranges from 0 to 255  
	short g,							// @param the green value, which ranges from 0 to 255  
	short b,							// @param the blue value, which ranges from 0 to 255  
	unsigned int* palIndex,		// @param address of value to receive palette index
	float* intensity				// @param address of value to receive intensity value
	);


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetColorIndexByName | finds the index of a color 
	palette entry from its name.
	@desc Given a database node, <p db>, and a color name <p name>, 
	<f mgGetColorIndexByName> sets <p index> to the index of the color 
	palette entry that has <p name> in its name list.  

	@return Returns <e mgbool.MG_TRUE> if the named color was found, 
	otherwise <e mgbool.MG_FALSE>. 

	@access Level 1
	@see <f mgGetCurrentColorName>, <f mgGetNextColorName>, <f mgDeleteColorName>
*/
extern MGAPIFUNC(mgbool) mgGetColorIndexByName (
	mgrec* db,			// @param the database node
	char* name,			// @param the color name
	int* index			// @param address of the returned index
	);


/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetNextColorName | gets the name of the next color for 
	a particular color index.
	@desc Each color palette entry can have a list of names associated with it. 
	Given a database node, <p db>, an index into the color palette, <p index>, 
	and the name list, <p ptr>, <f mgGetNextColorName> returns the next name in 
	<p index>�s color name list.  If <p ptr> points to MG_NULL, then it will be 
	set to hold an opaque pointer to the name list, and the first name in the 
	list will be returned. Subsequent calls to <f mgGetNextColorName> for the
	same index can then be made using <p ptr>.   

	@desc Storage for the name is dynamically allocated by <f mgGetNextColorName>.
	The user is responsible for deallocating the dynamically allocated 
	memory with <f mgFree>.  

	@return Returns the next name in the color name list for the given index. 

	@access Level 1
	@see <f mgGetCurrentColorName>, <f mgGetColorIndexByName>
*/
extern MGAPIFUNC(char*) mgGetNextColorName (
	mgrec* db,			// @param the database node
	int index,			// @param the color palette index
	void** ptr			// @param an opaque pointer holding the name 
							// list (can point to <m MG_NULL>).  If points
							// to <m MG_NULL>, returns an opaque
							// pointer to the name list
	);

/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetPolyColorName | gets a copy of the color name of a 
	<flt fltPolygon> record.
	@desc Given a <flt fltPolygon> record, <p polyrec>, <f mgGetPolyColorName> returns the 
	color name for the polygon. The storage for the name is dynamically allocated 
	by <f mgGetPolyColorName>.

	@desc Note: The user is responsible for deallocating the dynamically allocated 
	memory with <f mgFree>.  

	@return Returns a copy of the color name for the polygon if successful, 
	otherwise <m MG_NULL>. 

	@access Level 1
	@see <f mgSetPolyColorName>, <f mgGetNextColorName>
*/
extern MGAPIFUNC(char*) mgGetPolyColorName (
	mgrec* polyrec			// @param a <flt fltPolygon> record
	);


/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetPolyAltColorName | get a copy of the alternate 
	color name of a <flt fltPolygon> record.
	@desc Given a <flt fltPolygon> record, <p polyrec>, <f mgGetPolyAltColorName> 
	returns the alternate color name for the polygon.  The storage for the 
	name is dynamically allocated by <f mgGetPolyAltColorName>.

	@desc Note: The user is responsible for deallocating the dynamically allocated 
	memory with <f mgFree>.  

	@return Returns a copy of the alternate color name for the polygon if successful,  
	otherwise <m MG_NULL>. 

	@access Level 1
	@see <f mgSetPolyAltColorName>, <f mgGetNextColorName>
*/
extern MGAPIFUNC(char*) mgGetPolyAltColorName (
	mgrec* polyrec			// @param a <flt fltPolygon> record
	);


/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetCurrentColorName | gets a copy of the current name 
	of a particular color palette entry.
	@desc Each color palette entry can have a list of names associated with it. 
	One of these names is always the current name for that entry. 
	Given a database node, <p db>, and an index into the color palette, 
	<p index>, <f mgGetCurrentColorName> <p returns> the current name of the 
	given color palette entry. 
	The storage for the name is dynamically allocated by <f mgGetCurrentColorName>.

	@desc Note: The user is responsible for deallocating the dynamically allocated 
	memory with <f mgFree>.  

	@return Returns a copy of the current name for the color palette entry,
	otherwise <m MG_NULL>. 

	@access Level 1
	@see <f mgSetCurrentColorName>, <f mgGetNextColorName>, <f mgGetColorIndexByName>
*/
extern MGAPIFUNC(char*) mgGetCurrentColorName (
	mgrec* db,			// @param the database node
	int index			// @param the color palette index
	);


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadDefaultColorPalette | reads in a color file as	
	the default color palette.
	@desc Given a color file name, <p fileName>, <f mgReadDefaultColorPalette> reads 
	the color file as the default color palette.

	@return Returns <e mgbool.MG_TRUE> if the file was read successfully, 
	otherwise <e mgbool.MG_FALSE>. 

	@access Level 1
	@see <f mgReadColorPalette>, <f mgWriteDefaultColorPalette>
*/
extern MGAPIFUNC(mgbool) mgReadDefaultColorPalette (
	char* fileName			// @param the color file name
	);


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadColorPalette | reads in a color file as 
	a database�s current color palette.
	@desc Given a database node, <p db>, and color file <p fileName>, 
	<f mgReadColorPalette> reads the color file as the database�s 
	current color palette.

	@return Returns <e mgbool.MG_TRUE> if the file was read successfully, 
	otherwise <e mgbool.MG_FALSE>. 

	@access Level 1
	@see <f mgReadDefaultColorPalette>, <f mgWriteDefaultColorPalette>
*/
extern MGAPIFUNC(mgbool) mgReadColorPalette (
	mgrec* db,			// @param the database node
	char* fileName		// @param the color file name
	);


/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

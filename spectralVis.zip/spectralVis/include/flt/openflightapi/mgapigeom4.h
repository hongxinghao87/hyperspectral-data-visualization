/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIGEOM4_H_
#define MGAPIGEOM4_H_
/* @doc EXTERNAL GEOMETRYFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"
#include "mgapicoord.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgCoordsEqual | checks to see if two coordinates are 
	equal within a tolerance.

	@desc <f mgCoordsEqual> compares two coordinates, <p coord1> and <p coord2>
	to see if they are equal within a specified <p tolerance>.
	@desc The two coordinates are considered equal if:

	@desc absolute value ((coord1->x - coord2->x) is less than tolerance) AND<nl>
	absolute value ((coord1->y - coord2->y) is less than tolerance) AND<nl>
	absolute value ((coord1->z - coord2->z) is less than tolerance)<nl>

   @desc To compare for exact matches, set <p tolerance> to 0.0.  This function
	does not match based on distance.  Doing so, in some cases, may yield a
	more desirable result but is more computationally intensive than the simple
	comparison test used by this function.  
	@ex If you need more precise checking based on the distance between two
	coordinates, you can use the function <f mgDistance> to create your own
	equality check as shown here |
   static mgbool CheckEqual (mgcoord3d* c1, mgcoord* c2, double distance)
   {
      if (mgDistance (c1, c2) < distance)
         return MG_TRUE;
      return MG_FALSE;
   }

	@return Returns <e mgbool.MG_TRUE> if <p coord1> and <p coord2> are equal
	within <p tolerance>, <e mgbool.MG_FALSE> otherwise.  If either <p coord1> 
	or <p coord2> are <m MG_NULL>, this function returns <e mgbool.MG_FALSE>.

	@see <f mgDistance>

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgCoordsEqual (
	mgcoord3d* coord1,			// @param first coord to check for equality 
	mgcoord3d* coord2,			// @param first coord to check for equality
	double tolerance				// @param tolerance for equality check
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgCoordDif | calculates the difference of
	two 3D coordinates.

	@desc <f mgCoordDif> calculates the difference of two 3D double
	precision floating point coordinates, <p coord1> - <p coord2>.

	@return Returns double precision 3D coordinate record.

	@see <t mgcoord3d>

	@access Level 4
*/
extern MGAPIFUNC(mgcoord3d) mgCoordDif (
	mgcoord3d* coord1,			// @param address of coordinate from which <p coord2>
										// is subtracted
	mgcoord3d* coord2				// @param address of coordinate that is subracted
										// <p coord1>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mglined | mgMakeLine | makes a line between two points.

	@desc <f mgMakeLine> returns a double precision line record representing
	the line passing through the two specified points, <p coord1> and
	<p coord2>.

	@return Returns a double precision line record.

	@see <t mglined>

	@access Level 4
*/
extern MGAPIFUNC(mglined) mgMakeLine (
	mgcoord3d* coord1,			// @param address of first coordinate that defines the line
	mgcoord3d* coord2				// @param address of second coordinate that defines the line
	);
/*                                                                            */
/*============================================================================*/

/* @deprecated mgVectorMove | Use <f mgMoveCoordAlongVectorf> */
extern MGAPIFUNC(mgcoord3d) mgVectorMove (
	mgcoord3d* coord3d,
	mgvectorf* vectorf,
	float distance	
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgMoveCoordAlongVectorf | calculates the position of a
	3D coordinate translated along a single precision vector a given distance.

	@desc <f mgMoveCoordAlongVectorf> calculates and returns the position of the
	specified 3D coordinate, <p coord3d>, translated the specified distance,
	<p distance>, in the direction specified by the single precision
	floating point vector <p vectorf>.

	@return Returns a double precision 3D coordinate record.

	@see <f mgMoveCoordAlongVector>

	@access Level 4
*/
extern MGAPIFUNC(mgcoord3d) mgMoveCoordAlongVectorf (
	mgcoord3d* coord3d,			// @param address of 3D coordinate to move
	mgvectorf* vectorf,			// @param address of vector along which <p coord3d>
										// is to be moved
	float distance					// @param distance along <p vectorf> that <p coord3d>
										// is to be moved
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgMoveCoordAlongVector | calculates the position of a
	3D coordinate translated along a double precision vector a given distance.

	@desc <f mgMoveCoordAlongVector> calculates and returns the position of the
	specified 3D coordinate, <p coord3d>, translated the specified distance,
	<p distance>, in the direction specified by the double precision
	floating point vector <p vectord>.

	@return Returns a double precision 3D coordinate record.

	@see <f mgMoveCoordAlongVectorf>

	@access Level 4
*/
extern MGAPIFUNC(mgcoord3d) mgMoveCoordAlongVector (
	mgcoord3d* coord3d,			// @param address of 3D coordinate to move
	mgvectord* vectord,			// @param address of vector along which <p coord3d>
										// is to be moved
	double distance				// @param distance along <p vectorf> that <p coord3d>
										// is to be moved
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3f | mgCoord3dTof | converts a 3D coordinate from double
	to single precision floating point.

	@desc <f mgCoord3dTof> converts the specified 3D double precision
	floating point coordinate to a 3D single precision floating point
	coordinate.

	@return Returns a single precision coordinate record.

	@see <t mgcoord3f>, <t mgcoord3d>

	@access Level 4
*/
extern MGAPIFUNC(mgcoord3f) mgCoord3dTof (
	mgcoord3d* ip				// @param address of double precision 3D coordinate to convert
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgvectorf | mgVectordTof | converts a vector from double 
	to single precision floating point.

	@desc <f mgVectordTof> converts the specified double precision
	floating point vector to a single precision floating point
	vector.

	@return Returns single precision vector record.

	@see <t mgvectord>, <t mgvectorf>

	@access Level 4
*/
extern MGAPIFUNC(mgvectorf) mgVectordTof (
	mgvectord* vector3d		// @param address of double precision vector to convert
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

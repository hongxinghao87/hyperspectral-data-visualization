/*
@doc MAIN

@contents1 Introduction |

<m What Is the OpenFlight API?>

The OpenFlight API is a set of C header files and libraries that provides a 
programming interface to Creator and the OpenFlight database format. The API is broken
into four levels: Read, Write, Extensions, and Tools. This document contains the reference
pages for all levels of the API.

<m Audience>

This document is written for programmers who want to write stand-alone applications,
plugins, or both, using OpenFlight API interfaces.  To use the OpenFlight API, 
and this manual, you should be comfortable with the American National Standards Institute
(ANSI) C programming language and have some understanding of 3D modeling.  Familiarity
with MultiGen-Paradigm modeling tools and the OpenFlight format is helpful, but is not required.

<m About This Manual>

This manual provides detailed information on functions included in 
the API.  It is intended to be used in conjunction with both the OpenFlight API User's Guides;
Read/Write User�s Guide and Extensions/Tools User's Guide.  These guides provide instructions
and examples for integrating these functions into your code. Both of these guides are
available in Acrobat format. 

Last revised: <date>

<m Use and Disclosure of Data>

Copyright 2003 MultiGen-Paradigm, Inc., a subsidiary of Computer Associates International, Inc. 
("Computer Associates"). All trademarks, trade names, service marks and logos referenced 
herein belong to their respective companies. All rights reserved.

MultiGen-Paradigm Inc. (MultiGen-Paradigm) PROVIDES THIS MATERIAL AS IS, WITHOUT WARRANTY 
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

MultiGen-Paradigm may make improvements and changes to the product described in this manual 
at any time without notice. MultiGen-Paradigm assumes no responsibility for the use of the 
product or this document except as expressly set forth in the applicable MultiGen-Paradigm 
agreement or agreements and subject to terms and conditions set forth therein and applicable 
MultiGen-Paradigm policies and procedures. This document may contain technical inaccuracies 
or typographical errors. Periodic changes may be made to the information contained herein. 
If necessary, these changes will be incorporated in new editions of the document.

MultiGen-Paradigm, Inc. is the owner of all intellectual property rights in and to this 
document and any proprietary software that accompanies this documentation, including but 
not limited to, copyrights in and to this document and any derivative works therefrom. 
Use of this document is subject to the terms and conditions of the MultiGen-Paradigm 
Software License Agreement included with this product.

No part of this publication may be stored in a retrieval system, transmitted, distributed 
or reproduced, in whole or in part, in any way, including, but not limited to, photocopy, 
photograph, magnetic, or other record, without the prior written permission of MultiGen-Paradigm, 
Inc.

Use, duplication, or disclosure by the government is subject to restrictions set 
forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and Computer 
Software clause and DFARS 52.227-7013 and in similar clauses in the FAR and 
NASA FAR Supplement.

@contents1 OpenFlight API Release Notes |

@normal
This section contains the release notes for all versions of the
OpenFlight API beginning at v2.1 and ending with the current version.
The release notes for the different versions are listed here in
reverse chronological order (i.e., the most recent version first).
In addition to version specific release notes, there is also a
general release notes section here containing information applicable
to all versions of the API.

@group1 General
@group2 Developer Studio Project Settings

@normal
It is very important that your plug-in module be linked with the correct system 
run-time libraries to match Creator.  In particular, multithreaded DLLs are 
required.  In Developer Studio, open the <m Project Settings> window, 
select the <m C/C++> tab and then select the <m Code Generation> category.  In
the <m Use run-time librarys> popup, select <m Debug Multithreaded DLL> for the 
Win32 Debug configuration and <m Multithreaded DLL> for the Win32 Release
configuration.

@group2 Deprecated API

@normal
Please review the list of deprecated API symbols and functions that
appear in the <m Deprecated API> section of this reference manual.  
For each symbol that appears in this section, an appropriate 
replacement symbol or strategy is also given.  Although deprecated
API symbols are still supported in the current version of the API,
they may not be in future releases.  To ensure that code you develop
using the MultiGen OpenFlight API remains compatible with future
versions of the API, you should eliminate any deprecated symbols
from your code.

When you compile code that uses a deprecated symbol, the compiler
may issue a warning message stating that the symbol is not defined.
This is expected and is an indication to you that action should be
taken to replace that symbol as described above.  Note that even
though the compiler issues this warning message, your program or
plug-in should link successfully even when it uses a deprecated
symbol.

@group1 v2.6

@group2 Common Directory Organization
@normal
The OpenFlight API is now installed into the MultiGen-Paradigm
Common Directory Organization.  This structure is significantly different
than previous installations and affects the developer in the following areas:

OpenFlight API installation root<nl>
Location of C source header files<nl>
Location of link libraries<nl>
Location of documentation<nl>
Location of sample code<nl>
Location of redistributable OpenFlight API binaries<nl>
Location of runtime plug-in directory

Note that the relocation of the C source header files
and link libraries will cause developers to update their
Developer Studio Project files and/or IRIX makefiles before
the corresponding application(s) or plug-in(s) can be rebuilt
with this version of the OpenFlight API.

@group3 OpenFlight API Installation Root
@normal
The installer now creates an environment variable <m MPI_LOCATE_OPENFLIGHT_API>
whose value specifies the root of the OpenFlight API installation.  This
replaces the environment variable <m MGAPIDIST> used by previous versions.

@group3 Location of C source header files
@normal
The C source header files have been relocated to:
<q &ltMPI_LOCATE_OPENFLIGHT_API&gt/include/openflightapi>

@group3 Location of link libraries
@normal
The link libraries have been relocated to:
<q &ltMPI_LOCATE_OPENFLIGHT_API&gt/lib>

@group3 Location of documentation
@normal
The documentation has been relocated to:
<q &ltMPI_LOCATE_OPENFLIGHT_API&gt/docs/openflightapi>

@group3 Location of sample code
@normal
The samples have been relocated to:
<q &ltMPI_LOCATE_OPENFLIGHT_API&gt/resources/samples/openflightapi>

with subfolders for the individual kinds of samples:
<q
/apps - sample stand-alone programs
/extensions - sample OpenFlight data extensions
/plugins - sample plug-ins>

@group3 Location of redistributable OpenFlight API binaries
@normal
If you need to redistribute the OpenFlight API binaries,
the dynamic link libraries you will need are located at:

<q &ltMPI_LOCATE_OPENFLIGHT_API&gt/resources/samples/openflightapi/apps/bin>

@group3 Location of runtime plug-in directory
@normal
At start up, Creator and stand-alone OpenFlight API applications
now use the environment variable <m MPI_CREATOR_PLUGIN_DIR> to locate
plug-ins.  This replaces the environment variable <m MGPLUGINDIR> used
by previous versions.
  
@group2 Light Points
@normal
Light Points were changed significantly in this version.  Prior to this
version, light point attributes were completely contained within the 
<flt fltLightPoint> node.  Starting with this version, the light point
attributes have been moved from the light point node into two separate
palettes.  This introduces a level of indirection (similar to color, 
material and texture palette) on the light point node into two separate
palette entries.

@normal
The new light point palettes include the Light Point Appearance Palette 
and Light Point Animation Palette, <flt fltLpAppearancePalette> and
<flt fltLpAnimationPalette>, respectively.  Entries in the Light Point 
Appearance palette describe the visual "appearance" of a light point
(color, directionality, etc) while entries in the Light Point Animation
palette describe how a light point behaves (flashes, rotates, etc).  

@normal
See the Read/Write User�s Guide for more information on light points
in this version.

@group2 New Functions

@group3 Light Point Functions
@normal
<f mgGetLightPointAppearance><nl>
<f mgIndexOfLightPointAppearance><nl>
<f mgNameOfLightPointAppearance><nl>
<f mgGetLightPointAppearanceCount><nl>
<f mgGetFirstLightPointAppearance><nl>
<f mgGetNextLightPointAppearance><nl>
<f mgGetLightPointAnimation><nl>
<f mgIndexOfLightPointAnimation><nl>
<f mgNameOfLightPointAnimation><nl>
<f mgGetLightPointAnimationCount><nl>
<f mgGetFirstLightPointAnimation><nl>
<f mgGetNextLightPointAnimation><nl>
<f mgReadLightPointFile><nl>
<f mgNewLightPointAppearance><nl>
<f mgDeleteLightPointAppearance><nl>
<f mgNewLightPointAnimation><nl>
<f mgDeleteLightPointAnimation><nl>
<f mgWriteLightPointFile><nl>
<f mgGetCurrentLightPointAppearance><nl>
<f mgSetCurrentLightPointAppearance><nl>
<f mgGetCurrentLightPointAnimation><nl>
<f mgSetCurrentLightPointAnimation><nl>
<f mgLightPointAnimationSequenceGet><nl>
<f mgLightPointAnimationSequenceSet><nl>

  @group3 Attribute Functions
@normal
<f mgGetVtxColorRGBA><nl>
<f mgSetVtxColorRGBA>

@group3 Structure Functions
@normal
<f mgWalkEx><nl>
<f mgWalkGetMatrix><nl>
<f mgValidAttach><nl>

@group3 Tool Activation Functions
@normal
<f mgGetDefaultModelingParent><nl>

@group3 Matrix Functions
@normal
<f mgNewMatrix><nl>
<f mgFreeMatrix><nl>
<f mgMatrixIdentity><nl>
<f mgMatrixIsIdentity><nl>
<f mgMatrixInvert><nl>
<f mgMatrixMultiply><nl>
<f mgMatrixCopy><nl>
<f mgMatrixFormTranslate><nl>
<f mgMatrixFormScale><nl>
<f mgMatrixFormRotateX><nl>
<f mgMatrixFormRotateY><nl>
<f mgMatrixFormRotateZ><nl>
<f mgMatrixFormQuadToQuad><nl>
<f mgMatrixTranslate><nl>
<f mgMatrixScale><nl>
<f mgMatrixRotateX><nl>
<f mgMatrixRotateY><nl>
<f mgMatrixRotateZ><nl>

@group3 Matrix Stack Functions
@normal
<f mgNewMatrixStack><nl>
<f mgFreeMatrixStack><nl>
<f mgMatrixStackPush><nl>
<f mgMatrixStackPop><nl>
<f mgMatrixStackLoadIdentity><nl>
<f mgMatrixStackLoadMatrix><nl>
<f mgMatrixStackGetMatrix><nl>
<f mgMatrixStackIsIdentity><nl>
<f mgMatrixStackMultiply><nl>
<f mgMatrixStackTranslate><nl>
<f mgMatrixStackScale><nl>
<f mgMatrixStackRotate><nl>
<f mgMatrixStackRotateX><nl>
<f mgMatrixStackRotateY><nl>
<f mgMatrixStackRotateZ><nl>
<f mgMatrixStackTransformCoord><nl>
<f mgMatrixStackTransformVector><nl>

@group3 Geometry Functions
@normal
<f mgMoveCoordAlongVector><nl>
<f mgMoveCoordAlongVectorf><nl>
<f mgVectorCross><nl>
<f mgVectorDot><nl>
<f mgReversePoly><nl>
<f mgCoordsEqual><nl>
<f mgMakeUnitVector><nl>
<f mgMakeCoord3d><nl>
<f mgMakeCoord3f><nl>
<f mgMakeCoord2d><nl>
<f mgMakeCoord2i><nl>
<f mgTransformVector><nl>

@group3 Dialog Functions
@normal
<f mgShowPalette><nl>

@group3 Text Controls
@normal
<f mgTextSetFilename><nl>

@group3 Pointer Array Functions
@normal
<f mgPtrArraySort><nl>

@group3 Mesh Functions
@normal
<f mgMeshSetVtxMask><nl>
<f mgMeshGetVtxColorRGBA><nl>
<f mgMeshGetVtxColorAlpha><nl>
<f mgMeshSetVtxColorRGBA><nl>
<f mgMeshSetVtxColorAlpha><nl>

@group3 Switch Functions
@normal
<f mgGetSwitchMaskName><nl>
<f mgSetSwitchMaskName><nl>

@group3 Info Functions
@normal
<f mgGetOpenFlightVersion><nl>

@group3 Texture Functions
@normal
<f mgIsTextureIndexInPalette><nl>

@group3 Preference Functions
@normal
<f mgSetSaveNonIndexedLightPoints><nl>
<f mgModelingPrefGetInteger><nl>
<f mgModelingPrefGetDouble><nl>

@group3 Plugin Registration Functions
@normal
<f mgGetRegistryString><nl>
<f mgSetRegistryString><nl>

@group2 New Data Types
@normal
<t mgptrarraycomparefunc><nl>

@group2 New Symbols
@normal
<e mgnotifierevent.MNOTIFY_CURRENTTEXTUREMAPPINGCHANGED> for <f mgRegisterNotifier><nl>
<e mgcontrolattribute.MCA_BOLDFONT> for <f mgControlSetAttribute><nl>
<e mgcontrolattribute.MCA_ITALICFONT> for <f mgControlSetAttribute><nl>
<m MVERSION_OPENFLIGHT><nl>
<m MWALK_MATRIXSTACK> for <f mgWalk> and <f mgWalkEx><nl>

@group2 Sample Plugins
@normal
Two new sample plugins, <m dfdtest> and <m walktest>, were added to the sample plugins
folder.  The first <m dfdtest> shows you how to use the DFD API in the context of a
Creator plugin.  It also shows some interesting OpenGL drawing
techniques.  The second <m walktest> shows you how to use the new functions
<f mgWalkEx> and <f mgWalkGetMatrix>.

The existing plugin, <m attrviewer>, was updated to include all the new attributes
added in OpenFlight version 15.8.

@group2 Fixes
@normal
Corrected <f mgSetAttList> when used to set <flt fltPolyTexWhite>.

Corrected <f mgGlMaterialIndex> to render transparent materials properly.

Corrected <f mgGlTextureIndex> to load a pattern's pixels when necessary.

Corrected <f mgWriteDb> to calculate LOD centers (when applicable) properly.

Corrected <f mgPtrArrayAppend> to return the proper array length.

Corrected <f mgReadTexturePalette> and <f mgCopyTexturePalette> to update
the Texture Palette window correctly.

Corrected <f mgReadMaterialFile>, <f mgDeleteMaterial>, <f mgDeleteMaterialByName>,
and <f mgNewMaterial> to update the Material Palette window correctly.

Corrected <f mgEditorResetUndo> to clear the Undo Menu correctly when invoked
from a tool that does not display a dialog.
 
Corrected <f mgInsert> to correctly insert nested children (subfaces) and
transformation nodes.
 
The pick function assigned for editor plug-in tools is now called when the user
selects nodes in the hierarchy view.

Corrected <f mgSelectOne> to always select a valid transformation path above
selected node.

@group2 Deprecated API
@normal
The following symbols have been deprecated in this version of 
the API. For each symbol that appears in this section, an appropriate 
replacement symbol or strategy is also given.  These deprecated symbols
are still supported in this version of the API and will likely remain
supported indefinitely in future versions.  However, it is recommended
(but not required) that you replace any deprecated symbols in your code
with the suggested replacements.  This will ensure that code you develop
using the MultiGen OpenFlight API remains compatible with future versions
of the API.

@normal
<f mgVectorMove> replaced by <f mgMoveCoordAlongVectorf><nl>
<f mgCrossProdVector> replaced by <f mgVectorCross><nl>
<f mgDelLightSource> replaced by <f mgDeleteLightSource><nl>
<f mgDelSound> replaced by <f mgDeleteSound><nl>
<f mgDelMaterial> replaced by <f mgDeleteMaterial><nl>
<f mgDelMaterialByName> replaced by <f mgDeleteMaterialByName><nl>
<f mgDelTextureMapping> replaced by <f mgDeleteTextureMapping><nl>
<f mgDelTextureMappingByName> replaced by <f mgDeleteTextureMappingByName><nl>
<flt fltLpAttr> replaced by <flt fltLpAppearancePalette> and <flt fltLpAnimationPalette>

@group2 New in the OpenFlight Data Dictionary
@normal

@group3 Header Nodes
@normal
<flt fltHeader><nl>
<flt fltHdrEarthMinorAxis><nl>
<flt fltHdrEarthMajorAxis><nl>

@group3 LOD Nodes
@normal
<flt fltLod><nl>
<flt fltLodSignificantSize><nl>

@group3 Group Nodes
@normal
<flt fltGroup><nl>
<flt fltGrpLoopCount><nl>
<flt fltGrpLoopDuration><nl>
<flt fltGrpLastFrameDuration><nl>

@group3 Switch Nodes
@normal
Individual masks of Switch Nodes can now be named.
See <f mgGetSwitchMaskName> and <f mgSetSwitchMaskName>.

@group3 Polygon/Mesh Nodes
@normal
<flt fltPolygon><nl>
<flt fltPolyRoofline><nl>
@normal
<flt fltMesh><nl>
<flt fltPolyRoofline><nl>

@group3 Vertex Nodes
@normal
Vertex Nodes now can include alpha color components.<nl>
<flt fltVAlpha><nl>
<f mgGetVtxColorRGBA><nl>
<f mgSetVtxColorRGBA><nl>

@group3 Light Point Nodes
@normal
<flt fltLpAppearance><nl>
<flt fltLpAnimation><nl>

@group3 Light Point Palette Nodes
@normal
<flt fltLpAppearancePalette><nl>
<flt fltLpAnimationPalette><nl>
<flt fltLpAppearanceName><nl>
<flt fltLpAppearanceIndex><nl>
<flt fltLpAnimationName><nl>
<flt fltLpAnimationIndex><nl>
<flt fltLpRange><nl>
<flt fltLpFadeRangeRatio><nl>
<flt fltLpFadeInTime><nl>
<flt fltLpFadeOutTime><nl>
<flt fltLpLodRangeRatio><nl>
<flt fltLpLodScale><nl>
<flt fltLpAnimationType><nl>
<flt fltLpMorseTiming><nl>
<flt fltLpWordRate><nl>
<flt fltLpCharacterRate><nl>
<flt fltLpMorseString><nl>
<flt fltLpSequenceLength><nl>

@group3 External Reference Nodes
@normal
<flt eFltGcLpPal><nl>

@group1 v2.5.1

@normal
No new functions were added for this release.

@group1 v2.5

@group2 OpenFlight API version number
@normal
When you call <f mgInit>, it now displays the OpenFlight API version
number currently loading.  This can help stand-alone program developers
and users verify that the correct version of the OpenFlight API libraries
are loading at runtime.  You can disable this as well as other messages
issued by the API using the function <f mgSetMessagesEnabled>.

@group2 Menus in Plugin Dialogs
@normal
Menus are now supported within plugin dialogs.
See the Extension/Tools User's Guide for more 
information. Also, see the new supporting functions
<f mgMenuSetState> and <m mgMenuGetState>.

@group2 Mouse Motion Events in GL Controls
@normal
GL controls in plug-in dialogs can now receive mouse motion events
even when a mouse button is not pressed.  This allows a plug-in to
"monitor" the cursor location as the user moves the mouse
(without pressing a mouse button) over the GL control.  See 
<f mgGLSetMouseFunc>, <m MGMA_MOTION>, and <t mgglmousemotiondatarec>.

@group2 New Data Types
@normal
<t mgglmousemotiondatarec><nl>
<t mgcontrolattribute><nl>

@group2 New Symbols
@normal
<m MGMA_MOTION><nl>
<e mgcontrolattribute.MCA_GLBORDERSTYLE> for <f mgControlSetAttribute><nl>
<m MGLBS_NONE> for <e mgcontrolattribute.MCA_GLBORDERSTYLE><nl>
<m MGLBS_SUNKEN> for <e mgcontrolattribute.MCA_GLBORDERSTYLE><nl>
<m MGLBS_RAISED> for <e mgcontrolattribute.MCA_GLBORDERSTYLE><nl>
<m MGLBS_SOLID> for <e mgcontrolattribute.MCA_GLBORDERSTYLE><nl>
 
@group2 New Functions
@normal

<f mgMenuSetState><nl>
<f mgMenuGetState><nl>
<f mgControlSetAttribute><nl>

@group2 Sample Plugins
@normal
A new sample plugin, called <m menutest>, was added to the <m sample_plugins>
folder. This plugin shows you how to add menus to your plugin tool 
dialogs using the new menu capabilities included in this version
of the API.

The existing plugin, <m attrviewer>, was updated to show you how to add
a custom Windows control (in this case, a tree view control) to
a plugin tool dialog.  The example includes how to access native
Windows GUI constructs through the OpenFlight plugin API.
  
@group1 v2.4.1

@group2 Debugging Plug-ins in the Creator environment

@normal
When debugging your plug-in initialization code on Windows, you may
find that the Creator splash screen occludes your workspace.  To avoid
this, you can disable the Creator splash screen by setting the environment
variable <m MGNOSPLASH> to <m 1>, <m TRUE>, or <m true> before running
Creator.  To re-enable
the splash screen, un-set this environment variable or set it to
<m 0>, <m FALSE>, or <m false>.

Note: After you change an environment variable on the Windows
platform, you must exit and restart your development environment
(Developer Studio, etc) before the change you make takes effect in
your environment.

@group1 v2.4

@group2 New Tool Attributes for Editor and Viewer Tools 
@normal
(see <f mgRegisterEditor> and <f mgRegisterViewer>)

<m MTA_MENUPOSITION><nl>
<m MTA_MENUSUBMENU><nl>

@group2 New Data Types
@normal
<t mgreclist> - formerly <t mgselectlist><nl>
<t mgcursorid><nl>
<t mgcursor><nl>
<t mgcursorhandle><nl>

@group2 New Symbols
@normal

<m MPRIM_TRI_STRIP><nl>
<m MPRIM_TRI_FAN><nl>
<m MPRIM_QUAD_STRIP><nl>
<m MPRIM_INDEXED_POLY><nl>

<m MMESH_VTXCOORD><nl>
<m MMESH_VTXCOLOR><nl>
<m MMESH_VTXCOLORRGB><nl>
<m MMESH_VTXNORMAL><nl>
<m MMESH_VTXUV0><nl>
<m MMESH_VTXUV1><nl>
<m MMESH_VTXUV2><nl>
<m MMESH_VTXUV3><nl>
<m MMESH_VTXUV4><nl>
<m MMESH_VTXUV5><nl>
<m MMESH_VTXUV6><nl>
<m MMESH_VTXUV7><nl>

@group2 New Functions

@group3 Mesh Functions
@normal
<f mgMeshGetVtxPool><nl>
<f mgMeshGetVtxMask><nl>
<f mgMeshGetVtxStride><nl>
<f mgMeshGetVtxOffset><nl>
<f mgMeshPrimitiveGetType><nl>
<f mgMeshPrimitiveGetNumVtx><nl>
<f mgMeshPrimitiveGetVtxIndexArray><nl>
<f mgMeshGetVtxCoord><nl>
<f mgMeshGetVtxColor><nl>
<f mgMeshGetVtxColorRGB><nl>
<f mgMeshGetVtxNormal><nl>
<f mgMeshGetVtxUV><nl>

<f mgMeshCreateVtxPool><nl>
<f mgMeshCreatePrimitives><nl>
<f mgMeshPrimitiveSetType><nl>
<f mgMeshPrimitiveSetVtxIndexArray><nl>
<f mgMeshSetVtxCoord><nl>
<f mgMeshSetVtxColor><nl>
<f mgMeshSetVtxColorRGB><nl>
<f mgMeshSetVtxNormal><nl>
<f mgMeshSetVtxUV><nl>

@group3 Database/Attribute Functions
@normal
<f mgIsDbUntitled><nl>

<f mgDuplicateToDb><nl>

<f mgGetVectord><nl>
<f mgSetVectord><nl>

<f mgGeoCoordCount><nl>

<f mgGetTextureSaveName><nl>

<f mgGetConstructList><nl>

@group3 SubTexture Functions
@normal
<f mgSubTextureCount><nl>
<f mgSubTextureGet><nl>
<f mgSubTextureAdd><nl>
<f mgSubTextureDelete><nl>

@group3 Texture Layer Functions
@normal
<f mgGetCurrentTextureLayer><nl>
<f mgSetCurrentTextureLayer><nl>

@group3 Dialog/Control Functions
@normal
<f mgListDeselectItemAtPos><nl>
<f mgListGetItemStringAtPos><nl>
<f mgListReplaceItemAtPos><nl>

<f mgTextGetDMS><nl>
<f mgTextSetDMS><nl>

<f mgResourceGetCursor><nl>
<f mgGetCursorHandle><nl>
<f mgSetCursor><nl>

<f mgGuiSetFixedFont><nl>
<f mgRefreshControl><nl>

@group3 Convenience Dialog Functions
@normal
<f mgPromptDialogFile><nl>
<f mgPromptDialogColor><nl>
<f mgPromptDialogFolder><nl>

@group3 Select List Functions
@normal
<f mgGetSelectList> - formerly <f mgNewSelectList><nl>
<f mgFreeRecList> - formerly <f mgFreeSelectList><nl>
<f mgResetRecList> - formerly <f mgResetSelectList><nl>
<f mgGetNextRecInList> - formerly <f mgGetNextSelected><nl>
<f mgGetNthRecInList> - formerly <f mgGetNthSelected><nl>
<f mgGetRecListCount> - formerly <f mgGetSelectListCount><nl>
<f mgGetRecListLevel> - formerly <f mgGetSelectListLevel><nl>

@group2 Changed Functions
@normal
<f mgSetMessagesEnabled> can now be called before <f mgInit> within
the stand alone program environment to control message display
during the OpenFlight API initialization function.<nl>

@group2 New in the OpenFlight Data Dictionary
@normal

@group3 Mesh Nodes
@normal
<flt fltMesh><nl>
fltMeshNumPrimitives<nl>
fltMeshNumVtx<nl>

Mesh Nodes use the <flt fltPolygon> attributes.

@group3 MultiTexture
@normal

For <flt fltPolygon> nodes and <flt fltMesh> nodes:<nl>

fltLayerTexture1<nl>
fltLayerTexture2<nl>
fltLayerTexture3<nl>
fltLayerTexture4<nl>
fltLayerTexture5<nl>
fltLayerTexture6<nl>
fltLayerTexture7<nl>

fltLayerTexmap1<nl>
fltLayerTexmap2<nl>
fltLayerTexmap3<nl>
fltLayerTexmap4<nl>
fltLayerTexmap5<nl>
fltLayerTexmap6<nl>
fltLayerTexmap7<nl>

fltLayerEffect1<nl>
fltLayerEffect2<nl>
fltLayerEffect3<nl>
fltLayerEffect4<nl>
fltLayerEffect5<nl>
fltLayerEffect6<nl>
fltLayerEffect7<nl>

fltLayerData1<nl>
fltLayerData2<nl>
fltLayerData3<nl>
fltLayerData4<nl>
fltLayerData5<nl>
fltLayerData6<nl>
fltLayerData7<nl>

For <flt fltVertex> nodes:

fltLayerU1<nl>
fltLayerU2<nl>
fltLayerU3<nl>
fltLayerU4<nl>
fltLayerU5<nl>
fltLayerU6<nl>
fltLayerU7<nl>

fltLayerV1<nl>
fltLayerV2<nl>
fltLayerV3<nl>
fltLayerV4<nl>
fltLayerV5<nl>
fltLayerV6<nl>
fltLayerV7<nl>

@group3 Header Node (<flt fltHeader>)
@normal
fltUTMZone<nl>
fltTerTransX<nl>
fltTerTransY<nl>
fltTerTransZ<nl>
fltDBRadius<nl>


@group2 Deprecated API
@normal
The following symbols have been deprecated in this version of 
the API. For each symbol that appears in this section, an appropriate 
replacement symbol or strategy is also given.  These deprecated symbols
are still supported in this version of the API and will likely remain
supported indefinitely in future versions.  However, it is recommended
(but not required) that you replace any deprecated symbols in your code
with the suggested replacements.  This will ensure that code you develop
using the MultiGen OpenFlight API remains compatible with future versions
of the API.

@normal
<t mgselectlist> replaced by <t mgreclist><nl>
<f mgNewSelectList> replaced by <f mgGetSelectList><nl>
<f mgFreeSelectList> replaced by <f mgFreeRecList><nl>
<f mgResetSelectList> replaced by <f mgResetRecList><nl>
<f mgGetNextSelected> replaced by <f mgGetNextRecInList><nl>
<f mgGetNthSelected> replaced by <f mgGetNthRecInList><nl>
<f mgGetSelectListCount> replaced by <f mgGetRecListCount><nl>
<f mgGetSelectListLevel> replaced by <f mgGetRecListLevel><nl>

<f fltHdrFlagVtxNorms> replaced by fltHdrSaveVtxNorms>

<f fltPolyMgTemplate> replaced by fltPolyTemplate<nl>
<f fltPolyTexture1> replaced by fltPolyDetailTexture<nl>
<f fltPolyTexmap1> replaced by fltPolyDetailTexmap<nl>
<f fltCatTexture1> replaced by fltCatDetailTexture<nl>

<f fltPolyFlagNocolor> replaced by fltPolyNoPrimeColor<nl>
<f fltPolyFlagNocolor2> replaced by fltPolyNoAltColor<nl>
<f fltPolyFlagRgbMode> replaced by fltPolyRgbMode<nl>
<f fltPolyFlagTerrain> replaced by fltPolyTerrain<nl>
<f fltPolyFlagHidden> replaced by fltPolyHidden<nl>
<f fltPolyFlagFootprint> replaced by fltPolyFootprint<nl>

<f fltObjFlagDay> replaced by fltObjNoDay<nl>
<f fltObjFlagDusk> replaced by fltObjNoDusk<nl>
<f fltObjFlagNight> replaced by fltObNoNight<nl>
<f fltObjFlagNoillum> replaced by fltObjNoIllum<nl>
<f fltObjFlagNoshade> replaced by fltObjNoShade<nl>
<f fltObjFlagShadow> replaced by fltObjShadow<nl>

<f fltGrpFlagAnimation> replaced by fltGrpAnimation<nl>
<f fltGrpFlagAnimationFB> replaced by fltGrpAnimationFB<nl>
<f fltGrpFlagBoxed> replaced by fltGrpBoxed<nl>
<f fltGrpFlagFreezeBox> replaced by fltGrpFreezeBox<nl>

<f fltLodFlagAdditive> replaced by fltLodAdditive<nl>
<f fltLodFlagFreezeCenter> replaced by fltLodFreezeCenter<nl>
<f fltLodFlagRange> replaced by fltLodUsePrevRange<nl>

<f fltDofFlagTxtRepeat> replaced by fltDofTxtRepeat<nl>
<f fltDofFlagMembrane> replaced by fltDofMembrane<nl>

<f fltDofCurAzim> replaced by fltDofCurXRot<nl>
<f fltDofMinAzim> replaced by fltDofMinXRot<nl>
<f fltDofMaxAzim> replaced by fltDofMaxXRot<nl>
<f fltDofIncrementAzim> replaced by fltDofIncXRot<nl>
<f fltDofFlagAzimLimited> replaced by fltDofLimitXRot<nl>

<f fltDofCurIncl> replaced by fltDofCurYRot<nl>
<f fltDofMinIncl> replaced by fltDofMinYRot<nl>
<f fltDofMaxIncl> replaced by fltDofMaxYRot<nl>
<f fltDofIncrementIncl> replaced by fltDofIncYRot<nl>
<f fltDofFlagInclLimited> replaced by fltDofLimitYRot<nl>

<f fltDofCurTwist> replaced by fltDofCurZRot<nl>
<f fltDofMinTwist> replaced by fltDofMinZRot<nl>
<f fltDofMaxTwist> replaced by fltDofMaxZRot<nl>
<f fltDofIncrementTwist> replaced by fltDofIncZRot<nl>
<f fltDofFlagTwistLimited> replaced by fltDofLimitZRot<nl>

<f fltDofIncrementX> replaced by fltDofIncX<nl>
<f fltDofIncrementY> replaced by fltDofIncY<nl>
<f fltDofIncrementZ> replaced by fltDofIncZ<nl>

<f fltDofFlagXLimited> replaced by fltDofLimitX<nl>
<f fltDofFlagYLimited> replaced by fltDofLimitY<nl>
<f fltDofFlagZLimited> replaced by fltDofLimitZ<nl>

<f fltDofIncrementXScale> replaced by fltDofIncXScale<nl>
<f fltDofIncrementYScale> replaced by fltDofIncYScale<nl>
<f fltDofIncrementZScale> replaced by fltDofIncZScale<nl>

<f fltDofFlagXScaleLimited> replaced by fltDofLimitXScale<nl>
<f fltDofFlagYScaleLimited> replaced by fltDofLimitYScale<nl>
<f fltDofFlagZScaleLimited> replaced by fltDofLimitZScale<nl>

@normal


@group1 v2.3
@normal
The Level 4 API was implemented on the SGI/Irix
platform.  The OpenFlight API libraries were distributed
on SGI/Irix using n32 binary format.

@group2 New Functions
@normal
<f mgGetExtRec>

@group2 Changed Functions
@normal
<f mgAttach> was modified to support attaching tag-along
extension records to nodes programmatically.<nl>


@group1 v2.2.1
@group2 New Functions
@normal
<f mgTextureGetLocatorFunc><nl>
<f mgTextureSetLocatorFunc><nl>
<f mgExtRefGetLocatorFunc><nl>
<f mgExtRefSetLocatorFunc>

@group2 New Data Types
@normal
<t mgfilelocatorfunc>

@group1 v2.2

@normal
Access to the following OpenFlight node types was added to the
OpenFlight Data Dictionary:

@normal
<flt fltGrid><nl>
<flt fltHelper><nl>
<flt fltSurface><nl>
<flt fltTorsion><nl>

@group1 v2.1

@group2 Plug-in Runtime Directory

@normal
The directory specified by the environmental variable <m MGPLUGINDIR> supersedes
all other plug-in runtime directories searched.  Additionally, once a plug-in 
runtime directory is located, it and all subdirectories below it are recursively
searched for plug-in modules.  See the Extension/Tools User's Guide for more 
information.

@group2 Automatic Version Update for Data Extension Records

@normal
Padding is no longer required to reserve space for future additions to
<m struct> definitions.  When the API finds an extension record in a
database file that is shorter than the current corresponding <m struct>
definition, the extension record (when it is read into memory) is automatically
expanded to accommodate for the new fields at the end of the new <m struct>
definition.  When this happens, the values for these new fields are 
initialized to 0.  See the Extension/Tools User's Guide for more 
information.

@group2 Changed Functions

@normal
<f mgIndex2RGB> was changed to return <t mgbool>.<nl>
<f mgRGB2Index> was changed to return <t mgbool>.<nl>
<f mgRegisterPostEdit> was changed to return <t mgstatus>.<nl>
<f mgRegisterPreEdit> was changed to return <t mgstatus>.<nl>
<f mgResourceGetPixmap> now supports icons in addition to bitmaps on Windows NT.<nl>


@group2 Changes to OpenFlight record/data codes

@normal
Typo in <m fltTxtGetCoordLst> was corrected to fltTxtGeoCoordLst>

@group2 Previously Undocumented Functions

@normal
<f ddIsField><nl>
<f ddIsFieldFollowAll><nl>
<f ddIsFieldFollowPointer><nl>
<f ddIsFieldFollowInLine><nl>
<f ddLabelToCode><nl>
<f ddNameToCode><nl>

@group2 New Control and Dialog Events

@normal
<m MGCB_SIZE><nl>
<m MGCB_DRAW><nl>

@group2 New Menu Locations for Editor and Viewer Tools 
@normal
(see <m MTA_MENULOCATION>)

@normal
<m MMENU_TERRAIN><nl>
<m MMENU_ROAD><nl>
<m MMENU_GEOFEATURE><nl>
<m MMENU_SOUND><nl>
<m MMENU_INSTRUMENTS><nl>
<m MMENU_BSP><nl>

@group2 New Tool Attributes
 
@normal
<m MTA_HELPCONTEXT><nl>

@group2 New Data Types

@normal
<t mgglmousefunc><nl>
<t mgglmousedatatype><nl>
<t mgglmouseaction><nl>
<t mgglmousedatarec><nl>
<t mgglmousebuttondatarec><nl>
<t mgglmousedoubleclickdatarec><nl>
<t mgguicalldatatype><nl>
<t mgtextactivatecallbackrec><nl>
<t mgscaleactivatecallbackrec><nl>
<t mggldrawcallbackrec><nl>
<t mgdialogsizecallbackrec><nl>
<t mgtimer><nl>
<t mgtimerfunc><nl>
<t mgeditorfocusvertexfunc><nl>
<t mgcreatefunc><nl>
<t mginputdevicestartfunc><nl>
<t mginputdevicestopfunc><nl>
<t mginputdevicesetinputtypefunc><nl>
<t mginputdevicestartfunc><nl>
<t mgdeviceinputdata><nl>
<t mginputdevice><nl>
<t mggraphicdrawfunc><nl>
<t mggraphicviewdata><nl>
<t mggraphicdrawmode><nl>
<t mghierarchydrawfunc><nl>
<t mghierarchyviewdata><nl>
<t mgglcontext><nl>
<t mghelpcontext><nl>

@group2 New Functions

@group3 Info Functions

@normal
<f mgGetVersion><nl>

@group3 I/O Functions

@normal
<f mgIsDb><nl>

@group3 Attribute Functions

@normal
<f mgGetVtxCoord><nl>
<f mgSetVtxCoord><nl>
<f mgRemoveVtxNormal><nl>

@group3 Input Device Plug-in Tool Class
@normal

<f mgRegisterInputDevice><nl>
<f mgInputDeviceGetHandle><nl>
<f mgInputDeviceSetVertex><nl>
<f mgInputDeviceSetPoint><nl>
<f mgInputDeviceSetButtonStatus><nl>
<f mgInputDeviceSetDeviceData><nl>
<f mgInputDeviceSendEvent><nl>
<f mgInputDeviceGetDeviceData><nl>
<f mgInputDeviceGetButtonStatus><nl>

@group3 Image Importer Plug-in Tool Class
@normal

Function <f mgSetTextureSampleSize> now allows sample sizes of
8 or 16 bits.

<f mgSetTextureMinMax><nl>
<f mgSetTextureTransparentValue><nl>
<f mgSetTextureSignedFlag><nl>
<f mgSetReadImageGeoInfoFunc><nl>
<f mgSetTextureGeoType><nl>
<f mgSetTextureGeoProjection><nl>
<f mgSetTextureGeoEarthModel><nl>
<f mgSetTextureGeoUTMZone><nl>
<f mgSetTextureGeoUTMHemisphere><nl>
<f mgSetTextureGeoImageOrigin><nl>
<f mgSetTextureGeoNumCtlPts><nl>
<f mgSetTextureGeoCtlPt><nl>

@group3 Image Geo Coordinate Access
@normal

<f mgGeoCoordGet><nl>
<f mgGeoCoordAdd><nl>
<f mgGeoCoordDelete><nl>

@group3 Data Extension Site Functions
@normal

<f mgRegisterGraphicDraw><nl>
<f mgRegisterHierarchyDraw><nl>
<f mgRegisterCreate><nl>

@group3 Image Info Functions
@normal

<f mgReadImageInfo><nl>
<f mgGetTextureType><nl>
<f mgGetTextureWidth><nl>
<f mgGetTextureHeight><nl>
<f mgGetTextureSampleSize><nl>
<f mgGetTextureTiledFlag><nl>
<f mgGetTextureMinMax><nl>
<f mgHasTextureTransparentValue><nl>
<f mgGetTextureTransparentValue><nl>
<f mgGetTextureSignedFlag><nl>
<f mgFreeImageInfo><nl>

@group3 Georeferenced Image Info Functions
@normal

<f mgReadImageGeoInfo><nl>
<f mgGetTextureGeoType><nl>
<f mgGetTextureGeoProjection><nl>
<f mgGetTextureGeoEarthModel><nl>
<f mgGetTextureGeoUTMZone><nl>
<f mgGetTextureGeoUTMHemisphere><nl>
<f mgGetTextureGeoImageOrigin><nl>
<f mgGetTextureGeoNumCtlPts><nl>
<f mgGetTextureGeoCtlPt><nl>
<f mgFreeImageGeoInfo><nl>

@group3 General Controls

@normal
<f mgGuiSetToolTip><nl>

@group3 Scale Controls

@normal
<f mgScaleSetValue><nl>
<f mgScaleGetValue><nl>
<f mgScaleSetMinMax><nl>
<f mgScaleGetMinMax><nl>
<f mgScaleSetSpinBuddy><nl>
<f mgScaleSetTextBuddy><nl>
<f mgScaleSetSpinIncrement><nl>
<f mgScaleSetTextFormat><nl>

@group3 Progress Controls

@normal
<f mgProgressSetValue><nl>
<f mgProgressGetValue><nl>
<f mgProgressStepValue><nl>
<f mgProgressSetMinMax><nl>
<f mgProgressGetMinMax><nl>
<f mgProgressSetStepIncrement><nl>

@group3 Text Controls

@normal
<f mgTextSetSpinBuddy><nl>
<f mgTextSetSpinIncrement><nl>
<f mgTextSetTextFormat><nl>

@group3 GL Controls

@normal
<f mgGLSetMouseFunc><nl>
<f mgDrawControl><nl>

@group3 Online Help

@normal
<f mgRegisterHelpFile><nl>
<f mgGuiSetHelpContext><nl>
<f mgShowHelpContext><nl>
<m MTA_HELPCONTEXT><nl>

@group3 Timers

@normal
<f mgRegisterTimer><nl>
<f mgUnregisterTimer><nl>

@group3 Sizing and Positioning Controls and Dialogs

@normal
<f mgGuiGetSize><nl>
<f mgGuiSetSize><nl>
<f mgGuiGetPos><nl>
<f mgGuiSetPos><nl>
<f mgGuiGetViewSize><nl>
<f mgDialogSetAttribute><nl>

@group3 Property Lists for Controls and Dialogs

@normal
<f mgGuiPutProperty><nl>
<f mgGuiGetProperty><nl>
<f mgGuiDeleteProperty><nl>

@group3 Focus Vertex Lists

@normal
<f mgClearFocusVertex><nl>
<f mgFocusVertexListAddItem><nl>
<f mgFocusVertexListDeleteAllItems><nl>
<f mgFocusVertexListDeleteItem><nl>
<f mgGetFocusVertex><nl>
<f mgSetFocusVertex><nl>

@group3 Eyepoint Look At

@normal
<f mgGetCurrentLookAt><nl>
<f mgSetCurrentLookAt><nl>

@group3 Texture Mapping Palette

@normal
<f mgGetTextureMapping><nl>
<f mgIndexOfTextureMapping><nl>
<f mgGetTextureMappingCount><nl>
<f mgNewTextureMapping><nl>
<f mgDelTextureMapping><nl>
<f mgDelTextureMappingByName><nl>
<f mgReadTextureMappingFile><nl>
<f mgWriteTextureMappingFile><nl>

@end
*/

/* module stuff */

/*
@doc MODULE

@submodule Attribute Functions |
List of attribute functions
@index func | ATTRIBUTEFUNC

@submodule Focus Vertex Functions |
List of focus vertex functions
@index func | FOCUSVERTEXFUNC

@submodule Switch Functions |
List of switch functions
@index func | SWITCHFUNC

@submodule Mesh Functions |
List of mesh functions
@index func | MESHFUNC

@submodule EyePoint Functions |
List of eyepoint functions
@index func | EYEFUNC

@submodule Graphic View Functions |
List of graphic view functions
@index func | GRAPHICVIEWFUNC

@submodule Base Functions |
List of basic functions
@index func | BASEFUNC

@submodule Color Functions |
List of color functions
@index func | COLORFUNC

@submodule Info Functions |
List of info functions
@index func | INFOFUNC

@submodule Input Device Functions |
List of input device functions
@index func | INPUTDEVFUNC

@submodule I/O Functions |
List of I/O functions
@index func | IOFUNC

@submodule Material Functions |
List of material functions
@index func | MATERIALFUNC

@submodule Memory Functions |
List of memory functions
@index func | MEMORYFUNC

@submodule Light Source Functions |
List of light source functions
@index func | LIGHTSOURCEFUNC

@submodule Light Point Functions |
List of light point functions
@index func | LIGHTPOINTFUNC

@submodule Sound Functions |
List of sound functions
@index func | SOUNDFUNC

@submodule Texture Functions |
List of texture functions
@index func | TEXTUREFUNC

@submodule Texture Mapping Functions |
List of texture mapping functions
@index func | TXTRMAPFUNC

@submodule Dynamic Array Functions |
List of dynamic array functions
@index func | POINTERARRAYFUNC

@submodule Preference Functions |
List of preference functions
@index func | PREFFUNC

@submodule Structure Functions |
List of structure functions
@index func | STRUCFUNC

@submodule Select List Functions |
List of select list functions
@index func | SELECTFUNC

@submodule Geometry Functions |
List of geometry functions
@index func | GEOMETRYFUNC

@submodule Matrix Functions |
List of matrix functions
@index func | MATRIXFUNC

@submodule Matrix Stack Functions |
List of matrix stack functions
@index func | MATRIXSTACKFUNC

@submodule Resource Functions |
List of functions used to access the contents of a resource, including
dialogs, pixmaps and string definitions.
@index func | RESOURCEFUNC

@submodule Dialog Functions |
List of functions used to manipulate all classes of dialogs.
@index func | DIALOGFUNC

@submodule General Controls |
List of functions applicable to all classes of controls.
@index func | GENERALCONTROLFUNC

@submodule Text Controls |
List of functions used to manipulate text controls.
@index func | TEXTCONTROLFUNC

@submodule GL Functions |
List of functions used to manipulate GL controls.
@index func | GLFUNC

@submodule Toggle Button Controls |
List of functions used to manipulate toggle button controls.
@index func | TOGGLEBUTTONCONTROLFUNC

@submodule Menu Controls |
List of functions used to manipulate menu controls.
@index func | MENUCONTROLFUNC

@submodule Option Menu Controls |
List of functions used to manipulate option menu controls.
@index func | OPTIONMENUCONTROLFUNC

@submodule List Controls |
List of functions used to manipulate list controls.
@index func | LISTCONTROLFUNC

@submodule Scale Controls |
List of functions used to manipulate scale controls.
@index func | SCALECONTROLFUNC

@submodule Progress Controls |
List of functions used to manipulate progress controls.
@index func | PROGRESSFUNC

@submodule Notifier Functions |
List of notifier functions
@index func | NOTIFIERFUNC

@submodule Tool Registration Functions |
List of tool registration functions
@index func | TOOLREGISTERFUNC

@submodule Extension Registration Functions |
List of data extension registration functions
@index func | SITEREGISTERFUNC

@submodule Editor Context Functions |
List of editor context functions
@index func | EDITORCONTEXTFUNC

@submodule Construction Functions |
List of Construction functions
@index func | CONSTRUCTIONFUNC

@submodule Tool Activation Functions |
List of tool activation functions
@index func | TOOLACTIVATIONFUNC

@submodule Timer Functions |
List of Timer functions
@index func | TIMERFUNC

@submodule Data Dictionary Functions |
List of data dictionary functions
@index func | DATADICTIONARYFUNC

@submodule Online Help Functions |
List of online help functions
@index func | ONLINEHELPFUNC



*/

/* index stuff */

/*

@doc INDEX

@contents1 |

@menu Index |
@subindex Introduction | mgapi.htm#Introduction TARGET=content
@subindex API Version | mgapi.htm#API_Version TARGET=content
@subindex OpenFlight Format Version | mgapi.htm#OpenFlight_Format_Version TARGET=content
@subindex Release Notes | mgapi.htm#OpenFlight_API_Release_Notes TARGET=content
@subindex Required Plugin Symbols |
@subindex Data Types |
@subindex Constants |
@subindex Macros |
@subindex Obsolete API |
@subindex Deprecated API |
@subindex Function Categories |
@subindex Functions |

@module Data Types |
@index struct,structtype,enum,enumtype,flagtype,type,uniontype,cb |

@module Constants | 
@index msg |

@module Macros | 
@index macro |

@module Deprecated API |
@index deprecated | 

@module Obsolete API |
@index obsolete |

@module Required Plugin Symbols |
This section lists all the symbols a plugin module must declare
to be recognized as a valid plugin module.
@index func | REQUIREDFUNC

@module Function Categories |
@linkindex submodule | | s/HREF=mgapi.htm#(.*?) TARGET=content/HREF=#$1/g

@module Functions |
@index func |

*/


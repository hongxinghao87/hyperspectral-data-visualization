/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIPLUGIN_H_
#define MGAPIPLUGIN_H_

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#ifdef API_LEV5
#include "mgapiplugin4.h"
#endif

#ifdef API_LEV4
#include "mgapiplugin4.h"
#endif

#ifdef API_LEV3
#include "mgapiplugin4.h"
#endif

#ifdef API_LEV2
#endif

#ifdef API_LEV1
#endif

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPIPLUGIN_H_ */
/* DON'T ADD STUFF AFTER THIS #endif */


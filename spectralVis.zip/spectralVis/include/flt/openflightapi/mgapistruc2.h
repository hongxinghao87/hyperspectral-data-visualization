/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPISTRUC2_H_
#define MGAPISTRUC2_H_
// @doc EXTERNAL STRUCFUNC

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/* @func mgrec * | mgNewRec | allocates a new node record
	@desc Given a node record code <p code>, <f mgNewRec> allocates
	and initializes a node record of the type defined by <p code>.  
	A new node is returned if the action is successful.
	The new node is an orphan, meaning that it is not attached to any
	other node in the hierarchy.  Use <f mgAttach>, <f mgAppend> or
	<f mgInsert> to attach the node into the database hierarchy.
	@desc Note: Valid codes for this function include all node type record
	codes except <flt fltHeader> and all transformation node type record
	codes (<flt fltXmTranslate >, <flt fltXmScale>, etc). 
	Since <flt fltHeader> is the root of a database, use <f mgNewDb> or
	<f mgOpenDb> to create.

	@return Returns the pointer to the newly created node record if successful,
	<m MG_NULL> otherwise.
	@ex | 
	mgrec *db, *parRec, *poly1, *poly2, *poly3;
	db = mgOpenDb ( "file1.flt" );
	parRec = UserGetParentNodeFunc ( db );
	poly1 = mgNewRec ( fltPolygon ); 
	poly2 = mgNewRec ( fltPolygon );
	poly3 = mgNewRec ( fltPolygon );
	mgAttach ( parRec, poly1 );  // poly1 is first child of parRec
	mgAppend ( parRec, poly2 );  // poly2 is the last child of parRec
	mgInsert ( poly2, poly3 );   // poly3 is the next-to-last child of parRec
	@access Level 2
	@see <f mgDuplicate>, <f mgDuplicateToDb>, <f mgDelete>, <f mgAttach>,
	<f mgAppend>, <f mgInsert>, <f mgReference>
*/
extern MGAPIFUNC(mgrec*) mgNewRec ( 
									mgcode rcode // @param the code for the new record
									);

/* @func mgrec * | mgDuplicate | duplicates a node record in the database
	@desc Given a node record <p rec> in a database, <f mgDuplicate> duplicates
	this node and all of its descendants, returning the new (duplicate) node.
	@desc Note: The node returned can be attached ONLY to another node contained in
	the same database as the original node.  If you want to attach the duplicate node
	to a node contained in another database, use <f mgDuplicateToDb> to create the
	duplicate node.
	@return Returns the new node if successful, otherwise <m MG_NULL>.
	@see <f mgDuplicateToDb>
	@access Level 2
*/
extern MGAPIFUNC(mgrec*) mgDuplicate ( 											  
									mgrec* rec // @param the node to duplicate
									);

/* @func mgrec * | mgDuplicateToDb | duplicates a node record in one database
	for attaching into another database
	@desc Given a node record <p rec> in one database, <f mgDuplicateToDb> 
	duplicates this node and all of its descendants, returning the new 
	(duplicate) node that can be attached to a node contained in the 
	database <p toDb>.  Unlike <f mgDuplicate>, this function allows you
	to copy nodes from one database to another.

   @desc The node returned can be attached ONLY to a node contained in
	the database <p toDb>.  If you specify <p toDb> as <m MG_NULL> or the 
	database that contains <p rec>, it is equivalent to calling <f mgDuplicate>.

   @desc Note: This function does not resolve palette indicies between the 
	source and destination databases.  So if you copy between two databases
	that have "different" palette entries, the duplicate node (and nodes below)
	returned will reference palette entries in the destination database.
	
	@return Returns the new node if successful, otherwise <m MG_NULL>.
	@see <f mgDuplicate>
	@access Level 2
*/
extern MGAPIFUNC(mgrec*) mgDuplicateToDb ( 											  
									mgrec* rec,	// @param the node to duplicate
									mgrec* db	// @param the database where you are
													// going to attach the duplicate
									);

/* @func mgbool | mgDelete | deletes a node record
	@desc Given a node record <p rec>, <f mgDelete> deletes it. If the record
	is a node in the database, and has children, its descendants are recursively
	deleted as well. This deletion is permanent and there is no "undo".
	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@access Level 2
	@see <f mgDetach>, <f mgRemove>, <f mgUnRemove>
*/
extern MGAPIFUNC(mgbool) mgDelete ( 
									mgrec* rec // @param the record to delete
									);

/* @func mgbool | mgDetach | unlinks a node record from the database hierarchy
	@desc <f mgDetach> unlinks a node record, <p rec>,  and its children from the database 
	hierarchy. The node is left as an orphan, and is not deleted. 
	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@access Level 2
	@see <f mgDelete>, <f mgRemove>, <f mgUnRemove>
*/
extern MGAPIFUNC(mgbool) mgDetach ( 
									mgrec* rec // @param the record to detach
									);

/* @func mgbool | mgAttach | links a node record into the database hierarchy
	@desc Given a parent node record <p parent>, <f mgAttach> links a node record, <p child>, 
	and its children into the database hierarchy.  The resulting hierarchy has <p child> as 
	the first child of <p parent>.

	@desc If <p parent> nad <p child> are both <flt fltPolygon> records, <p child> is attached
	as a nested child of <p parent>.  Otherwise <p child> is attached as a normal child of
	<p parent>.

	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@ex |
   mgrec *db, *parRec, *poly1, *poly2, *poly3;
   db = mgOpenDb ( "file1.flt" );
   parRec = UserGetParentNodeFunc ( db );
   poly1 = mgNewRec ( fltPolygon );
   poly2 = mgNewRec ( fltPolygon );
   poly3 = mgNewRec ( fltPolygon );
   mgAttach ( parRec, poly1 );  // poly1 is first child of parRec
   mgAppend ( parRec, poly2 );  // poly2 is the last child of parRec
   mgInsert ( poly2, poly3 );   // poly3 is inserted "after" poly2

	@access Level 2
	@see <f mgAppend>, <f mgInsert>
*/
extern MGAPIFUNC(mgbool) mgAttach (
									mgrec* parent, // @param the parent node record
									mgrec* child	// @param the node record to be inserted into the hierarchy
									);

/* @func mgbool | mgAppend | links a node record into the database hierarchy
	@desc Given a parent node <p parent>, <f mgAppend> links a node record, <p child>,
	and its children into the database hierarchy.  The resulting hierarchy has <p child>
	as the last child of <p parent>.

	@desc If <p parent> nad <p child> are both <flt fltPolygon> records, <p child> is attached
	as a nested child of <p parent>.  Otherwise <p child> is attached as a normal child of
	<p parent>.

	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@ex |
   mgrec *db, *parRec, *poly1, *poly2, *poly3;
   db = mgOpenDb ( "file1.flt" );
   parRec = UserGetParentNodeFunc ( db );
   poly1 = mgNewRec ( fltPolygon );
   poly2 = mgNewRec ( fltPolygon );
   poly3 = mgNewRec ( fltPolygon );
   mgAttach ( parRec, poly1 );  // poly1 is first child of parRec
   mgAppend ( parRec, poly2 );  // poly2 is the last child of parRec
   mgInsert ( poly2, poly3 );   // poly3 is inserted "after" poly2

	@access Level 2
	@see <f mgAttach>, <f mgInsert>
*/
extern MGAPIFUNC(mgbool) mgAppend ( 
									mgrec* parent, // @param the parent node record
									mgrec* child	// @param the node record to be inserted into the hierarchy
									);

/* @func mgbool | mgInsert | links a node record into the database hierarchy
	@desc Given a sibling node <p sibling>, <f mgInsert> links a node record, <p child>,
	and its children into the database hierarchy.  The resulting hierarchy has <p child>
	as the next sibling of <p sibling>.
	@desc This function does not work for transformation node records.
	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@ex |
   mgrec *db, *parRec, *poly1, *poly2, *poly3;
   db = mgOpenDb ( "file1.flt" );
   parRec = UserGetParentNodeFunc ( db );
   poly1 = mgNewRec ( fltPolygon );
   poly2 = mgNewRec ( fltPolygon );
   poly3 = mgNewRec ( fltPolygon );
   mgAttach ( parRec, poly1 );  // poly1 is first child of parRec
   mgAppend ( parRec, poly2 );  // poly2 is the last child of parRec
   mgInsert ( poly2, poly3 );   // poly3 is inserted "after" poly2

	@access Level 2
	@see <f mgAttach>, <f mgAppend>
*/
extern MGAPIFUNC(mgbool) mgInsert ( 
									mgrec* sibling,	// @param the sibling node record
									mgrec* child		// @param the node record to be inserted into the hierarchy
									);

/* @func mgbool | mgReference | changes an existing node record into an instance node record
	@desc Given an existing node record <p rec>, <f mgReference> causes rec to become an instance 
	of the reference node record <p refRec>.
	@desc The node <p refRec> must not be a child node of any node in the database.
	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@access Level 2
	@see <f mgDeReference>
*/
extern MGAPIFUNC(mgbool) mgReference ( 
									mgrec* rec,		// @param a node record, which will be an instance of the reference node.
									mgrec* refRec // @param a reference node record.
									);

/* @func mgbool | mgDeReference | makes an existing instance node record into a regular node record
	@desc <f mgDeReference> removes the instance relationship between <p rec> and its reference node. 
	@return Returns <e mgbool.MG_TRUE> if successful, otherwise <e mgbool.MG_FALSE>.
	@access Level 2
	@see <f mgReference>
*/

extern MGAPIFUNC(mgbool) mgValidAttach ( 
									mgcode parentCode,	// @param the parent record code
									mgcode childCode		// @param the child record code
									);

/* @func mgbool | mgValidAttach | determines whether an attach operation would be valid
	@desc <f mgValidAttach> checks if a node whose code is <p childCode> could be attached
	to a node whose code is <p parentCode> using one of <f mgAttach>, <f mgAppend> or 
	<f mgInsert>.
   @return <e mgbool.MG_TRUE> if attach would be valid, <e mgbool.MG_FALSE> otherwise.
	@access Level 2
	@see <f mgAttach>, <f mgAppend>, <f mgInsert>
*/
extern MGAPIFUNC(mgbool) mgDeReference ( 
									mgrec* rec // @param an instance node record
									);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */


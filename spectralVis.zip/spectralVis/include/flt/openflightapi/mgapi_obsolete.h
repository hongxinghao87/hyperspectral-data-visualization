/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPI_OBSOLETE_H_
#define MGAPI_OBSOLETE_H_

/* @doc EXTERNAL */

/*############################################################################*/
/*############################################################################*/
/*###                                                                         */
/*###   The function definitions and other information defined in this header */
/*###   file are unsupported and may be removed in future releases.           */
/*###                                                                         */
/*############################################################################*/
/*############################################################################*/


#ifdef __cplusplus
extern "C" {
#endif

#include "mgapistruc1.h"
#include "mgapidd1.h"

/* 
@deprecated fltVbead | Use <flt fltVertex>
@deprecated fltLodFloat | Use <flt fltLod>
@deprecated fltIcoord | Use <flt fltCoord3d>
@deprecated fltIcoordX | Use <flt fltCoord3dX>
@deprecated fltIcoordY | Use <flt fltCoord3dY>
@deprecated fltIcoordZ | Use <flt fltCoord3dZ>

@deprecated fltFCoord | Use <flt fltCoord3f>
@deprecated fltFCoordX | Use <flt fltCoord3fX>
@deprecated fltFCoordY | Use <flt fltCoord3fY>
@deprecated fltFCoordZ | Use <flt fltCoord3fZ>

@deprecated fltIPoint | Use <flt fltCoord2i>
@deprecated fltIPointX | Use <flt fltCoord2iX>
@deprecated fltIPointY | Use <flt fltCoord2iY>

@deprecated fltPolyMgTemplate | Use <flt fltPolyTemplate>
@deprecated fltPolyTexture1 | Use <flt fltPolyDetailTexture>
@deprecated fltPolyTexmap1 | Use <flt fltPolyDetailTexmap>
@deprecated fltCatTexture1 | Use <flt fltCatDetailTexture>

@deprecated fltPolyFlagNocolor | Use <flt fltPolyNoPrimeColor>
@deprecated fltPolyFlagNocolor2 | Use <flt fltPolyNoAltColor>
@deprecated fltPolyFlagRgbMode | Use <flt fltPolyRgbMode>
@deprecated fltPolyFlagTerrain | Use <flt fltPolyTerrain>
@deprecated fltPolyFlagHidden | Use <flt fltPolyHidden>
@deprecated fltPolyFlagFootprint | Use <flt fltPolyFootprint>

@deprecated fltObjFlagDay | Use <flt fltObjDay>
@deprecated fltObjFlagDusk | Use <flt fltObjDusk>
@deprecated fltObjFlagNight | Use <flt fltObjNight>
@deprecated fltObjFlagNoillum | Use <flt fltObjNoillum>
@deprecated fltObjFlagNoshade | Use <flt fltObjNoshade>
@deprecated fltObjFlagShadow | Use <flt fltObjShadow>

@deprecated fltGrpFlagAnimation | Use <flt fltGrpAnimation>
@deprecated fltGrpFlagAnimationFB | Use <flt fltGrpAnimationFB>
@deprecated fltGrpFlagBoxed | Use <flt fltGrpBoxed>
@deprecated fltGrpFlagFreezeBox | Use <flt fltGrpFreezeBox>

@deprecated fltDofFlagXLimited | Use <flt fltDofLimitX>
@deprecated fltDofFlagYLimited | Use <flt fltDofLimitY>
@deprecated fltDofFlagZLimited | Use <flt fltDofLimitZ>
@deprecated fltDofFlagAzimLimited | Use <flt fltDofLimitXRot>
@deprecated fltDofFlagInclLimited | Use <flt fltDofLimitYRot>
@deprecated fltDofFlagTwistLimited | Use <flt fltDofLimitZRot>
@deprecated fltDofFlagXScaleLimited | Use <flt fltDofLimitXScale>
@deprecated fltDofFlagYScaleLimited | Use <flt fltDofLimitYScale>
@deprecated fltDofFlagZScaleLimited | Use <flt fltDofLimitZScale>
@deprecated fltDofFlagTxtRepeat | Use <flt fltDofTxtRepeat>
@deprecated fltDofFlagMembrane | Use <flt fltDofMembrane>

@deprecated fltDofCurAzim | Use <flt fltDofCurXRot>
@deprecated fltDofCurIncl | Use <flt fltDofCurYRot>
@deprecated fltDofCurTwist | Use <flt fltDofCurZRot>

@deprecated fltDofIncrementAzim | Use <flt fltDofIncXRot>
@deprecated fltDofIncrementIncl | Use <flt fltDofIncYRot>
@deprecated fltDofIncrementTwist | Use <flt fltDofIncZRot>

@deprecated fltDofIncrementX | Use <flt fltDofIncX>
@deprecated fltDofIncrementXScale | Use <flt fltDofIncXScale>

@deprecated fltDofIncrementY | Use <flt fltDofIncY>
@deprecated fltDofIncrementYScale | Use <flt fltDofIncYScale>

@deprecated fltDofIncrementZ | Use <flt fltDofIncZ>
@deprecated fltDofIncrementZScale | Use <flt fltDofIncZScale>

@deprecated fltDofMaxAzim | Use <flt fltDofMaxXRot>
@deprecated fltDofMaxIncl | Use <flt fltDofMaxYRot>
@deprecated fltDofMaxTwist | Use <flt fltDofMaxZRot>

@deprecated fltDofMinAzim | Use <flt fltDofMinXRot>
@deprecated fltDofMinIncl | Use <flt fltDofMinYRot>
@deprecated fltDofMinTwist | Use <flt fltDofMinZRot>

@deprecated fltHdrFlagVtxNorms | Use <flt fltHdrSaveVtxNorms>

@deprecated fltLodFlagAdditive | Use <flt fltLodAdditive>
@deprecated fltLodFlagFreezeCenter | Use <flt fltLodFreezeCenter>
@deprecated fltLodFlagRange | Use <flt fltLodUsePrevRange>
@deprecated fltLpAttr | Use <flt fltLpAppearancePalette> and <flt fltLpAnimationPalette>

*/

#define MGWALKNEXT			MWALK_NEXT			/* @deprecated MGWALKNEXT | Use <m MWALK_NEXT> */
#define MGWALKON				MWALK_ON				/* @deprecated MGWALKON | Use <m MWALK_ON> */
#define MGWALKMASTER			MWALK_MASTER		/* @deprecated MGWALKMASTER | Use <m MWALK_MASTER> */
#define MGWALKNORDONLY		MWALK_NORDONLY		/* @deprecated MGWALKNORDONLY | Use <m MWALK_NORDONLY> */
#define MGWALKVERTEX			MWALK_VERTEX		/* @deprecated MGWALKVERTEX | Use <m MWALK_VERTEX> */
#define MGWALKMASTERALL		MWALK_MASTERALL	/* @deprecated MGWALKMASTERALL | Use <m MWALK_MASTERALL> */
#define MGWALKATTR			MWALK_ATTR			/* @deprecated MGWALKATT | Use <m MWALK_ATTR> */

#define XLL_TRANSLATE		MXLL_TRANSLATE		/* @deprecated XLL_TRANSLATE | Use <e mgxfllcode.MXLL_TRANSLATE> */
#define XLL_SCALE				MXLL_SCALE			/* @deprecated XLL_SCALE | Use <e mgxfllcode.MXLL_SCALE> */
#define XLL_ROTEDGE			MXLL_ROTEDGE		/* @deprecated XLL_ROTEDGE | Use <e mgxfllcode.MXLL_ROTEDGE	> */
#define XLL_ROTPT				MXLL_ROTPT			/* @deprecated XLL_ROTPT | Use <e mgxfllcode.MXLL_ROTPT> */
#define XLL_PUT				MXLL_PUT				/* @deprecated XLL_PUT | Use <e mgxfllcode.MXLL_PUT> */
#define XLL_TOPOINT			MXLL_TOPOINT		/* @deprecated XLL_TOPOINT | Use <e mgxfllcode.MXLL_TOPOINT> */
#define XLL_GENERAL			MXLL_GENERAL		/* @deprecated XLL_GENERAL | Use <e mgxfllcode.MXLL_GENERAL> */

#define mgITYPE_INT			MIMG_INT				/* @deprecated mgITYPE_INT  | Use <m MIMG_INT> */
#define mgITYPE_INTA			MIMG_INTA			/* @deprecated mgITYPE_INTA | Use <m MIMG_INTA> */
#define mgITYPE_RGB			MIMG_RGB				/* @deprecated mgITYPE_RGB  | Use <m MIMG_RGB> */
#define mgITYPE_RGBA			MIMG_RGBA			/* @deprecated mgITYPE_RGBA | Use <m MIMG_RGBA> */

typedef mgwalkfunc mgwalk_func;					/* @deprecated mgwalk_func | Use <t mgwalkfunc> */

typedef mggetmaxidfunc GetMaxIdFunc;				/* @deprecated GetMaxIdFunc | Use <t mggetmaxidfunc> */
typedef mgsetmaxidfunc SetMaxIdFunc;				/* @deprecated SetMaxIdFunc | Use <t mgsetmaxidfunc> */
typedef mggetheadercodefunc GetHeaderCodeFunc;	/* @deprecated GetHeaderCodeFunc | Use <t mggetheadercodefunc> */

#define action_get		MACTION_GET				/* @deprecated action_get | Do not use */
#define action_set		MACTION_SET				/* @deprecated action_set | Do not use */
#define action_print		MACTION_PRINT			/* @deprecated action_print | Do not use */
typedef mgactiontype action_type;				/* @deprecated action_type | Do not use */

/*============================================================================*/

extern MGAPIFUNC(char) mgGetValC ( mgrec* rec );				/* @deprecated mgGetValC | Use <f mgGetAttList> */
extern MGAPIFUNC(short) mgGetValS ( mgrec* rec );				/* @deprecated mgGetValS | Use <f mgGetAttList> */
extern MGAPIFUNC(int) mgGetValI ( mgrec* rec );					/* @deprecated mgGetValI | Use <f mgGetAttList> */
extern MGAPIFUNC(float) mgGetValF ( mgrec* rec );				/* @deprecated mgGetValF | Use <f mgGetAttList> */
extern MGAPIFUNC(double) mgGetValD ( mgrec* rec );				/* @deprecated mgGetValD | Use <f mgGetAttList> */
extern MGAPIFUNC(void) *mgGetValP ( mgrec* rec );				/* @deprecated mgGetValP | Use <f mgGetAttList> */
extern MGAPIFUNC(unsigned char) mgGetValUC ( mgrec* rec );	/* @deprecated mgGetValUC | Use <f mgGetAttList> */
extern MGAPIFUNC(unsigned short) mgGetValUS ( mgrec* rec );	/* @deprecated mgGetValUS | Use <f mgGetAttList> */
extern MGAPIFUNC(unsigned int) mgGetValUI ( mgrec* rec );	/* @deprecated mgGetValUI | Use <f mgGetAttList> */
extern MGAPIFUNC(char) mgGetChar ( mgrec* rec );				/* @deprecated mgGetChar | Use <f mgGetAttList> */
extern MGAPIFUNC(char) *mgGetText ( mgrec* rec );				/* @deprecated mgGetText | Use <f mgGetAttList> */
extern MGAPIFUNC(unsigned int) mgGetValBits ( mgrec* rec );	/* @deprecated mgGetValBits | Use <f mgGetAttList> */
extern MGAPIFUNC(mgbool) mgGetFlag ( mgrec* rec );				/* @deprecated mgGetFlag | Use <f mgGetAttList> */
	
extern MGAPIFUNC(mgrec) *mgGetAttNth ( mgrec* rec0, int nth );  										/* @deprecated mgGetAttNth | Use <f ddGetFieldNth> and <f mgGetAttList> */

extern MGAPIFUNC(char) *mgCode2Buf ( mgrec* rec0, mgcode fcode, attr_def** aptr_out );  	/* @deprecated mgCode2Buf | Do not use */


extern MGAPIFUNC(void) mgSetValC ( mgrec* rec, char cval );					/* @deprecated  mgSetValC | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValS ( mgrec* rec, short sval );				/* @deprecated  mgSetValS | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValI ( mgrec* rec, int ival );					/* @deprecated  mgSetValI | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValF ( mgrec* rec, float fval );				/* @deprecated  mgSetValF | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValD ( mgrec* rec, double dval );				/* @deprecated  mgSetValD | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValP ( mgrec* rec, void* ptr );					/* @deprecated  mgSetValP | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValIP ( mgrec* rec, int* ptr );					/* @deprecated  mgSetValIP | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValUC ( mgrec* rec, unsigned char cval );	/* @deprecated  mgSetValUC | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValUS ( mgrec* rec, unsigned short sval );	/* @deprecated  mgSetValUS | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValUI ( mgrec* rec, int ival );					/* @deprecated  mgSetValUI | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetChar ( mgrec* rec, char* text );				/* @deprecated  mgSetChar | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetText ( mgrec* rec, char* text );				/* @deprecated  mgSetText | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetValBits ( mgrec* rec, unsigned int ival );	/* @deprecated  mgSetValBits | Use <f mgSetAttList> */
extern MGAPIFUNC(void) mgSetFlag ( mgrec* rec, mgbool flag );				/* @deprecated  mgSetFlag | Use <f mgSetAttList> */

extern MGAPIFUNC(mgbool) mgAddMatrix ( mgrec* rec, mgmatrix* matrix );					/* @deprecated mgAddMatrix | Do not use */

extern MGAPIFUNC(void) mgSetReadExtFlag ( int flag );			/* @deprecated mgSetReadExtFlag | Do not use */
extern MGAPIFUNC(int) mgGetRepCount ( mgrec* rec );			/* @deprecated mgGetRepCount | Use <f mgGetAttList> with <flt fltRepCnt> */
extern MGAPIFUNC(mgbool) mgGetAttXmBuf ( mgrec* xrec, mgcode fcode, void* buf );		/* @deprecated mgGetAttXmBuf | Do not use */

extern MGAPIFUNC(mgbool) mgIsBsp ( mgrec* rec );			/* @deprecated mgIsBsp | Use <f mgIsCode> ( rec, <flt fltBsp>) */
extern MGAPIFUNC(mgbool) mgIsDof ( mgrec* rec );			/* @deprecated mgIsDof | Use <f mgIsCode> ( rec, <flt fltDof>) */
extern MGAPIFUNC(mgbool) mgIsGroup ( mgrec* rec );			/* @deprecated mgIsGroup | Use <f mgIsCode> ( rec, <flt fltGroup>) */
extern MGAPIFUNC(mgbool) mgIsHeader ( mgrec* rec );		/* @deprecated mgIsHeader | Use <f mgIsCode> ( rec, <flt fltHeader>) */
extern MGAPIFUNC(mgbool) mgIsLightSource ( mgrec* rec );	/* @deprecated mgIsLightSource | Use <f mgIsCode> ( rec, <flt fltLightSource>) */
extern MGAPIFUNC(mgbool) mgIsLod ( mgrec* rec );			/* @deprecated mgIsLod | Use <f mgIsCode> ( rec, <flt fltLod>) */
extern MGAPIFUNC(mgbool) mgIsObject ( mgrec* rec );		/* @deprecated mgIsObject | Use <f mgIsCode> ( rec, <flt fltObject>) */
extern MGAPIFUNC(mgbool) mgIsPolygon ( mgrec* rec );		/* @deprecated mgIsPolygon | Use <f mgIsCode> ( rec, <flt fltPolygon>) */
extern MGAPIFUNC(mgbool) mgIsSound ( mgrec* rec );			/* @deprecated mgIsSound | Use <f mgIsCode> ( rec, <flt fltSound>) */
extern MGAPIFUNC(mgbool) mgIsSwitch ( mgrec* rec );		/* @deprecated mgIsSwitch | Use <f mgIsCode> ( rec, <flt fltSwitch>) */
extern MGAPIFUNC(mgbool) mgIsPath ( mgrec* rec );			/* @deprecated mgIsPath | Use <f mgIsCode> ( rec, <flt fltPath>) */
extern MGAPIFUNC(mgbool) mgIsVertex ( mgrec* rec );		/* @deprecated mgIsVertex | Use <f mgIsCode> ( rec, <flt fltVertex>) */
extern MGAPIFUNC(mgbool) mgIsXref ( mgrec* rec );			/* @deprecated mgIsXref | Use <f mgIsCode> ( rec, <flt fltXref>) */

extern MGAPIFUNC(tagtype) mgGetType ( mgrec* rec );		/* @deprecated mgGetType | Use <f ddGetTagType> */

/* @deprecated mgGetPackedColor | Do not use */
extern MGAPIFUNC(mgbool) mgGetPackedColor ( mgrec* rec, mgcode colorRgbaCode, unsigned char* r, unsigned char* g, unsigned char* b, unsigned char* a);
/* @deprecated mgSetPackedColor | Do not use */
extern MGAPIFUNC(mgbool) mgSetPackedColor ( mgrec* rec, mgcode packedcolorCode, unsigned char r, unsigned char g, unsigned char b, unsigned char a );

/* @deprecated mgRegisterCallback | Use <f mgRegisterGetMaxId>, <f mgRegisterSetMaxId>, and <f mgRegisterGetHeaderCode> */
extern MGAPIFUNC(void) mgRegisterCallback ( mgpluginsite pluginSite, char *func_name, mgbool (*func)() );

#define ILNEXT 1			/* @deprecated ILNEXT | Use <m MWALK_NEXT> */
#define ILON 2				/* @deprecated ILON | Use <m MWALK_ON> */
#define ILMASTER 4		/* @deprecated ILMASTER | Use <m MWALK_MASTER> */
#define ILNORDONLY 8		/* @deprecated ILNORDONLY | Use <m MWALK_NORDONLY> */
#define ILVERTEX 16		/* @deprecated ILVERTEX | Use <m MWALK_VERTEX> */
#define ILMASTERALL 32	/* @deprecated ILMASTERALL | Use <m MWALK_MASTERALL> */
#define ILATTR 64			/* @deprecated ILATTR | Use <m MWALK_ATTR> */
#define ILXFORM 128		/* @deprecated ILXFORM | Do not use */

/*============================================================================
	The following symbols/functions have been removed/replaced 
\*============================================================================

@obsolete mgGetFirstTextureInPalette	|	Replaced by			<f mgGetFirstTexture>
@obsolete mgGetNextTextureInPalette		|	Replaced by			<f mgGetNextTexture>

@obsolete mgDelMaterialTableEntry		|	Replaced by			<f mgDelMaterial>
@obsolete mgDelMaterialTableEntryByName|	Replaced by			<f mgDelMaterialByName>

@obsolete mgIndexOfLtsEntry				|	Replaced by			<f mgIndexOfLightSource>
@obsolete mgNameOfLtsEntry					|	Replaced by			<f mgNameOfLightSource>
@obsolete mgGetLtsCount						|	Replaced by			<f mgGetLightSourceCount>

@obsolete mgTempLightSourceTableEntry	|	Replaced by			<f mgNewLightSource>	(different params)
@obsolete mgAddLightSourceTableEntry	|	Replaced by			<f mgNewLightSource>	(different params)

@obsolete mgGetUser 							|	Replaced by			<f mgGetUserData>
@obsolete mgSetUser 							|	Replaced by			<f mgSetUserData>

@obsolete mgGetPolyRGBA						|	Replaced by			<f mgGetPolyColorRGB>
@obsolete mgSetPolyRGBA						|	Replaced by			<f mgSetPolyColorRGB>

@obsolete mgCheckVal							|	No longer supported
@obsolete mgSetAttRec						|	Use <f mgSetAttList>
@obsolete mgSetAttFlag						|	Use <f mgSetAttList>
@obsolete mgSetAttBits						|	Use <f mgSetAttList>
@obsolete mgSetAttValUI						|	Use <f mgSetAttList>
@obsolete mgSetAttValUS						|	Use <f mgSetAttList>
@obsolete mgSetAttValUC						|	Use <f mgSetAttList>
@obsolete mgSetAttValP						|	Use <f mgSetAttList>
@obsolete mgSetAttValD						|	Use <f mgSetAttList>
@obsolete mgSetAttValI						|	Use <f mgSetAttList>
@obsolete mgSetAttValS						|	Use <f mgSetAttList>
@obsolete mgSetAttValC						|	Use <f mgSetAttList>
@obsolete mgSetAttValF						|	Use <f mgSetAttList>
@obsolete mgSetAttText						|	Use <f mgSetAttList>

@obsolete mgGetAttValC						|	Use <f mgGetAttList>
@obsolete mgGetAttValS						|	Use <f mgGetAttList>
@obsolete mgGetAttValI						|	Use <f mgGetAttList>
@obsolete mgGetAttValF 						|	Use <f mgGetAttList>
@obsolete mgGetAttValD						|	Use <f mgGetAttList>
@obsolete mgGetAttValP						|	Use <f mgGetAttList>
@obsolete mgGetAttValUC						|	Use <f mgGetAttList>
@obsolete mgGetAttValUS						|	Use <f mgGetAttList>
@obsolete mgGetAttValUI						|	Use <f mgGetAttList>
@obsolete mgGetAttText						|	Use <f mgGetAttList>
@obsolete mgGetAttFlag						|	Use <f mgGetAttList>
@obsolete mgGetAttBits						|	Use <f mgGetAttList>
@obsolete mgGetAttAddress					|	No longer supported
@obsolete mgGetAtt							|	Use <f mgGetAttList>

@end

############################################################################*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIEDITOR4_H
#define MGAPIEDITOR4_H
/* @doc EXTERNAL TOOLREGISTERFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#include "mgapicoord.h"
#include "mgapiplugin.h"
#include "mgapidialog.h"
#include "mgapiselect.h"
#include "mgapiinputdev.h"

/*============================================================================*\
	public constants
\*============================================================================*/

/*----------------------------------------------------------------------------*/

/* editor dialog button constants */
#define MBT_DONE				0			// @msg MBT_DONE | Editor dialog button event <p Done>
												// @desc This is the button event that is sent to the
												// button function for an editor tool when the user
												// presses the <p Done> button in the editor tool dialog.
												// @see <f mgRegisterEditor>, <f mgEditorSetButtonFunc>

#define MBT_NEXT				1			// @msg MBT_NEXT | Editor dialog button event <p Next>
												// @desc This is the button event that is sent to the
												// button function for an editor tool when the user
												// presses the <p Next> button in the editor tool dialog.
												// @see <f mgRegisterEditor>, <f mgEditorSetButtonFunc>

#define MBT_CANCEL			2			// @msg MBT_CANCEL | Editor dialog button event <p Cancel>
												// @desc This is the button event that is sent to the
												// button function for an editor tool when the user
												// presses the <p Cancel> button in the editor tool dialog.
												// @see <f mgRegisterEditor>, <f mgEditorSetButtonFunc>

#define MBT_HELP				3			// @msg MBT_HELP | Editor dialog button event <p Help>
												// @desc This is the button event that is sent to the
												// button function for an editor tool when the user
												// presses the <p Help> button in the editor tool dialog.
												// @desc This editor dialog event is currently not used
												// and is reserved for future enhancement. 
												// @see <f mgRegisterEditor>, <f mgEditorSetButtonFunc>

	/* keyboardFlags constants */
#define MKB_ALTKEY			0x00000001		// @msg MKB_ALTKEY | Keyboard flag <p Alt Key Down>
														// @desc When the appropriate mouse input function is 
														// called to report mouse input activity to an
														// editor tool or to a GL control, this keyboard
														// flag mask will be set if the <p Alt Key> is down
														// when the input was reported.
														// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
														// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
														// <f mgGLSetMouseFunc>

#define MKB_CTRLKEY			0x00000002		// @msg MKB_CTRLKEY | Keyboard flag <p Ctrl Key Down>
														// @desc When the appropriate mouse input function is 
														// called to report mouse input activity to an
														// editor tool or to a GL control, this keyboard
														// flag mask will be set if the <p Ctrl Key> is down
														// when the input was reported.
														// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
														// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
														// <f mgGLSetMouseFunc>

#define MKB_SHIFTKEY			0x00000004		// @msg MKB_SHIFTKEY | Keyboard flag <p Shift Key Down>
														// @desc When the appropriate mouse input function is 
														// called to report mouse input activity to an
														// editor tool or to a GL control, this keyboard flag
														// mask will be set if either <p Shift Key> is down when
														// the input was reported.
														// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
														// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
														// <f mgGLSetMouseFunc>

/* buttonFlags constants */
#define MMB_LEFTMOUSE		0x00000001		// @msg MMB_LEFTMOUSE | Mouse Button flag <p Left Mouse Down>
														// @desc When the appropriate mouse input function is 
														// called to report mouse input activity to an
														// editor tool or to a GL control, this mouse button
														// flag mask will be set if the <p Left Mouse> is down
														// when the input was reported.
														// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
														// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
														// <f mgGLSetMouseFunc>

#define MMB_MIDDLEMOUSE		0x00000002		// @msg MMB_MIDDLEMOUSE | Mouse Button flag <p Middle Mouse Down>
														// @desc When the appropriate mouse input function is 
														// called to report mouse input activity to an
														// editor tool or to a GL control, this mouse button
														// flag mask will be set if the <p Middle Mouse> is down
														// when the input was reported.
														// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
														// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
														// <f mgGLSetMouseFunc>

#define MMB_RIGHTMOUSE		0x00000004		// @msg MMB_RIGHTMOUSE | Mouse Button flag <p Right Mouse Down>
														// @desc When the appropriate mouse input function is 
														// called to report mouse input activity to an
														// editor tool or to a GL control, this mouse button
														// flag mask will be set if the <p Right Mouse> is down
														// when the input was reported.
														// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
														// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
														// <f mgGLSetMouseFunc>

#define MUML_USETOOLNAME	MG_NULL			// @msg MUML_USETOOLNAME | Undo menu label <p Use Tool Name>
														// @desc When an editor tool instance registers an undo-able
														// action using the function, <f mgEditorAddUndo>, 
														// <m MUML_USETOOLNAME> can be specified for the menu
														// label parameter.  If this value is specified as the 
														// menu label, the name of the editor tool is displayed
														//	on the undo menu item in the Edit-<gt>Undo menu.
														// @see <f mgRegisterEditor>, <f mgEditorAddUndo>

// @enumtype mgmouseinputtype | mgmouseinputtype | Mouse Input Selector Type.
// @see <f mgRegisterEditor>, <f mgEditorSelectMouseInput>
typedef enum mgmouseinputtype {
	MMSI_NOINPUT = 0,       // @emem No mouse input selected
	MMSI_VERTEXINPUT,       // @emem Select 3d vertex mouse input
	MMSI_POINTINPUT,        // @emem Select 2d point mouse input
	MMSI_PICKINPUT,         // @emem Select geometry pick mouse input
	MMSI_DEVICEINPUT			// @emem Select device specific input
} mgmouseinputtype;

// @enumtype mgvertexreftype | mgvertexreftype | 3d Vertex Mouse Input Reference Type.
// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>, <t mgvertexrefdata>
typedef enum mgvertexreftype {
   MVRF_VERTEX = 0,        // @emem Vertex input references existing vertex node
   MVRF_EDGE,              // @emem Vertex input references existing edge
   MVRF_CURVE,             // @emem Vertex input references existing curve node
   MVRF_TRACKPLANE,        // @emem Vertex input references trackplane
   MVRF_UNKNOWN            // @emem Unknown vertex input reference
} mgvertexreftype;

// @enumtype mgtoolterminationreason | mgtoolterminationreason | Editor Tool Termination Reason Type.
// @see <f mgRegisterEditor>, <f mgEditorSetTerminateFunc>
typedef enum mgtoolterminationreason {
	MTRM_DONE = 0,          // @emem Tool terminated because user pressed <p Done> button (<m MBT_DONE>).
	MTRM_CANCEL,            // @emem Tool terminated because user pressed <p Cancel> button (<m MBT_CANCEL>).
	MTRM_SELF,              // @emem Tool terminated itself by calling <f mgEditorTerminateTool>.
	MTRM_SYSTEM             // @emem Tool terminated by modeling system (window closed, tool chain, etc)
} mgtoolterminationreason;

// @enumtype mgconstructcolor | mgconstructcolor | Construction Vertex/Edge Color.
// @see <f mgSetConstructVertexColor>, <f mgSetConstructEdgeColor>
typedef enum mgconstructcolor {
	MCCOLOR_RED,            // @emem Construction color <p red>
	MCCOLOR_GREEN,          // @emem Construction color <p green>
	MCCOLOR_YELLOW,         // @emem Construction color <p yellow>
	MCCOLOR_BLUE,           // @emem Construction color <p blue>
	MCCOLOR_MAGENTA,        // @emem Construction color <p magenta>
	MCCOLOR_CYAN,           // @emem Construction color <p cyan>
	MCCOLOR_WHITE           // @emem Construction color <p white>
} mgconstructcolor;

// @enumtype mgundocleanupreason | mgundocleanupreason | Editor Tool Undo Cleanup Reason Type.
// @see <f mgRegisterEditor>, <f mgEditorAddUndo>, <f mgEditorAppendUndo>
typedef enum mgundocleanupreason {
	MUCR_AFTERUNDO,		   // @emem Undo cleanup function called after undo function called
	MUCR_NOUNDO             // @emem Undo cleanup function called without calling undo function
} mgundocleanupreason;

/*============================================================================*\
	private types
\*============================================================================*/

// @type mgeditorcontext | Abstract type used to represent an active editor
// tool context.
// @desc If, when an editor tool is launched, it requires additional user 
// interaction to complete its processing, the API creates an editor tool
// context corresponding to that instance of the tool.  The editor tool
// context is maintained while the editor tool instance is active on the
// desktop.  It is used to encapsulate and identify the state of
// the active editor tool instance.
typedef struct mgeditorcontext_t* mgeditorcontext;

/*============================================================================*\
	public types
\*============================================================================*/

// @structtype | mgeditorcallbackrec | 
// callback structure for editor tool start functions.
// @desc When an editor tool is launched, the corresponding
// start function is called. The start function is passed a
// pointer to a record of this type in the <p callData> parameter. 
// @desc This record contains a tool activation object from which
// you can obtain the identity of the top (focus) database.
// @desc This record also contains two fields that your tool 
// fills in and returns if a dialog is required by your tool.  If your
// editor tool needs to display a dialog to continue its work, it must
// set the <p dialogRequired> field to <e mgbool.MG_TRUE>.  Additionally,
// you can fill in the <p toolData> field with tool defined data that
// is passed to subsequent editor interactions while your tool
// is active on the desktop.
// @desc If you do not need to display a dialog, set the
// <p dialogRequired> field to <e mgbool.MG_FALSE>.
// @see <t mgtoolstartfunc>, <f mgGetActivationDb>
typedef struct {
	mgtoolactivation 	toolActivation;		// @field Tool activation

	/* fields filled in by plug-in */
	mgbool				dialogRequired;		// @field <e mgbool.MG_TRUE> to tell 
														// API to create your editor dialog for you.
	void*					toolData;				// @field tool instance data that will be
														// passed to subsequent editor tool interactions.
	mgeditorcontext	editorContext;			// @field the editor context associated to this
														// invocation of the editor tool.
} mgeditorcallbackrec;

// @uniontype | mgvertexrefdata | 
// 3D Vertex Mouse Input Reference Data.
// @desc When 3D vertex mouse input is reported to an editor tool via
// the corresponding 3d vertex input function, reference data may be
// included that specifies how the user entered the 3D vertex input.
// This record is used to specify this 3D vertex input reference data.
// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>, <t mgvertexreftype>
typedef union mgvertexrefdata {
   mgrec*     vertex;      // @field The existing vertex referenced for <e mgvertexreftype.MVRF_VERTEX>
   mgrec*     edge[2];		// @field The existing edge referenced for <e mgvertexreftype.MVRF_EDGE>
   mgrec*     curve;       // @field The existing curve referenced for <e mgvertexreftype.MVRF_CURVE>
	mgplaned*  trackPlane;  // @field The trackplane referenced for <e mgvertexreftype.MVRF_TRACKPLANE>
} mgvertexrefdata;

// @structtype | mgvertexinputdata | 3D Vertex Mouse Input Data.
// @desc When 3D vertex mouse input is reported to an editor tool via
// the corresponding 3D vertex input function, a pointer to a record
// of this type is passed to the vertex function that describes
// the vertex input.
// @see <f mgRegisterEditor>, <f mgEditorSetVertexFunc>
typedef struct mgvertexinputdata {
   mgmousestate         mouseEvent;       // @field The vertex input sequence state
   unsigned	int         keyboardFlags;		// @field The state of the <p Alt>, <p Ctrl>, and <p Shift> keys
														// The value of this field will be a bitwise combination
														// of <m MKB_ALTKEY>, <m MKB_CTRLKEY> and <m MKB_SHIFTKEY>.
   unsigned int			buttonFlags;		// @field The state of the <p Left>, <p Middle> and <p Right>
														// mouse buttons.  The value of this field will be a bitwise
														// combination of <m MMB_LEFTMOUSE>, <m MMB_MIDDLEMOUSE> and
														// <m MMB_RIGHTMOUSE>.
   mgvertexreftype      refType;				// @field Vertex Input reference type 
   mgcoord3d*           thisPoint;			// @field Address of 3D coordinate record for the current
														// vertex being reported in this sequence
   mgcoord3d*           firstPoint;       // @field Address of 3D coordinate record for the first
														// vertex reported in this sequence
   mgvertexrefdata		refData;          // @field Vertex Input reference data 
	mginputdevice			inputDevice;		// @field input device that generated this input
} mgvertexinputdata;

// @structtype | mgpointinputdata | 2D Point Mouse Input Data.
// @desc When 2D point mouse input is reported to an editor tool via
// the corresponding 2D point input function, a pointer to a record
// of this type is passed to the point function that describes
// the point input.
// @desc The coordinates of 2D point mouse input are reported relative
// to the lower left corner of the graphics view in which the input
// was received.  That is, if the point reported is at the lower left
// corner of the graphics view, it will be reported as (0, 0).
// @see <f mgRegisterEditor>, <f mgEditorSetPointFunc>
typedef struct mgpointinputdata {
   mgmousestate	  mouseEvent;           // @field The point input sequence state
   unsigned int     keyboardFlags;        // @field The state of the <p Alt>, <p Ctrl>, and <p Shift> keys
														// The value of this field will be a bitwise combination
														// of <m MKB_ALTKEY>, <m MKB_CTRLKEY> and <m MKB_SHIFTKEY>.
   unsigned int     buttonFlags;          // @field The state of the <p Left>, <p Middle> and <p Right>
														// mouse buttons.  The value of this field will be a bitwise
														// combination of <m MMB_LEFTMOUSE>, <m MMB_MIDDLEMOUSE> and
														// <m MMB_RIGHTMOUSE>.
   mgcoord2i*       thisPoint;            // @field Address of 2D coordinate record for 
														// the current point being reported in this sequence
   mgcoord2i*       firstPoint;           // @field Address of 2D coordinate record for 
														// the first point reported in this sequence
} mgpointinputdata;

// @structtype | mgpickinputdata | Pick Mouse Input Data.
// @desc When pick mouse input is reported to an editor tool via
// the corresponding pick input function, a pointer to a record
// of this type is passed to the pick function that describes
// the pick input.
// @see <f mgRegisterEditor>, <f mgEditorSetPickFunc>
typedef struct mgpickinputdata {
   unsigned int     keyboardFlags;        // @field The state of the <p Alt>, <p Ctrl>, and <p Shift> keys
														// The value of this field will be a bitwise combination
														// of <m MKB_ALTKEY>, <m MKB_CTRLKEY> and <m MKB_SHIFTKEY>.
   unsigned int     buttonFlags;          // @field The state of the <p Left>, <p Middle> and <p Right>
														// mouse buttons.  The value of this field will be a bitwise
														// combination of <m MMB_LEFTMOUSE>, <m MMB_MIDDLEMOUSE> and
														// <m MMB_RIGHTMOUSE>.
	mgselectlist     pickList;		         // @field <t mgselectlist> - The select list containing the nodes that were selected
} mgpickinputdata;

// @cb int | mgeditordeviceinputfunc | Editor device input function.   
// @desc This is the signature for editor device input functions.
// If your editor tool expects device specific input at 
// any time while it is active, you will assign a device 
// function to your editor tool of this form.  
// @desc device functions are called to notify your editor
// tool when the input device is activated (or gets focus) by the user 
// as specified by the input device.
// @see <f mgEditorSetDeviceInputFunc>, <f mgEditorSelectMouseInput>
typedef int ( *mgeditordeviceinputfunc ) ( 
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance receiving the device specific input.  
		mgdeviceinputdata* deviceInputData,			// @param address of record describing the device
																// specific input.
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb int | mgeditorvertexfunc | Editor 3D vertex function.   
// @desc This is the signature for editor 3D vertex functions.
// If your editor tool requires 3D vertex (coordinate) input at 
// any time while it is active, you will assign a 3D vertex
// function to your editor tool of this form.  
// @desc 3D vertex functions are called to notify your editor
// tool when a 3D coordinate has been entered by the user 
// either via the mouse or the Track Coordinate Window.
// @return 1 if the 3D vertex coordinates passed in should
// be copied to Reference Coordinate in Track Coordinate
// Window, 0 otherwise.
// @see <f mgEditorSetVertexFunc>, <f mgEditorSelectMouseInput>
typedef int ( *mgeditorvertexfunc ) ( 
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance receiving the 3D vertex input.  
		mgvertexinputdata* vertexInputData,			// @param address of record describing the 3D 
																// vertex input.
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb void | mgeditorpointfunc | Editor 2D point function.   
// @desc This is the signature for editor 2D point functions.
// If your editor tool requires 2D point input at 
// any time while it is active, you will assign a 2D point
// function to your editor tool of this form. 
// @desc 2D point functions are called to notify your editor
// tool when a 2D screen coordinate has been entered by the 
// user via the mouse.
// @see <f mgEditorSetPointFunc>, <f mgEditorSelectMouseInput>
typedef void ( *mgeditorpointfunc ) (
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance receiving the 2D point input.  
		mgpointinputdata* pointInputData,			// @param address of record describing the 2D 
																// point input.
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb void | mgeditorpickfunc | Editor pick function.   
// @desc This is the signature for editor pick functions.
// If your editor tool requires pick input at 
// any time while it is active, you will assign a pick
// function to your editor tool of this form. 
// @desc Pick functions are called to notify your editor
// tool when geometry has been picked by the user.
// @see <f mgEditorSetPickFunc>, <f mgEditorSelectMouseInput>
typedef void ( *mgeditorpickfunc ) (
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance receiving the pick input.  
		mgpickinputdata* pickInputData,				// @param address of record describing the 
																// pick input.
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb void | mgeditorfocusvertexfunc | Editor focus vertex function.   
// @desc This is the signature for editor focus vertex functions. If
// your editor tool uses focus vertices while it is active, you will
// assign a focus vertex function to your editor tool of this form. 
// @desc Focus vertex functions are called to notify your editor tool
// when the user has selected or deselected a vertex, vertexRec, from
// your vertex focus list.
// @see <f mgEditorSetFocusVertexFunc>
typedef void ( *mgeditorfocusvertexfunc ) (  
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance receiving the focus vertex
																// notification.  
      mgrec* vertexRec,									// @param the vertex node that was selected by the
																// user to become the new focus vertex. <m MG_NULL>
																// if the user deselected the current focus vertex.
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
      );

// @cb void | mgeditorbuttonfunc | Editor dialog button function   
// @desc This is the signature for editor dialog button functions.
// If your editor tool displays a dialog, you can assign a button
// function to your editor tool of this form.  
// @desc Editor dialog button
// functions are called to notify your editor tool when the user
// has pressed one of the four pre-defined buttons on your dialog.
// @see <f mgRegisterEditor>, <f mgEditorSetButtonFunc>
typedef void ( *mgeditorbuttonfunc ) (
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance receiving the button event.  
		int whichButton,									// @param the button that was pressed <nl>
																// <m MBT_DONE> - Done button <nl>
																// <m MBT_CANCEL> - Cancel button <nl>
																// <m MBT_NEXT> - Next button <nl>
																// <m MBT_HELP> - Help button (reserved for
																// future enhancement)
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb void | mgeditorterminatefunc | Editor termination function.   
// @desc This is the signature for editor termination callback functions.
// If your editor tool displays a dialog, you can assign a termination
// function to your editor tool of this form.  
// @desc Termination
// functions are called to notify your editor tool when it has
// been terminated.  Refer to <t mgtoolterminationreason> for
// a list of reasons an editor tool can be terminated.
// @see <f mgRegisterEditor>, <f mgEditorSetTerminateFunc>
typedef void ( *mgeditorterminatefunc ) (
		mgeditorcontext editorContext,				// @param the editor context that identifies the 
																// editor instance being terminated.  
		mgtoolterminationreason reason,				// @param the reason editor is being terminated <nl>
																// <e mgtoolterminationreason.MTRM_DONE> <nl>
																// <e mgtoolterminationreason.MTRM_CANCEL> <nl>
																// <e mgtoolterminationreason.MTRM_SELF> <nl>
																// <e mgtoolterminationreason.MTRM_SYSTEM>
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb void | mgeditorcreatedialogfunc | Editor create dialog function   
// @desc This is the signature for editor create dialog functions.
// If your editor tool displays a dialog, assign a create dialog
// function to your editor tool of this form.  
// @desc Create dialog functions are called to create an editor dialog
// instance when your editor tool is launched.  This function must create
// and return a new dialog instance each time it is invoked.
// @return dialog instance created for editor tool instance.
// @see <f mgEditorSetPickFunc>, <f mgEditorSetCreateDialogFunc>
typedef mggui ( *mgeditorcreatedialogfunc ) (
		mgplugintool editorPluginTool,				// @param the editor plug-in tool for which
																// the dialog is to be created.
		void* editorToolData								// @param user defined tool instance data 
																// set in <p toolData> field of <p callData>
																// parameter (<t mgeditorcallbackrec>) during
																// editor tool start function <t mgtoolstartfunc>.
		);

// @cb void | mgeditorundofunc | Editor undo callback function   
// @desc This is the signature for editor undo callback functions.
// If your editor tool performs an undo-able action, register
// an undo callback function for your editor tool instance of this form.
// @desc Editor undo functions are called when the user selects the 
// corresponding Undo "ToolName" menu item from the Edit-<gt>Undo menu.
// This function must "undo" any actions performed by the corresponding
// editor tool instance.
// @see <f mgEditorAddUndo>, <f mgEditorAppendUndo>
typedef void ( *mgeditorundofunc ) ( 
		mgrec* db,									// @param the database node for which the undo
														// callback is being called.
		void* undoData								// @param user defined undo data specified when undo
														// callback was registered via
														// <f mgEditorAddUndo> or <f mgEditorAppendUndo>.
		);

// @cb void | mgeditorundocleanupfunc | Editor undo cleanup callback function   
// @desc This is the signature for editor undo cleanup callback functions.
// If your editor tool performs an undo-able action, register
// an undo cleanup callback function for your editor tool instance of this form.
// @desc Editor undo cleanup functions are called to notify your editor tool when 
// it is safe to deallocate any undo data you may have allocated for your undo 
// callback function.  Undo data may be deallocated either after the 
// undo callback function is called or after the corresponding undo entry
// becomes unreachable in the Edit-<gt>Undo menu.  Undo entries become unreachable
// when their position in the undo stack becomes deeper than the maximum undo
// stack size set by the user preference.  
// @desc This function must deallocate any undo data allocated
// for the corresponding undo callback.
// @see <f mgEditorAddUndo>, <f mgEditorAppendUndo>
typedef void ( *mgeditorundocleanupfunc ) (
		mgrec* db,									// @param the database node for which the undo
														// cleanup callback is being called.
		mgundocleanupreason cleanupReason,	// @param the reason why the undo cleanup callback
														// is being called.  Refer to <t mgundocleanupreason>
														// for a list of reasons an undo cleanup callback
														// function can be called.
		void* undoData								// @param user defined undo data specified when undo
														// callback was registered via
														// <f mgEditorAddUndo> or <f mgEditorAppendUndo>.
														// This is typically the data you will deallocate.
		);

/*============================================================================*\
	public methods
\*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetDeviceInputFunc | set device input function for editor tool.
	@desc <f mgEditorSetDeviceInputFunc> assigns a device input function to the
	specified editor tool <p editorPluginTool>. 

	@desc device input functions are called to notify your editor tool when
	an input device is activated by the user

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorSelectMouseInput>, <t mgeditordeviceinputfunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetDeviceInputFunc (
		mgplugintool editorPluginTool,		// @param the editor plug-in tool
		mgeditordeviceinputfunc devInputFunc			// @param the device specific input function
		);

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetVertexFunc | set 3D vertex function for editor tool.
	@desc <f mgEditorSetVertexFunc> assigns a 3d vertex function to the
	specified editor tool <p editorPluginTool>. 

	@desc 3D vertex functions are called to notify your editor tool when
	a 3D coordinate has been entered by the user either via the mouse or
	the Track Coordinate Window.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorSelectMouseInput>, <t mgeditorvertexfunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetVertexFunc (
		mgplugintool editorPluginTool,		// @param the editor plug-in tool
		mgeditorvertexfunc vertexFunc			// @param the 3d vertex input function
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetPointFunc | sets 2D point function for editor tool.
	@desc <f mgEditorSetPointFunc> assigns a 2D point function to the specified
	editor tool <p editorPluginTool>. 

	@desc 2D point functions are called to notify your editor tool when
	a 2d screen coordinate has been entered by the user via the mouse.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorSelectMouseInput>, <t mgeditorpointfunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetPointFunc (
		mgplugintool editorPluginTool,		// @param the editor plug-in tool
		mgeditorpointfunc pointFunc			// @param the 2d point input function
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetPickFunc | sets pick function for editor tool.
	@desc <f mgEditorSetPickFunc> assigns a pick function to the specified
	editor tool <p editorPluginTool>. 

	@desc Pick functions are called to notify your editor tool when
	geometry has been picked by the user.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorSelectMouseInput>, <t mgeditorpickfunc>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetPickFunc (
		mgplugintool editorPluginTool,		// @param the editor plug-in tool
		mgeditorpickfunc pickFunc				// @param the pick input function
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetFocusVertexFunc | sets focus vertex function for 
	editor tool.
	@desc <f mgEditorSetFocusVertexFunc> assigns a focus vertex function to the
	specified editor tool <p editorPluginTool>. 

	@desc Focus vertex functions are called to notify your editor tool
	when the user has selected or deselected a vertex, <p vertexRec>,
	from your vertex focus list.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <t mgeditorfocusvertexfunc>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetFocusVertexFunc (
		mgplugintool editorPluginTool,				// @param the editor plug-in tool
		mgeditorfocusvertexfunc focusVertexFunc	// @param the focus vertex function
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetButtonFunc | sets dialog button function for editor tool.
	@desc <f mgEditorSetButtonFunc> assigns a dialog button function to the 
	specified editor tool <p editorPluginTool>. 

	@desc Dialog button functions are called to notify your editor tool when
	the user has pressed one of the four pre-defined buttons in the editor
	tool dialog.  These buttons are <m MBT_DONE>, <m MBT_CANCEL>, <m MBT_NEXT>
	and <m MBT_HELP>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <t mgeditorbuttonfunc>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetButtonFunc (
		mgplugintool editorPluginTool,		// @param the editor plug-in tool
		mgeditorbuttonfunc buttonFunc			// @param the editor dialog button function
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetTerminateFunc | sets termination function for editor tool.
	@desc <f mgEditorSetTerminateFunc> assigns a termination function to the 
	specified editor tool <p editorPluginTool>. 

	@desc Termination functions are called to notify your editor tool when it has
	been terminated.  Refer to <t mgtoolterminationreason> for
	a list of reasons an editor tool can be terminated.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <t mgtoolterminationreason>, <t mgeditorterminatefunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetTerminateFunc (
		mgplugintool editorPluginTool,			// @param the editor plug-in tool
		mgeditorterminatefunc terminateFunc		// @param the editor termination function
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgEditorSetCreateDialogFunc | sets create dialog function for
	editor tool.
	@desc <f mgEditorSetCreateDialogFunc> assigns a create dialog function
	to the specified editor tool <p editorPluginTool>. 

	@desc Create dialog functions are called to build and return a dialog 
	instance for an editor tool instance.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <t mgtoolterminationreason>, <t mgeditorcreatedialogfunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetCreateDialogFunc (
		mgplugintool editorPluginTool,				// @param the editor plug-in tool
		mgeditorcreatedialogfunc createDialogFunc	// @param the create dialog function
		);
/*                                                                            */
/*============================================================================*/

/*----------------------------------------------------------------------------*/

/* @doc EXTERNAL EDITORCONTEXTFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgeditorcontext | mgEditorGetContext | gets the editor context 
	associated with an editor tool dialog or control in that dialog.
	@desc <f mgEditorGetContext> returns the editor context that is associated
	with the specified editor tool dialog or control, <p gui>.  

	@desc A unique editor context is created for each editor tool instance that
	is launched.  When an editor tool instance creates a dialog, the editor 
	context automatically becomes associated with the dialog and therefore may be 
	acquired from the dialog or any control contained in the dialog.

	@return Returns editor context if <p gui> is associated with an editor tool dialog, 
	<m MG_NULL> otherwise.

	@see <f mgRegisterEditor>, <f mgEditorGetDialog>,
	<f mgEditorSetCreateDialogFunc>, <t mgeditorcreatedialogfunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgeditorcontext) mgEditorGetContext ( 
		mggui gui		// @param the dialog or control to get associated editor
							// context for
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorTerminateTool | terminates an editor tool instance.
	@desc <f mgEditorTerminateTool> terminates the editor tool instance identified
	by editor context, <p editorContext>.  

	@desc Normally, editor tool instances are terminated when the user presses
	the <p Done> or <p Cancel> buttons in the tool dialog associated with the
	editor instance.  In some cases, however, the editor tool instance may allow
	for other actions (user or processing) to cause the termination of the 
	tool instance.  In these cases, the tool can call <f mgEditorTerminateTool>
	to terminate itself.  

	@desc When an editor tool is terminated in this way, the termination function
	is called with termination reason  <e mgtoolterminationreason.MTRM_SELF>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorSetTerminateFunc>, 
	<t mgeditorterminatefunc>, <t mgtoolterminationreason> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorTerminateTool (
		mgeditorcontext editorContext		// @param the editor context that identifies  
													// the editor instance being terminated  
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mggui | mgEditorGetDialog | gets the dialog associated with an editor
	context.
	@desc <f mgEditorGetDialog> returns the dialog that is associated with the
	specified editor context, <p editorContext>.  

	@desc When an editor tool instance is active, a unique association exists
	between the tool instance and the corresponding editor tool dialog.  This
	function is used to retrieve the dialog associated with a particular editor
	tool instance.

	@return Returns editor tool dialog if <p editorContext> is associated with one, 
	<m MG_NULL> otherwise.

	@see <f mgRegisterEditor>, <f mgEditorGetContext>,
	<f mgEditorSetCreateDialogFunc>, <t mgeditorcreatedialogfunc> 
	@access Level 4
*/
extern MGAPIFUNC(mggui) mgEditorGetDialog ( 
		mgeditorcontext editorContext		// @param the editor context to get
													// associated dialog for  
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void* | mgEditorGetToolData | gets the user defined tool instance data 
	associated with an editor context.
	@desc <f mgEditorGetToolData> returns the user defined tool instance data
	that is associated with the specified editor context, <p editorContext>.  

	@desc When an editor tool instance is active, a unique association exists
	between the tool instance and the corresponding editor tool instance data.
	This function is used to retrieve the tool data associated with a particular
	editor tool instance.

	@return Returns editor tool instance data if defined for this tool instance,
	<m MG_NULL> otherwise.

	@see <f mgEditorGetDialog>, <f mgEditorGetContext>, <f mgEditorGetDbRec>
	@access Level 4
*/
extern MGAPIFUNC(void*) mgEditorGetToolData (
		mgeditorcontext editorContext		// @param the editor context to get 
													// associated tool instance data for
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgEditorGetDbRec | gets the database node associated with an
	editor context.
	@desc <f mgEditorGetDbRec> returns the database node that is associated
	with the specified editor context, <p editorContext>.  

	@desc When an editor tool instance is active, it is explicitly bound
	to the database node in which the editor tool was launched.
	This function is used to retrieve the database node associated
	with a particular editor tool instance.

	@return Returns the database node associated with tool instance.

	@see <f mgEditorGetDialog>, <f mgEditorGetContext>, <f mgEditorGetToolData>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgEditorGetDbRec (
		mgeditorcontext editorContext		// @param the editor context to get 
													// associated database node for
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorSetPrompt | sets the prompt string within an
	editor tool dialog.
	@desc <f mgEditorSetPrompt> copies the prompt string, <p promptString>,
	into the prompt text field of the dialog associated with the specified 
	editor context, <p editorContext>.  

	@desc If an editor tool instance creates a dialog that contains a text
	control whose identifier is <m MGID_PROMPT>, <f mgEditorSetPrompt> can
	be used as a convenience function to load a string into that text control. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorGetDialog>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetPrompt (
		mgeditorcontext editorContext,	// @param the editor context whose
													// associated dialog prompt is to
													// be set 
		char* promptString					// @param the prompt string
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorSelectMouseInput | selects the active mouse input 
	callback function for an editor tool instance.
	@desc <f mgEditorSelectMouseInput> selects which mouse input callback
	function to make active for the specified editor context, <p editorContext>. 

	@desc When an editor tool is registered, a separate mouse input callback
	function may be assigned for each class of mouse input (3D vertex input
	using <f mgEditorSetVertexFunc>, 2D point input
	using <f mgEditorSetPointFunc>, geometry pick input using 
	<f mgEditorSetPickFunc> and device specific input using <f mgEditorSetDeviceInputFunc>).
	When an editor instance is active,
	only one of the mouse input functions registered may be active at a time.
	This function is used to select which mouse input callback function is
	currently active for an editor tool instance.

	@ex The following code fragments show how an editor tool might register
	multiple mouse input functions (a 3D vertex function, a 2D point function
	and a pick function) for an editor tool, <p editorTool> and then select
	one of them to be active when the tool instance is active. |

	@ex When the editor tool is registered: |

   // Register the mouse input functions that are used by tool
   mgEditorSetVertexFunc ( editorTool, MyVertexFunc );
   mgEditorSetPointFunc ( editorTool, MyPointFunc );
   mgEditorSetPickFunc ( editorTool, MyPickFunc );
   mgEditorSetDeviceInputFunc ( editorTool, MyDeviceInputFunc );

	@ex Then when the editor tool instance is active: |

   // Activate the 3d vertex function, MyVertexFunc
   mgEditorSelectMouseInput ( editorContext, MMSI_VERTEXINPUT );

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetVertexFunc>, <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSelectMouseInput (
		mgeditorcontext editorContext,	// @param the editor context to select
													// active mouse input for
		mgmouseinputtype inputType			// @param the mouse input callback function to select. <nl>
													// <e mgmouseinputtype.MMSI_VERTEXINPUT> - to select 3d vertex input <nl>
													// <e mgmouseinputtype.MMSI_POINTINPUT> - to select 2d point input <nl>
													// <e mgmouseinputtype.MMSI_PICKINPUT> - to select geometry pick input <nl>
													// <e mgmouseinputtype.MMSI_DEVICEINPUT> - to select device specific input
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorSetSnapLine | selects a snap line to control 3D
	vertex input for an editor tool instance.
	@desc <f mgEditorSetSnapLine> selects a line <p snapLine>, to which all
	3D vertex input is "snapped" for the specified editor context,
	<p editorContext>. 

	@desc When a 3D vertex input callback function is active for an editor
	tool instance, you can use this function to specify that all coordinate
	input be "snapped" to the specified line.  In this way, when the user enters
	coordinates (x, y, z), the actual coordinates reported, (x', y', z'), will
	represent the point closest to (x, y, z) on the specified line.

	@desc If <p snapLine> is specified as <m MG_NULL>, normal 3D vertex input
	will resume.  That is the current snap line will be ignored.

	@desc Note: The Wall Tool in Creator uses this technique to raise the 
	walls of a selected polygon along the normal vector of the polygon.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetVertexFunc>, <f mgEditorSetTrackPlane>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetSnapLine (
		mgeditorcontext editorContext,	// @param the editor context to select
													// the snap line for
		mglined* snapLine						// @param the line to control 3D
													// vertex input
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorSetTrackPlane | selects a tracking plane to control 
	3D vertex input for an editor tool instance.
	@desc <f mgEditorSetTrackPlane> selects a tracking plane <p trackPlane>, that
	controls 3D vertex input for the specified editor context, 
	<p editorContext>. 

	@desc When a 3D vertex input callback function is active for an editor
	tool instance, you can use this function to specify that all coordinate
	input be projected onto the specified plane. In this way, you can override
	the tracking plane(s) set up by the modeler in Creator.

	@desc The tracking plane you select does not affect vertex and edge 
	references or coordinates input via the Track Coordinate Window.
	Also, Snap To Grid, if set in Creator, is ignored for your selected
	tracking plane.
	
	@desc If <p trackPlane> is specified as <m MG_NULL>, the tracking plane
	set by the modeler in Creator will be used again for 3D vertex input.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetVertexFunc>, <f mgEditorSetSnapLine>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorSetTrackPlane (
		mgeditorcontext editorContext,	// @param the editor context to select
													// the tracking plane for
		mgplaned* trackPlane					// @param the tracking plane to control 3D
													// vertex input
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorAddUndo | registers a new undo callback action
	for an editor tool instance.
	@desc <f mgEditorAddUndo> creates a new undo-able action item
	in the undo menu for the specified editor context, <p editorContext>.

	@desc When an editor tool instance performs an undo-able action, it
	registers the action using this function. Doing so causes 
	an undo entry to be created in the Edit-<gt>Undo menu with the
	specified label string <p menuLabel>. If <m MUML_USETOOLNAME> is 
	specified for <p menuLabel>, the name of the editor	tool is used
	as the menu label string. 
	
	@desc When this undo entry is selected by the user, the specified
	undo callback function, <p undoFunc> is called and passed
	the specified undo data <p undoData>.  In this function, the editor
	tool instance is responsible for restoring the database to the state
	it was in prior to the editor tool instance being launched.  This
	may be critical for previous undo callback actions to correctly
	perform their processing.  
	
	@desc After the undo callback function is called, the undo cleanup
	callback function, <p undoCleanupFunc> is called.  In this
	function, the editor tool instance can deallocate the undo
	data.  Alternatively, the undo cleanup callback function may be
	called when the undo entry in the Edit-<gt>Undo menu becomes
	unreachable.  In this case, the undo callback function will not
	be called before the undo cleanup callback function.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorAppendUndo>, <f mgEditorResetUndo>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorAddUndo (
		mgeditorcontext editorContext,					// @param the editor context to 
																	// register undo callback for
		char* menuLabel,										// @param the text of the undo
																	// menu item to display
		mgeditorundofunc undoFunc,							// @param the undo callback function
																	// for this undo-able action
		mgeditorundocleanupfunc undoCleanupFunc,		// @param the undo cleanup callback
																	// function for this undo-able action
		void* undoData											// @param user data to be passed to	
																	// callback functions <p undoFunc>
																	// and <p undoCleanupFunc> when they
																	// are called
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorAppendUndo | append an undo callback action
	to an existing undo entry for an editor tool instance.
	@desc <f mgEditorAppendUndo> creates an undo-able action and appends
	it to an existing entry in the undo menu for the specified editor context,
	<p editorContext>.

	@desc Using this function after calling <f mgEditorAddUndo> within the
	same editor tool instance, an editor tool instance can register multiple
	undo callback actions that all are represented by a single undo entry
	in the Edit-<gt>Undo menu.

	@ex The following code fragments show how an editor tool instance 
	might register multiple undo callback actions. |

	@ex When the first undo callback action is registered, an undo entry
	labeled "My Action" is created in the Edit-<gt>Undo menu: |

   // Register the first undo callback action
   mgEditorAddUndo ( editorContext, "My Action", 
                     MyUndoFunc, MyUndoCleanupFunc,
                     myUndoData );

	@ex Then when subsequent undo callback actions are registered (appended)
	within the same editor tool instance, the undo callback functions are
	appended to the "My Action" undo entry added above: |

   // Register the "next" undo callback action
   mgEditorAppendUndo ( editorContext,
                        MyUndoFunc, MyUndoCleanupFunc,
                        myUndoData );

	@desc When the user selects an undo entry from the Edit-<gt>Undo menu that
	corresponds to multiple undo callback actions, the undo callback functions
	(including the undo cleanup callback) are called in the reverse order in
	which they were appended.  That is, the last undo callback action to be
	appended is called first and the undo callback action registered by
	<f mgEditorAddUndo> is called last.

	@desc Calling <f mgEditorAppendUndo> without first calling 
	<f mgEditorAddUndo> within the editor tool instance is equivalent to
	calling <f mgEditorAddUndo> and specifying <m MUML_USETOOLNAME> 
	for the menu label.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgRegisterEditor>, <f mgEditorAddUndo>, <f mgEditorResetUndo>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorAppendUndo (
		mgeditorcontext editorContext,					// @param the editor context to 
																	// register undo callback for
		mgeditorundofunc undoFunc,							// @param the undo callback function
																	// for this undo-able action to be
																	// appended
		mgeditorundocleanupfunc undoCleanupFunc,		// @param the undo cleanup callback
																	// function for this undo-able action
																	// to be appended
		void* undoData											// @param user data to be passed to	
																	// callback functions <p undoFunc>
																	// and <p undoCleanupFunc> when they
																	// are called
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgEditorResetUndo | clear the undo menu
	@desc <f mgEditorResetUndo> clears the contents of the Edit-<gt>Undo menu
	for the database node associated with the specified editor context,
	<p editorContext>.

	@desc There are times when an editor tool instance performs actions which
	cannot be "undone".  In other words, the editor tool instance cannot
	guarantee that it can restore the database to the state it was in prior
	to the editor tool instance being launched.  When this is the case, undo
	entries that are currently in the Edit-<gt>Undo menu when the editor instance
	is launched must be cleared from the menu as they may not be able to 
	correctly perform their processing given that the state of the database
	has been altered.

	@desc If your editor tool performs actions that cannot be undone, you
	should call this function after you perform the drastic action(s), typically
	from your editor termination function.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorAddUndo>, <f mgEditorAppendUndo>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgEditorResetUndo (
		mgeditorcontext editorContext			// @param the editor context used to identify
														// the database node for which the undo menu
														// is to be cleared
		);
/*                                                                            */
/*============================================================================*/

/*----------------------------------------------------------------------------*/

/* @doc EXTERNAL FOCUSVERTEXFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgFocusVertexListAddItem | add a node as a potential
	focus vertex.
	@desc <f mgFocusVertexListAddItem> adds a node to the focus vertex list 
	for the specified editor context, <p editorContext>.  All vertices below 
	the specified node <p rec> will become candidates for focus vertex selection.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetFocusVertexFunc>, <f mgFocusVertexListDeleteItem>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgFocusVertexListAddItem ( 
		mgeditorcontext editorContext,		// @param the editor context used to identify
														// the focus vertex list to which the specified
														// node is to be added
      mgrec* rec									// @param the node containing vertices to be
														// added
      );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgFocusVertexListDeleteItem | remove a node from the
	focus vertex list.
	@desc <f mgFocusVertexListDeleteItem> removes a node from the focus 
	vertex list for the specified editor context, <p editorContext>.  All vertices
	below the specified node <p rec> will no longer be candidates for focus vertex
	selection.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetFocusVertexFunc>, <f mgFocusVertexListAddItem>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgFocusVertexListDeleteItem ( 
		mgeditorcontext editorContext,		// @param the editor context used to identify
														// the focus vertex list from which the specified
														// node is to be removed
      mgrec* rec									// @param the node containing vertices to be
														// removed
      );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgFocusVertexListDeleteAllItems | clear focus vertex list.
	@desc <f mgFocusVertexListDeleteAllItems> clears all nodes from the focus 
	vertex list for the specified editor context, editorContext. 
	
	@desc After calling this function, no vertices will be candidates for 
	focus vertex selection.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetFocusVertexFunc>, <f mgFocusVertexListAddItem>,
	<f mgFocusVertexListDeleteItem>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgFocusVertexListDeleteAllItems ( 
		mgeditorcontext editorContext		// @param the editor context used to identify
													// the focus vertex list to be cleared
      );
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetFocusVertex | set the current focus vertex.
	@desc <f mgSetFocusVertex> sets the focus vertex to the specified
	vertex node, <p vertexRec> for the specified editor context, <p editorContext>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetFocusVertexFunc>, <f mgFocusVertexListAddItem>, 
	<f mgClearFocusVertex>, <f mgGetFocusVertex>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgSetFocusVertex ( 
		mgeditorcontext editorContext,		// @param the editor context used to identify
														// the database node in which the focus vertex
														// is to be set
      mgrec* vertexRec							// @param the vertex node to become the new
														// focus vertex
      );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgClearFocusVertex | clear the current focus vertex.
	@desc <f mgClearFocusVertex> clears the focus vertex for the specified
	editor context, <p editorContext>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgEditorSetFocusVertexFunc>, <f mgSetFocusVertex>,
	<f mgGetFocusVertex>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgClearFocusVertex ( 
		mgeditorcontext editorContext			// @param the editor context used to identify
														// the database node in which the focus vertex
														// is to be set
      );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetFocusVertex | get the current focus vertex.
	@desc <f mgGetFocusVertex> gets the current focus vertex associated
	to the specified editor context, <p editorContext>.

	@return Returns current focus vertex node if set, <m MG_NULL> otherwise.

	@see <f mgEditorSetFocusVertexFunc>, <f mgFocusVertexListAddItem>,
	<f mgSetFocusVertex>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgGetFocusVertex ( 
		mgeditorcontext editorContext			// @param the editor context used to identify
														// the database node for which the focus vertex
														// is to be returned
      );
/*                                                                            */
/*============================================================================*/

/*----------------------------------------------------------------------------*/

/* @doc EXTERNAL CONSTRUCTIONFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgNewConstructVertex | create a construction vertex node.
	@desc <f mgNewConstructVertex> creates a new construction vertex node 
	with the specified coordinates, <p coord>.  The new construction node
	is created in the database associated with the specified editor
	context, <p editorContext>.  

	@desc If <p coord> is <m MG_NULL>, the coordinates assigned to the new
	construction vertex will be (0.0, 0.0, 0.0).

	@desc The attributes of the construction vertex node returned can be
	accessed like any other <flt fltVertex> node using <f mgGetAttList> and
	<f mgSetAttList>.  The node returned, however, should not be explicitly
	attached to other geometry nodes in the database.  Doing so yields
	undefined results.

	@return Returns construction node created if successful, <m MG_NULL> otherwise.

	@see <f mgSetConstructVertexCoords>, <f mgSetConstructVertexColor>, 
	<f mgDeleteConstructVertex>, <f mgNewConstructEdge>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgNewConstructVertex (
		mgeditorcontext editorContext,		// @param the editor context used to identify
														// the database node in which the construction
														// vertex is to be created
		mgcoord3d* coord							// @param address of record containing initial
														// coordinates of new construction vertex
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetConstructVertexColor | sets the color of a 
	construction vertex node.
	@desc <f mgSetConstructVertexColor> sets the color of a construction
	vertex node <p constructVtx> to the specified pre-defined color
	<p constructColor>.

	@desc See <t mgconstructcolor> for the list of pre-defined colors.
	By default, construction vertex nodes are created using color
	<e mgconstructcolor.MCCOLOR_RED>.  

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructVertex>, <f mgSetConstructVertexCoords>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgSetConstructVertexColor (
		mgrec* constructVtx,						// @param the construction vertex to color
		mgconstructcolor constructColor		// @param the color 
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetConstructVertexCoords | sets the coordinates of a 
	construction vertex node.
	@desc <f mgSetConstructVertexCoords> sets the coordinates of a construction
	vertex node <p constructVtx> to the specified values in
	<p coord>.

	@desc If <p coord> is not specified, no action is taken.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructVertex>, <f mgSetConstructVertexColor>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgSetConstructVertexCoords (
		mgrec* constructVtx,				// @param the construction vertex to 
												// set coordinates for
		mgcoord3d* coord					// @param address of record containing
												// coordinates for construction vertex
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGetConstructVertexCoords | gets the coordinates of a 
	construction vertex node.
	@desc <f mgGetConstructVertexCoords> gets the coordinates of a construction
	vertex node <p constructVtx>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p coord> contains the corresponding coordinate values,
	otherwise <p coord> is undefined.

	@see <f mgNewConstructVertex>, <f mgSetConstructVertexColor>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGetConstructVertexCoords (
		mgrec* constructVtx,				// @param the construction vertex to 
												// get coordinates for
		mgcoord3d* coord					// @param address of record to receive
												// coordinates of construction vertex
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDeleteConstructVertex | deletes a construction vertex node.
	@desc <f mgDeleteConstructVertex> deletes the specified construction vertex
	node <p constructVtx>. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructVertex>, <f mgDeleteAllConstructs>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgDeleteConstructVertex (
		mgrec* constructVtx			// @param the construction vertex to delete
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgFirstConstructVertex | gets the first construction vertex
	node associated with an active editor tool instance.
	@desc <f mgFirstConstructVertex> gets the first construction vertex node
	associated with the editor tool instance identified by editor
	context, <p editorContext>.  

	@desc While an editor tool instance is active, all construction vertices
	created via calls to <f mgNewConstructVertex> are maintained internally
	within the editor context record.  In this way, you can use 
	<f mgFirstConstructVertex> and <f mgNextConstructVertex> to traverse
	all construction vertices associated with the current editor tool
	instance.

	@return first construction vertex node if found, <m MG_NULL> otherwise.

	@see <f mgNewConstructVertex>, <f mgNextConstructVertex>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgFirstConstructVertex (
		mgeditorcontext editorContext			// @param the editor context from which to
														// get the first construction vertex node
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgNextConstructVertex | gets the next construction vertex
	node associated with an active editor tool instance.
	@desc <f mgNextConstructVertex> gets the construction vertex node
	that follows the specified construction node, <p constructVtx>,
	associated with the editor tool instance identified by
	editor context, <p editorContext>.  

	@desc After calling <f mgFirstConstructVertex> to get the first 
	construction vertex node associated with an editor tool instance, you  
	can call <f mgNextConstructVertex> to get successive construction
	vertex nodes.

	@return Returns the next construction vertex node if found, <m MG_NULL> otherwise.

	@see <f mgNewConstructVertex>, <f mgFirstConstructVertex>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgNextConstructVertex (
		mgeditorcontext editorContext,		// @param the editor context from which to
														// get the next construction vertex node
		mgrec* constructVtx						// @param the construction vertex node
														// to get next construction vertex for
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgNewConstructEdge | creates a construction edge node.
	@desc <f mgNewConstructEdge> creates a new construction edge node 
	with the specified endpoint coordinates, <p coord1> and <p coord2>.  
	The new construction node is created in the database associated
	with the specified editor context, <p editorContext>.  

	@desc If either <p coord1> or <p coord2> is <m MG_NULL>, the corresponding
	coordinate of the edge is assigned (0.0, 0.0, 0.0).

	@desc A construction edge is actually composed of two construction
	vertex nodes.  This function returns the first vertex node of the edge
	created.  Calling <f mgGetNext> for the first vertex of the edge is
	return the second vertex of the edge.

	@desc The attributes of either vertex of a construction edge can be
	accessed like any other <flt fltVertex> node using <f mgGetAttList> and
	<f mgSetAttList>.  The edge returned, however, should not be explicitly
	attached to other geometry nodes in the database.  Doing so will yield
	undefined results.

	@return Returns first vertex node of construction edge created if successful, 
	<m MG_NULL> otherwise.

	@see <f mgSetConstructEdgeCoords>, <f mgSetConstructEdgeColor>, 
	<f mgDeleteConstructEdge>, <f mgNewConstructVertex>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgNewConstructEdge (
		mgeditorcontext editorContext,	// @param the editor context used to identify
													// the database node in which the construction
													// edge is to be created
		mgcoord3d* coord1,					// @param address of record containing initial
													// coordinates of first vertex of construction edge
		mgcoord3d* coord2						// @param address of record containing initial
													// coordinates of second vertex of construction edge
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetConstructEdgeColor | sets the color of a 
	construction edge.
	@desc <f mgSetConstructEdgeColor> sets the color of a construction
	edge <p constructEdge> to the specified pre-defined color
	<p constructColor>.

	@desc See <t mgconstructcolor> for the list of pre-defined colors.
	By default, construction edge nodes are created using color
	<e mgconstructcolor.MCCOLOR_RED>.  

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructEdge>, <f mgSetConstructEdgeCoords>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgSetConstructEdgeColor (
		mgrec* constructEdge,					// @param the construction edge to color
		mgconstructcolor constructColor		// @param the color 
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetConstructEdgeCoords | sets the endpoint coordinates
	of a construction edge node.
	@desc <f mgSetConstructEdgeCoords> sets the coordinates of the endpoints
	of a construction edge node <p constructEdge> to the specified values in
	<p coord1> and <p coord3>.

	@desc If either <p coord1> or <p coord2> is not specified, 
	no action is taken.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructEdge>, <f mgSetConstructEdgeColor>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgSetConstructEdgeCoords (
		mgrec* constructEdge,			// @param the construction edge to 
												// set coordinates for
		mgcoord3d* coord1,				// @param address of record containing
												// coordinates of first vertex of 
												// construction edge
		mgcoord3d* coord2					// @param address of record containing
												// coordinates of second vertex of 
												// construction edge
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGetConstructEdgeCoords | gets the endpoint coordinates
	of a construction edge node.
	@desc <f mgGetConstructEdgeCoords> gets the coordinates of the endpoints
	of a construction edge node <p constructEdge>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If
	function is successful, <p coord1> and <p coord2> contains the 
	corresponding coordinate values, otherwise <p coord1> and <p coord2>
	are undefined.

	@see <f mgNewConstructEdge>, <f mgSetConstructEdgeColor>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGetConstructEdgeCoords (
		mgrec* constructEdge,			// @param the construction edge to 
												// get coordinates for
		mgcoord3d* coord1,				// @param address of record to receive
												// coordinates of first vertex of 
												// construction edge
		mgcoord3d* coord2					// @param address of record to receive
												// coordinates of second vertex of 
												// construction edge
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDeleteConstructEdge | deletes a construction edge node
	@desc <f mgDeleteConstructEdge> deletes the specified construction edge
	node <p constructEdge>. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructEdge>, <f mgDeleteAllConstructs>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgDeleteConstructEdge (
		mgrec* constructEdge			// @param the construction edge to delete
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgFirstConstructEdge | gets the first construction edge
	node associated with an active editor tool instance.
	@desc <f mgFirstConstructEdge> gets the first construction edge node
	associated with the editor tool instance identified by 
	editor context, <p editorContext>.  

	@desc While an editor tool instance is active, all construction edges
	created via calls to <f mgNewConstructEdge> are maintained internally
	within the editor context record.  In this way, you can use 
	<f mgFirstConstructEdge> and <f mgNextConstructEdge> to traverse
	all construction edges associated with the current editor tool
	instance.

	@return Returns the first construction edge node if found, <m MG_NULL> otherwise.

	@see <f mgNewConstructEdge>, <f mgNextConstructEdge>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgFirstConstructEdge (
		mgeditorcontext editorContext			// @param the editor context from which to
														// get the first construction edge node
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgNextConstructEdge | gets the next construction edge
	node associated with an active editor tool instance.
	@desc <f mgNextConstructEdge> gets the construction edge node
	that follows the specified construction node, <p constructEdge>,
	associated with the editor tool instance identified by 
	editor context, <p editorContext>.  

	@desc After calling <f mgFirstConstructEdge> to get the first 
	construction edge node associated with an editor tool instance, you  
	can call <f mgNextConstructEdge> to get successive construction
	edge nodes.

	@return Returns the next construction edge node if found, <m MG_NULL> otherwise.

	@see <f mgNewConstructEdge>, <f mgFirstConstructEdge>
	@access Level 4
*/
extern MGAPIFUNC(mgrec*) mgNextConstructEdge (
		mgeditorcontext editorContext,		// @param the editor context from which to
														// get the next construction edge node
		mgrec* constructEdge						// @param the construction edge node
														// to get next construction edge for
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDeleteAllConstructs | deletes all construction vertices
	and edges for a given editor tool instance.
	@desc <f mgDeleteAllConstructs> deletes all construction vertices and
	edges associated with the editor tool instance 
	identified by editor context, <p editorContext>.  

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgNewConstructEdge>, <f mgDeleteAllConstructs>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgDeleteAllConstructs (
		mgeditorcontext editorContext			// @param the editor context for which
														// all construction nodes are to be
														// deleted
		);
/*                                                                            */
/*============================================================================*/

/* @doc EXTERNAL EDITORCONTEXTFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgRefreshScene | forces a database to be redrawn.
	@desc <f mgRefreshScene> forces the database node associated with the
	specified editor context, <p editorContext> to be redrawn in Creator.

	@desc While an editor tool instance is active, it may perform actions
	within a database node that change the appearance of the database contents
	in the graphics or hierarchy view or both.  For example, the tool may
	create new geometry or modify a visual attribute of an existing geometry
	node.  When such an action is performed, <f mgRefreshScene> can be called
	to make sure the graphic and hierarchy views of the corresponsing
	database are redrawn.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgRefreshScene (
		mgeditorcontext editorContext			// @param the editor context used to identify
														// the database node that is to be redrawn
		);
/*                                                                            */
/*============================================================================*/

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPIEDITOR4_H */
/* DON'T ADD STUFF AFTER THIS #endif */



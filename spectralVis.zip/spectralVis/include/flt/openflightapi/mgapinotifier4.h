/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPINOTIFIER4_H
#define MGAPINOTIFIER4_H
/* @doc EXTERNAL NOTIFIERFUNC */

#include "mgapistd.h"
#include "mgapiplugin4.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

// @type mgnotifier | Abstract type used to represent a model-time event notifier.
// @desc You can register a notifier that triggers notification callbacks when
// pre-defined model time events occur. 
// @see <f mgRegisterNotifier>.
typedef struct mgnotifier_t* mgnotifier;

// @enumtype mgnotifierevent | mgnotifierevent | Notifier Event Types
typedef enum mgnotifierevent {
	MNOTIFY_SELECTLISTCHANGED = 0,					// @emem Select List Change notifier event.  This
																// is sent whenever the select list contents change.<nl>
																// Applicable to viewer tools only.
	MNOTIFY_NEWTOPDATABASE,								// @emem New Top Database notifier event.  This is
																// sent whenever a new database is selected to be
																// the top (focus) database in Creator.<nl>
																// Applicable to viewer tools only.
	MNOTIFY_DATABASECLOSED,								// @emem Database Close notifier event.  This is
																// sent whenever a database is closed from Creator.<nl>
																// Applicable to viewer tools only.
	MNOTIFY_CURRENTPRIMARYCOLORCHANGED,				// @emem Current Primary Color Change notifier event.
																// This is sent whenever the modeler selects a new
																// primary modeling color.<nl>
																// Applicable to viewer and editor tools only.
	MNOTIFY_CURRENTALTCOLORCHANGED,					// @emem Current Alternate Color Change notifier event.
																// This is sent whenever the modeler selects a new
																// alternate modeling color.<nl>
																// Applicable to viewer and editor tools only.
	MNOTIFY_CURRENTTEXTURECHANGED,					// @emem Current Texture Change notifier event.
																// This is sent whenever the modeler selects a new
																// modeling texture.<nl>
																// Applicable to viewer and editor tools only.
	MNOTIFY_CURRENTMATERIALCHANGED,					// @emem Current Material Change notifier event.
																// This is sent whenever the modeler selects a new
																// modeling material.<nl>
																// Applicable to viewer and editor tools only.
	MNOTIFY_CURRENTTEXTUREMAPPINGCHANGED,			// @emem Current Texture Mapping Change notifier event.
																// This is sent whenever the modeler selects a new
																// modeling texture mapping.<nl>
																// Applicable to viewer and editor tools only.
	MNOTIFY_CURRENTLIGHTPOINTAPPEARANCECHANGED,	// @emem Current Light Point Appearance Change notifier event.
																// This is sent whenever the modeler selects a new
																// modeling light point appearance.<nl>
																// Applicable to viewer and editor tools only.
	MNOTIFY_CURRENTLIGHTPOINTANIMATIONCHANGED,	// @emem Current Light Point Animation Change notifier event.
																// This is sent whenever the modeler selects a new
																// modeling light point animation.<nl>
																// Applicable to viewer and editor tools only.
} mgnotifierevent;

// @cb mgstatus | mgnotifyfunc | Notifier callback function.   
// @see <f mgRegisterNotifier>  
typedef void ( *mgnotifyfunc ) (
		mgnotifier notifier,			// @param the notifier
		mgnotifierevent event,		// @param the notification event that triggered the callback
		mgrec* db,						// @param the database to which or in which the event occurred	
		mgrec* rec,						// @param the specific node in the database to which the event occurred
		void* userData					// @param user defined data specified when notifier registered
		);

/*----------------------------------------------------------------------------*/

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgnotifier | mgRegisterNotifier | registers a notifier
	@desc <f mgRegisterNotifier> registers a model-time notifier on behalf
	of the specified editor or viewer plug-in tool, <p pluginTool>.  When the
	specified model time <p event> occurs for the specified database <p db> 
	and/or node <p rec>, the notification callback function, <p notifyFunc> 
	is called and passed the specified user defined data, <p userData>.

	@desc Note: Notifier events only apply to viewer and editor tools. 
	Database importers and exporters, image importers and input device plug-in
	cannot receive model-time notification in this way.  Furthermore, not all
	notifier events are applicable to both viewer and editor tools.  Viewer 
	tools can receive any notifier event while editor tools can only receive
	a subset of the notifier events.  In particular, the notifier events, 
	<e mgnotifierevent.MNOTIFY_SELECTLISTCHANGED>, 
	<e mgnotifierevent.MNOTIFY_NEWTOPDATABASE>, and 
	<e mgnotifierevent.MNOTIFY_DATABASECLOSED> are not sent to editor tools.

   @desc Typically, you register a model-time notifier for a particular 
	database node <p db>.  If you do this, your notification callback function
	will be called only when the specified <p event> occurs to that specific <p db>
	node.  If you want your notification callback function to be called whenever
	the event occurs to any database node, set <p db> to <m MG_NULL>.

	@return Returns a notifier object if successful, <m MG_NULL> otherwise.

	@see <f mgUnregisterNotifier>, <f mgSetNotifierEnabled>, <m mgnotifierevent>

	@access Level 4
*/
extern MGAPIFUNC(mgnotifier) mgRegisterNotifier (
		mgplugintool pluginTool,		// @param the plug-in tool that is registering the notifier
		mgnotifierevent event,			// @param notification event you are interested in	
		mgrec* db,							// @param the database for which you are registering the event
		mgrec* rec,							// @param the specific node for which the event applies
		mgnotifyfunc notifyFunc,		// @param the notification callback function
		void* userData						// @param user data to be passed to notification callback 
												// function when it is called
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgUnregisterNotifier | unregisters a notifier
	@desc <f mgUnregisterNotifier> unregisters the specified <p notifier>.
	Unregistering a notifier disables and destroys it. 

	@see <f mgRegisterNotifier>, <f mgSetNotifierEnabled>
	@access Level 4
*/
extern MGAPIFUNC(void) mgUnregisterNotifier (
		mgnotifier notifier			// @param the notifier to unregister
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgUnregisterAllNotifiers | unregisters all notifiers for
	a plug-in tool.

	@desc <f mgUnregisterAllNotifiers> unregisters all notifiers
	currently registered for the specified plug-in tool <p pluginTool>.
	Unregistering a notifier disables and destroys it. 

	@desc Unregister a notifier when you are finished with it.
	Disable a notifier if you just want to stop the notifier from
	reporting events temporarily.

	@see <f mgRegisterNotifier>, <f mgSetNotifierEnabled>
	@access Level 4
*/
extern MGAPIFUNC(void) mgUnregisterAllNotifiers (
		mgplugintool pluginTool		// @param the plug-in tool for which all notifiers
											// are being unregistered
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgSetNotifierEnabled | enables or disables a notifier
	@desc Depending on the value of the parameter <p enabled>, <f mgSetNotifierEnabled> 
	either enables (<e mgbool.MG_TRUE>) or disables (<e mgbool.MG_FALSE>) the specified
	<p notifier>.  

	@desc A notifier that is enabled reports events; one that is disabled
	does not.

	@see <f mgRegisterNotifier>, <f mgUnregisterNotifier>, <f mgSetAllNotifiersEnabled>
	@access Level 4
*/
extern MGAPIFUNC(void) mgSetNotifierEnabled (
		mgnotifier notifier,			// @param the notifier to enable/disable
		mgbool enabled					// @param enum mgbool <e mgbool.MG_TRUE> to enable 
											// notifier, <e mgbool.MG_FALSE> to disable it
	
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgSetAllNotifiersEnabled | enables or disables all notifiers for
	a plug-in tool.
	@desc Depending on the value of the parameter <p enabled>, 
	<f mgSetAllNotifiersEnabled> either enables (<e mgbool.MG_TRUE>) or
	disables (<e mgbool.MG_FALSE>). 

	@desc A notifier that is enabled reports events; one that is disabled
	does not.

	@see <f mgRegisterNotifier>, <f mgUnregisterNotifier>, <f mgSetNotifierEnabled>

	@access Level 4
*/
extern MGAPIFUNC(void) mgSetAllNotifiersEnabled (
		mgplugintool pluginTool,	// @param the plug-in tool for which all notifiers
											// are being enabled/disabled
		mgbool enabled					// @param enum mgbool <e mgbool.MG_TRUE> to enable all
											// notifiers, <e mgbool.MG_FALSE> to disable them
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

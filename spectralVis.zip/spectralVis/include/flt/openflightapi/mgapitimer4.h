/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPITIMER4_H_
#define MGAPITIMER4_H_
/* @doc EXTERNAL TIMERFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapibase.h"
#include "mgapidialog.h"

// @type mgtimer | Abstract type used to represent timer objects
typedef struct mgtimer_t* mgtimer;
					
// @cb mgbool | mgtimerfunc | Timer function
// @desc This is the signature for timer functions.
// When you create a timer object using <f mgRegisterTimer>, you will provide a 
// timer function of this form that will be called when your timer expires. 
// @return Return <e mgbool.MG_TRUE> if you want to resubmit the timer
// request, <e mgbool.MG_FALSE> otherwise.  In this way you can set up a
// recurring timer object by returning <e mgbool.MG_TRUE>.
// @see <f mgRegisterTimer>, <f mgUnregisterTimer>
typedef mgbool ( *mgtimerfunc )(
		mgtimer timerId,		// @param the timer object that identifies the timer that has expired.
		void* userData			// @param user defined data specified when timer was submitted.
		);

/*============================================================================*/
/*                                                                            */
/* @func mgtimer | mgRegisterTimer | submit a timer request.
	@desc <f mgRegisterTimer> submits a timer request for a specified time-out 
	value <p timeout>.  When the time-out expires, the specified timer function
	<p timerFunc> will be called.

   @desc If the timer request was accepted, a timer object will be created
	and returned by this function.  If you need to cancel the timer before it
	expires, you can call <f mgUnregisterTimer> passing to it the timer object.

	@return Returns a timer object if successful, <m MG_NULL> otherwise.

	@access Level 4
	@see <f mgUnregisterTimer>, <t mgtimerfunc>
*/
extern MGAPIFUNC(mgtimer) mgRegisterTimer ( 
	mggui gui,					// @param dialog or control to associate timer to.
	unsigned int timeout,	// @param time-out value in milliseconds.
	mgtimerfunc timerFunc,	// @param timer function to call when time-out expires.
	void* userData				// @param user data to be passed to timer function when it is called.
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgUnregisterTimer | remove a timer request.
	@desc <f mgUnregisterTimer> removes a timer request identified by <p timerId>
	if it has not yet expired.  The timer object <p timerId> was returned from
	<f mgRegisterTimer>.

	@access Level 4
	@see <f mgRegisterTimer>, <t mgtimerfunc>
*/
extern MGAPIFUNC(void) mgUnregisterTimer ( 
	mgtimer timerId			// @param timer object to remove.
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */



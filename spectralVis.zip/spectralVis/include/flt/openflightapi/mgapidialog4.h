/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIDIALOG4_H_
#define MGAPIDIALOG4_H_
/* @doc EXTERNAL GENERALCONTROLFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapibase.h"
#include "mgapiplugin.h"
#include "mgapiattr.h"
#include "mgapicoord.h"
#include "mgapigl.h"

/*============================================================================*\
	Platform dependent typedefs
\*============================================================================*/

// @type mgguihandle | Platform-specific type used to represent native Dialog 
// and Control GUI items
// @desc On Windows NT, this is type HWND
// @see <f mgGetGuiHandle>
typedef void* mgguihandle;

// @type mgdialogid | Dialog identifier type used to identify and extract
// dialog templates from resources.
// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>
typedef int mgdialogid;

// @type mgstringid | String Definition identifier type used to identify 
// and extract string definitions from resources.
// @see <f mgResourceGetString>
typedef int mgstringid;

// @type mgpixmapid | Pixmap identifier type used to identify and extract
// pixmaps from resources.
// @see <f mgResourceGetPixmap>
typedef int mgpixmapid;

// @type mgcontrolid | Control identifier type used to identify and find
// controls within dialog instances.
// @see <f mgFindGuiById>
typedef int mgcontrolid;

// @type mgcursorid | Cursor identifier type used to identify and extract
// cursors from resources.
// @see <f mgResourceGetCursor>
typedef int mgcursorid;

// @type mgstringlist |  String list identifier type used to store list of
// strings as in an array. 
// @see <f mgGetPromptDialogFile> <f mgListGetStrings> <f mgListGetSelectedStrings> <f mgFreeStringList> 
typedef char** mgstringlist;

#define mgResourceIdsMatch(id1,id2) ((id1)==(id2))

// @macro int | mgStringIdsMatch | Checks if two string definition identifiers match.   
// @param | id1 | A string definition identifier   
// @param | id2 | Another string definition identifier   
//	@access Level 4
// @see <f mgResourceIdsMatch>, <f mgPixmapIdsMatch>, <f mgControlIdsMatch>,
// <f mgCursorIdsMatch>
// @return Returns 1 if identifiers match, 0 otherwise.  
#define mgStringIdsMatch(id1,id2)  mgResourceIdsMatch(id1,id2)

// @macro int | mgPixmapIdsMatch | Checks if two pixmap identifiers match.   
// @param | id1 | A pixmap identifier   
// @param | id2 | Another pixmap identifier   
//	@access Level 4
// @see <f mgResourceIdsMatch>, <f mgStringIdsMatch>, <f mgControlIdsMatch>,
// <f mgCursorIdsMatch>
// @return Returns 1 if identifiers match, 0 otherwise.
#define mgPixmapIdsMatch(id1,id2)  mgResourceIdsMatch(id1,id2)

// @macro int | mgControlIdsMatch | Checks if two control identifiers match.   
// @param | id1 | A control identifier   
// @param | id2 | Another control identifier   
// @access Level 4
// @see <f mgResourceIdsMatch>, <f mgStringIdsMatch>, <f mgPixmapIdsMatch>,
// <f mgCursorIdsMatch>
// @return Returns 1 if identifiers match, 0 otherwise.   
#define mgControlIdsMatch(id1,id2) mgResourceIdsMatch(id1,id2)

// @macro int | mgCursorIdsMatch | Checks if two cursor identifiers match.   
// @param | id1 | A cursor identifier   
// @param | id2 | Another cursor identifier   
// @access Level 4
// @see <f mgResourceIdsMatch>, <f mgStringIdsMatch>, <f mgPixmapIdsMatch>,
// <f mgControlIdsMatch>
// @return Returns 1 if identifiers match, 0 otherwise.   
#define mgCursorIdsMatch(id1,id2) mgResourceIdsMatch(id1,id2)

/*----------------------------------------------------------------------------*/

// @type mggui | Abstract type used to represent Dialog and Control GUI items
typedef struct mggui_t*	mggui;
					
// @type mgguicallbackreason | Callback reason type used to specify dialog 
// and control events.
// @desc When a control callback or dialog function is called, the <p callbackReason> 
// parameter passed in of this type will specify which event triggered the callback. 
// @desc Dialog and control callback functions are called to report these events.
// @desc The events that are sent to dialog functions are: <nl>
// <m MGCB_INIT> <nl>
// <m MGCB_SHOW> <nl>
// <m MGCB_SIZE> <nl>
// <m MGCB_REFRESH> <nl>
// <m MGCB_HIDE> <nl>
// <m MGCB_DESTROY> <nl>
// @desc The events that are sent to control callback functions are: <nl>
// <m MGCB_ACTIVATE> <nl>
// <m MGCB_REFRESH> <nl>
// <m MGCB_DRAW> <nl>
// @see <f mgSetGuiCallback>, <f mgResourceGetDialog>, <f mgResourceModalDialog>,
// <t mgguifunc>, <t mgdialogfunc>, <t mgguicalldatatype>
typedef unsigned int mgguicallbackreason;

#define MGCB_ACTIVATE			0x00000001			// @msg MGCB_ACTIVATE | Control event <p Activate>.
																// @desc This is the control event that is sent to a
																// control (via the control callback function)
																// when the user activates the control.  
																// @desc When this event is sent to a text control,
																// the <p callData> parameter passed to the callback
																// function will be a pointer to an object of type
																// <t mgtextactivatecallbackrec>.
																// @desc When this event is sent to a scale control,
																// the <p callData> parameter passed to the callback
																// function will be a pointer to an object of type
																// <t mgscaleactivatecallbackrec>.
																// @see <f mgSetGuiCallback>, <t mgguifunc>

#define MGCB_REFRESH				0x00000002			// @msg MGCB_REFRESH | Dialog/Control event <p Refresh>.
																// @desc This is the dialog/control event that is sent
																// to both dialogs and controls to notify them that
																// they need to be refreshed.
																// @desc Dialog events are sent to dialogs via
																// the dialog function.
																// @desc Control events are sent to controls via
																// the control callback function.
																// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>,
																// <t mgdialogfunc>,
																// <f mgSetGuiCallback>, <t mgguifunc>

#define MGCB_INIT					0x00000004			// @msg MGCB_INIT | Dialog event <p Initialize>.
																// @desc This is the dialog event that is sent
																// to a dialog (via the dialog function) when it
																// is initialized.
																// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>,
																// <t mgdialogfunc>

#define MGCB_SHOW					0x00000008			// @msg MGCB_SHOW | Dialog event <p Show>.
																// @desc This is the dialog event that is sent
																// to a dialog (via the dialog function) when it
																// changes from hidden to displayed.
																// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>,
																// <t mgdialogfunc>

#define MGCB_HIDE					0x00000010			// @msg MGCB_HIDE | Dialog event <p Hide>.
																// @desc This is the dialog event that is sent
																// to a dialog (via the dialog function) when it
																// changes from displayed to hidden.
																// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>,
																// <t mgdialogfunc>

#define MGCB_DESTROY				0x00000020			// @msg MGCB_DESTROY | Dialog event <p Destroy>.
																// @desc This is the dialog event that is sent
																// to a dialog (via the dialog function) when it
																// is destroyed.
																// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>,
																// <t mgdialogfunc>

#define MGCB_DRAW					0x00000040			// @msg MGCB_DRAW | Control event <p Draw>.
																// @desc This is the control event that is sent
																// to a GL control (via the control callback function) when it
																// needs to be drawn.
																// @desc When this event is sent to a GL control,
																// the <p callData> parameter passed to the callback
																// function will be a pointer to an object of type
																// <t mggldrawcallbackrec>.
																// @see <f mgSetGuiCallback>, <t mgguifunc>

#define MGCB_SIZE					0x00000080			// @msg MGCB_SIZE | Dialog event <p Size>.
																// @desc This is the dialog event that is sent
																// to a dialog (via the dialog function) when the
																// user changes its size.  A user can change a dialog's
																// size by explicitly dragging the resize handles on
																// the dialog or by minimizing or maximizing the dialog.
																// @desc When this event is sent to a dialog,
																// the <p callData> parameter passed to the dialog
																// function will be a pointer to an object of type
																// <t mgdialogsizecallbackrec>.
																// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>,
																// <t mgdialogfunc>

// @enumtype mgmousestate | mgmousestate | Mouse State Type.
// @desc This enumerated type is used in the following contexts:
// @desc When reporting mouse input events to editor tools.  See 
// <f mgRegisterEditor>, <f mgEditorSetVertexFunc>,
// <f mgEditorSetPointFunc>, <f mgEditorSetPickFunc> for more
// information.
// @desc When reporting the <m MGCB_ACTIVATE> control event to scale controls.
// See <t mgscaleactivatecallbackrec> for more information.
// @desc When reporting the <m MGCB_ACTIVATE> control event to text controls
// that have an associated spin buddy control. 
// See <t mgtextactivatecallbackrec> for more information.
typedef enum mgmousestate {
   MMSS_START = 0,         // @emem The mouse-start state.  This indicates that the 
									// associated event was the first (down) event in a sequence 
									// of mouse down/drag/release events.  The event sequence will
									// have at most, one <e mgmousestate.MMSS_START> event which
									// will always be the first event sent.
   MMSS_CONTINUE,          // @emem The drag-mouse state.  This indicates that the 
									// associated event was a drag event in a sequence of mouse
									// down/drag/release events.  The event sequence will
									// have 0-n <e mgmousestate.MMSS_CONTINUE> events, the first of
									// which will always follow the <e mgmousestate.MMSS_START> event,
									// and the last of which will always precede the 
									// <e mgmousestate.MMSS_STOP> event.
   MMSS_STOP,              // @emem The mouse-stop state.  This indicates that the 
									// associated event was the last (release) event in a sequence 
									// of mouse down/drag/release events.  The event sequence will
									// have at most, one <e mgmousestate.MMSS_STOP> event which will
									// always be the last event sent.
   MMSS_NONE               // @emem The mouse-none state.  This indicates that the 
									// mouse was not involved with the associated event.
} mgmousestate;

// @type mgglmouseaction | GL mouse action.
// @desc When a GL mouse function is called, the <p mouseAction> 
// parameter passed in of this type will specify which action triggered the 
// function being called. 
// @desc The mouse actions that are sent to GL mouse functions are: <nl>
// <m MGMA_BUTTON> <nl>
// <m MGMA_DOUBLECLICK> <nl>
// <m MGMA_MOTION> <nl>
// @see <f mgGlSetMouseFunc>, <t mgglmousefunc>
typedef unsigned int mgglmouseaction;

#define MGMA_BUTTON				0x00000001			// @msg MGMA_BUTTON | GL Mouse Action <p Button>.
																// @desc This is the GL mouse action that is reported
																// to GL controls (via the GL mouse function) when the
																// user presses, drags or releases a mouse button in
																// the control.
																// @desc When this action is reported, the <p callData>
																// parameter passed to the GL mouse function will be a
																// pointer to an object of type <t mgglmousebuttondatarec>.
																// @see <f mgGlSetMouseFunc>, <f mgglmousefunc>

#define MGMA_DOUBLECLICK		0x00000002			// @msg MGMA_DOUBLECLICK | GL Mouse Action <p Double Click>.
																// @desc This is the GL mouse action that is reported
																// to GL controls (via the GL mouse function) when the
																// user double clicks a mouse button in the control.
																// @desc When this action is reported, the <p callData>
																// parameter passed to the GL mouse function will be a
																// pointer to an object of type 
																// <t mgglmousedoubleclickdatarec>.
																// @see <f mgGlSetMouseFunc>, <f mgglmousefunc>

#define MGMA_MOTION				0x00000004			// @msg MGMA_MOTION | GL Mouse Action <p Motion>.
																// @desc This is the GL mouse action that is reported
																// to GL controls (via the GL mouse function) when the
																// user moves the the mouse pointer over the control
																// with no mouse buttons pressed.  This is useful for
																// simply tracking the mouse cursor within the GL control.
																// @desc When this action is reported, the <p callData>
																// parameter passed to the GL mouse function will be a
																// pointer to an object of type 
																// <t mgglmousemotiondatarec>.
																// @see <f mgGlSetMouseFunc>, <f mgglmousefunc>

// @enumtype mgglmousedatatype | mgglmousedatatype | GL Mouse Function Callback data type.
// @desc This type is used to indicate the type of call data passed to GL mouse function. 
// When a GL mouse function is called, the <p callData> parameter passed in will be a pointer
// to an object type that is dependent on the context of the mouse function. 
// @desc Each member of this type corresponds to a different GL mouse function call data
// structure.  
// @see <f mgGLSetMouseFunc>, <t mgglmousefunc>, <t mgglmouseaction>
typedef enum mgglmousedatatype {
   MGMCD_COMMON = 100,     // @emem GL Mouse Common Call Data.  This indicates that the 
									// <p callData> parameter to a GL mouse function is a pointer
									// to an object of type <t mgglmousedatarec> and has no
									// additional data.
   MGMCD_BUTTONDATA,			// @emem GL Mouse Button Call Data.  This indicates that the 
									// <p callData> parameter to a GL mouse function is a pointer
									// to an object of type <t mgglmousebuttondatarec>.
   MGMCD_DOUBLECLICKDATA,	// @emem GL Mouse Double Click Call Data.  This indicates that  
									// the <p callData> parameter to a GL mouse function is a pointer
									// to an object of type <t mgglmousedoubleclickdatarec>.
   MGMCD_MOTIONDATA,			// @emem GL Mouse Motion Call Data.  This indicates that  
									// the <p callData> parameter to a GL mouse function is a pointer
									// to an object of type <t mgglmousemotiondatarec>.
} mgglmousedatatype;


//	@structtype | mgglmousedatarec | generic callback structure for <p callData> 
//	parameter of <t mgglmousefunc>.
// @desc When a GL mouse function is called, the <p callData>
// parameter passed in will be a pointer to an object type that is dependent on the context
// of the mouse function.  The first field of each data structure is the same as this
// structure.  In this way, the <p callData> parameter can always safely be cast to a pointer
// to an object of this type.  Doing so, you can then examine the <p callDataType> field to
// determine which callback record structure has actually been passed.
// @see <t mgglmousedatatype>, <t mgglmousefunc>, <f mgGLSetMouseFunc>.
typedef struct {
	mgglmousedatatype		callDataType;		// @field Call data type that indicates 
														// the type of call data this object really is.
} mgglmousedatarec;

//	@structtype | mgglmousebuttondatarec | callback structure for the GL mouse button 
// action sent to GL controls.  
// @desc When the <m MGMA_BUTTON> mouse action is reported to a GL control via its 
// <t mgglmousefunc>, the <p calldata> parameter passed in will point to an object
// of this type.
// @desc The coordinates of mouse button input are reported relative
// to the lower left corner of the GL control in which the input
// was received.  That is, if the point reported is at the lower left
// corner of the control, it will be reported as (0, 0).
typedef struct {
	mgglmousedatatype		callDataType;		// @field Call data type that indicates
														// the type of call data this object really is.
														// Will always be <e mgglmousedatatype.MGMCD_BUTTONDATA>.
   mgmousestate			mouseEvent;       // @field The vertex input sequence state
   unsigned int			keyboardFlags;    // @field The state of the <p Alt>, <p Ctrl>, and <p Shift> keys.
														// The value of this field will be a bitwise combination
														// of <m MKB_ALTKEY>, <m MKB_CTRLKEY> and <m MKB_SHIFTKEY>.
   unsigned int			buttonFlags;      // @field The state of the <p Left>, <p Middle> and <p Right>
														// mouse buttons.  The value of this field will be a bitwise
														// combination of <m MMB_LEFTMOUSE>, <m MMB_MIDDLEMOUSE> and
														// <m MMB_RIGHTMOUSE>.
   mgcoord2i*				thisPoint;        // @field Address of 2D coordinate record for 
														// the current point being reported in this sequence
   mgcoord2i*				prevPoint;        // @field Address of 2D coordinate record for  
														// the previous point being reported in this sequence
   mgcoord2i*				firstPoint;       // @field Address of 2D coordinate record for	
														// the first point reported in this sequence

} mgglmousebuttondatarec;

//	@structtype | mgglmousedoubleclickdatarec | callback structure for the GL mouse 
// double click action sent to GL controls.  
// @desc When the <m MGMA_DOUBLECLICK> mouse action is reported to a GL control via its 
// <t mgglmousefunc>, the <p calldata> parameter passed in will point to an object
// of this type.
// @desc The coordinates of mouse button input are reported relative
// to the lower left corner of the GL control in which the input
// was received.  That is, if the point reported is at the lower left
// corner of the control, it will be reported as (0, 0).
typedef struct {
	mgglmousedatatype		callDataType;		// @field Call data type that indicates 
														// the type of call data this object really is.
														// Will always be <e mgglmousedatatype.MGMCD_DOUBLECLICKDATA>.
   unsigned int			keyboardFlags;    // @field The state of the <p Alt>, <p Ctrl>, and <p Shift> keys
														// The value of this field will be a bitwise combination
														// of <m MKB_ALTKEY>, <m MKB_CTRLKEY> and <m MKB_SHIFTKEY>.
   unsigned int			buttonFlags;      // @field The state of the <p Left>, <p Middle> and <p Right>
														// mouse buttons.  The value of this field will be a bitwise
														// combination of <m MMB_LEFTMOUSE>, <m MMB_MIDDLEMOUSE> and
														// <m MMB_RIGHTMOUSE>.
   mgcoord2i*				thisPoint;        // @field Address of 2D coordinate record for 
														// the double click reported
} mgglmousedoubleclickdatarec;

//	@structtype | mgglmousemotiondatarec | callback structure for the GL mouse 
// motion action sent to GL controls.  
// @desc When the <m MGMA_MOTION> mouse action is reported to a GL control via its 
// <t mgglmousefunc>, the <p calldata> parameter passed in will point to an object
// of this type.
// @desc The coordinates of mouse button input are reported relative
// to the lower left corner of the GL control in which the input
// was received.  That is, if the point reported is at the lower left
// corner of the control, it will be reported as (0, 0).
typedef struct {
	mgglmousedatatype		callDataType;		// @field Call data type that indicates 
														// the type of call data this object really is.
														// Will always be <e mgglmousedatatype.MGMCD_MOTIONDATA>.
   unsigned int			keyboardFlags;    // @field The state of the <p Alt>, <p Ctrl>, and <p Shift> keys
														// The value of this field will be a bitwise combination
														// of <m MKB_ALTKEY>, <m MKB_CTRLKEY> and <m MKB_SHIFTKEY>.
   mgcoord2i*				thisPoint;        // @field Address of 2D coordinate record for motion
														// reported
} mgglmousemotiondatarec;

#define MGSP_DONOTCHANGE		(-1)			// @msg MGSP_DONOTCHANGE | Gui Size/Position <p Do Not Change>.
														// @desc When you call <f mgGuiSetSize> or <f mgGuiSetPos>, 
														// you may specify <m MGSP_DONOTCHANGE> for any of the 
														// position or dimension parameters to indicate that you do
														// not want that position or dimension value for the gui item
														// to change.


// @cb mgstatus | mgglmousefunc | GL mouse function.   
// @desc This is the signature for GL mouse functions.
// If a GL control is to accept mouse input from the user, you will provide a 
// GL mouse function of this form that will be called to notify your GL control
// of the actions from the user via the mouse.
// @return Currently, the value returned by <t mgglmousefunc> is ignored and
// reserved for future enhancement.  For now always return <m MSTAT_OK>.
// @see <f mgGLSetMouseFunc>, <f mgSetGuiCallback>
typedef mgstatus ( *mgglmousefunc )(
		mggui control,										// @param the gl control
		mgcontrolid controlId,							// @param the identifier of the control
		mgglmouseaction mouseAction,					// @param the mouse action that triggered the function
		void* userData,									// @param user defined data specified when function assigned to control
		void* callData										// @param callback specific data - you can always safely 
																// cast this pointer to a pointer to an object of type
																// <t mgglmousedatarec> to determine the type of call
																// data this object really is
		);

// @cb mgstatus | mgguifunc | Control callback function.   
// @desc This is the signature for control callback functions.
// You can define the behavior of controls in your dialog instances
// by assigning control callbacks to them of this form.  Control
// callback functions are called to notify your plug-in tool of
// significant control events.
// @return Currently the value returned by <t mgguifunc> is ignored and
// reserved for future enhancement.  For now always return <m MSTAT_OK>.
// @see <f mgSetGuiCallback>  
typedef mgstatus ( *mgguifunc )(
		mggui control,										// @param the control
		mgcontrolid controlId,							// @param the identifier of the control
		mgguicallbackreason callbackReason,			// @param the control event that triggered the callback
		void* userData,									// @param user defined data specified when callback assigned 
																// to control
		void* callData										// @param callback specific data - you can always safely 
																// cast this pointer to a pointer to an object of type 
																// <t mgguicallbackrec> to determine the type of call
																// data this object really is
		);


// @enumtype mgdialogattribute | mgdialogattribute | Dialog attribute name type.
// @desc This type is used to enumerate the dialog attributes that can be set.
// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>, <f mgDialogSetAttribute>
typedef enum mgdialogattribute {
		MDA_RESIZEWIDTH,			// @emem Resize Width.
										// This dialog attribute specifies whether or not a dialog's 
										// width is resizable.  A value of 1 indicates that the width 
										// is resizable, 0 it is not.  If your dialog
										// can be minimized, you must set this attribute to 1.
										// The default value of this attribute is 1 meaning that
										// the width of a dialog may be resized (if allowed to do
										// so in the dialog template).   
		MDA_RESIZEHEIGHT,			// @emem Resize Height.
										// This dialog attribute specifies whether or not a dialog's
										// height is resizable.  A value of 1 indicates that the height
										// is resizable, 0 it is not.  If your dialog
										// can be minimized, you must set this attribute to 1.
										// The default value of this attribute is 1 meaning that
										// the height of a dialog may be resized (if allowed to do
										// so in the dialog template).    
		MDA_MINWIDTH,				// @emem Minimum Width.
										// This dialog attribute specifies the minimum width
										// (in pixels) the dialog is allowed to be resized.
										// If the value of this attribute is -1, the dialog has no
										// user defined minimum width.  In this case, the minimum
										// width will be imposed by the window system.  Also, if
										// a minimum width is specified that is less than the system
										// imposed minimum width, the system may override this value.
										// The default value of this attribute is -1 meaning that
										// there is no user defined minimum dimension.
										// This attribute is only applicable if the dialog width is
										// resizable (i.e., <e mgdialogattribute.MDA_RESIZEWIDTH> is 1).
		MDA_MAXWIDTH,				// @emem Maximum Width.
										// This dialog attribute specifies the maximum width
										// (in pixels) the dialog is allowed to be resized.
										// If the value of this attribute is -1, the dialog has no
										// user defined maximum width.  In this case, the maximum 
										// width will be imposed by the window system.
										// The default value of this attribute is -1 meaning that
										// there is no user defined maximum dimension.  Also, if
										// a maximum width is specified that is greater than the system
										// imposed maximum width, the system may override this value.
										// This attribute is only applicable if the dialog width is
										// resizable (i.e., <e mgdialogattribute.MDA_RESIZEWIDTH> is 1).
		MDA_MINHEIGHT,				// @emem Minimum Height.
										// This dialog attribute specifies the minimum height
										// (in pixels) the dialog is allowed to be resized.
										// If the value of this attribute is -1, the dialog has no
										// user defined minimum height.  In this case, the minimum 
										// height will be imposed by the window system.
										// The default value of this attribute is -1 meaning that
										// there is no user defined minimum dimension.  Also, if
										// a minimum height is specified that is less than the system
										// imposed minimum height, the system may override this value.
										// This attribute is only applicable if the dialog height is
										// resizable (i.e., <e mgdialogattribute.MDA_RESIZEHEIGHT> is 1).
		MDA_MAXHEIGHT				// @emem Maximum Height.
										// This dialog attribute specifies the maximum height
										// (in pixels) the dialog is allowed to be resized.
										// If the value of this attribute is -1, the dialog has no
										// user defined maximum height.  In this case, the maximum 
										// height will be imposed by the window system.  Also, if
										// a maximum height is specified that is greater than the system
										// imposed maximum height, the system may override this value.
										// The default value of this attribute is -1 meaning that
										// there is no user defined maximum dimension.
										// This attribute is only applicable if the dialog height is
										// resizable (i.e., <e mgdialogattribute.MDA_RESIZEHEIGHT> is 1).
} mgdialogattribute;

// @cb mgstatus | mgdialogfunc | Dialog function
// @desc This is the signature for dialog functions.
// When you create a dialog instance, you will provide a dialog function
// of this form that will be called to notify your plug-in tool of 
// significant dialog events.
// @return Currently, the value returned by <t mgdialogfunc> is ignored and
// reserved for future enhancement.  For now always return <m MSTAT_OK>.
// @see <f mgResourceGetDialog>, <f mgResourceModalDialog>
typedef mgstatus ( *mgdialogfunc )(
		mggui dialog,										// @param the dialog
		mgdialogid dialogId,								// @param the identifier of the dialog
		mgguicallbackreason callbackReason,			// @param the dialog event that triggered the callback
		void* userData,									// @param user defined data specified when dialog was created
		void* callData										// @param callback specific data - you can always safely 
																// cast this pointer to aa pointer to an object of type
																// <t mgguicallbackrec> to determine the type of call
																// data this object really is
		);

// @enumtype mgguicalldatatype | mgguicalldatatype | GUI Callback data type.
// @desc This type is used to indicate the type of call data passed to control callback
// and dialog functions. When a control callback or dialog function is called, the <p callData>
// parameter passed in will be a pointer to an object type that is dependent on the context of
// the callback function. 
// @desc Each member of this type corresponds to a different callback data structure.  
// @see <f mgSetGuiCallback>, <f mgResourceGetDialog>, <f mgResourceModalDialog>,
// <t mgguifunc>, <t mgdialogfunc>, <t mgguicallbackreason>
typedef enum mgguicalldatatype {
   MGCD_COMMON = 0,        // @emem Common Call Data.  This indicates that the 
									// <p callData> parameter to a control callback or dialog 
									// function is a pointer to an object of type 
									// <t mgguicallbackrec> and has no additional data.
   MGCD_TEXTACTIVATE,      // @emem Text Activate Call Data.  This indicates that the 
									// <p callData> parameter to a control callback is a pointer
									// to an object of type <t mgtextactivatecallbackrec>.
   MGCD_SCALEACTIVATE,     // @emem Scale Activate Call Data.  This indicates that the 
									// <p callData> parameter to a control callback is a pointer
									// to an object of type <t mgscaleactivatecallbackrec>.
   MGCD_GLDRAW,				// @emem GL Draw Call Data.  This indicates that the 
									// <p callData> parameter to a control callback is a pointer
									// to an object of type <t mggldrawcallbackrec>.
	MGCD_DIALOGSIZE			// @emem Dialog Size Call Data.  This indicates that the 
									// <p callData> parameter to a dialog function is a pointer
									// to an object of type <t mgdialogsizecallbackrec>.
} mgguicalldatatype;

//	@structtype | mgguicallbackrec | generic callback structure for <p callData> 
//	parameter of <t mgguifunc> and <t mgdialogfunc>.  
// @desc When a control callback or dialog
// function is called, the <p callData> parameter passed in will be a pointer to an 
// object type that is dependent on the context of the callback function.  The first
// field of each data structure is the same as this structure.  In this way, the
// <p callData> parameter can always safely be cast to a pointer to an object of this 
// type.  Doing so, you can then examine the <p callDataType> field to determine which
// callback record structure has actually been passed.
// @see <t mgguicalldatatype>, <t mgguifunc>, <t mgdialogfunc>.
typedef struct {
	mgguicalldatatype callDataType;	// @field Call data type that indicates
												// the type of call data this object really is.
} mgguicallbackrec;

//	@structtype | mgscaleactivatecallbackrec | callback structure for the activate control
// event sent to scale controls.  
// @desc When the <m MGCB_ACTIVATE> control event is sent to
// a scale control via its <t mgguifunc>, the <p calldata> parameter passed in will point
// to an object of this type.
typedef struct {
	mgguicalldatatype callDataType;	// @field Call data type that indicates the 
												// type of call data this object really is.
												// Will always be <e mgguicalldatatype.MGCD_SCALEACTIVATE>.
		
	mgmousestate mouseState;	// @field State of mouse when event was triggered. 
										// Possible values are: <nl>
										// <e mgmousestate.MMSS_START> - The mouse state will be set to this 
										// value under either of the following conditons: <nl>
										// When the user first presses the left mouse button on the thumb or
										// the trough of the scale control. -- or -- <nl>
										// When the user first presses (and then holds) the left mouse button
										// on either arrow button of the spin buddy control associated to the
										// scale control.  Note: If the user clicks the left mouse button on the 
										// spin buddy control (without holding it down), the event will be treated
										// like a single event and <e mgmousestate.MMSS_NONE> will be used. 
										// <nl>
										// <e mgmousestate.MMSS_CONTINUE> - The mouse state is set to this value 
										// as long as the user continues to hold the left mouse button down on the 
										// thumb or the trough of the scale control, or on either arrow of an
										//	associated spin buddy control.
										// <nl>
										// <e mgmousestate.MMSS_STOP> - The mouse state is set to this value when
										// the user releases the left mouse button after dragging the mouse on the
										// thumb or the trough of the scale control, or after holding down either
										// arrow of an associated spin buddy control.
										// <nl>
										// <e mgmousestate.MMSS_NONE> - The mouse state will be set to this value 
										// under either of the following conditons: <nl>
  										// When the user enters a numeric value into the text buddy control
										// of the associated scale control. -- or -- <nl>
										// When the user clicks (but does not hold) the left mouse button on
										// either arrow of the spin buddy control associated to the scale control.	
} mgscaleactivatecallbackrec;

//	@structtype | mgtextactivatecallbackrec | callback structure for the activate control
// event sent to text controls.
// @desc When the <m MGCB_ACTIVATE> control event is sent to
// a text control via its <t mgguifunc>, the <p calldata> parameter passed in will point
// to an object of this type.
typedef struct {
	mgguicalldatatype callDataType;	// @field Call data type that indicates
												// the type of call data this object really is.
												// Will always be <e mgguicalldatatype.MGCD_TEXTACTIVATE>.

	mgmousestate mouseState;	// @field State of mouse when event was triggered. 
										// Possible values are: <nl>
										// <e mgmousestate.MMSS_START> - The mouse state will be set to this 
										// value when the user first presses (and then holds) the left mouse button
										// on either arrow button of the spin buddy control associated to the
										// text control.  Note: If the user clicks the left mouse button on the 
										// spin buddy control (without holding it down), the event will be treated
										// like a single event and <e mgmousestate.MMSS_NONE> will be used. 
										// <nl>
										// <e mgmousestate.MMSS_CONTINUE> - The mouse state is set to this value 
										// as long as the user continues to hold the left mouse button down on 
										// either arrow of an associated spin buddy control. 
										// <nl>
										// <e mgmousestate.MMSS_STOP> - The mouse state is set to this value when
										// the user releases the left mouse button after holding down either
										// arrow of an associated spin buddy control. 
										// <nl>
										// <e mgmousestate.MMSS_NONE> - The mouse state will be set to this value 
										// under either of the following conditons: <nl>
  										// When the user enters a numeric value into the text control. -- or -- <nl>
										// When the user clicks (but does not hold) the left mouse button on
										// either arrow of the spin buddy control associated to the text control.
} mgtextactivatecallbackrec;

//	@structtype | mggldrawcallbackrec | callback structure for the draw control
// event sent to GL controls.
// @desc When the <m MGCB_DRAW> control event is sent to
// a GL control via its <t mgguifunc>, the <p calldata> parameter passed in will point
// to an object of this type.
typedef struct {
	mgguicalldatatype		callDataType;		// @field Call data type that 
														// indicates the type of call data this object really is.
														// Will always be <e mgguicalldatatype.MGCD_GLDRAW>.	
	int						width;				// @field width, in pixels of the GL control.
	int						height;				// @field height, in pixels of the GL control.
	mgglcontext				glContext;			// @field rendering context associated with GL control
} mggldrawcallbackrec;

//	@structtype | mgdialogsizecallbackrec | callback structure for the size dialog
// event sent to dialogs.
// @desc When the <m MGCB_SIZE> dialog event is sent to a
// dialog via its <t mgdialogfunc>, the <p calldata> parameter passed in will point
// to an object of this type.
typedef struct {							
	mgguicalldatatype		callDataType;		// @field Call data type that 
														// indicates the type of call data this object really is.
														// Will always be 
														// <e mgguicalldatatype.MGCD_DIALOGSIZE>.
	mgbool					isMinimized;		// @field <e mgbool.MG_TRUE> if 
														// dialog is being minimized, <e mgbool.MG_FALSE>
														// otherwise.
} mgdialogsizecallbackrec;

#define MGLBS_NONE		0x00000000			// @msg MGLBS_NONE | Control Attribute GL Border Style <p None>
														// @desc This is a valid value for Control Attribute <p GL Border Style>
														// <m MCA_GLBORDERSTYLE>.
														// @desc If you specify this value for <m MCA_GLBORDERSTYLE> when
														// you call <f mgControlSetAttribute>, no border will be drawn
														// around the specified GL control. This is the default.
														// @see <f mgControlSetAttribute>, <f mgSetGuiCallback>

#define MGLBS_SUNKEN		0x00000001			// @msg MGLBS_SUNKEN | Control Attribute GL Border Style <p Sunken>
														// @desc This is a valid value for Control Attribute <p GL Border Style>
														// <m MCA_GLBORDERSTYLE>.
														// @desc If you specify this value for <m MCA_GLBORDERSTYLE> when
														// you call <f mgControlSetAttribute>, a sunken frame will be drawn
														// around the specified GL control.
														// @see <f mgControlSetAttribute>, <f mgSetGuiCallback>

#define MGLBS_RAISED		0x00000002			// @msg MGLBS_RAISED | Control Attribute GL Border Style <p Raised>
														// @desc This is a valid value for Control Attribute <p GL Border Style>
														// <m MCA_GLBORDERSTYLE>.
														// @desc If you specify this value for <m MCA_GLBORDERSTYLE> when
														// you call <f mgControlSetAttribute>, a raised frame will be drawn
														// around the specified GL control.
														// @see <f mgControlSetAttribute>, <f mgSetGuiCallback>

#define MGLBS_SOLID		0x00000003			// @msg MGLBS_SOLID | Control Attribute GL Border Style <p Solid>
														// @desc This is a valid value for Control Attribute <p GL Border Style>
														// <m MCA_GLBORDERSTYLE>.
														// @desc If you specify this value for <m MCA_GLBORDERSTYLE> when
														// you call <f mgControlSetAttribute>, a solid frame will be drawn
														// around the specified GL control.
														// @see <f mgControlSetAttribute>, <f mgSetGuiCallback>


// @enumtype mgcontrolattribute | mgcontrolattribute | Control attribute name type.
// @desc This type is used to enumerate the control attributes that can be set.
// @see <f mgControlSetAttribute>
typedef enum mgcontrolattribute {
		MCA_GLBORDERSTYLE,		// @emem GL Control Border Style.
										// This control attribute specifies what kind (if any)
										// of border to draw around the GL control.
										// The possible values for this attribute include:
										// <m MGLBS_NONE>, <m MGLBS_SUNKEN>, <m MGLBS_RAISED>
										// and <m MGLBS_SOLID>.  <m MGLBS_NONE> is the default.
		MCA_BOLDFONT,				// @emem Control Bold Font Style.
										// This control attribute specifies whether or not
										// a control's font is bold.
										// The possible values for this attribute include:
										// 1 (bold) or 0 (not bold).  0 is the default.
		MCA_ITALICFONT,			// @emem Control Italic Font Style.
										// This control attribute specifies whether or not
										// a control's font is italic.
										// The possible values for this attribute include:
										// 1 (italic) or 0 (not italic).  0 is the default.
} mgcontrolattribute;

// @enumtype mgpaletteid | mgpaletteid | Palette Id type.
// @desc This type is used to enumerate the database palettes that can be displayed
// using the <f mgShowPalette> function.
// @see <f mgShowPalette>
typedef enum mgpaletteid {
		MPID_COLORPALETTE,				// @emem Primary Color Palette Id.
												// This palette id specifies the Primary Color Palette.
		MPID_ALTCOLORPALETTE,			// @emem Alternate Color Palette Id.
												// This palette id specifies the Alternate Color Palette.
		MPID_IRCOLORPALETTE,				// @emem Infrared Color Palette Id.
												// This palette id specifies the Infrared Color Palette.
		MPID_MATERIALPALETTE,			// @emem Material Palette Id.
												// This palette id specifies the Material Palette.
		MPID_LIGHTSOURCEPALETTE,		// @emem Light Source Palette Id.
												// This palette id specifies the Light Source Palette.
		MPID_TEXTUREPALETTE,				// @emem Texture Palette Id.
												// This palette id specifies the Texture Palette.
		MPID_TEXTUREMAPPINGPALETTE,	// @emem Texture Mapping Palette Id.
												// This palette id specifies the Texture Mapping Palette.
		MPID_SOUNDPALETTE,				// @emem Sound Palette Id.
												// This palette id specifies the Sound Palette.
		MPID_LINESTYLEPALETTE,			// @emem Line Style Palette Id.
												// This palette id specifies the Line Style Palette.
		MPID_LIGHTPOINTPALETTE,			// @emem light point Palette Id.
												// This palette id specifies the Light Point Palette.
} mgpaletteid;

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgguihandle | mgGetGuiHandle | return a native GUI handle.
	@desc <f mgGetGuiHandle> returns a platform specific handle to the specified
	dialog or control <p gui>.

	@return For Windows NT, this function returns an object of type HWND.

	@access Level 4
	@see <f mgFindGuiById>, <f mgResourceGetDialog>
*/
extern MGAPIFUNC(mgguihandle) mgGetGuiHandle ( 
	mggui gui			// @param abstract dialog or control to get native handle for
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* General Dialog Functions                                                   */
/*============================================================================*/
/* @doc EXTERNAL DIALOGFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgShowDialog | display a dialog.
	@desc <f mgShowDialog> displays a dialog on the screen.

	@desc If the show dialog event has been selected for the dialog function, it
	is sent.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgResourceGetDialog>, <f mgHideDialog>, <f mgDestroyDialog>, <f mgRefreshDialog>
*/
extern MGAPIFUNC(mgstatus) mgShowDialog ( 
	mggui dialog		// @param dialog to display
	);

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgShowPalette | displays a database palette window.
	@desc <f mgShowPalette> displays the database palette specified 
	<p paletteId>.  If the palette is not already displayed, it will be.  If
	the palette is already displayed but occluded by another window, it will
	be brought to the top of the window order on the desktop.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
MGAPIFUNC(mgstatus) mgShowPalette ( 
	mgpaletteid paletteId // @param the palette to show
	);	
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgHideDialog | hides a dialog.
	@desc <f mgHideDialog> removes a dialog from the screen.

	@desc If the hide dialog event has been selected for the dialog function, it
	is sent.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgShowDialog>, <f mgDestroyDialog>, <f mgRefreshDialog>
*/
extern MGAPIFUNC(mgstatus) mgHideDialog (
	mggui dialog		// @param dialog to hide
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDestroyDialog | destroys a dialog.
	@desc <f mgDestroyDialog> destroys a dialog.

	@desc If the dialog is currently displayed, it is first hidden
	and then destroyed.

	@desc If the destroy dialog event has been selected for the dialog function,
	it is sent.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgShowDialog>, <f mgHideDialog>, <f mgRefreshDialog>
*/
extern MGAPIFUNC(mgstatus) mgDestroyDialog (
	mggui dialog		// @param dialog to destroy
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgRefreshDialog | refreshes a dialog.
	@desc <f mgRefreshDialog> refreshes the dialog associated to the specified
	<p gui>.  The parameter <p gui> may be any control contained in the dialog
	or may be the dialog itself.

	@desc If the refresh dialog event has been selected for the dialog function
	of the intended dialog, the refresh event is first sent to the dialog.  
	Then, for all controls contained in the dialog that have selected the
	refresh control event, the event is sent.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgShowDialog>, <f mgHideDialog>, <f mgDestroyDialog>, 
	<f mgRefreshControl>
*/
extern MGAPIFUNC(mgstatus) mgRefreshDialog (
	mggui gui		// @param any control in the dialog (or the dialog itself)
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgRefreshControl | refreshes a control.
	@desc <f mgRefreshControl> refreshes the specified <p control>.  

	@desc If the refresh control event has been selected for the callback
	function of the specified control, the refresh event is sent to the
	control.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSetGuiCallback>, <f mgRefreshDialog>
*/
extern MGAPIFUNC(mgstatus) mgRefreshControl (
	mggui control		// @param the control to refresh
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDialogSetAttribute | sets the attribute values of a dialog.
	@desc <f mgDialogSetAttribute> sets the specified dialog attribute <p dialogAttr>
	for the <p dialog> to the specified value <p attrValue>.
	
	@desc Dialog attributes define how dialogs behave in different situations.  
	The dialog attributes and a brief description of each are listed below.  
	These are the possible values for  <p dialogAttr>.  For more information
	on the meaning of each attribute, see the description of that particular
	attribute.

	@desc <e mgdialogattribute.MDA_RESIZEWIDTH> - specifies whether or not the 
	dialog's width can be resized.
	@desc <e mgdialogattribute.MDA_RESIZEHEIGHT> - specifies whether or not the
	dialog's height can be resized.  
	@desc <e mgdialogattribute.MDA_MINWIDTH> - specifies the minimum width
	the dialog can be sized.
	@desc <e mgdialogattribute.MDA_MAXWIDTH> - specifies the maximum width
	the dialog can be sized.
	@desc <e mgdialogattribute.MDA_MINHEIGHT> - specifies the minimum height
	the dialog can be sized.
	@desc <e mgdialogattribute.MDA_MAXHEIGHT> - specifies the maximum height
	the dialog can be sized.

	@ex The following example sets the minimum size the user can resize a 
	dialog to be its current dimentions.  This would be done, most likely,
	when the <m MGCB_INIT> dialog event is handled by the dialog function. |
   mggui dialog;
   int dlgW, dlgH;

   mgGuiGetSize ( dialog, &dlgW, &dlgH );
   mgDialogSetAttribute ( dialog, MDA_MINWIDTH, dlgW );
   mgDialogSetAttribute ( dialog, MDA_MINHEIGHT, dlgH );

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgResourceGetDialog>, <f mgShowDialog>, <t mgdialogattribute>, 
	<m MGCB_SIZE>, <f mgControlSetAttribute>
*/
extern MGAPIFUNC(mgstatus) mgDialogSetAttribute (
	mggui dialog,								// @param the dialog whose attribute is to be set
	mgdialogattribute dialogAttr,			// @param the dialog attribute to set
	int attrValue								//	@param the value to which the attribute is set
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGetTitle | retrieves title string for a dialog.
	@desc <f mgGetTitle> retrieves the title string of the specified <p dialog>.

	@desc The title is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSetTitle>, <f mgGetCaption>, <f mgSetCaption>
*/
extern MGAPIFUNC(mgstatus) mgGetTitle (
	mggui dialog,		//	@param the dialog to get title string for
	char* string,		//	@param character buffer to hold title retrieved
	int maxLen			//	@param the maximum number of characters to store in <p string>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetTitle | sets title string for a dialog.
	@desc <f mgSetTitle> sets the title of the specified <p dialog>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgGetTitle>, <f mgGetCaption>, <f mgSetCaption>
*/
extern MGAPIFUNC(mgstatus) mgSetTitle (
	mggui dialog,		//	@param the dialog whose title will be set
	char* string		//	@param the title string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* General Control Functions                                                  */
/*============================================================================*/
/* @doc EXTERNAL GENERALCONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGuiGetSize | retrieves the dimensions of a control
	or dialog.
	@desc <f mgGuiGetSize> returns the <p width> and/or <p height> of the
	specified control or dialog, <p gui>, measured in pixels.

	@desc For both controls and dialogs, the dimensions returned define the
	"outer" dimensions of the gui item.  The outer dimensions include the margin,
	or in the case of dialogs, the title bar dimensions.  For most controls, the
	outer dimensions are identical to the "inner" or "view" dimensions of the control.
	For dialogs, the outer dimensions are almost always larger than the view dimensions.
	As stated above, this is due to margins and the title bar of the dialog.
  
	@desc If either of the dimension parameters are <m MG_NULL>, that
	particular dimension will not be returned.  

   @return Use macro <m MSTAT_ISOK> to check return value for success.  If
	function is successful, <p width> and <p height> contain the corresponding
	dimensions, otherwise their contents are undefined.

	@see <f mgGuiSetSize>, <f mgGuiGetViewSize>, <f mgGuiGetPos>, <f mgGuiSetPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGuiGetSize (
	mggui gui,				// @param the control or dialog whose dimensions
								// are to be returned
	int* width,				// @param address of value to receive width dimension
	int* height				// @param address of value to receive height dimension
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGuiSetSize | sets the dimensions of a control
	or dialog.
	@desc <f mgGuiSetSize> sets the <p width> and/or <p height> of the
	specified control or dialog, <p gui>, measured in pixels.

	@desc For both controls and dialogs, the dimensions set by this function
	are the "outer" dimensions of the gui item.  The outer dimensions include
	the margin, or in the case of dialogs, the title bar dimensions.  For most
	controls, the outer dimensions are identical to the "inner" or "view"
	dimensions of the control.  For dialogs, the outer dimensions are almost
	always larger than the view dimensions.  As stated above, this is due to
	margins and the title bar of the dialog.
  
	@desc If either of the input parameters are <m MGSP_DONOTCHANGE>, that
	particular dimension will not be changed.  In this way, you can set one 
	dimension without having to respecify the value for the other.  For example,
	if you specify a value for <p width>, but <m MGSP_DONOTCHANGE> for <p height>,
	the width of the gui item will be changed, but the height will not be affected.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgGuiGetSize>, <f mgGuiGetViewSize>, <f mgGuiGetPos>, <f mgGuiSetPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGuiSetSize (
	mggui gui,				// @param the control or dialog whose dimensions
								// are to be set
	int width,				// @param new width dimension
	int height				// @param new height dimension
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGuiGetViewSize | retrieves the view dimensions of
	a control or dialog.
	@desc <f mgGuiGetViewSize> returns the view <p width> and/or <p height>
	of the specified control or dialog, <p gui>, measured in pixels.

	@desc For both controls and dialogs, the dimensions returned define the
	"inner" or "view" dimensions of the gui item.  The view dimensions do not
	include the margin, or in the case of dialogs, the title bar dimensions.
	For most controls, the view dimensions are identical to the outer dimensions
	of the control.  For dialogs, the view dimensions are almost always smaller
	than the view dimensions.  As stated above, this is due to margins and the
	title bar of the dialog.
  
	@desc If either of the dimension parameters are <m MG_NULL>, that
	particular dimension will not be returned.  

   @return Use macro <m MSTAT_ISOK> to check return value for success.  If
	function is successful, <p width> and <p height> contain the corresponding
	dimensions, otherwise their contents are undefined.

	@see <f mgGuiGetSize>, <f mgGuiSetSize>, <f mgGuiGetPos>, <f mgGuiSetPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGuiGetViewSize (
	mggui gui,				// @param the control or dialog whose view dimensions
								// are to be returned
	int* width,				// @param address of value to receive width dimension
	int* height				// @param address of value to receive height dimension
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGuiGetPos | retrieves the position of a control
	or dialog.
	@desc <f mgGuiGetPos> returns the <p left> and/or <p top> position 
	of the specified control or dialog, <p gui>, measured in pixels.

   @desc The position of a control is measured relative to the upper left corner
	of the parent dialog's "view" area.  The upper left corner of a dialog's 
	view area is at position (0, 0).  Remember that the view area of a dialog
	does not include the margin or the title bar of the dialog.
  
   @desc The position of a dialog is measured relative to the upper left
	corner of the screen.  The upper left corner of the screen is at position
	(0, 0).

	@desc If either of the position parameters are <m MG_NULL>, that
	particular position will not be returned.  

   @return Use macro <m MSTAT_ISOK> to check return value for success.  If
	function is successful, <p top> and <p left> contain the corresponding
	positions, otherwise their contents are undefined.

	@see <f mgGuiSetPos>, <f mgGuiGetSize>, <f mgGuiSetSize>, <f mgGuiGetViewSize>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGuiGetPos (
	mggui gui,				// @param the control or dialog whose position is
								// to be returned
	int* left,				// @param address of value to receive left position
	int* top					// @param address of value to receive top position
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGuiSetPos | sets the position of a control
	or dialog.
	@desc <f mgGuiSetPos> sets the <p left> and/or <p top> position 
	of the specified control or dialog, <p gui>, measured in pixels.

   @desc The position of a control is measured relative to the upper left corner
	of the parent dialog's "view" area.  The upper left corner of a dialog's 
	view area is at position (0, 0).  Remember that the view area of a dialog
	does not include the margin or the title bar of the dialog.
  
   @desc The position of a dialog is measured relative to the upper left
	corner of the screen.  The upper left corner of the screen is at position
	(0, 0).

	@desc If either of the input parameters are <m MGSP_DONOTCHANGE>, that
	particular position will not be changed.  In this way, you can set one 
	position without having to respecify the value for the other.  For example,
	if you specify a value for <p top>, but <m MGSP_DONOTCHANGE> for <p left>,
	the top position of the gui item will be changed, but the left position
	will not be affected.

	@see <f mgGuiGetPos>, <f mgGuiGetSize>, <f mgGuiSetSize>, <f mgGuiGetViewSize>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGuiSetPos (
	mggui gui,				// @param the control or dialog whose position is
								// to be set
	int left,				// @param new left position
	int top					// @param new top position
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetEnabled | enables or disables a control in a dialog.
	@desc Depending on the value of the parameter <p enabled>, <f mgSetEnabled> will
	either enable (<e mgbool.MG_TRUE>) or disable (<e mgbool.MG_FALSE>) the 
	control <p control>.  Controls that are enabled can accept user input.

	@desc If the control you specify to this function has any buddy controls 
	associated, the buddy controls are also enabled/disabled accordingly.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgIsEnabled>, <f mgSetVisible>, <f mgIsVisible>
*/
extern MGAPIFUNC(mgstatus) mgSetEnabled (
	mggui control,			// @param the control to enable or disable
	mgbool enabled			// @param enum mgbool <e mgbool.MG_TRUE> to enable control, 
								// <e mgbool.MG_FALSE> to disable control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIsEnabled | determine if a control in a dialog is enabled.
	@desc <f mgIsEnabled> determines if a control in a dialog is enabled.
	Controls that are enabled can accept user input.

	@return Returns <e mgbool.MG_TRUE> if the control is enabled, <e mgbool.MG_FALSE>
	otherwise.

	@access Level 4
	@see <f mgSetEnabled>, <f mgSetVisible>, <f mgIsVisible>
*/
extern MGAPIFUNC(mgbool) mgIsEnabled (
	mggui control				//	@param the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetVisible | displays or hides a control in a dialog.
	@desc Depending on the value of the parameter <p visible>, <f mgSetVisible> 
	either displays (<e mgbool.MG_TRUE>) or hides (<e mgbool.MG_FALSE>) the 
	control <p control>.  Controls that are visible can be seen on the dialog.

	@desc If the control you specify to this function has any buddy controls 
	associated, the buddy controls are also hidden/displayed accordingly.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgIsVisible>, <f mgSetEnabled>, <f mgIsEnabled> 
*/
extern MGAPIFUNC(mgstatus) mgSetVisible (
	mggui control,			//	@param the control to display or hide
	mgbool visible			// @param enum mgbool <e mgbool.MG_TRUE> to display control,
								// <e mgbool.MG_FALSE> to hide control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIsVisible | determines if a control in a dialog is visible.
	@desc <f mgIsEnabled> determines if a control in a dialog is enabled.
	Controls that are enabled can accept user input.

	@return Returns <e mgbool.MG_TRUE> if the control is enabled, <e mgbool.MG_FALSE>
	otherwise.

	@access Level 4
	@see <f mgSetEnabled>, <f mgSetVisible>, <f mgIsVisible>
*/
extern MGAPIFUNC(mgbool) mgIsVisible (
	mggui control				//	@param the control
	);
/*                                                                            */
/*============================================================================*/

/* Property List for mggui*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGuiPutProperty | associates user defined data with a gui
	item.

	@desc <f mgGuiPutProperty> allows plug-in writers to associate data of any type, 
	<p propValue>, with a dialog or control.  The user-defined data is associated with
	a gui item, <p gui>, along with a property name string, <p propName>, 
	allowing any number of data records to be associated with the gui item, 
	as long as all property names are unique.

	@return <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 4
	@see <f mgGuiGetProperty>, <f mgGuiDeleteProperty>
*/
extern MGAPIFUNC(mgbool) mgGuiPutProperty	(
	mggui gui,							// @param the gui item to put property on
	mgpropertyname propName,		// @param the name of the property to assign
	mgpropertyvalue propValue		// @param the value of the property to assign
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgpropertyvalue | mgGuiGetProperty | retrieves user defined data 
	associated with a gui item.

	@desc Use <f mgGuiGetProperty> to retrieve the data named <p propName> 
	that was associated with the control or dialog <p gui> using <f mgGuiPutProperty>.

	@return Upon success, the user-defined data is returned, otherwise
	the return value is <m MG_NULL>.

	@access Level 4
	@see <f mgGuiPutProperty>, <f mgGuiDeleteProperty>
*/
extern MGAPIFUNC(mgpropertyvalue) mgGuiGetProperty	(
	mggui gui,							// @param the gui item to get property for
	mgpropertyname propName			// @param the name of the property to get
	);
/*                                                                            */
/*============================================================================*/

 
/*============================================================================*/
/*                                                                            */
/* @func void | mgGuiDeleteProperty | deletes user defined data 
	associated with a gui item.

	@desc Use <f mgGuiDeleteProperty> to delete the data named <p propName> 
	that was associated with the control or dialog <p gui> using <f mgGuiPutProperty>.

	@access Level 3
	@see <f mgGuiPutProperty>, <f mgGuiGetProperty>
*/
extern MGAPIFUNC(void) mgGuiDeleteProperty (	
	mggui gui,							// @param the gui item 
	mgpropertyname propName			// @param the name of the property to delete
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGetCaption | retrieves caption string for a control.
	@desc <f mgGetCaption> retrieves the caption string of the specified 
	<p control>.

	@desc The caption is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgGetCaption>, <f mgSetTitle>, <f mgGetTitle>
*/
extern MGAPIFUNC(mgstatus) mgGetCaption (
	mggui control,		//	@param the control to get caption string for
	char* string,		//	@param character buffer to hold caption retrieved
	int maxLen			//	@param the maximum number of characters to store in <p string>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetCaption | sets caption string for a control.
	@desc <f mgSetCaption> sets the caption of the specified <p control>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSetCaption>, <f mgSetTitle>, <f mgGetTitle>
*/
extern MGAPIFUNC(mgstatus) mgSetCaption (
	mggui control,		//	@param the control whose caption will be set
	char* string		//	@param the caption string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgClearCaption | clears caption string for a control.
	@desc <f mgClearCaption> clears the caption of the specified <p control>.
	This is the equivalent of calling <f mgSetCaption> with an empty string.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSetCaption>, <f mgGetCaption>, <f mgSetTitle>, <f mgGetTitle>
*/
extern MGAPIFUNC(mgstatus) mgClearCaption (
	mggui control		//	@param the control whose caption will be cleared
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetPixmap | sets a pixmap for a control.
	@desc <f mgSetPixmap> sets the pixmap of the specified <p control>.

   @desc For push button and toggle button controls, this function will assign
	the specified <p pixmap> to the control so that it will be drawn in place of
	the text caption.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSetCaption>, <f mgGetCaption>
*/
extern MGAPIFUNC(mgstatus) mgSetPixmap (
	mggui control,		//	@param the control whose pixmap is to be set
	mgpixmap pixmap	// @param the pixmap to assign to the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGuiSetFixedFont | applies a fixed width font to a control.
	@desc <f mgGuiSetFixedFont> sets the font of the specified <p control> to a
	suitable fixed width font (one whose character glyphs are all the same width).

	You can apply a bold or italic font style to a control using the function
	<f mgControlSetAttribute>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.
	@see <f mgControlSetAttribute>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGuiSetFixedFont (
	mggui control		//	@param the control to get the fixed width font
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mggui | mgFindGuiById | retrieves handle to a control in a dialog.
	@desc <f mgFindGuiById> returns the abstract handle to a control identified 
	by <p controlId> contained 
	in the specified <p dialog>. 

	@return Control handle if found, <m MG_NULL> otherwise.

	@access Level 4
*/
extern MGAPIFUNC(mggui) mgFindGuiById (
	mggui dialog,				// @param dialog that contains the control
	mgcontrolid controlId	// @param the identifier of the control to find
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgSetGuiCallback | sets callback function for a control.
	@desc <f mgSetGuiCallback> assigns a callback function to the specified
	<p control>. 

	@desc You select which control events the callback function is to be called
	for using the parameter <p callbackMask>.  The value for this parameter may be
	any bitwise combination of <m MGCB_ACTIVATE>, <m MGCB_REFRESH> and <m MGCB_DRAW>.

   @desc The <m MGCB_ACTIVATE> and <m MGCB_REFRESH> events are sent to all sent to
	all control types.  The <m MGCB_DRAW> event is only sent to GL control types.

	@see <f mgFindGuiById>, <t mgguifunc>, <m MGCB_ACTIVATE>, 
	<m MGCB_REFRESH>, <m MGCB_DRAW>
	@access Level 4
*/
extern MGAPIFUNC(void) mgSetGuiCallback (
	mggui control,						// @param the control whose callback function is to be set
	unsigned int callbackMask,		// @param mask indicating which control events are selected for callback function
	mgguifunc callback,				// @param the control callback function
	void* userData						// @param user data to be passed to callback function when it is called
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgControlSetAttribute | sets the attribute values of a control.
	@desc <f mgControlSetAttribute> sets the specified control attribute <p controlAttr>
	for the <p control> to the specified value <p attrValue>.
	
	@desc GL control attributes define how GL controls behave in different
	situations.  The GL control attributes and a brief description of each
	are listed below.  These are the possible values for  <p attribute>. 
	For more information on the meaning of each attribute, see the description
	of that particular attribute.

	@desc <e mgcontrolattribute.MCA_GLBORDERSTYLE> - specifies the border
	style for a GL control.

	@ex The following example causes a raised frame to be automatically drawn
	around a GL control within a plugin dialog |
   mggui glControl;
   mgControlSetAttribute ( glControl, MCA_GLBORDERSTYLE, MGLBS_RAISED );

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgSetGuiCallback>, <t mgcontrolattribute>, <f mgDialogSetAttribute>
*/
extern MGAPIFUNC(mgstatus) mgControlSetAttribute (
	mggui control,								// @param the control whose attribute is to be set
	mgcontrolattribute controlAttr,		// @param the control attribute to set
	int attrValue								//	@param the value to which the attribute is set
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/* GL Control Functions                                                       */
/*============================================================================*/
/* @doc EXTERNAL GLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgDrawControl | draws a GL control.
	@desc <f mgDrawControl> draws the specified GL control <f control>.

	@desc If the draw control event has been selected for the control callback
	of the specified GL control, the draw event is sent to the control.  

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgSetGuiCallback>, <t MGCB_DRAW>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgDrawControl (
	mggui control							// @param the GL control to draw
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgGLSetMouseFunc | sets mouse function for GL control.
	@desc <f mgGLSetMouseFunc> assigns a GL mouse function to the specified
	GL control <p glControl>. 

	@desc You select which mouse events the callback function is to be called
	for using the parameter <p actionMask>.  The value for this parameter may be
	any bitwise combination of <m MGMA_BUTTON>, <m MGMA_DOUBLECLICK> and 
	<m MGMA_MOTION>.

	@desc GL mouse functions are called to notify your GL control that the user
	has entered some form of mouse input into the GL control.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgSetGuiCallback>, <t mgglmousefunc> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgGLSetMouseFunc (
	mggui glControl,					// @param the GL control
	unsigned int actionMask,		// @param mask indicating which mouse actions are selected  
											// for mouse function
	mgglmousefunc mouseFunc,		// @param the GL mouse function
	void* userData						// @param user data to be passed to mouse function when it
											// is called
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* Text Control Functions                                                     */
/*============================================================================*/
/* @doc EXTERNAL TEXTCONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextClear | clears text in text control
	@desc <f mgTextClear> clears the text displayed in the specified 
	text <p control>.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextSetInteger>, <f mgTextSetFloat>, 
	<f mgTextSetDouble>, <f mgTextSetDMS>, <f mgTextSetFilename>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextClear (
	mggui control						//	@param the text control
	);

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetString | displays text in a text control.
	@desc <f mgTextSetString> sets the text displayed in the specified 
	text <p control>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextClear>, <f mgTextSetInteger>, <f mgTextSetFloat>, 
	<f mgTextSetDouble>, <f mgTextSetDMS>, <f mgTextSetFilename>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetString (
	mggui control,						//	@param the text control
	char* string						// @param the text string to load into the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextGetString | retrieves text from a text control.
	@desc <f mgTextGetString> retrieves the text displayed in the specified 
	text <p control>.

	@desc The text is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextGetInteger>, <f mgTextGetFloat>,
	<f mgTextGetDouble>, <f mgTextGetDMS> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextGetString (
	mggui control,						//	@param the text control
	char* string,						//	@param character buffer to hold text retrieved
	int maxLen							//	@param the maximum number of characters to store in <p string>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextGetSelection | retrieves the selected text from a text control.
	@desc <f mgTextGetSelection> retrieves the selected portion of the
	text displayed in the specified text <p control>.

	@desc The selected text is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextGetString>, <f mgTextGetInteger>, <f mgTextGetFloat>, 
	<f mgTextGetDouble>, <f mgTextGetDMS> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextGetSelection (
	mggui control,						//	@param the text control
	char* string,						//	@param character buffer to hold selected text retrieved 
	int maxLen							//	@param the maximum number of characters to store in <p string>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetInteger | displays integer formatted text in a text control.
	@desc <f mgTextSetInteger> displays the specified integer value <p intVal> using
	the specified <f printf> style formatting string <p fmtString> in the specified text
	<p control>. 

   @desc If you specify <m MG_NULL> in <p fmtString>, the default integer formatting
	string "%d" is used.

   @return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextSetFloat>, <f mgTextSetDouble>, <f mgTextSetDMS>,
	<f mgTextSetFilename>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetInteger (
	mggui control,						//	@param the text control
	int intVal,							// @param integer value to display
	char* fmtString					// @param <f printf> style formatting string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextGetInteger | retrieves integer value from text a control.
	@desc <f mgTextGetInteger> attempts to interpret the text value displayed
	in the specified text <p control> as an integer value.  

	@desc If the text displayed 
	does represent an integer value, the value will be returned in the parameter 
	<p intVal>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p intVal> contains the corresponding numeric value, otherwise
	<p intVal> is undefined.

   @see <f mgTextGetString>, <f mgTextGetFloat>, <f mgTextGetDouble>, <f mgTextGetDMS> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextGetInteger (
	mggui control,	//	@param the text control
	int *intVal		// @param address of integer value to receive numeric value
						// from text control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetFloat | displays single precision floating point
	formatted text in a text control.
	@desc <f mgTextSetFloat> displays the specified float value <p floatVal> using
	the specified <f printf> style formatting string <p fmtString> in the specified text
	<p control>. 

   @desc If you specify <m MG_NULL> in <p fmtString>, the default single
	precision floating point formatting string "%f" will be used.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextSetInteger>, <f mgTextSetDouble>, <f mgTextSetDMS>,
	<f mgTextSetFilename>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetFloat ( 
	mggui control,						//	@param the text control
	float floatVal,					// @param single precision floating point value to display
	char* fmtString					// @param <f printf> style formatting string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextGetFloat | retrieves single precision floating point
	value from text a control.
	@desc <f mgTextGetFloat> attempts to interpret the text value displayed
	in the specified text <p control> as a single precision floating point value.  

	@desc If the text displayed 
	represents a single precision floating point value, the value is
	returned in the parameter <p floatVal>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p floatVal> contains the corresponding numeric value, otherwise
	<p floatVal> is undefined.

   @see <f mgTextGetString>, <f mgTextGetInteger>, <f mgTextGetDouble>, <f mgTextGetDMS> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextGetFloat (
	mggui control,		//	@param the text control
	float *floatVal	// @param address of float value to receive numeric value 
							// from text control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetDouble | displays double precision floating point
	formatted text in a text control.
	@desc <f mgTextSetDouble> displays the specified double value <p doubleVal> using
	the specified <f printf> style formatting string <p fmtString> in the specified text
	<p control>. 

   @desc If you specify <m MG_NULL> in <p fmtString>, the default double
	precision floating point formatting string "%lf" is used.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextSetInteger>, <f mgTextSetFloat>, <f mgTextSetDMS>,
	<f mgTextSetFilename>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetDouble (
	mggui control,						//	@param the text control
	double doubleVal,					// @param double precision floating point value to display
	char* fmtString					// @param <f printf> style formatting string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextGetDouble | retrieves double precision floating point
	value from text a control.
	@desc <f mgTextGetDouble> attempts to interpret the text value displayed
	in the specified text <p control> as a double precision floating point value.  

	@desc If the text displayed 
	does in fact represent a double precision floating point value, the value is
	returned in the parameter 
	<p doubleVal>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p doubleVal> contains the corresponding numeric value, otherwise
	<p doubleVal> is undefined.

   @see <f mgTextGetString>, <f mgTextGetInteger>, <f mgTextGetFloat>, <f mgTextGetDMS> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextGetDouble (
	mggui control,			//	@param the text control
	double *doubleVal		// @param address of double value to receive numeric value
								// from text control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetFilename | displays a file name in a text control.
	@desc <f mgTextSetFilename> displays the specified <p fileName> string in the
	specified text <p control> in such a way that the name and extension parts of
	the file name are guaranteed to be visible.

   @desc This function is useful when used with left justified static text controls
	that may not be "wide" enough to display the full file name (including path, name
	and extension parts).  In such a control, the name and extension parts of long
	file names may get truncated and may become unviewable.  
	
	@desc If you use this function to display
	a file name in a text control and the file name is too long to fit completely,
	the name is truncated from the left until the remainder can be displayed, ensuring
	that the name and extension parts are visible.

	@desc When a file name is truncated in this way, it is prepended with "..."
	to indicate to the user that the full name is not displayed.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextSetInteger>, <f mgTextSetFloat>, 
	<f mgTextSetDouble>, <f mgTextSetDMS>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetFilename (
	mggui control,						//	@param the text control
	char* fileName						// @param the file name string to load into the control
	);
/*                                                                            */
/*============================================================================*/

#define MDFMT_LAT		"STANDARD_LAT"		// @msg MDFMT_LAT | DMS (Degrees, Minutes, Seconds)
													// format string for standard Latitude display.
													// @desc This is the format string you will specify
													// when calling <f mgTextGetDMS> or <f mgTextSetDMS>
													// if the input or output string is formatted as a
													// measurement of latitude.  The standard format for
													// latitude display is <m DD~MM'SS"H>, where DD is the 
													// number of degrees, MM is the number of minutes,
													// SS is the number of seconds and H is either 'N'
													// or 'S' depending on whether the value lies in
													// the northern or southern hemisphere, respectively.
													// @see <f mgTextGetDMS>, <f mgTextSetDMS>, <m MDFMT_LON> 

#define MDFMT_LON		"STANDARD_LON"		// @msg MDFMT_LON | DMS (Degrees, Minutes, Seconds)
													// format string for standard Longitude display.
													// @desc This is the format string you will specify
													// when calling <f mgTextGetDMS> or <f mgTextSetDMS>
													// if the input or output string is formatted as a
													// measurement of longitude.  The standard format for
													// longitude display is <m DD~MM'SS"H>, where DD is the 
													// number of degrees, MM is the number of minutes,
													// SS is the number of seconds and H is either 'E'
													// or 'W' depending on whether the value lies in 
													// the eastern or western hemisphere, respectively.
													// @see <f mgTextGetDMS>, <f mgTextSetDMS>, <m MDFMT_LAT> 

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetDMS | displays DMS (degrees, minutes, seconds)
	formatted text in a text control.
	@desc <f mgTextSetDMS> displays the specified double value <p dmsVal>
	(assumed to be in decimal degrees) in the specified text <p control>
	formatted as degrees, minutes and seconds.

	@desc Depending on the <p fmtString> you specify, you can control the 
	format of the string displayed in the text control.  You must specify
	either <m MDFMT_LAT> or <m MDFMT_LON> as described below.
	
	@desc If you specify <m MDFMT_LAT>
	in <p fmtString>, <p dmsVal> is converted to a latitude measurement and is
	displayed in the form: <m DD~MM'SS"H>, where DD is the number of degrees, MM is
	the number of minutes, SS is the number of seconds and H is either 'N' or 'S'
	depending on whether the value lies in the northern or southern hemisphere,
	respectively.

	@desc If you specify <m MDFMT_LON>
	in <p fmtString>, <p dmsVal> is converted to a longitude measurement and is
	displayed in the form: <m DD~MM'SS"H>, where DD is the number of degrees, MM is
	the number of minutes, SS is the number of seconds and H is either 'E' or 'W'
	depending on whether the value lies in the eastern or western hemisphere,
	respectively.  

	@desc By convention, values in the northern and eastern hemispheres are
	positive (0.0 .. 180.0).  Values in the southern and western hemispheres
	are negative (-180 .. 0.0).  If you specify a value outside these ranges,
	the results are undefined.

   @ex Here are some examples |
   mgstatus status;

   // will display 37~30'00"N in text control
   status = mgTextSetDMS ( text, 37.5, MDFMT_LAT );

   // will display 123~15'00"W in text control
   status = mgTextSetDMS ( text, -123.25, MDFMT_LON );

	@return Use macro <m MSTAT_ISOK> to check return value for success.

   @see <f mgTextSetString>, <f mgTextSetInteger>, <f mgTextSetFloat>,
	<f mgTextSetDouble>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetDMS (
	mggui control,			//	@param the text control
	double dmsVal,			// @param double precision floating point value 
								// in decimal degrees to format and display
	char* fmtString		// @param latitude/longitude formatting string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextGetDMS | retrieves double precision floating point
	value represented in DMS (degrees, minutes, seconds) format from text a
	control.
	
	@desc <f mgTextGetDMS> attempts to interpret the text value displayed
	in the specified text <p control> as a double precision floating point
	value.  The text is assumed to be formatted as a DMS string as described
	below.

	@desc Depending on the <p fmtString> you specify, you can specify how 
	you expect the text in the control to be formatted.  You must specify
	either <m MDFMT_LAT> or <m MDFMT_LON> as described here.

	@desc If you specify <m MDFMT_LAT>
	in <p fmtString>, the text in the control is expected to be a latitude
	measurement expressed in the form: <m DD~MM'SS"H>, where DD is the number of
	degrees, MM is the number of minutes, SS is the number of seconds and H
	is either 'N' or 'S' depending on whether the value lies in the northern
	or southern hemisphere, respectively.  

	@desc If you specify <m MDFMT_LON>
	in <p fmtString>, the text in the control is expected to be a longitude
	measurement expressed in the form: <m DD~MM'SS"H>, where DD is the number of
	degrees, MM is the number of minutes, SS is the number of seconds and H
	is either 'E' or 'W' depending on whether the value lies in the eastern
	or western hemisphere, respectively.  

	@desc By convention, values entered in the northern and eastern hemispheres
	are returned as positive (0.0 .. 180.0).  Values entered in the southern and
	western hemispheres are returned as negative (-180 .. 0.0).  

  @return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p dmsVal> contains the corresponding numeric value in
	decimal degrees, otherwise <p dmsVal> is undefined.

   @see <f mgTextGetString>, <f mgTextGetInteger>, <f mgTextGetFloat>, <f mgTextGetDouble> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextGetDMS (
	mggui control,			//	@param the text control
	double *dmsVal,		// @param address of double value to receive numeric value
								// in decimal degrees from text control
	char* fmtString		// @param latitude/longitude formatting string
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetEditable | enables or disables editing of a text control.
	@desc Depending on the value of the parameter <p editable>, <f mgTextSetEditable>
	either enables (<e mgbool.MG_TRUE>) or disables (<e mgbool.MG_FALSE>) the editing of
	a text control.  

   @desc Text controls that are editable can be modified by the user.  Text controls
	that are not editable can be used to display "read-only" values.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetEditable (
	mggui control,				//	@param the text control
	mgbool editable			// @param enum mgbool <e mgbool.MG_TRUE> to allow 
									// editing, <e mgbool.MG_FALSE> to disallow editing
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSelectAll | selects all the text in a text control.
	@desc <f mgTextSelectAll> selects all the characters displayed in the 
	specified text <p control>.  
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSelectAll (
	mggui control						//	@param the text control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSelectRange | selects range of text in a text control.
	@desc <f mgTextSelectRange> selects the specified range of characters
	displayed in the specified text <p control>.  

	@desc The first position is at index 0.

	@desc If <p firstPos> is 0 and <p lastPos> is -1, all the text in the text control is selected. 
	If <p firstPos> is -1, any current selection is removed. The caret is placed at the end of the selection
	indicated by the greater of the two values <p firstPos> and <p lastPos>. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSelectRange (
	mggui control,		//	@param the text control
	int firstPos,		// @param position of first character to select
	int lastPos			// @param position of last character to select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetSpinBuddy | associates a spin buddy control 
	to a text control.    
	@desc <f mgTextSetSpinBuddy> associates the specified spin buddy control,
	<p spinControl>, to the specified text control <p textControl>.

	@desc A spin buddy control will direct user input from itself to the 
	associated text control.  As the user clicks the up or down arrows of 
	the spin control, the value of the text control will increase or decrease
	accordingly. 
	
	@desc The amount that the text control value will increase/decrease when
	either arrow of the spin buddy control is pressed can be set by calling 
	<f mgTextSetSpinIncrement>.  The default spin increment is 1.0.
		
	@desc A text control can have at most one spin buddy control.  Furthermore,
	once you associate a spin buddy control to a given text control using this
	function, you cannot change which spin buddy is associated to that text
	control by calling this function again.  

  	@desc After associating a buddy control to a text control, the two controls
	will behave as one.  In particular, when calling <f mgSetEnabled> or 
	<f mgSetVisible> for the text control, both the text and the buddy
	control will be affected simultaneously and automatically.  Furthermore, 
	when accessing the resulting composite control, you must use the text
	control object, not the buddy control object.  Performing operations on the
	buddy control explicitly is not supported and the results are undefined.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgTextSetSpinIncrement>, <f mgTextSetTextFormat>, <f mgSetGuiCallback>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetSpinBuddy (
	mggui textControl,		//	@param the text control
	mggui spinControl			// @param the spin control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetSpinIncrement | sets the spin increment for
	a text control.
	@desc <f mgTextSetSpinIncrement> sets the spin increment value for the 
	specified text control, <p textControl> to the specified value, <p increment>.

	@desc The spin increment value is the value that a text control is automatically
	incremented or decremented when the user clicks the up/down arrow buttons of the
	spin buddy control associated to the text control.  

   @desc If <p increment> is positive, the up arrow of the spin control will 
	increase the value of the text control and the down arrow will decrease it.  
	If <p increment> is negative, the up arrow will decrease the text's value 
	and the down arrow will increase it.
		
   @desc This function is only meaningful for a text control that has a 
	spin buddy control.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgTextSetSpinBuddy>, <f mgTextSetTextFormat>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetSpinIncrement (
	mggui textControl,		//	@param the text control
	double increment			//	@param the increment value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgTextSetTextFormat | sets the text format string for
	a text control.
	@desc <f mgTextSetTextFormat> sets the format string for the text control
	that has a spin buddy control.  The format string, <p fmtString>, is assumed
	to be a <f printf> style format string and is used to automatically format
	the numeric value that is displayed in the text control when the associated
	spin buddy is activated.

   @desc The default format string for a text control is "%lf".

   @desc This function is only meaningful for a text control that has a 
	spin buddy control.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgTextSetSpinBuddy>, <f mgTextSetSpinIncrement>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgTextSetTextFormat (
	mggui textControl,		//	@param the text control
	char* fmtString			//	@param the format string for the text buddy
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/* Menu Control Functions                                            */
/*============================================================================*/
/* @doc EXTERNAL MENUCONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgMenuSetState | sets the state of a menu item control.
	@desc <f mgMenuSetState> sets the selection state of the specified 
	menu item <p control>.
	
	@desc In two state menu item controls, 1 indicates that the control
	is selected (or checked), and 0 indicates that it is not.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgMenuGetState>, <f mgSetEnabled>, <f mgIsEnabled>

	@param mggui | control | the menu item control
	@param int | state | the state of the control (1 is checked, 0 is not checked)
*/
#define mgMenuSetState	mgToggleButtonSetState
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgMenuGetState | retrieves the state of a menu item control.
	@desc <f mgMenuGetState> retrieves the selection state of the specified 
	menu item <p control>.
	
	@desc In two state menu item controls, 1 indicates that the control is selected
	(or checked), and 0 indicates that it is not.
	
	@return Returns 1 if the control is selected, 0 otherwise.

	@access Level 4
	@see <f mgMenuGetState>, <f mgSetEnabled>, <f mgIsEnabled>
	
	@param mggui | control | the menu item control
*/
#define mgMenuGetState	mgToggleButtonGetState
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/* Toggle Button Control Functions                                            */
/*============================================================================*/
/* @doc EXTERNAL TOGGLEBUTTONCONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgToggleButtonSetState | sets the state of a toggle button control.
	@desc <f mgToggleButtonSetState> sets the selection state of the specified 
	toggle button <p control>.
	
	@desc In two state toggle button controls, 1 indicates that the control
	is selected (or checked), and 0 indicates that it is not.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgToggleButtonGetState>, <f mgSetEnabled>, <f mgIsEnabled>,
	<f mgSetVisible>, <f mgIsVisible>
*/
extern MGAPIFUNC(mgstatus) mgToggleButtonSetState (
	mggui control,				//	@param the toggle button control
	int state					// @param the state of the control (1 is selected, 0 
									// is not selected)
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgToggleButtonGetState | retrieves the state of a toggle button control.
	@desc <f mgToggleButtonGetState> retrieves the selection state of the specified 
	toggle button <p control>.
	
	@desc In two state toggle button controls, 1 indicates that the control
	is selected (or checked), and 0 indicates that it is not.
	
	@return Returns 1 if the control is selected, 0 otherwise.

	@access Level 4
	@see <f mgToggleButtonGetState>, <f mgSetEnabled>, <f mgIsEnabled>,
	<f mgSetVisible>, <f mgIsVisible>
*/
extern MGAPIFUNC(int) mgToggleButtonGetState (
	mggui control			//	@param the toggle button control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* Option Menu Control Functions                                              */
/*============================================================================*/
/* @doc EXTERNAL OPTIONMENUCONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgOptionMenuAddItem | adds an item to an option menu control.
	@desc <f mgOptionMenuAddItem> appends the specified <p itemString> to the end of
	the items already contained in the option menu <p control>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgOptionMenuDeleteAllItems>
*/
extern MGAPIFUNC(mgstatus) mgOptionMenuAddItem (
	mggui control,			//	@param the option menu control
	char* itemString		// @param the string to add
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgOptionMenuGetItemCount | counts the number of items in an
	option menu control.
	@desc <f mgOptionMenuGetItemCount> returns the number of items contained in the 
	specified option menu <p control>.
	
	@return The number of items contained in the control, 0 if none.

	@access Level 4
*/
extern MGAPIFUNC(int) mgOptionMenuGetItemCount (
	mggui control			//	@param the option menu control
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgOptionMenuDeleteAllItems | deletes all items in an option
	menu control.
	@desc <f mgOptionMenuDeleteAllItems> deletes all the items contained in the 
	specified option menu <p control>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgOptionMenuDeleteAllItems (
	mggui control			//	@param the option menu control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgOptionMenuGetSelectedItemPos | retrieves position of 
	selected item in an option menu control.
	@desc <f mgOptionMenuGetSelectedItemPos> retrieves the position of the selected
	item in the specified option menu <p control>.

	@desc Position 1 indicates the first item in the control.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p itemPos> contains the position of the selected item.  Otherwise,
	<p itemPos> is undefined.
	
	@see <f mgOptionMenuGetSelectedItemString>, <f mgOptionMenuSelectItemAtPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgOptionMenuGetSelectedItemPos (
	mggui control,			//	@param the option menu control
	int* itemPos			// @param address of value to receive selected position
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgOptionMenuGetSelectedItemString | retrieves text of selected item 
	in an option menu control.
	@desc <f mgOptionMenuGetSelectedItemString> retrieves the text string of the selected
	item in the specified option menu <p control>.
	
	@desc The string is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p itemString> is loaded with the text of the selected item.  Otherwise,
	<p itemString> is undefined.
	
	@see <f mgOptionMenuGetSelectedItemPos>, <f mgOptionMenuSelectItemAtPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgOptionMenuGetSelectedItemString (
	mggui control,			//	@param the option menu control
   char* itemString,		//	@param character buffer to hold text of selected item retrieved
	int maxLen				//	@param the maximum number of characters to store in <p itemString>
   );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgOptionMenuSelectItemAtPos | selects an item an option
	menu control.
	@desc <f mgOptionMenuSelectItemAtPos> selects the item at the position
	specified by <p itemPos> in the specified option menu <p control>.
	
	@desc Position 1 specifies the first item in the control.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.
	
	@see <f mgOptionMenuGetSelectedItemString>, <f mgOptionMenuGetSelectedItemPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgOptionMenuSelectItemAtPos (
	mggui control,			//	@param the option menu control
	int itemPos				// @param the position of the item to select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* List Control Functions                                                     */
/*============================================================================*/
/* @doc EXTERNAL LISTCONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func int | mgListGetItemCount | counts the number of items in a
	list control.

	@desc <f mgListGetItemCount> returns the number of items contained in the 
	specified list <p control>.
	
	@return The number of items contained in the control, 0 if none.

	@see <f mgListGetSelectedItemCount>

	@access Level 4
*/
extern MGAPIFUNC(int) mgListGetItemCount (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgListGetSelectedItemCount | counts the number of selected 
	items in a list control.
	@desc <f mgListGetSelectedItemCount> returns the number of selected items
	contained in the  specified list <p control>.  For single select list controls
	there is at most 1 item selected.  For multi-select list controls, there
	may be 0 or more items selected.
	
	@return Returns the number of selected items contained in the control,  0 if none.

	@see <f mgListGetItemCount>

	@access Level 4
*/
extern MGAPIFUNC(int) mgListGetSelectedItemCount (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListGetSelectedItemPos | retrieves position of 
	selected item in a listcontrol.
	@desc <f mgListGetSelectedItemPos> retrieves the position of the selected
	item in the specified list <p control>.  
	
	@desc Position 1 indicates the first item in the control.

	@desc For multi-select list controls with more than one item currently
	selected, the position retrieved is the position of the first item
	selected.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success. If function 
	is successful, <p itemPos> contains the position of the selected item. Otherwise,
	<p itemPos> is undefined. 
	
	@see <f mgListGetSelectedItemString>, <f mgListSelectItemAtPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListGetSelectedItemPos ( 
	mggui control,			//	@param the list control
	int* itemPos			// @param address of value to receive selected position
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListGetSelectedItemString | retrieves text of selected item 
	in a list control.
	@desc <f mgListGetSelectedItemString> retrieves the text string of the selected
	item in the specified list <p control>.
	
	@desc For multi-select list controls with more than one item currently
	selected, the string retrieved is the text of the first item
	selected.

	@desc The string is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p itemString> is loaded with the text of the selected item.
	Otherwise, <p itemString> is undefined.
	
	@see <f mgListGetSelectedItemPos>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListGetSelectedItemString (
	mggui control,			//	@param the list control
   char* itemString,		//	@param character buffer to hold text of selected item retrieved
	int maxLen				//	@param the maximum number of characters to store in <p itemString>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListGetItemStringAtPos | retrieves text of an item 
	in a list control.
	@desc <f mgListGetItemStringAtPos> retrieves the text string of the
	item at the specified position <p itemPos>, in the specified list <p control>.

  	@desc Position 1 indicates the first item in the control.

	@desc The string is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.  If function 
	is successful, <p itemString> is loaded with the text of the item.
	Otherwise, <p itemString> is undefined.
	
	@see <f mgListGetSelectedItemString>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListGetItemStringAtPos (
	mggui control,			//	@param the list control
   int itemPos,			//	@param the position of item in list to get
   char* itemString,		//	@param character buffer to hold text of item
	int maxLen				//	@param the maximum number of characters to store in <p itemString>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgListIsItemInList | determines if an item is in a
	list control.
	@desc <f mgListIsItemInList> checks if a text string <p itemString>
	is present in the specified list <p control>.
	
	@return Returns <e mgbool.MG_TRUE> if specified text string is in the list,
	<e mgbool.MG_FALSE> otherwise.
	
	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgListIsItemInList (
	mggui control,			//	@param the list control
	char* itemString		// @param the text of the item whose presence is checked
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListDeleteItem | deletes an item from a list control.
	@desc <f mgListDeleteItem> deletes the first item in the specified list 
	<p control> that matches the specified text string <p itemString>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.
	@see <f mgListDeleteItemAtPos>, <f mgListDeleteAllItems>, <f mgListDeleteSelectedItems>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListDeleteItem (
	mggui control,			//	@param the list control
	char* itemString		// @param the text of the item to delete
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListDeleteItemAtPos | deletes an item from a list control
	at a specified position.
	@desc <f mgListDeleteItemAtPos> deletes the item at the specified position
	<p itemPos> from the specified list <p control>.  

  	@desc Position 1 indicates the first item in the control.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListDeleteItem>, <f mgListDeleteAllItems>, <f mgListDeleteSelectedItems>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListDeleteItemAtPos (
	mggui control,			//	@param the list control
	int itemPos				// @param the position of item in list to delete
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListDeleteAllItems | deletes all items from a list control.
	@desc <f mgListDeleteAllItems> deletes all the items from the specified
	list <p control>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListDeleteItem>, <f mgListDeleteItemAtPos>, <f mgListDeleteSelectedItems>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListDeleteAllItems (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListDeleteSelectedItems | deletes all selected items
	from a list control.
	@desc <f mgListDeleteSelectedItems> deletes all selected items from 
	the specified list <p control>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListDeleteItem>, <f mgListDeleteItemAtPos>, <f mgListDeleteAllItems>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListDeleteSelectedItems (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListDeselectAllItems | deselects all items in a list control
	@desc <f mgListDeselectAllItems> deselects all the items in the specified
	list <p control>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSelectItemAtPos>, <f mgListSelectItem>, <f mgListDeselectItemAtPos>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListDeselectAllItems (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListDeselectItemAtPos | deselects an item in a list control
	at a specified position.
	@desc <f mgListDeselectItemAtPos> selects the item at the specified position
	<p itemPos> in the specified list <p control>.  

  	@desc Position 1 indicates the first item in the control.

	@desc The <m MGCB_ACTIVATE> control event is not sent when this function
	is called.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSelectItemAtPos>, <f mgListDeselectAllItems>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListDeselectItemAtPos (
	mggui control,			//	@param the list control
	int itemPos				// @param the position of item in list to select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSelectItemAtPos | selects an item in a list control
	at a specified position.
	@desc <f mgListSelectItemAtPos> selects the item at the specified position
	<p itemPos> in the specified list <p control>.  
	
	@desc Position 1 indicates the first item in the control.

	@desc The <m MGCB_ACTIVATE> control event is not sent when this function
	is called.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSelectItem>, <f mgListSelectAllItems>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSelectItemAtPos (
	mggui control,			//	@param the list control
	int itemPos				// @param the position of item in list to select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSelectItem | selects an item in a list control.
	@desc <f mgListSelectItem> selects the first item in the specified list 
	<p control> that matches the specified text string <p itemString>.
	
	@desc The <m MGCB_ACTIVATE> control event is not sent when this function
	is called.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSelectItemAtPos>, <f mgListSelectAllItems>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSelectItem (
	mggui control,			//	@param the list control
	char* itemString		// @param the text of the item to select
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSelectAllItems | selects all items in a list control.
	@desc <f mgListSelectAllItems> selects all the items in the specified
	list <p control>.
	
	@desc The <m MGCB_ACTIVATE> control event is not sent when this function
	is called.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSelectItemAtPos>, <f mgListSelectItem>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSelectAllItems (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgListIsItemAtPosSelected | determines if an item at a 
	specified position in a list control is selected.
	@desc <f mgListIsItemAtPosSelected> checks if the item at a specified 
	position <p itemPos> is selected in the specified list <p control>.

  	@desc Position 1 indicates the first item in the control.

	@return Returns <e mgbool.MG_TRUE> if item at specified position in list is selected.
	<e mgbool.MG_FALSE> otherwise.
	
	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgListIsItemAtPosSelected (
	mggui control,			//	@param the list control
	int itemPos				// @param the position of the item to check
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSetBottomPos | makes a specified item the last visible
	item in the list. 
	@desc If possible, <f mgListSetBottomPos> makes the item at the specified 
	position <p itemPos> the last visible item in the specified list <p control>.

  	@desc Position 1 indicates the first item in the control.

	@desc Calling this function only ensures that the item at the specified position
	is visible in a scrolling list control.  Depending on the configuration of
	the items in the list when this function is called, it may not be possible to
	make the specified item the last item visible, but it is guaranteed to be 
	visible.
  	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSetTopPos>, <f mgListSetBottomPos>, <f mgListSetBottomItem>,
	<f mgListSetTopItem>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSetBottomPos (
	mggui control,			//	@param the list control
	int itemPos				// @param the position of the item to make visible
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSetTopPos | makes a specified item the first visible
	item in the list 
	@desc If possible, <f mgListSetTopPos> makes the item at the specified 
	position <p itemPos> the first visible item in the specified list <p control>.

  	@desc Position 1 indicates the first item in the control.

	@desc Calling this function only ensures that the item at the specified position
	is visible in a scrolling list control.  Depending on the configuration of
	the items in the list when this function is called, it may not be possible to
	make the specified item the first item visible, but it is guaranteed to be 
	visible.
  	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSetTopPos>, <f mgListSetBottomPos>, <f mgListSetBottomItem>,
	<f mgListSetTopItem>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSetTopPos (
	mggui control,			//	@param the list control
	int itemPos				// @param the position of the item to make visible
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSetBottomItem | makes a specified item the last visible
	item in the list. 
	@desc If possible, <f mgListSetBottomItem> makes the item specified 
	by <p itemString> the last visible item in the specified list <p control>.
	
	@desc Calling this function only ensures that the item at the specified position
	is visible in a scrolling list control.  Depending on the configuration of
	the items in the list when this function is called, it may not be possible to
	make the specified item the last item visible, but it is guaranteed to be 
	visible.
  	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSetTopPos>, <f mgListSetBottomPos>, <f mgListSetBottomItem>,
	<f mgListSetTopItem>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSetBottomItem (
	mggui control,			//	@param the list control
	char* itemString		// @param the text of the item to make visible
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListSetTopItem | makes a specified item the first visible
	item in the list. 
	@desc If possible, <f mgListSetTopItem> makes the item specified 
	by <p itemString> the first visible item in the specified list <p control>.
	
	@desc Calling this function only ensures that the item at the specified position
	is visible in a scrolling list control.  Depending on the configuration of
	the items in the list when this function is called, it may not be possible to
	make the specified item the first item visible, but it is guaranteed to be 
	visible.
  	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgListSetTopPos>, <f mgListSetBottomPos>, <f mgListSetBottomItem>,
	<f mgListSetTopItem>
	
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgListSetTopItem (
	mggui control,			//	@param the list control
	char* itemString		// @param the text of the item to make visible
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListAddItem | adds an item to a list control.
	@desc <f mgListAddItem> adds the specified <p itemString> to the specified
	list <p control> at the specified position <p itemPos>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgListAppendItem>, <f mgListReplaceItem>
*/
extern MGAPIFUNC(mgstatus) mgListAddItem (
	mggui control,			//	@param the list control
	char* itemString,		// @param the string to add
	int itemPos,			// @param the position of the new item in the list - a
								// value of 1 makes the new item the first item in the
								// list, 2 makes it the second item and so on - 
								// a value of 0 (zero) makes the new
								// item the last item in the list
	mgbool selectFlag		// @param enum mgbool <e mgbool.MG_TRUE> to make new 
								// item selected, <e mgbool.MG_FALSE> to make new item
								// unselected
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListAppendItem | appends an item to the end of a list control
	@desc <f mgListAppendItem> appends the specified <p itemString> to the end
	of the specified list <p control>.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgListAddItem>, <f mgListReplaceItem>
*/
extern MGAPIFUNC(mgstatus) mgListAppendItem (
	mggui control,			//	@param the list control
	char* itemString,		// @param the string to add
	mgbool selectFlag		// @param enum mgbool <e mgbool.MG_TRUE> to make new 
								// item selected, <e mgbool.MG_FALSE> to make new item
								// unselected
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListReplaceItem | replaces an item in a list control.
	@desc <f mgListReplaceItem> replaces the specified <p oldItemString> 
	with a new string <p newItemString> in the specified list <p control>.

	@desc If the item being replaced is currently selected, the new item will
	also be selected.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgListAddItem>, <f mgListAppendItem>, <f mgListReplaceItemAtPos>
*/
extern MGAPIFUNC(mgstatus) mgListReplaceItem (
	mggui control,			//	@param the list control
	char* oldItemString,	// @param the item to be replaced
	char* newItemString	// @param the string to replace <p oldItemString>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgListReplaceItemAtPos | replaces an item in a list control.
	@desc <f mgListReplaceItemAtPos> replaces the item at position <p itemPos> 
	with a new string <p itemString> in the specified list <p control>.

	@desc Position 1 specifies the first item in the control.

   @desc If the item being replaced is currently selected, the new item will
	be selected.	

   @return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgListAddItem>, <f mgListAppendItem>, <f mgListReplaceItem>
*/
extern MGAPIFUNC(mgstatus) mgListReplaceItemAtPos (
	mggui control,			//	@param the list control
	int itemPos,			// @param the position of the item to be replaced
	char* itemString		// @param the string to replace the item
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstringlist | mgListGetStrings | retrieves the text of all items in
	a list control.
	@desc <f mgListGetStrings> returns a <m MG_NULL> terminated array of character
	strings representing all the items in the specified list <p control>.  

	@desc The strings returned are dynamically allocated so when you are done
	with them, use <f mgFreeStringList> to properly dispose of the memory
	associated with them.
	
	@return <m MG_NULL> terminated array of character strings,  
	<m MG_NULL> if list is empty. 

	@ex The following example prints out each item from a 
	list control <p list> |
   mgstringlist strings;
   if ( strings = mgListGetStrings ( list ) )
   {
      int i = 1;
      mgstringlist thisString = strings;
      while ( thisString && *thisString )
      {
         printf ( "Item number %d : %s\n", i, *thisString );
         thisString++;
         i++;
      }
      mgFreeStringList ( strings );
   }

	@access Level 4
	@see <f mgListGetSelectedStrings>, <f mgFreeStringList>
*/
extern MGAPIFUNC(mgstringlist) mgListGetStrings (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstringlist | mgListGetSelectedStrings | retrieves the text of all selected
	items in a list control.
	@desc <f mgListGetSelectedStrings> returns a <m MG_NULL> terminated array 
	of character
	strings representing all the selected items in the specified list <p control>.  

	@desc The strings returned are dynamically allocated so when you are done
	with them, use <f mgFreeStringList> to properly dispose of the memory
	associated with them.
	
	@return <m MG_NULL> terminated array of character strings,  
	<m MG_NULL> if list is empty. 

	@ex The following example prints out each selected item from a 
	list control <p list> |
   mgstringlist strings;
   if ( strings = mgListGetSelectedStrings ( list ) )
   {
      int i = 1;
      mgstringlist thisString = strings;
      while ( thisString && *thisString )
      {
         printf ( "Item number %d : %s\n", i, *thisString );
         thisString++;
         i++;
      }
      mgFreeStringList ( strings );
   }

	@access Level 4
	@see <f mgListGetSelectedStrings>, <f mgFreeStringList>
*/
extern MGAPIFUNC(mgstringlist) mgListGetSelectedStrings (
	mggui control			//	@param the list control
	);
/*                                                                            */
/*============================================================================*/

/* @deprecated mgListFreeStrings | Use <f mgFreeStringList> */
extern MGAPIFUNC(mgstatus)	mgListFreeStrings ( mgstringlist strings );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgFreeStringList | frees the string list returned by 
	<f mgListGetStrings>, <f mgListGetSelectedStrings>, or <f mgPromptDialogFile>.
	@desc <f mgFreeStringList> disposes of the dynamic memory allocated for
	the string lists returned by the functions listed.
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgListGetStrings>, <f mgListGetSelectedStrings>, <f mgPromptDialogFile>
*/
extern MGAPIFUNC(mgstatus)	mgFreeStringList (
	mgstringlist strings		// @param the string list returned from <f mgListGetStrings>,
									// <f mgListGetSelectedStrings> or <f mgPromptDialogFile>
									// to free
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* Scale Control Functions                                                    */
/*============================================================================*/
/* @doc EXTERNAL SCALECONTROLFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleSetSpinBuddy | associates a spin buddy control 
	to a scale control.    
	@desc <f mgScaleSetSpinBuddy> associates the specified spin buddy control,
	<p spinControl>, to the specified scale control <p scaleControl>.

	@desc A spin buddy control will direct user input from itself to the 
	associated scale control.  As the user clicks the up or down arrows of 
	the spin control, the value of the scale control will increase or decrease
	accordingly. 
	
	@desc The amount that the scale control value will increase/decrease when
	either arrow of the spin buddy control is pressed can be set by calling 
	<f mgScaleSetSpinIncrement>.  The default spin increment is 1.0.
		
	@desc A scale control can have at most one spin buddy control.  Furthermore,
	once you associate a spin buddy control to a given scale control using this
	function, you cannot change which spin buddy is associated to that scale
	control by calling this function again.

  	@desc After associating a buddy control to a scale control, the two controls
	will behave as one.  In particular, when calling <f mgSetEnabled> or 
	<f mgSetVisible> for the scale control, both the scale and the buddy
	control will be affected simultaneously and automatically.  Furthermore, 
	when accessing the resulting composite control, you must use the scale
	control object, not the buddy control object.  Performing operations on the
	buddy control explicitly is not supported and the results are undefined.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgScaleSetSpinIncrement>, <f mgScaleSetTextBuddy>, <f mgSetGuiCallback>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleSetSpinBuddy (
	mggui scaleControl,		//	@param the scale control
	mggui spinControl			// @param the spin control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleSetTextBuddy | associates a text buddy control 
	to a scale control.    
	@desc <f mgScaleSetTextBuddy> associates the specified text buddy control,
	<p textControl>, to the specified scale control <p scaleControl>.

	@desc A text buddy control will accept input from the user and automatically 
	apply it to the associated scale control.  The text buddy control will also 
	automatically display the current value of the scale control when the scale
	value changes.

  	@desc A scale control can have at most one text buddy control.  Furthermore,
	once you associate a text buddy control to a given scale control using this
	function, you cannot change which text buddy is associated to that scale
	control by calling this function again.

  	@desc After associating a buddy control to a scale control, the two controls
	will behave as one.  In particular, when calling <f mgSetEnabled> or 
	<f mgSetVisible> for the scale control, both the scale and the buddy
	control will be affected simultaneously and automatically.  Furthermore, 
	when accessing the resulting composite control, you must use the scale
	control object, not the buddy control object.  Performing operations on the
	buddy control explicitly is not supported and the results are undefined.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

  	@see <f mgScaleSetTextFormat>, <f mgScaleSetSpinBuddy>, <f mgSetGuiCallback>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleSetTextBuddy (
	mggui scaleControl,		//	@param the scale control
	mggui textControl			// @param the text control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleSetMinMax | sets the minimum and maximum logical
	values for a scale control.
	@desc <f mgScaleSetMinMax> sets the range of logical values valid for the 
	specified scale control, <p scaleControl>.  The minimum value is specified 
	by <p min>, the maximum by <p max>.  

	@desc The default minimum and maximum values for a scale control are 0 
	and 100 respectively.  

   @desc If the current scale value is outside the new range, the scale value
	will be clamped to the new maximum or minimum value.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.
	
	@see <f mgScaleGetMinMax>, <f mgScaleSetValue>, <f mgScaleGetValue>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleSetMinMax (
	mggui scaleControl,		//	@param the scale control
	double min,					//	@param the minimum value for the control
	double max					//	@param the maximum value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleGetMinMax | retrieves the minimum and maximum
	logical values for a scale control.

	@desc <f mgScaleGetMinMax> returns the range of values valid for the 
	specified scale control, <p scaleControl>.  The minimum value is returned in
	<p min>, the maximum in <p max>.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.  If 
	function is successful, <p min> and <p max> contain the corresponding minimum
	and maximum values, otherwise their contents are undefined.

	@see <f mgScaleSetMinMax>, <f mgScaleSetValue>, <f mgScaleGetValue>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleGetMinMax (
	mggui scaleControl,		//	@param the scale control
	double* min,				//	@param address of double value to receive 
									// minimum value from control
	double* max					//	@param address of double value to receive 
									// maximum value from control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleSetValue | sets the value of a scale control.
	@desc <f mgScaleSetValue> sets the value of a scale control, <p scaleControl>, 
	to the specified value <p value>.   

   @desc If the value you specify is greater than the maximum value allowed for
	the scale control, the scale value will be set to the maximum scale value.  
	Similarly, if value is less than the minimum scale value, the scale value will
	be set to the minimum scale value.  

   @desc If the scale control has a text buddy control, the text control will
	be updated automatically.
		
	@see <f mgScaleGetValue>, <f mgScaleSetMinMax>, <f mgScaleGetMinMax>

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleSetValue (
	mggui scaleControl,		//	@param the scale control
	double value				//	@param the value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleGetValue | retrieves the current value of a scale
	control.
	@desc <f mgScaleGetValue> returns the current value of the specified scale
	control, <p scaleControl>.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.  If 
	function is successful, <p value> contains the current value of the
	control, otherwise <p value> is undefined.

	@see <f mgScaleSetValue>, <f mgScaleSetMinMax>, <f mgScaleGetMinMax>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleGetValue (
	mggui scaleControl,		//	@param the scale control
	double* value				//	@param address of double value to receive 
									// current value from control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleSetSpinIncrement | sets the spin increment for
	a scale control.
	@desc <f mgScaleSetSpinIncrement> sets the spin increment value for the 
	specified scale control, <p scaleControl> to the specified value, <p increment>.

	@desc The spin increment value is the value that a scale control is automatically
	incremented or decremented when the user clicks the up/down arrow buttons of the
	spin buddy control associated to the scale control.  

   @desc If <p increment> is positive, the up arrow of the spin control will 
	increase the value of the scale control and the down arrow will decrease it.  
	If <p increment> is negative, the up arrow will decrease the scale's value 
	and the down arrow will increase it.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgScaleSetSpinBuddy>, <f mgScaleSetTextBuddy>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleSetSpinIncrement (
	mggui scaleControl,		//	@param the scale control
	double increment			//	@param the increment value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgScaleSetTextFormat | sets the text format string for
	a scale control.
	@desc <f mgScaleSetTextFormat> sets the format string for the text buddy of
	a scale control.  The format string, <p fmtString>, is assumed to be a 
	<f printf> style format string and is used to automatically format the
   numeric value that is displayed in the text buddy control associated
	to the scale control.  

	@desc Since the value represented by a scale control is of type double, you
	may, for example, use this format string to effectively display integer values
	in the scale control by using a format string similar to "%.0lf".  See <f printf>
	for more details on allowable format strings.

   @desc The default format string for a text buddy control is "%lf".

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgScaleSetTextBuddy>, <f mgScaleSetSpinBuddy>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgScaleSetTextFormat (
	mggui scaleControl,		//	@param the scale control
	char* fmtString			//	@param the format string for the text buddy
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* Progress Control Functions                                                 */
/*============================================================================*/
/* @doc EXTERNAL PROGRESSFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgProgressSetMinMax | sets the minimum and maximum logical
	values for a progress control.
	@desc <f mgProgressSetMinMax> sets the range of logical values valid for the 
	specified progress control, <p progressControl>.  The minimum value is specified 
	by <p min>, the maximum by <p max>.  

	@desc The default minimum and maximum values for a progress control are 0 
	and 100 respectively.  

   @desc If the current progress value is outside the new range, the progress value
	will be clamped to the new maximum or minimum value.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.
	
	@see <f mgProgressGetMinMax>, <f mgProgressSetValue>, <f mgProgressGetValue>,
	<f mgProgressStepValue>, <f mgProgressSetStepIncrement>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgProgressSetMinMax ( 
	mggui progressControl,	//	@param the progress control
	double min,					//	@param the minimum value for the control
	double max					//	@param the maximum value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgProgressGetMinMax | retrieves the minimum and maximum
	logical values for a progress control.

	@desc <f mgProgressGetMinMax> returns the range of values valid for the 
	specified progress control, <p progressControl>.  The minimum value is returned in
	<p min>, the maximum in <p max>.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.  If 
	function is successful, <p min> and <p max> contain the corresponding minimum
	and maximum values, otherwise their contents are undefined.

	@see <f mgProgressSetMinMax>, <f mgProgressSetValue>, <f mgProgressGetValue>,
	<f mgProgressStepValue>, <f mgProgressSetStepIncrement>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgProgressGetMinMax (
	mggui progressControl,	//	@param the progress control
	double* min,				//	@param address of double value to receive 
									// minimum value from control
	double* max					//	@param address of double value to receive 
									// maximum value from control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgProgressSetValue | sets the value of a progress control.
	@desc <f mgProgressSetValue> sets the value of a progress control, 
	<p progressControl>, to the specified value <p value>.   

   @desc If the value you specify is greater than the maximum value allowed for
	the progress control, the progress value will be set to the maximum progress value.  
	Similarly, if value is less than the minimum progress value, the progress value will
	be set to the minimum progress value.  
		
	@see <f mgProgressStepValue>, <f mgProgressGetValue>, <f mgProgressSetMinMax>,
	<f mgProgressGetMinMax>, <f mgProgressSetStepIncrement>
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgProgressSetValue (
	mggui progressControl,	//	@param the progress control
	double value				//	@param the value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgProgressGetValue | retrieves the current value of a progress
	control.
	@desc <f mgProgressGetValue> returns the current value of the specified progress
	control, <p progressControl>.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.  If 
	function is successful, <p value> contains the current value of the
	control, otherwise <p value> is undefined.

	@see <f mgProgressSetValue>, <f mgProgressStepValue>, <f mgProgressSetMinMax>,
	<f mgProgressGetMinMax>, <f mgProgressSetStepIncrement>

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgProgressGetValue (
	mggui progressControl,	//	@param the progress control
	double* value				//	@param address of double value to receive 
									// current value from control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgProgressStepValue | steps the value of a progress control.
	@desc <f mgProgressStepValue> steps the value of a progress control, 
	<p progressControl>, by the current step increment value of the control.
	
   @desc You can specify the step increment value for a progress control using
	the function <f mgProgressSetStepIncrement>. 
		
	@see <f mgProgressSetValue>, <f mgProgressGetValue>, <f mgProgressSetMinMax>,
	<f mgProgressGetMinMax>, <f mgProgressSetStepIncrement>
	
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgProgressStepValue (
	mggui progressControl	//	@param the progress control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgProgressSetStepIncrement | sets the step increment for
	a progress control.
	@desc <f mgProgressSetStepIncrement> sets the step increment value for the 
	specified progress control, <p progressControl> to the specified value,
	<p increment>.

	@desc The step increment value is the value that a progress control is 
	incremented when <f mgProgressStepValue> is called.

   @desc The step increment value specified must be positive.  The value
	will be ignored if it is not.  The default step increment value for a 
	progress control is 10.
		
	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@see <f mgProgressSetValue>, <f mgProgressGetValue>, <f mgProgressSetMinMax>,
	<f mgProgressGetMinMax>, <f mgProgressStepValue>

  @access Level 4
*/
extern MGAPIFUNC(mgstatus) mgProgressSetStepIncrement (
	mggui progressControl,	//	@param the progress control
	double increment			//	@param the step increment value for the control
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/* Convenience Dialog Functions                                               */
/*============================================================================*/
/* @doc EXTERNAL DIALOGFUNC */

/* mask bits for message dialog flags */
#define MMBX_OK				0x00000001				// @msg MMBX_OK | <f mgMessageDialog> flag indicating that
																// a single push button "OK" be displayed in the dialog.
#define MMBX_OKCANCEL		0x00000002				// @msg MMBX_OKCANCEL | <f mgMessageDialog> flag indicating that
																// two push buttons, "OK" and "Cancel" be displayed in the dialog.
#define MMBX_YESNO			0x00000004				// @msg MMBX_YESNO | <f mgMessageDialog> flag indicating that
																// two push buttons, "Yes" and "No" be displayed in the dialog.
#define MMBX_YESNOCANCEL	0x00000008				// @msg MMBX_YESNOCANCEL | <f mgMessageDialog> flag indicating that
																// three push buttons, "Yes", "No" and "Cancel" be displayed 
																// in the dialog.

#define MMBX_STATUS	      0x00000100				// @msg MMBX_STATUS | <f mgMessageDialog> flag indicating that
																// the status icon (lower case i) be displayed in the dialog.
#define MMBX_WARNING	      0x00000200				// @msg MMBX_WARNING | <f mgMessageDialog> flag indicating that
																// the warning icon (exclamation point ) be displayed in the dialog.
#define MMBX_ERROR         0x00000400				// @msg MMBX_ERROR | <f mgMessageDialog> flag indicating that
																// the error icon (stop sign) be displayed in the dialog.
#define MMBX_QUESTION      0x00000800				// @msg MMBX_QUESTION | <f mgMessageDialog> flag indicating that
																// the question icon (question mark) be displayed in the dialog.
												
/*============================================================================*/
/*                                                                            */
/* @func int | mgMessageDialog | displays modal message dialog.
	@desc <f mgMessageDialog> displays a modal dialog that contains a text
	message, an icon and any combination of push button controls. You 
	specify which icon and which combination of push buttons
	using the parameter <p flags>.  The value of <p flags> is the bitwise 
	combination of masks as described here.  

	@desc Choose one mask from the following group
	to specify which icon to display.

	@desc <m MMBX_STATUS> displays an informational icon (lower case i in a circle).  
	<nl><m MMBX_WARNING> displays a warning icon (exclamation point).
	<nl><m MMBX_ERROR> displays a warning icon (stop sign).
	<nl><m MMBX_QUESTION> displays a warning icon (question mark).

	@desc Choose one mask from the following group to specify which
	combination of push buttons to display. 
	
	@desc <m MMBX_OK> displays a single button "OK".  
	<nl><m MMBX_OKCANCEL> displays two buttons "OK" and "Cancel".
	<nl><m MMBX_YESNO> displays two buttons "Yes" and "No".
	<nl><m MMBX_YESNOCANCEL> displays three buttons "Yes", "No" and "Cancel".  

	@desc You must select one and only one mask from each group listed above.  If
	you do not select a mask from each group or select more than one from either group,
	the results are undefined.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.

	@return Returns integer value indicating which push button was pressed by the user
	to dismiss the dialog.  The return value depends on the push button combination
	you specified in the <p flags> parameter. <nl>
	@return For <m MMBX_OK>, the return value
	is always 1 (OK).  <nl>
	@return For <m MMBX_OKCANCEL>, the return value is
	either 1 (OK) or 2 (Cancel).  <nl>
	@return For <m MMBX_YESNO>, the return value
	is either 1 (Yes) or 2 (No).  <nl>
	@return For <m MMBX_YESNOCANCEL>, 
	the return value is either 1 (Yes), 2 (No), or 3 (Cancel). 

	@access Level 4
*/
extern MGAPIFUNC(int) mgMessageDialog (
	mggui parent,			// @param the dialog parent to attach the prompt dialog
   char* title,			// @param the title string for the dialog
   char* messageText,	// @param the message text to display in the dialog
   int flags				// @param flags to specify which icon and push button
								// controls to display in the dialog
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogString | prompts user to enter string value.
	@desc <f mgPromptDialogString> displays a modal dialog in which the 
	user is asked to enter a text string value. 

	@desc The dialog displays a text message and contains a text control and
	two push button controls - OK and Cancel.  The text control is wide 
	enough to display <p numColumns> characters and initially displays the
	text string contained in the parameter <p value>.  The user enters the 
	string value into this text control. The OK and Cancel push button controls are used to dismiss the dialog.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.

	@desc If the user enters a valid string value and chooses the OK button
	to dismiss the dialog, the value is returned in the parameter 
	<p value>.  The string is truncated and 
	null terminated if it is longer than <p maxLen> characters. 

	@return Use macro <m MSTAT_ISOK> to check return value for success.  Success
	indicates that the value entered was valid
	and the user dismissed the dialog using the OK push button.  If function 
	is successful, <p value> contains the corresponding numeric value, otherwise
	<p value> it is undefined.

   @see <f mgPromptDialogInteger>, <f mgPromptDialogFloat>, <f mgPromptDialogDouble> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgPromptDialogString (
	mggui parent,			// @param the dialog parent to attach the prompt dialog
	int numColumns,		// @param number of columns that will be visible in the
								// text control
	char* messageText,	// @param a text string that is displayed in the dialog 
								// as a message to the user
	char* value,			// @param on input, the initial text string to display in
								// the text control, on output will receive the text entered.
	int maxLen				//	@param the maximum number of characters to store in <p value>
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogInteger | prompts user to enter integer value.
	@desc <f mgPromptDialogInteger> displays a modal dialog in which the 
	user is asked to enter an integer value. 

	@desc The dialog displays a text message and contains a text control and
	two push button controls - OK and Cancel.  The text control is used to control
	the numeric value contained in the parameter <p value>.  The OK and Cancel
	push button controls will be used to dismiss the dialog.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog wis created as a 
	child of the Creator main window.

	@desc If the user enters a valid numeric value and chooses the OK button
	to dismiss the dialog, the value is returned in the parameter 
	<p value>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  Success
	indicates that the value entered was a valid inteter value
	and the user dismissed the dialog using the OK push button.  If function 
	is successful, <p value> contains the corresponding numeric value, otherwise
	<p value> is undefined.

   @see <f mgPromptDialogString>, <f mgPromptDialogFloat>, <f mgPromptDialogDouble> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgPromptDialogInteger (
	mggui parent,			// @param the dialog parent to attach the prompt dialog
	char* messageText,	// @param a text string that is displayed in the dialog 
								// as a message to the user
	int* value				// @param on input, the address of the initial integer 
								// value to display in the text control, on output will 
								// receive the integer value entered
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogFloat | prompts user to enter single
	precision floating point value.
	@desc <f mgPromptDialogFloat> displays a modal dialog in which the 
	user is asked to enter a single precision floating point value. 

	@desc The dialog displays a text message and contain a text control as well
	as two push button controls - OK and Cancel.  The text control is used
	to enter the numeric value.  The initial value displayed in the text control
	is the numeric value contained in the parameter <p value>.  
	The OK and Cancel push button controls are used to dismiss the dialog.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.

	@desc If the user enters a valid numeric value and chooses the OK button
	to dismiss the dialog, the value is returned in the parameter 
	<p value>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  Success
	indicates that the value entered was a valid single precision floating point value
	and the user dismissed the dialog using the OK push button.  If function 
	is successful, <p value> contains the corresponding numeric value, otherwise
	<p value> is undefined.

   @see <f mgPromptDialogString>, <f mgPromptDialogInteger>, <f mgPromptDialogDouble> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgPromptDialogFloat (
	mggui parent,			// @param the dialog parent to attach the prompt dialog
	char* messageText,	// @param a text string that is displayed in the dialog 
								// as a message to the user
	float* value			// @param on input, the address of the initial float 
								// value to display in the text control, on output  
								// receives the float value entered
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogDouble | prompts user to enter double
	precision floating point value.
	@desc <f mgPromptDialogDouble> displays a modal dialog in which the 
	user is asked to enter a double precision floating point value. 

	@desc The dialog displays a text message and contain a text control as well
	as two push button controls - OK and Cancel. The text control is used
	to enter the numeric value.  The initial value displayed in the text control
	is the numeric value contained in the parameter <p value>.  
	The OK and Cancel push button controls are
	used to dismiss the dialog.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.

	@desc If the user enters a valid numeric value and chooses the OK button
	to dismiss the dialog, the value is returned in the parameter 
	<p value>.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  Success
	indicates that the value entered was a valid double precision floating point value
	and the user dismissed the dialog using the OK push button.  If function 
	is successful, <p value> contains the corresponding numeric value, otherwise
	<p value> is undefined.

   @see <f mgPromptDialogString>, <f mgPromptDialogInteger>, <f mgPromptDialogFloat> 
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgPromptDialogDouble (
	mggui parent,			// @param the dialog parent to attach the prompt dialog
	char* messageText,	// @param a text string that is displayed in the dialog 
								// as a message to the user
	double* value			// @param on input, the address of the initial double 
								// value to display in the text control, on output  
								// receives the double value entered
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogFolder | prompts the user to select a
	folder using a standard folder browser.
	
	@desc <f mgPromptDialogFolder> displays a modal dialog in which the 
	user is prompted to select a folder. 

	@desc The dialog displays the directory structure using a tree control and 
	two push button controls - OK and Cancel.  The tree control is used to select 
	the directory.  The initial folder selected in the tree control is specified
	through the parameter <p initialFolderName>.  The OK and Cancel push 
	button controls are used to dismiss the dialog.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.

	@desc If the user selects a valid folder name and pressed the OK 
	button to dismiss the dialog, the value is returned in the parameter 
	<p selectedFolderName>.  The storage for the <p selectedFolderName> is
	dynamically allocated by this function.  When you are done using this
	string value, use <f mgFree> to properly dispose of the allocated memory.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  Success
	indicates that the folder selected was a valid folder	and the user dismissed 
	the dialog using the OK push button.  If function is successful, 
	<p selectedFolderName> contains the corresponding folder name, otherwise
	<p selectedFolderName> is undefined.

	@ex The following example illiustrates the use of <f mgPromptDialogFolder>
	with the initial folder "C:/multigen/gallery/models" |

   char *selectedFolder;
   mgstatus status;

   status = mgPromptDialogFolder ( 
      parent, "Choose Folder",
      "C:/multigen/gallery/models"
      &selectedFolder );

   if ( MSTAT_ISOK ( status ) ) {
      printf ( "Successful operation" );
      // free allocated memory when done with folder
      mgFree ( selectedFolder );
   }

   @see <f mgPromptDialogFile>
	@access Level 4
*/
extern MGAPIFUNC(mgstatus) mgPromptDialogFolder (
	mggui parent,					// @param the dialog parent to attach the prompt dialog
	char* title,					// @param the title string for the dialog
	char* initialFolderName,	// @param the initial folder that the user wants to go to
	char** selectedFolderName	// @param on selection and choosing OK button, this parameter
										// contains the selected folder name
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogFile | prompts the user to select one or
	more files using a standard file browser.

	@desc <f mgPromptDialogFile> displays a modal dialog in which the 
	user is prompted to select one or more files. 

	@desc The dialog displays the directory structure using a file browser with 
	two push buttons Open/Save and Cancel.	The file browser control is used to 
	select the file. The user can specify the mode of the file browser as either 
	Open or Save by specifying either <m MPFM_OPEN> or <m MPFM_SAVE> in <p mode>.

	@desc Optional Input Parameters:
	@desc <m MPFA_FLAGS> - argument is a bitwise combination of<nl>
	<m MPFF_OVERWRITEPROMPT>,<nl>
	<m MPFF_FILEMUSTEXIST>, and<nl> 
	<m MPFF_MULTISELECT>.

	@desc <m MPFA_TITLE> - argument is a string specifying the title of the dialog.

	@desc <m MPFA_PATTERN> - argument is a string containing a list of 
	description-extension pairs that describe the file browser filters
	to use.  See <m MPFA_PATTERN> for a description of the required
	format of this string.

	@desc <m MPFA_DIRECTORY> - argument is a string specifying the
	initial directory name.

	@desc	<m MPFA_FILENAME> - argument is a string specifying the initial
	filename (does not include directory path).

	@desc <m MPFA_FULLFILENAME> - argument is a string specifying
	the full filename including the path.

	@desc <m MPFA_DIALOGID> - argument is the identifier of a custom dialog
	to use for the file browser.

	@desc <m MPFA_RESOURCE> - argument is an object of type <t mgresource>
	to identify the resource where your custom dialog template is located.
	
	@desc <m MPFA_DIALOGFUNC> - argument is a dialog function for the file
	browser dialog.

	@desc <m MPFA_CALLBACKMASK> - argument is an unsigned integer value specifying
	the dialog events  selected for the dialog function of the file browser.

	@desc <m MPFA_PATTERNINDEX> - argument is the address of an integer object
	to receive the index of the selected pattern when the file chooses a file
	in the browser.

	@desc All optional parameters are passed using variable argument style
	and must be terminated with <m MG_NULL>.

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.

	@return Use macro <m MSTAT_ISOK> to check return value for success.  
	Success indicates that the file selected was a valid file and the user 
	dismissed the dialog using the Open/Save push button.  If function call is 
	successful, <p numFiles> contains the number of files that have been selected,
	and <p fileList> contains the selected file name(s), otherwise both are undefined.
	
	@desc Note: The storage for the <p fileList> is dynamically allocated by 
	this function.  When you are done using these names, use <f mgFreeStringList>
	to properly dispose of the allocated memory.

	@ex The following example creates a file broswer with *.flt and *.txt as filters 
	starting at the initial directory 'C:/multigen/gallery/models' and with the initial 
	file from that directory 'cdcspsce.flt'. The title for the dialog is 'Open Flight or 
	Text Files'. The user is allowed to select multiple files and success is returned only if 
	a valid file is selected. |

   mgstatus status;
   int numberOfFilesSelected;
   mgstringlist filenames = MG_NULL;

   status = mgPromptDialogFile (
      parent, MPFM_OPEN,
      &numberOfFilesSelected,
      &filenames,
      MPFA_FLAGS, MPFF_OVERWRITEPROMPT|
                         MPFF_FILEMUSTEXIST|
                         MPFF_MULTISELECT,
      MPFA_PATTERN, "Flight Files|*.flt || Text Files|*.txt",
      MPFA_TITLE, "Open Flight Files or Text Files",
      MPFA_DIRECTORY, "C:/multigen/gallery/models",
      MPFA_FILENAME, "cdcspace.flt",
      MG_NULL );

   if ( MSTAT_ISOK ( status ) ) {
      printf ( "Successful operation" );
      // free allocated memory when done with file names
      mgFreeStringList ( filenames );
   }

	@see <f mgPromptDialogFolder>
	@access Level 4
*/

extern MGAPIFUNC(mgstatus) mgPromptDialogFile (
	mggui parent,					// @param the dialog parent to attach the prompt dialog
	int mode,						// @param an integer value that is either MPFM_OPEN or 
										// MPFM_SAVE that specified the mode for the file dialog
	int *numFiles,					// @param a pointer to an integer that holds the number of
										// files that have been selected -
										// if the user had selected the MPFF_MULTISELECT option, 
										// then this value can be more than 1 else it will be 
										// atmost 1
	mgstringlist* fileList,		// @param a pointer to an <t mgstringlist> object 
										// that will be allocated and filled with the names,
										// of the selected files, <m MG_NULL> if no files selected
	...								//	@param | ... | optional input parameters in variable 
										// argument style 
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgPromptDialogColor | prompts the user to select a color
	using a standard color chooser.

	@desc <f mgPromptDialogColor> displays a modal color chooser dialog in 
	which the user is prompted to select a color. 

	@desc The dialog is created as a child of the specified dialog <p parent>.
	If you specify <p parent> as <m MG_NULL>, the dialog is created as a 
	child of the Creator main window.  When the dialog is initially displayed,
	it will present the color specified by the input parameters <p inR>, <p inG>,
	and <p inB>.

   @desc The input and output color values are in the range 0 to 255.

	@return Use macro <m MSTAT_ISOK> to check return value for success.
	Success indicates that the user selected and accepted a color.  
	If function call is successful, <p outR>, <p outG>,
	and <p outB> will contain the red, green and blue components of the color
	selected, otherwise these output parameters are undefined.
	
	@access Level 4
*/

MGAPIFUNC(mgstatus) mgPromptDialogColor (
	mggui parent,		// @param the dialog parent to attach the color dialog
	short inR,			// @param the red component of the initial color
	short inG,			// @param the green component of the initial color
	short inB,			// @param the blue component of the initial color
	short* outR,		// @param the red component of the selected color
	short* outG,		// @param the green component of the selected color
	short* outB			// @param the blue component of the selected color
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */



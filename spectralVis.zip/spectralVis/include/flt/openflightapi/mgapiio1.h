/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIIO1_H_
#define MGAPIIO1_H_
/* @doc EXTERNAL IOFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif
	
/*============================================================================*/

/******************************************************************************/
/*                                                                            */
/* @func void | mgInit | initializes the MultiGen API software 
	development environment
	@desc <f mgInit> is the very first routine an application should call. 
	This routine performs the proper initialization of internal memory, 
	the default palettes (color, material, light source, and texture), 
	and loads the OpenFlight Data Dictionary. It is a mandatory call to 
	activate the entire programming environment.  

	@desc Note: This function is for use in stand alone applications only, 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@access Level 1
	@see <f mgOpenDb>, <f mgExit>
*/
extern MGAPIFUNC(void) mgInit (
	int* argc,			// @param pointer to an int containing the number of 
							// command line arguments
	char* argv []		// @param the array of command line argument strings
	);
/*                                                                            */
/******************************************************************************/
 
/******************************************************************************/
/*                                                                            */
/* @func mgbool | mgIsDb | checks if a file is an OpenFlight database file 
	@desc <f mgIsDb> determines whether the file named by <p fileName> is
	an OpenFlight database file. 

	@return Returns <e mgbool.MG_TRUE> if the specified file is an OpenFlight
	database file, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgNewDb>, <f mgOpenDb>, <f mgCloseDb> 
*/
extern MGAPIFUNC(mgbool) mgIsDb (
	char* fileName				// @param the name of the file to be checked
	);
/*                                                                            */
/******************************************************************************/
 
/******************************************************************************/
/*                                                                            */
/* @func mgrec* | mgNewDb | creates a new database
	@desc <f mgNewDb> creates a new database with the specified file
	name <p fileName>. The new database consists of a database node, 
	which is returned by this function. 

	@desc Note: This function is for use in stand alone applications only, 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@return Returns a pointer to the new database node if successful,
	<m MG_NULL> otherwise.

	@ex The following example creates a new database: |
   mgrec* db;
   db = mgNewDb ( "newfile.flt" );

	@access Level 1
	@see <f mgOpenDb>, <f mgWriteDb>, <f mgCloseDb>, 
	<f mgSetNewOverwriteFlag>, <f mgSetOpenCreateFlag>
*/
extern MGAPIFUNC(mgrec*) mgNewDb (
	char* fileName			// @param the name of the new database file
	);
/*                                                                            */
/******************************************************************************/
 
/******************************************************************************/
/*                                                                            */
/* @func mgrec* | mgOpenDb | opens an existing OpenFlight database 
	for reading or writing
	@desc <f mgOpenDb> opens the file named by <p fileName> . 
	It checks for legal file type and revision, builds the internal 
	node tree, and returns the database node upon successful completion.

	@desc Note: This function is for use in stand alone applications only, 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@return Returns a pointer to the opened database node if successful,
	<m MG_NULL> otherwise.

	@ex The following example opens an existing database: |
   mgrec* db;
   db = mgOpenDb ( "existingfile.flt" );

	@access Level 1
	@see <f mgNewDb>, <f mgCloseDb>, 
	<f mgSetNewOverwriteFlag>, <f mgSetOpenCreateFlag>
*/
extern MGAPIFUNC(mgrec*) mgOpenDb (
	char* fileName				// @param the name of the file to be opened
	);
/*                                                                            */
/******************************************************************************/

#define MOPX_READEXT			0x0001
#define MOPX_OPENCREATE		0x0002
#define MOPX_HEADERONLY		0x0004

extern MGAPIFUNC(mgrec*) mgOpenDbEx (
	char* fileName,				// param the name of the file to be opened
	int flags						// param flags controlling how the file is opened
	);
 
/******************************************************************************/
/*                                                                            */
/* @func mgbool | mgCloseDb | closes a database
	@desc <f mgCloseDb> closes the database with the given top node 
	of <p db>. This routine is the recommended way to close a database. 
	Besides the system call to close a file, it also performs many 
	housekeeping functions such as updating the time stamp, updating the 
	file revision, and releasing memory.

	@desc Note: This function is for use in stand alone applications only, 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgOpenDb>, <f mgWriteDb> 
*/
extern MGAPIFUNC(mgbool) mgCloseDb (
	mgrec* db			// @param the database node
	);
/*                                                                            */
/******************************************************************************/
 
/******************************************************************************/
/*                                                                            */
/* @func mgbool | mgExit | exits the MultiGen API software development 
	environment
	@desc <f mgExit> is the very last routine an application should call. 
	This routine performs the proper exit functions, such as closing all 
	database and resource files, housekeeping, and releasing memory. 
	It is a mandatory call to exit the entire programming environment. 
	<f mgExit> does not write or save any databases.

	@desc Note: This function is for use in stand alone applications only 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgCloseDb>, <f mgInit>
*/
extern MGAPIFUNC(mgbool) mgExit ( void );
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/* @func mgbool | mgExtRefSetLocatorFunc | sets the external reference
	file locator function.

	@desc <f mgExtRefSetLocatorFunc> allows you to setup an external
	refernce file locator function used by the API to "locate" external
	reference files referenced within OpenFlight databases.  When a 
	database file is opened using the API, the current external reference
	file locator function set will be called to locate the external
	reference file.  In this way, your application can override
	the way the API locates external reference files.

	@desc Note: This function is for use in stand alone applications only, 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@return Returns <e mgbool.MG_TRUE> if external refernce locator
	function could be set, otherwise <e mgbool.MG_FALSE>.

	@see <f mgExtRefGetLocatorFunc>, <f mgTextureSetLocatorFunc>,

	@access Level 1
*/
MGAPIFUNC(mgbool) mgExtRefSetLocatorFunc (
	mgfilelocatorfunc locatorFunc,	// @param the external reference file
												// locator function
	void* userData							// @param user defined data that will be 
												// passed to <p locatorFunc> when it is 
												// called
	);
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/* @func mgfilelocatorfunc | mgExtRefGetLocatorFunc | gets the current 
	external reference file locator function.

	@desc <f mgExtRefGetLocatorFunc> returns the current external reference
	file locator function.  In this way, you can query the current locator
	function and then call it as part of the locator function you set
	up or call it directly for other file location processing your
	application or plug-in requires.

	@desc Note: Although only stand-alone applications can override the
	external reference file locator, stand-alone applications as well as
	plug-ins can obtain it.  This allows both stand-alone applications
	and plug-ins to "mimic" the behavior of the default file locator
	when locating files as part of their processing.

	@see <f mgExtRefSetLocatorFunc>, <f mgTextureGetLocatorFunc>,
	<t mgfilelocatorfunc>

	@access Level 1
*/
MGAPIFUNC(mgfilelocatorfunc) mgExtRefGetLocatorFunc ( void );
/*                                                                            */
/******************************************************************************/

extern MGAPIFUNC(mgbool) mgGetWorkingDirectory (
	char* workingDir,
	int maxLen
	);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

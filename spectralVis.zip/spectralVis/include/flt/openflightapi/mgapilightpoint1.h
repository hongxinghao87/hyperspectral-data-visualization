/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPILIGHTPOINT1_H_
#define MGAPILIGHTPOINT1_H_
// @doc EXTERNAL LIGHTPOINTFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

// @type mglightpointanimationsequencedata | Light Point Animation Sequence data
// @desc Use an array of <t mglightpointanimationsequencedata> to add and get 
// light point animation sequence records.
// @see <f mglightpointanimationsequencedata>, 
// <f mgLightPointAnimationSequenceGet>,
// <f mgLightPointAnimationSequenceSet>
typedef struct {
	unsigned int state;						// @field state of this item in the sequence.  
													// On = 0, Off = 1, Color Change = 2
	float	duration;							// @field time (in seconds) for this item in the sequence
	unsigned int colorIndex;				// @field index of color for this item in the sequence if 
													// state is On or Color Change, ignored when state is Off
	float colorIntensity;					// @field intensity of color for this item in the sequence if 
													// state is On or Color Change, ignored when state is Off
} mglightpointanimationsequencedata;

/*============================================================================*/
/*                                                                            */
/* @func int | mgLightPointAnimationSequenceGet | gets the sequence items from
	a light point animation record

	@desc <f mgLightPointAnimationSequenceGet> gets the items of an animation
	sequence of a light point animation record into an array <p sequenceData>. 
	The size of the array is specified by <p n>. The number of items actually
	written into the array is returned.  The <flt fltLpSequenceLength> attribute
	defines the actual number of items contained in an animation sequence.

	@return The number of items actually written into the array 
	<p sequenceData>

	@see <f mgLightPointAnimationSequenceSet>
   
	@ex |
   mgrec* lpaRec = mgGetLightPointAnimation ( dbRec, index );
   int seqLength;
   mgGetAttList (lpaRec, fltLpSequenceLength, &seqLength, MG_NULL);
   if ( seqLength > 0 ) {
      int num;
      mglightpointanimationsequencedata* seqData;
      seqData = mgMalloc ( seqLength * sizeof(mglightpointanimationsequencedata) );
      num = mgLightPointAnimationSequenceGet ( lpaRec, seqData, seqLength );
   }

	@access Level 1
*/
MGAPIFUNC(int) mgLightPointAnimationSequenceGet (
	mgrec* lpaRec,														// @param the light point animation attribute record
	mglightpointanimationsequencedata sequenceData[],		// @param the array of sequence records to be filled in
	int n																	// @param the size of the array <p sequenceData>
	);
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetLightPointAppearance | gets an entry from the
	light point appearance palette

	@desc <f mgGetLightPointAppearance> gets a light point appearance 
	palette entry for database <p db>.  The entry retrieved is specified
	by <p index>.

	@return Returns the palette entry if found, <m MG_NULL> otherwise.

	@access Level 1

	@see <f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(mgrec*) mgGetLightPointAppearance (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to get
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgIndexOfLightPointAppearance | gets the index of a named
	entry in the light point appearance palette

	@desc <f mgIndexOfLightPointAppearance> returns the index of the entry
	named <p name> in the light point appearance palette for database <p db>. 
	If the entry is not found, -1 is returned. 

	@return Returns the index of the palette entry if found, -1 otherwise.

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(int) mgIndexOfLightPointAppearance (
	mgrec* db,		// @param the database node
	char* name		// @param the name of the entry to look up
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func char* | mgNameOfLightPointAppearance | gets the name of an indexed
	entry in the light point appearance palette

	@desc <f mgNameOfLightPointAppearance> returns the name of the entry
	specified by <p index> in the light point appearance palette for database
	<p db>.  If the entry is not found, <m MG_NULL> is returned.  

	@desc Note: Storage for the name is dynamically allocated by
	this function.  The user is responsible for deallocating this memory
	using <f mgFree>.

	@return Returns the name of the entry if found, <m MG_NULL> otherwise.

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(char*) mgNameOfLightPointAppearance (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to look up
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgGetLightPointAppearanceCount | gets the number of entries
	in the light point appearance palette 

	@desc <f mgGetLightPointAppearanceCount> gets the number of entries
	contained in the light point appearance palette for database <p db>.
 
	@return Returns the number of palette entries.

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(int) mgGetLightPointAppearanceCount (
	mgrec* db		// @param the database node
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetFirstLightPointAppearance | gets the first entry in
	a light point appearance palette

	@desc <f mgGetFirstLightPointAppearance> gets the first entry contained
	in the light point appearance palette for database <p db>.

	@return Returns the first palette entry if successful, 
	<m MG_NULL> otherwise.  If successful, the output parameter
	<p index> is filled in with the index of the returned entry,
	otherwise it is undefined.

	@ex | 
   mgrec* thisEntry;
   mgrec* nextEntry;
   mgrec* db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   thisEntry = mgGetFirstLightPointAppearance ( db, &index );
   nextEntry = mgGetNextLightPointAppearance ( thisEntry, &index );

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(mgrec*) mgGetFirstLightPointAppearance (
	mgrec* db,		// @param the database node
	int* index		// @param address of value to receive index of entry 
						// returned
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetNextLightPointAppearance | gets the next entry in
	a light point appearance palette

  	@desc <f mgGetNextLightPointAppearance> gets the entry that follows
	<p lightPointAppearance> in the light point appearance palette for
	database <p db>.

	@return Returns the next palette entry if successful, 
	<m MG_NULL> otherwise.  If successful, the output parameter
	<p index> is filled in with the index of the returned entry,
	otherwise it is undefined.

	@ex | 
   mgrec* thisEntry;
   mgrec* nextEntry;
   mgrec* db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   thisEntry = mgGetFirstLightPointAppearance ( db, &index );
   nextEntry = mgGetNextLightPointAppearance ( thisEntry, &index );

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(mgrec*) mgGetNextLightPointAppearance ( 
	mgrec* lightPointAppearance,	// @param the palette entry to get next for
	int* index							// @param address of value to receive 
											// index of entry returned
	);
/*                                                                            */
/*============================================================================*/
 

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetLightPointAnimation | gets an entry from the
	light point appearance palette

	@desc <f mgGetLightPointAnimation> gets a light point appearance 
	palette entry for database <p db>.  The entry retrieved is specified
	by <p index>.

	@return Returns the palette entry if found, <m MG_NULL> otherwise.

	@access Level 1

	@see <f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(mgrec*) mgGetLightPointAnimation (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to get
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgIndexOfLightPointAnimation | gets the index of a named
	entry in the light point appearance palette

	@desc <f mgIndexOfLightPointAnimation> returns the index of the entry
	named <p name> in the light point appearance palette for database <p db>. 
	If the entry is not found, -1 is returned. 

	@return Returns the index of the palette entry if found, -1 otherwise.

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(int) mgIndexOfLightPointAnimation (
	mgrec* db,		// @param the database node
	char* name		// @param the name of the entry to look up
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func char* | mgNameOfLightPointAnimation | gets the name of an indexed
	entry in the light point appearance palette

	@desc <f mgNameOfLightPointAnimation> returns the name of the entry
	specified by <p index> in the light point appearance palette for database
	<p db>.  If the entry is not found, <m MG_NULL> is returned.  

	@desc Note: Storage for the name is dynamically allocated by
	this function.  The user is responsible for deallocating this memory
	using <f mgFree>.

	@return Returns the name of the entry if found, <m MG_NULL> otherwise.

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(char*) mgNameOfLightPointAnimation (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to look up
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgGetLightPointAnimationCount | gets the number of entries
	in the light point appearance palette 

	@desc <f mgGetLightPointAnimationCount> gets the number of entries
	contained in the light point appearance palette for database <p db>.
 
	@return Returns the number of palette entries.

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(int) mgGetLightPointAnimationCount (
	mgrec* db		// @param the database node
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetFirstLightPointAnimation | gets the first entry in
	a light point appearance palette

	@desc <f mgGetFirstLightPointAnimation> gets the first entry contained
	in the light point appearance palette for database <p db>.

	@return Returns the first palette entry if successful, 
	<m MG_NULL> otherwise.  If successful, the output parameter
	<p index> is filled in with the index of the returned entry,
	otherwise it is undefined.

	@ex | 
   mgrec* thisEntry;
   mgrec* nextEntry;
   mgrec* db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   thisEntry = mgGetFirstLightPointAnimation ( db, &index );
   nextEntry = mgGetNextLightPointAnimation ( thisEntry, &index );

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetNextLightPointAppearance>,
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(mgrec*) mgGetFirstLightPointAnimation (
	mgrec* db,		// @param the database node
	int* index		// @param address of value to receive index of entry 
						// returned
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetNextLightPointAnimation | gets the next entry in
	a light point appearance palette

  	@desc <f mgGetNextLightPointAnimation> gets the entry that follows
	<p lightPointAnimation> in the light point appearance palette for
	database <p db>.

	@return Returns the next palette entry if successful, 
	<m MG_NULL> otherwise.  If successful, the output parameter
	<p index> is filled in with the index of the returned entry,
	otherwise it is undefined.

	@ex | 
   mgrec* thisEntry;
   mgrec* nextEntry;
   mgrec* db;
   int index;
   db = mgNewDb ( "newfile.flt" );
   thisEntry = mgGetFirstLightPointAnimation ( db, &index );
   nextEntry = mgGetNextLightPointAnimation ( thisEntry, &index );

	@access Level 1
	@see
	<f mgGetLightPointAppearance>,
	<f mgGetLightPointAppearanceCount>, 
	<f mgIndexOfLightPointAppearance>, 
	<f mgNameOfLightPointAppearance>, 
	<f mgGetFirstLightPointAppearance>, 
	<f mgGetLightPointAnimation>,
	<f mgGetLightPointAnimationCount>, 
	<f mgIndexOfLightPointAnimation>, 
	<f mgNameOfLightPointAnimation>, 
	<f mgGetFirstLightPointAnimation>, 
	<f mgGetNextLightPointAnimation>
*/
extern MGAPIFUNC(mgrec*) mgGetNextLightPointAnimation ( 
	mgrec* lightPointAppearance,	// @param the palette entry to get next for
	int* index							// @param address of value to receive 
											// index of entry returned
	);
/*                                                                            */
/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadLightPointFile | reads in a light point file as 
	a database�s current light point appearance and animation palettes.
	@desc Given a database node, <p db>, and a light point file <p fileName>,
	<f mgReadLightPointFile> reads the light point entries contained in the file
	and replaces the database's light point palette with those entries read.

	@desc Existing light point palette appearance and animation entries
	all become invalid.

	@desc Note that even though the light point appearance and animation palettes
	are really separate, this function, as well as <f mgWriteLightPointFile> groups
	the entries in both into one single file.

	@return Returns <e mgbool.MG_TRUE> if the light point file was 
	read successfully, otherwise <e mgbool.MG_FALSE>. 

	@see <f mgWriteLightPointFile>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgReadLightPointFile ( 
			mgrec* db,			/* @param the database node */
			char* fileName		/* @param the light point file name */
			);

/*============================================================================*/


/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

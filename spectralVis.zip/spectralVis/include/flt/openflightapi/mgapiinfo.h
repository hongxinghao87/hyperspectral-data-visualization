/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIINFO_H_
#define MGAPIINFO_H_

/*----------------------------------------------------------------------------*/

#ifdef API_LEV5
#include "mgapiinfo3.h"
#include "mgapiinfo1.h"
#endif

#ifdef API_LEV4
#include "mgapiinfo3.h"
#include "mgapiinfo1.h"
#endif

#ifdef API_LEV3
#include "mgapiinfo3.h"
#include "mgapiinfo1.h"
#endif

#ifdef API_LEV2
#include "mgapiinfo1.h"
#endif

#ifdef API_LEV1
#include "mgapiinfo1.h"
#endif

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

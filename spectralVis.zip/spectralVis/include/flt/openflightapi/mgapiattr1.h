/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIATTR1_H_
#define MGAPIATTR1_H_
/* @doc EXTERNAL ATTRIBUTEFUNC */

/*============================================================================*/

#include "mgapibase.h"
#include "mgapidd1.h"
#include "mgapimem1.h"
#include "mgapimatrix.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/* @func mgbool | mgGetAttBuf | gets consecutive values from an attribute 
	record and stores them in a data buffer.
  
   @return Returns <e mgbool.MG_TRUE> if data is stored in the buffer, 
	<e mgbool.MG_FALSE> otherwise.

   @desc Given a record, rec, <f mgGetAttBuf> gets the values of the attribute 
	<p fcode> from <p rec> and stores those values in the data buffer <p buf>. 
	It is the caller's responsibility to ensure that sufficient storage is 
	allocated.

   @desc This routine is used for getting all attribute values of a record, 
	with the condition that the attributes are consecutive as defined by the
	data dictionary. Note: Simple records such as <flt fltCoord3d> and 
	<flt fltMatrix> are guaranteed to be stored consecutively; more complex
	records are not. Exercise caution when using this routine.

   @ex The following example gets the attribute values of <flt fltMatrix> 
	in <p polyRec>. |
   mgmatrix matrix;
  
   mgGetAttBuf ( polyRec, fltMatrix, matrix );

	@access Level 1
   @see <f mgSetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetAttBuf ( 
		mgrec* rec,		// @param points to the record from which to get values.
		mgcode fcode,	// @param the attribute code.
		void* buf		// @param points to the storage area for the attribute values.
		);
 

/* @func mgrec* | mgGetExtRec | gets pointer to one of a record's tag-along
   extension records.
  
   @return Returns the tag-along extension record pointer if found, 
	<m MG_NULL> otherwise.

   @desc <f mgGetExtRec> returns the tag-along extension record
	identified by <p rcode> attached to <p rec>.  Use this function to
	retrieve a tag-along extension record that may or may not be attached
	to <p rec>. Use <f mgGetAttRec> to retrieve a nested attribute record.
	
   @desc This function is useful to resolve field name ambiguity caused
	by multiple tag-along extension records containing common field names.
	For example, consider an OpenFlight data extension that defines two
	tag-along extension records for <flt fltGroup>, <m myExt1> and <m myExt2>.
	In turn, each of these tag-along extension records contains a field
	named <m myIntField>.  Given any <flt fltGroup> node, referencing field
	<m myIntField> using <f mgGetAttList> or <f mgSetAttList> is ambiguous
	since both <m myExt1> and <m myExt2> contain fields by that name.
	
   @ex The following example shows two techniques for getting the value
	of the field <m myIntField> from a tag-along extension record 
	attached to <m groupRec>.  The first technique leads to undefined
	results because it is not clear which tag-along extension record
	containing <m myIntField> to use.  The second technique uses
	<f mgGetExtRec> to resolve the ambiguity. |
   mgrec* groupRec;
   mgrec* extRec;
   int fieldVal;

   // this call to mgGetAttList is ambiguous
   mgGetAttList ( groupRec, myIntField, &fieldVal, MG_NULL );

   // this call to mgGetAttList is not ambiguous
   extRec = mgGetExtRec ( groupRec, myExt1 );
   if ( extRec )
      mgGetAttList ( extRec, myIntField, &fieldVal, MG_NULL ); 

   @access Level 1
   @see <f mgGetAttList>, <f mgGetAttRec>
*/
extern MGAPIFUNC(mgrec*) mgGetExtRec (
		mgrec* rec,				// @param points to the record that may or
									// may not have a tag-along extension record
									// attached
		mgcode rcode			// @param the tag-along extension record code
		);

/* @func mgrec* | mgGetAttRec | gets pointer to one of a record's attribute records.
  
   @return Returns the attribute record pointer if found, <m MG_NULL> otherwise.

   @desc <f mgGetAttRec> returns a pointer to the attribute record identified by 
	<p rcode> from <p rec>.  Use this function to retrieve an attribute record
   as opposed to an attribute value.  Use <f mgGetAttList> to retrieve an 
	attribute value.

	@desc If you specify <m MG_NULL> for <p recOut>, a new record will be 
	allocated and returned.  If you specify a valid <t mgrec*> for <p recOut>,
	the record retrieved will be copied into <p recOut>.  In this way, you 
	can reuse records.  
	
	@desc Note: Any <p recOut> that you pass in must have been returned
	from a previous call to <f mgGetAttRec> or must be <m MG_NULL>.
	This ensures that the contents of other records do not 
	inadvertently get overwritten.

   @ex The following example gets the attribute record pointer of 
   <flt fltBoundingBox> in <p groupRec> through <p attRec>. |
   mgrec* groupRec;
   mgrec* attRec;
   int boundType;
  
   attRec = mgGetAttRec ( groupRec, fltBoundingBox, MG_NULL );
   mgGetAttList ( attRec, fltBoundingType, &boundType, MG_NULL ); 

   @access Level 1
   @see <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgrec*) mgGetAttRec ( 
		mgrec* rec,				// @param points to the record from which to get 
									// the attribute record
		mgcode rcode,			// @param the attribute record code
		mgrec* recOut			// @param points to the attribute record
		);

/* @func char* | mgGetName | gets a copy of the name (ID) of a node record.
   @return Returns a copy of the node's name string; <m MG_NULL> otherwise.
	@desc Given a node record, <p rec>, <f mgGetName> returns the string that is the node�s ID.  
	The storage for the string is dynamically allocated by <f mgGetName>. Use <f mgSetName> to change 
	the name of a record.  The node record in question must have a name attribute.
	@desc Note: The user is responsible for deallocating the dynamically allocated memory with <f mgFree>.
	@access Level 1
	@see <f mgGetRecByName>, <f mgSetName>
*/
extern MGAPIFUNC(char*) mgGetName ( 
		mgrec* rec // @param the node record.
		);

/* @func char* | mgGetTextString | gets a copy of the string in a <flt fltText> record.
   @return Returns a copy of the <flt fltText> record's string, <m MG_NULL> otherwise.
	@desc Given a <flt fltText> record, <p rec>, <f mgGetTextString> returns the 
	string stored in the record.  The storage for the string is dynamically allocated
	by <f mgGetTextString>.  Use <f mgSetTextString> to change record's string.
	@desc Note: The user is responsible for deallocating the dynamically
	allocated memory with <f mgFree>.
	@access Level 1
	@see <f mgSetTextString>
*/
extern MGAPIFUNC(char*) mgGetTextString ( 
		mgrec* rec // @param the record
		);

/* @func char* | mgGetComment | gets a copy of the comment text of a node record. 
   @return Returns a copy of the node's comment text if successful, <m MG_NULL> otherwise.
	
	@desc Given a node record, <p rec>, <f mgGetComment> returns a copy of the node�s 
	comment text.  The storage for the returned text is dynamically allocated by
	<f mgGetComment>. Use <f mgSetComment> or <f mgDeleteComment> to change or delete
	the record�s actual comment text.  Vertex node records do not have comment text.

   @desc Note: The user is responsible for freeing the dynamically allocated
	memory with <f mgFree>.

	@access Level 1
	@see <f mgSetComment>, <f mgDeleteComment>
*/
extern MGAPIFUNC(char*) mgGetComment ( 
		mgrec* rec // @param points to the node record whose comment text is desired
		);

/* @func mgbool | mgGetPolyColorRGB | gets the primary RGB color values out of a 
	<flt fltPolygon> or <flt fltMesh> record.
	@return Returns <e mgbool.MG_TRUE> if data is stored in the buffer, 
	<e mgbool.MG_FALSE>, otherwise.

	@desc Given a <flt fltPolygon> or <flt fltMesh> record, <p rec>, this function
	gets the red, green, and blue values of its <flt fltPolyPrimeColor> attribute. 
	The values are returned in <p red>, <p green>, <p blue>.
	@desc Colors set in index mode is automatically converted to RGB values

   @ex |
   mgrec* rec;
   short r, g, b;

   db = mgOpenDb ( "file.flt" );

   // create polygon or mesh record
   rec = UserMakePolyOrMeshRec ( db );

   mgGetPolyColorRGB ( rec, &r, &g, &b );

   @access Level 1
   @see <f mgSetPolyColorRGB>, <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetPolyColorRGB ( 
		mgrec* rec,		// @param the <flt fltPolygon> or <flt fltMesh> record from 
							// which to get the color values.
		short* red,		// @param the red component
		short* green,	// @param the green component
		short* blue		// @param the blue component
		);

/* @func mgbool | mgGetPolyAltColorRGB | gets the alternate RGB color 
	values out of a <flt fltPolygon> or <flt fltMesh> record
	@return Returns <e mgbool.MG_TRUE> if data is stored in the buffer,
	<e mgbool.MG_FALSE> otherwise.

	@desc Given a <flt fltPolygon> or <flt fltMesh> record, <p rec>, this
	function gets the red, green, and blue values of its 
	<flt fltPolyAltColor> attribute.  The values are returned in 
	<p red>, <p green>, <p blue>.
	@desc Colors set in index mode are automatically converted to RGB values.

   @ex |
   mgrec* db;
   mgrec* rec;
   short r, g, b;

   db = mgOpenDb ( "file.flt" );

   // create polygon or Mesh rec
   rec = UserMakePolyOrMeshRec ( db );

   mgGetPolyAltColorRGB ( rec, &r, &g, &b);

   @access Level 1
   @see <f mgSetPolyAltColorRGB>, <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetPolyAltColorRGB ( 
		mgrec* rec,		// @param the <flt fltPolygon> or <flt fltMesh> 
							// record from which to get the color values.
		short* red,		// @param the red component
		short* green,	// @param the green component
		short* blue		// @param the blue component
      );

/* @func mgbool | mgGetVtxColorRGB | gets the RGB color values out of a <flt fltVertex> record
	@return Returns <e mgbool.MG_TRUE> if data is stored in the buffer, <e mgbool.MG_FALSE> otherwise.

	@desc Given a <flt fltVertex> record, <p vtx>, <f mgGetVtxColorRGB> gets the red, green, and blue values of its 
	<flt fltVColor> attribute.  The values are returned in <p red>, <p green>, <p blue>.
	@desc Colors set in index mode are automatically converted to RGB values.

	@access Level 1
	@see <f mgGetVtxColorRGBA>, <f mgSetVtxColorRGB>, <f mgSetVtxColorRGBA>,
	<f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetVtxColorRGB (
		mgrec* vtx,		// @param the <flt fltVertex> record from which to get the color values.
		short* red,		// @param the red component
		short* green,	// @param the green component
		short* blue		// @param the blue component
      );

/* @func mgbool | mgGetVtxColorRGBA | gets the RGBA color values out of a <flt fltVertex> record
	@return Returns <e mgbool.MG_TRUE> if data is stored in the buffer, <e mgbool.MG_FALSE> otherwise.

	@desc Given a <flt fltVertex> record, <p vtx>, <f mgGetVtxColorRGBA> gets the red, green, blue,
	and alpha values of its 
	<flt fltVColor> attribute.  The values are returned in <p red>, <p green>, <p blue>, <p alpha>.
	@desc Colors set in index mode are automatically converted to RGB values.

	@access Level 1
	@see <f mgGetVtxColorRGB>, <f mgSetVtxColorRGB>, <f mgSetVtxColorRGBA>,
	<f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetVtxColorRGBA (
		mgrec* vtx,		// @param the <flt fltVertex> record from which to get the color values.
		short* red,		// @param the red component
		short* green,	// @param the green component
		short* blue,	// @param the blue component
		short* alpha	// @param the alpha component
      );

// @func int | mgGetAttList | gets the values of record attributes using the 
// <f varargs> argument style
//
// @param mgrec* | rec | the record from which to get values
// @param | <lt> att_code <gt> | the attribute record code
// @param | <lt> att_var <gt> | the pointer to the returned attribute value
// @param | ... | the argument list is in pairs of <p att_code> and <p att_var>
// ending with <m MG_NULL> terminator.
//
// @desc Given a record, <p rec>, and a list of attribute code/variable pairs,
// <f mgGetAttList> gets the values of <p rec>'s attributes named by the attribute
// codes and stores them in the corresponding attribute variables.  Note that <p rec>
// must be a proper record and cannot be a value record.
//
// @desc For numeric attribute types (char, short, int, float, double, etc), pass
// the address of the corresponding variable type (char, short, int, float, double, etc). 
// For character string attributes (char*), pass the address of a char* variable
// (initialized to NULL).  In this case <f mgGetAttList> will allocate a dynamic
// memory buffer of type char*, fill this buffer with the character string value
// and return this buffer (now pointed to by your char* variable).  Since this buffer
// is dynamically allocated, you are responsible for deallocating it with <f mgFree>.
// The example below shows this in more detail.
//
// @desc Since variable-length argument lists cannot be type-checked by the compiler, 
// <f varargs> functions can be a source of bugs.  Be sure to end all of your argument
// lists with <m MG_NULL> and be sure that the type of each argument is as expected. 
// Also, when passing the address of variables here, be sure to use variables of the
// exact size expected by the specified attribute codes.  For example, when an attribute
// is of type "short", be sure to pass the address of a "short" variable.  Passing the
// address of an "int" in this case would yield incorrect results.
//
// @desc The expected sizes for all OpenFlight attribute values are shown in the
// OpenFlight Data Dictionary.
//
// @return Returns the number of attribute values successfully retrieved.
//
// @ex |
// // get the material and texture indices from a polygon node
// // both are of type short
//
// mgrec* polyRec;
// short polyTexture;
// short polyMaterial;
// int numAttr;
//
// numAttr = mgGetAttList ( polyRec,
//                fltPolyMaterial, &polyMaterial,
//                fltPolyTexture, &polyTexture,
//                MG_NULL );
// if ( numAttr == 2 )
//    printf ( "success" );
// else
//    printf ( "fail" );
//
// // get the revision number and the date of last revision from a
// // header node - revision number is int and date is character
// // string - note special handling of character strings
//
// mgrec* headerRec;
// int formatRev;
// char* date = MG_NULL;
// int numAttr;
//
// numAttr = mgGetAttList ( headerRec,
//                fltHdrFormatRev, &formatRev,
//                fltHdrLastDate, &date,
//                MG_NULL );
// if ( date ) {
//    // date now points to a character string filled with 
//    // the fltHdrLastDate attribute value - you need to
//    // free the memory when you are done with it !
//    mgFree ( date );
// }
//
// @access Level 1
// @see <f mgSetAttList>
extern MGAPIFUNC(int) mgGetAttList ( mgrec* rec, ... );

/* @func mgbool | mgHasAtt | determines whether an attribute record exists in its parent record
	@desc <f mgHasAtt> checks if an attribute record with code <p rcode> exists in <p parent_rec>
   @return <e mgbool.MG_TRUE> if <p parent_rec> has an atribute record with code <p rcode>; 
   <e mgbool.MG_FALSE> otherwise.
   @access Level 1
*/
extern MGAPIFUNC(mgbool) mgHasAtt ( 
  		mgrec* parent_rec,	// @param the parent record
		mgcode rcode			// @param the attribute record code
  		);

/* @func mgbool | mgGetCoord3d | gets values out of a <flt fltCoord3d> record. 
	@desc Given a record <p rec>, <f mgGetCoord3d> gets the values of <flt fltCoord3d>
	attribute record <p code> from <p rec> and stores them in <p x>, <p y>, 
	and <p z>.  

  	@desc For retrieving vertex coordinates, it is much more efficient to call the
	convenience function <f mgGetVtxCoord>.

   @return <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
   @ex | 
   mgrec* db;
   mgrec* lodRec;
   double x, y, z;

   db = mgOpenDb ( "file.flt" );

   // create lod rec
   lodRec = UserMakeLODRec ( db );

   mgGetCoord3d ( lodRec, fltLodCenterPoint, &x, &y, &z );

   @access Level 1
   @see <f mgGetAttList>, <f mgGetAttBuf>, <f mgGetVtxCoord>
*/
extern MGAPIFUNC(mgbool) mgGetCoord3d ( 
		mgrec* rec,				// @param the record from which to get the <flt fltCoord3d> 
									// attribute record
		mgcode code,			// @param the <flt fltCoord3d> attribute record code
		double* x,				// @param the x component value
		double* y,				// @param the y component value
		double* z				// @param the z component value
		);

#define mgGetIcoord mgGetCoord3d	/* @deprecated mgGetIcoord | Use <f mgGetCoord3d> */

/* @func mgbool | mgGetNormColor | gets values out of a <flt fltNormColor> record
   @desc Given a record, <p rec>, <f mgGetNormColor> gets the values of <flt fltNormColor> attribute 
	record <p normcolorCode> from <p rec> and stores them in <p r>, <p g>, and <p b>.  
	@desc <f mgGetNormColor> retrieves an attribute record, as opposed to an attribute value.  
	Use <f mgGetAttList> to retrieve an attribute value.  

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
   @ex | 
   mgrec* db;
   mgrec* matRec;
   float r, g, b;
   int index;

   db = mgOpenDb ( "file.flt" );
   index = mgGetFirstMaterial ( db, matRec );

   mgGetNormColor ( matRec, fltAmbient, &r, &g, &b );

   @access Level 1
	@see <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetNormColor ( 
		mgrec* rec,					// @param the record from which to get the 
										// <flt fltNormColor> attribute code 
		mgcode normcolorCode,	// @param the <flt fltNormColor> attribute code
		float* r,					// @param the red component value
		float* g,					// @param the green component value
		float* b						// @param the blue component value
		);

/* @func mgbool | mgGetCoord2i | gets values out of a <flt fltCoord2i> record
   @desc Given a record, <p rec>, <f mgGetCoord2i> gets the values of <flt fltCoord2i>
	attribute record <p code> from <p rec> and stores them in <p x> and <p y>.  

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	@ex | 
	mgrec* db;
	mgrec* imgRec;
	int x, y;

	db = mgOpenDb ( "file.flt" );

	// Get image rec

	mgGetCoord2i ( imgRec, fltImgUp, &x, &y );

	@access Level 1
	@see <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetCoord2i ( 
	mgrec* rec,			// @param points to the record from which to get values
	mgcode cde,			// @param the code of the point record to get
	int* x,				// @param address of x coordinate of point to receive
	int* y				// @param address of y coordinate of point to receive
	);

#define mgGetIPoint mgGetCoord2i	/* @deprecated mgGetIPoint | Use <f mgGetCoord2i> */

/* @func mgbool | mgGetColorRGBA | gets values out of a <flt fltColorRGBA> record
   @desc Given a record, <p rec>, <f mgGetColorRGBA> gets the values of <flt fltColorRGBA> attribute 
	record <p colorRgbaCode> from <p rec> and stores them in <p r>, <p g>, <p b> and <p a>.  

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	@ex | 
	mgrec* db;
	mgrec* ltsRec;
	float r, g, b, a;
	int index;

	db = mgOpenDb ( "file.flt" );
	index = mgGetFirstLightSource (db, ltsRec);
	mgGetColorRGBA ( ltsRec, fltLtspAmbient, &r, &g, &b, &a );

	@access Level 1
	@see <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetColorRGBA ( 
		mgrec* rec,					// @param the record from which to get the 
										// <flt fltColorRGBA> attribute code 
		mgcode colorRgbaCode,	// @param the <flt fltColorRGBA> attribute code
		float* r,					// @param the red component value
		float* g,					// @param the green component value
		float* b,					// @param the blue component value
		float* a						// @param the alpha component value
		);

/* @func mgbool | mgGetCoord3f | gets values out of a <flt fltCoord3f> record. 
	@desc Given a record <p rec>, <f mgGetCoord3f> gets the values of <flt fltCoord3f>
	attribute record <p code> from <p rec> and stores them in <p x>, <p y>, 
	and <p z>.  

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgSetCoord3d>, <f mgSetCoord3f>
*/
extern MGAPIFUNC(mgbool) mgGetCoord3f (
		mgrec* rec,				// @param the record from which to get the 
									// <flt fltCoord3f> attribute record
		mgcode code,			// @param the <flt fltCoord3f> attribute record code
		float* x,				// @param the x component value
		float* y,				// @param the y component value
		float* z					// @param the z component value
		);
#define mgGetFCoord mgGetCoord3f	/* @deprecated mgGetFCoord | Use <f mgGetCoord3f> */


/* @func mgbool | mgGetVector | gets values out of a <flt fltVector> record. 
	@desc Given a record <p rec>, <f mgGetVector> gets the values of <flt fltVector>
	attribute record <p vectorCode> from <p rec> and stores them in <p i>, <p j>,
	and <p k>.
	
	@desc For retrieving vertex normals, it is much more efficient to call the
	convenience function <f mgGetVtxNormal>.

   @return Returns <e mgbool.MG_TRUE> if <p vectorCode> is contained in <p rec>
	and its value is found successfully, <e mgbool.MG_FALSE> otherwise.
	@ex | 
	mgrec* eyeRec;
	float i, j, k;

	db = mgOpenDb ( "file.flt" );

	// create eyepoint rec
	eyeRec = UserMakeEyeRec ( db );

	mgGetVector ( eyeRec, fltEyeEyeDir, &i, &j, &k );

	@access Level 1
	@see <f mgGetAttList>, <f mgGetAttBuf>, <f mgGetVtxNormal>
*/
extern MGAPIFUNC(mgbool) mgGetVector (
		mgrec* rec,				// @param the record from which to get the 
									// <flt fltVector> attribute record
		mgcode vectorCode,	// @param the <flt fltVector> attribute record code
		float* i,				// @param the i component value
		float* j,				// @param the j component value
		float* k					// @param the k component value
		);

/* @func mgbool | mgGetVectord | gets values out of a <flt fltVectord> record. 
	@desc Given a record <p rec>, <f mgGetVectord> gets the values of <flt fltVectord>
	attribute record <p vectorCode> from <p rec> and stores them in <p i>, <p j>,
	and <p k>.  

   @return Returns <e mgbool.MG_TRUE> if <p vectorCode> is contained in <p rec>
	and its value is found successfully, <e mgbool.MG_FALSE> otherwise.
	@ex | 
	mgrec* torsionRec;
	double i, j, k;
	
	mgGetVectord ( torsionRec, fltTorsionVector, &i, &j, &k );

	@access Level 1
	@see <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetVectord (
		mgrec* rec,				// @param the record from which to get the 
									// <flt fltVectord> attribute record
		mgcode vectorCode,	// @param the <flt fltVectord> attribute record code
		double* i,				// @param the i component value
		double* j,				// @param the j component value
		double* k				// @param the k component value
		);

/* @func mgbool | mgGetPlane | gets values out of a <flt fltDPlane> record. 
	@desc Given a record <p rec>, <f mgGetPlane> gets the values of <flt fltDPlane>
	attribute record <p planeCode> from <p rec> and stores them in <p a>, <p b>, 
	<p c> and <p d>.  

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	@ex | 
	mgrec* db;
	mgrec* clipRec;
	mgplaned plane;

	db = mgOpenDb ( "file.flt" );

	// create clip rec
	clipRec = UserMakeClipRec ( db );

	mgGetPlane ( clipRec, fltClipPlane0, &plane.a, &plane.b, 
						&plane.c, &plane.d );

	@access Level 1
	@see <f mgGetAttList>, <f mgGetAttBuf>
*/
extern MGAPIFUNC(mgbool) mgGetPlane (
		mgrec* rec,				// @param the record from which to get the 
									// <flt fltDPlane> attribute record
		mgcode planeCode,		// @param the <flt fltDPlane> attribute record code
		double* a,				// @param the a coefficient value
		double* b,				// @param the b coefficient value
		double* c,				// @param the c coefficient value
		double* d				// @param the d coefficient value
		);

/* @func mgbool | mgGetMatrix | gets values out of a <flt fltMatrix> record. 
	@desc Given a record <p rec> which contains a <flt fltMatrix> record identified
	by the record code <p matrixCode>, <f mgGetMatrix> copies the corresponding 
	matrix of <p rec> into <p matrix>.
  
	@desc Note: Memory is not allocated for <p matrix> by this function. 

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> if 
	<p rec> has no such matrix or if otherwise unsuccessful.

	@access Level 1
	@see <f mgSetMatrix>, <f mgHasXform>, <f mgGetXform>, <f mgGetXformType>
*/
extern MGAPIFUNC(mgbool) mgGetMatrix ( 
		mgrec* rec,				// @param a node or record containing a <flt fltMatrix> record
		mgcode matrixCode,	// @param the record code of the <flt fltMatrix> to retrieve
		mgmatrix* matrix		// @param the address of the matrix to receive values
		);

// @doc EXTERNAL SWITCHFUNC
/* @func int | mgGetSwitchMaskCount | gets the number of switch masks defined
	for a <flt fltSwitch> node. 
	@desc <f mgGetSwitchMaskCount> returns the number of masks defined for
	the specified <flt fltSwitch> node <p rec>.

   @return Returns the number of masks defined for <p rec>.  Since 
	all <flt fltSwitch> nodes have at least one mask, the value returned
	by this function will be at least 1. 

	@access Level 1
	@see <f mgGetSwitchMaskNo>, 
	<f mgGetSwitchBit>,
	<f mgGetSwitchMaskName>,
	<f mgAddSwitchMask>,
	<f mgDeleteSwitchMask>,
	<f mgInitSwitchMask>,
	<f mgSetSwitchBit>,
	<f mgSetSwitchMaskName>
*/
extern MGAPIFUNC(int) mgGetSwitchMaskCount ( 
		mgrec* rec // @param the <flt fltSwitch> node
		);

/* @func mgbool | mgGetSwitchMaskNo | gets the current mask index of a 
	<flt fltSwitch> node.
	@desc A <flt fltSwitch> node contains at least one mask.  <f mgGetSwitchMaskNo> 
	returns the mask index currently being used to define the on/off display behavior
	of the switch node�s children.  The first switch mask is 0. The mask index is 
	set to -1 if unsuccessful. 

   @return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgGetSwitchMaskCount>,
	<f mgGetSwitchBit>,
	<f mgGetSwitchMaskName>,
	<f mgAddSwitchMask>,
	<f mgDeleteSwitchMask>,
	<f mgInitSwitchMask>,
	<f mgSetSwitchBit>,
	<f mgSetSwitchMaskName>
*/
extern MGAPIFUNC(mgbool) mgGetSwitchMaskNo ( 
		mgrec* rec,		// @param the <flt fltSwitch> node.
		int* maskNo		// @param address of the output mask number.
		);

/* @func mgbool | mgGetSwitchBit | gets the on/off status of a specific bit 
	within a switch mask.
	@desc Given a <flt fltSwitch> node, <p rec>, <f mgGetSwitchBit> checks 
	if the bit specified by <p bitNo> within the mask <p maskNo> is on or off. 
	The result is returned via <p onFlag>.

	@desc The value of <p bitNo> must be between 0 and the number of
	children of <p rec> minus 1.  The value of <p maskNo> must be between
	0 and the number of masks of <p rec> minus 1.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgGetSwitchMaskCount>,
	<f mgGetSwitchMaskNo>, 
	<f mgGetSwitchMaskName>,
	<f mgAddSwitchMask>,
	<f mgDeleteSwitchMask>,
	<f mgInitSwitchMask>,
	<f mgSetSwitchBit>,
	<f mgSetSwitchMaskName>
*/
extern MGAPIFUNC(mgbool) mgGetSwitchBit ( 
		mgrec* rec,			// @param the <flt fltSwitch> node
		int maskNo,			// @param switch mask number starting from 0
		int bitNo,			// @param bit number starting from 0
		mgbool* onFlag		// @param the return on/off status
		);

/* @func char | mgGetSwitchMaskName | gets the name of a switch mask.
	@desc Given a <flt fltSwitch> node, <p rec>, <f mgGetSwitchMaskName> returns
	the name assigned to the mask <p maskNo>.

	@desc The character string returned is a dynamically allocated copy of 
	the mask name.  It is the responsibility of the caller to deallocate
	this string when it is no longer needed using the function <f mgFree>.

	@return Returns the name of the switch mask if it exists and is named,
	<m MG_NULL> otherwise. 

	@access Level 1
	@see <f mgSetSwitchMaskName>,
	<f mgGetSwitchMaskCount>,
	<f mgGetSwitchMaskNo>, 
	<f mgGetSwitchBit>,
	<f mgAddSwitchMask>,
	<f mgDeleteSwitchMask>,
	<f mgInitSwitchMask>,
	<f mgSetSwitchBit>
*/
extern MGAPIFUNC(char*) mgGetSwitchMaskName ( 
		mgrec* rec,			// @param the <flt fltSwitch> node
		int maskNo			// @param switch mask number starting from 0
		);

/*============================================================================*/

// @doc EXTERNAL MESHFUNC

#define MPRIM_TRI_STRIP				1		// @msg MPRIM_TRI_STRIP | Mesh Primitive Type Triangle Strip
													// @desc This is the mesh primitive type defining a triangle
													// strip.  A triangle strip represents a series of 3-sided
													// polygons (triangles) defined by the vertices of the mesh
													// primitive.  
													// @desc One triangle is defined for each vertex of the
													// primitive after the first two.  For odd n,
													// the nth triangle is defined by vertices n, n+1 and n+2.  
													// For even n, the nth triangle is defined by vertices n+1,
													// n and n+2.
													// @desc If a triangle strip mesh primitive has N vertices,
													// N-2 triangles are defined.
													// @see <f mgMeshPrimitiveGetType>, <f mgMeshPrimitiveGetNumVtx>, 
													// <f mgMeshPrimitiveGetVtxIndexArray>

#define MPRIM_TRI_FAN				2		// @msg MPRIM_TRI_FAN | Mesh Primitive Type Triangle Fan
													// @desc This is the mesh primitive type defining a triangle
													// fan.  A triangle fan represents a series of 3-sided
													// polygons (triangles) defined by the vertices of the mesh
													// primitive.
													// @desc One triangle is defined for each vertex of the
													// primitive after the first two.  For any n,
													// the nth triangle is defined by vertices 1, n+1 and n+2.  
													// @desc If a triangle fan mesh primitive has N vertices,
													// N-2 triangles are defined.
													// @see <f mgMeshPrimitiveGetType>, <f mgMeshPrimitiveGetNumVtx>, 
													// <f mgMeshPrimitiveGetVtxIndexArray>

#define MPRIM_QUAD_STRIP			3		// @msg MPRIM_QUAD_STRIP | Mesh Primitive Type Quadrilateral Strip
													// @desc This is the mesh primitive type defining a quadrilateral
													// strip.  A quadrilateral strip represents a series of 4-sided
													// polygons (quadrilaterals) defined by the vertices of the mesh
													// primitive.
													// @desc One quadrilateral is defined for each pair of vertices
													// after the first pair.  For any n, the nth quadrilateral is
													// defined by vertices 2n-1, 2n, 2n+2 and 2n+1.
													// @desc If a quadrilateral strip mesh primitive has N vertices,
													// N-3 quadrilaterals are defined.
													// @see <f mgMeshPrimitiveGetType>, <f mgMeshPrimitiveGetNumVtx>, 
													// <f mgMeshPrimitiveGetVtxIndexArray>

#define MPRIM_INDEXED_POLY			4		// @msg MPRIM_INDEXED_POLY | Mesh Primitive Type Indexed Poly
													// @desc This is the mesh primitive type defining an indexed
													// polygon.  An indexed polygon represents a single N-sided
													// polygon defined by the vertices of the mesh primitive.
													// @desc One polygon is defined per indexed polygon mesh
													// primitive. If an indexed polygon mesh primitive has N vertices,
													// 1 N-sided polygon is defined.
													// @see <f mgMeshPrimitiveGetType>, <f mgMeshPrimitiveGetNumVtx>, 
													// <f mgMeshPrimitiveGetVtxIndexArray>


#define MMESH_VTXCOORD		0x80000000	// @msg MMESH_VTXCOORD | Mesh Vertex Mask Bit for
													// Vertex Coordinates
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// coordinate position (x,y,z) data.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXCOLOR		0x40000000	// @msg MMESH_VTXCOLOR | Mesh Vertex Mask Bit for
													// Vertex Color Index
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// color index (index, intensity) data.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXCOLORRGB	0x20000000	// @msg MMESH_VTXCOLORRGB | Mesh Vertex Mask Bit for
													// Vertex Color RGB
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain color RGB data.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXNORMAL		0x10000000	// @msg MMESH_VTXNORMAL | Mesh Vertex Mask Bit for
													// Vertex Normal
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain normals.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV0			0x08000000	// @msg MMESH_VTXUV0 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 0 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 0 (base layer).
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV1       0x04000000	// @msg MMESH_VTXUV1 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 1 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 1.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV2       0x02000000	// @msg MMESH_VTXUV2 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 2
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 2.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV3       0x01000000	// @msg MMESH_VTXUV3 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 3 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 3.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV4       0x00800000	// @msg MMESH_VTXUV4 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 4 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 4.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV5       0x00400000	// @msg MMESH_VTXUV5 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 5 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 5.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV6       0x00200000	// @msg MMESH_VTXUV6 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 6 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 6.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

#define MMESH_VTXUV7       0x00100000	// @msg MMESH_VTXUV7 | Mesh Vertex Mask Bit for
													// Texture Coordinates Layer 7 
													// @desc Mesh vertex mask bit indicating that the
													// vertices in a mesh contain
													// texture coordinates for layer 7.
													// @see <f mgMeshGetVtxMask>, <f mgMeshSetVtxMask>,
													// <f mgMeshCreateVtxPool>, <f mgMeshGetVtxOffset>

/* @func void* | mgMeshGetVtxPool | gets the vertex pool for a mesh
	@desc This function retrieves the vertex pool for mesh <p rec>.

	@desc The vertex pool is a packed sequence of values representing the 
	vertex data for a mesh.  The values packed in the vertex pool represent
	vertex coordinates (x,y,z), vertex colors (index/intensity or RGB), vertex
	normals (i,j,k) and vertex texture coordinates (u,v).

	@desc How the vertex data is packed in the vertex pool is dependent on
	the vertex mask of the mesh.  This mask, returned by <f mgMeshGetVtxMask>,
	indicates what kind of data is packed in the	vertex pool.  

  	@desc The following defines the format of the packed data corresponding
	to each Mesh Vertex Mask Bit:

	@desc <m MMESH_VTXCOORD> - 3 8-byte double precision floating point 
	values (24 bytes total) representing the coordinate position
	of the vertex.  The x position is first, then y followed by z.

	@desc <m MMESH_VTXCOLOR> - 1 4-byte integer value representing the
	color index (integer) and intensity (single precision floating point)
	of the vertex.  The color index and intensity of the vertex is encoded
	in this integer value N as follows.  The color index is the result of
	the integer division operation N/128.  This will be an integer
	value in the range 0..1023.  The intensity is the result of the 
	floating point operation (N mod 128.0f)/128.0f.  This will be a
	floating point number in the range 0.0f..1.0f.

	@desc <m MMESH_VTXCOLORRGB> - 3 1-byte unsigned integer values (4 bytes total
	including 1 byte padding) representing the RGB color of the vertex.
	The red component is first, then green followed by blue.

	@desc <m MMESH_VTXNORMAL> - 3 4-byte single precision floating point 
	values (12 bytes total) representing the normal of the vertex. 
	The i component is first, then j followed by k.

	@desc <m MMESH_VTXUV0> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 0 of the vertex. The u component is first followed by v.

	@desc <m MMESH_VTXUV1> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 1 of the vertex.  The u component is first followed by v.

	@desc <m MMESH_VTXUV2> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 2 of the vertex. The u component is first followed by v.

	@desc <m MMESH_VTXUV3> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 3 of the vertex. The u component is first followed by v.

	@desc <m MMESH_VTXUV4> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 4 of the vertex. The u component is first followed by v.

	@desc <m MMESH_VTXUV5> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 5 of the vertex. The u component is first followed by v.

	@desc <m MMESH_VTXUV6> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 6 of the vertex. The u component is first followed by v.

	@desc <m MMESH_VTXUV7> - 2 4-byte single precision floating point 
	values (8 bytes total) representing the texture coordinates for
	layer 7 of the vertex. The u component is first followed by v.
	
	@desc You can extract the data out of the vertex pool using the
	vertex stride and vertex offset values returned by functions 
	<f mgMeshGetVtxStride> and <f mgMeshGetVtxOffset>, respectively.
	Note: This is not the
	recommended technique for extracting data from the vertex
	pool.  Instead, it is much simpler to use the functions
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>,
	<f mgMeshGetVtxNormal> and <f mgMeshGetVtxUV>.

	@return Returns the vertex pool of mesh <p rec> if successful,
	<m MG_NULL> otherwise.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>
*/
extern MGAPIFUNC(void*) mgMeshGetVtxPool (
		mgrec* rec			// @param the <flt fltMesh> node
		);

/* @func unsigned int | mgMeshGetVtxMask | gets the vertex mask for a mesh
	@desc This function retrieves the vertex mask for mesh <p rec>.  The
	vertex mask of a mesh is a bitwise combination of Mesh Vertex Mask Bits
	specifying what kind of data is defined for the vertices in the mesh.
	
	@desc Mesh Vertex Mask Bits include:<nl>
	<m MMESH_VTXCOORD><nl>
	<m MMESH_VTXCOLOR><nl>
	<m MMESH_VTXCOLORRGB><nl>
	<m MMESH_VTXNORMAL><nl>
	<m MMESH_VTXUV0><nl>
	<m MMESH_VTXUV1><nl>
	<m MMESH_VTXUV2><nl>
	<m MMESH_VTXUV3><nl>
	<m MMESH_VTXUV4><nl>
	<m MMESH_VTXUV5><nl>
	<m MMESH_VTXUV6><nl>
	<m MMESH_VTXUV7>

	@return Returns the vertex mask of mesh <p rec> if successful,
	0 otherwise.
	
	@access Level 1
	@see <f mgMeshGetVtxPool>, <f mgMeshGetVtxStride>, <f mgMeshGetVtxOffset>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>, <f mgMeshSetVtxMask>
*/
extern MGAPIFUNC(unsigned int) mgMeshGetVtxMask ( 
		mgrec* rec			// @param the <flt fltMesh> node
		);

/* @func unsigned int | mgMeshGetVtxStride | gets the vertex stride
	for a mesh
	@desc This function retrieves the vertex stride for mesh <p rec>.  
	The vertex stride of a mesh indicates the number of bytes between
	successive vertices in the meshes vertex pool.
	
	@desc You can use this value together with the vertex data offsets
	returned by <f mgMeshGetVtxOffset> to extract data from a meshes
	vertex pool. Note: This is not the
	recommended technique for extracting data from the meshes vertex
	pool.  Instead, it is much simpler to use the functions
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>,
	<f mgMeshGetVtxNormal> and <f mgMeshGetVtxUV>.

	@return Returns the vertex stride of mesh <p rec> if successful,
	0 otherwise.

	@access Level 1
	@see <f mgMeshGetVtxPool>, <f mgMeshGetVtxMask>, <f mgMeshGetVtxOffset>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>
*/
extern MGAPIFUNC(unsigned int) mgMeshGetVtxStride ( 
		mgrec* rec			// @param the <flt fltMesh> node
		);

/* @func int | mgMeshGetVtxOffset | gets the offset for vertex data
	in a mesh
	@desc This function retrieves the offset for the vertex data
	specified by mesh vertex mask bit <p bit> in the vertex pool
	of mesh <p rec>.

	@desc The vertex data offset for a particular kind of data within
	a meshes vertex pool indicates the number of bytes from the start
	of the vertex pool to the first byte of the data in the first
	vertex.

	@desc Use a single Mesh Vertex Mask Bit for <p bit> to specify
	which data you want the offset for:<nl>
	<m MMESH_VTXCOORD>,<nl>
	<m MMESH_VTXCOLOR>,<nl>
	<m MMESH_VTXCOLORRGB>,<nl>
	<m MMESH_VTXNORMAL>,<nl>
	<m MMESH_VTXUV0>,<nl>
	<m MMESH_VTXUV1>,<nl>
	<m MMESH_VTXUV2>,<nl>
	<m MMESH_VTXUV3>,<nl>
	<m MMESH_VTXUV4>,<nl>
	<m MMESH_VTXUV5>,<nl>
	<m MMESH_VTXUV6>, or <nl>
	<m MMESH_VTXUV7>

	@desc You can use the values returned by this function together
	with the vertex stride returned by <f mgMeshGetVtxStride> to
	extract data from a meshes vertex pool.  Note: This is not the
	recommended technique for extracting data from the meshes vertex
	pool.  Instead, it is much simpler to use the functions
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal> and <f mgMeshGetVtxUV>.

	@return Returns the offset for the specified data in the 
	vertex pool of mesh <p rec> if successful, -1 otherwise.
	This function can fail if <p rec> is not a valid mesh node
	or if the vertices in the mesh do not have the data specified
	by <p bit>.

	@access Level 1
	@see <f mgMeshGetVtxPool>, <f mgMeshGetVtxMask>, <f mgMeshGetVtxStride>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>,
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>
*/
extern MGAPIFUNC(int) mgMeshGetVtxOffset ( 
		mgrec* rec,			// @param the <flt fltMesh> node
		unsigned int bit	// @param the mesh vertex mask bit specifying
								// the data to get offset for
		);

/*============================================================================*/

/* @func int | mgMeshPrimitiveGetType | gets the type of a mesh primitive
	@desc This function gets the type for mesh primitive number <p primNo>
	in mesh <p rec>.  A mesh node is composed of one or more mesh primitives.
	Each mesh primitive is one of four types:

	@desc <m MPRIM_TRI_STRIP> - Triangle Strip<nl>
	<m MPRIM_TRI_FAN> - Triangle Fan<nl>
	<m MPRIM_QUAD_STRIP> - Quadrilateral Strip<nl>
	<m MPRIM_INDEXED_POLY> - Indexed Polygon

	@desc The first mesh primitive
	in a mesh is number 0.  The <flt fltMeshNumPrims> attribute of a 
	mesh node specifies how many primitives are contained in the mesh.

	@return Returns the type for mesh primitive <p primNo> if successful, 
	0 otherwise.  This function can fail if <p rec> is
	not a valid mesh node or if <p primNo> does not specify a valid
	mesh primitive number.

	@access Level 1
	@see <flt fltMeshNumPrims>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>
*/
extern MGAPIFUNC(int) mgMeshPrimitiveGetType ( 
		mgrec* rec,			// @param the <flt fltMesh> node
		int primNo			// @param the mesh primitive number starting from 0
		);

/* @func int | mgMeshPrimitiveGetNumVtx | gets the number of vertices
	contained in a mesh primitive
	@desc This function gets the number of vertices contained in mesh
	primitive number <p primNo> in mesh <p rec>.  
	
	@desc The first mesh primitive
	in a mesh is number 0.  The <flt fltMeshNumPrims> attribute of a
	mesh node specifies how many primitives are contained in the mesh.

	@return Returns the number of vertices in mesh primitive <p primNo>
	if successful, -1 otherwise.  This function can fail if <p rec> is
	not a valid mesh node or if <p primNo> does not specify a valid
	mesh primitive number.

	@access Level 1
	@see <flt fltMeshNumPrims>, <f mgMeshPrimitiveGetType>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>
*/
extern MGAPIFUNC(int) mgMeshPrimitiveGetNumVtx ( 
		mgrec* rec,			// @param the <flt fltMesh> node
		int primNo			// @param the mesh primitive number starting from 0
		);

/* @func int | mgMeshPrimitiveGetVtxIndexArray | gets the vertex index
	array for a mesh primitive
	@desc This function gets the vertex index array for mesh primitive
	number <p primNo> in mesh <p rec>.  The vertex index array of a mesh
	primitive is an array of integer values that define the vertex ordering
	of the vertices that make up the mesh primitive.  The integer indices
	in the vertex index array refer to vertices stored in the vertex pool
	of the mesh.
	
	@desc The first vertex in a meshes vertex pool is at index 0.
	The <flt fltMeshNumVtx> attribute of a mesh node specifies how
	many vertices are contained in a meshes vertex pool.  By definition,
	this value is larger than the maximum number of vertex indices
	contained in any primitive of the mesh.

  	@desc If successful, <p indexArray> will be filled with in with
	the indices of the vertices of the mesh primitive.  You must pass
	a buffer for <p indexArray> that is large enough to receive at
	most <p maxLen> integer values.  The actual number of vertex
	indices filled in is the smaller of <p maxLen> and the number
	of vertex indices in the specified mesh primitive.

	@return Returns the number of vertex indices that were filled in
	<p indexArray> if successful, -1 otherwise.  This function can fail
	if <p rec> is not a valid mesh node or if <p primNo> does not specify
	a valid mesh primitive number.

	@access Level 1
	@see <f mgMeshPrimitiveGetType>, <f mgMeshPrimitiveGetNumVtx>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>
*/
extern MGAPIFUNC(int) mgMeshPrimitiveGetVtxIndexArray ( 
		mgrec* rec,			// @param the <flt fltMesh> node
		int primNo,			// @param the mesh primitive number starting from 0
		int* indexArray,	// @param the array to receive the vertex indices
		int maxLen			// @param the maximum number of indices to write 
								// into <p indexArray>
		);

/*============================================================================*/

/* @func mgbool | mgMeshGetVtxCoord | retrieves the x,y,z coordinate for
	a vertex in a mesh.

	@desc This function retrieves the <p x>, <p y>, and <p z> values of the
	vertex at index <p vtxIndex> in the vertex pool of mesh node <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	have coordinate positions.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>, <f mgMeshSetVtxCoord>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxCoord (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		double* x,			// @param address of value to receive x coordinate
		double* y, 			// @param address of value to receive y coordinate
		double* z			// @param address of value to receive z coordinate
		);

/* @func mgbool | mgMeshGetVtxColor | retrieves the color index and 
	intensity values for a vertex in a mesh.

	@desc This function retrieves the color <p index> and <p intensity>
	values of the vertex at index <p vtxIndex> in the vertex pool of mesh
	node <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	color values.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>, <f mgMeshSetVtxColor>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxColor (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		int* index,			// @param address of value to receive color index
		float* intensity	// @param address of value to receive intensity
      );

/* @func mgbool | mgMeshGetVtxColorRGB | retrieves the RGB color values
	for a vertex in a mesh.

	@desc This function retrieves the <p red>, <p green>, and <p blue>
	color values of the vertex at index <p vtxIndex> in the vertex pool of
	mesh node <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	have color values.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>,
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>, 
	<f mgMeshSetVtxColorRGBA>, <f mgMeshSetVtxColorRGB>, <f mgMeshSetVtxColorAlpha>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxColorRGB (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		short* red,			// @param address of value to receive red component
		short* green,		// @param address of value to receive green component
		short* blue			// @param address of value to receive blue component
      );

/* @func mgbool | mgMeshGetVtxColorRGBA | retrieves the RGBA color values
	for a vertex in a mesh.

	@desc This function retrieves the <p red>, <p green>, <p blue>, and 
	<p alpha> color values of the vertex at index <p vtxIndex> in the vertex
	pool of mesh node  <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	have color values.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>,
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>, 
	<f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshSetVtxColorRGBA>, <f mgMeshSetVtxColorRGB>, <f mgMeshSetVtxColorAlpha>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxColorRGBA (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		short* red,			// @param address of value to receive red component
		short* green,		// @param address of value to receive green component
		short* blue,		// @param address of value to receive blue component
		short* alpha		// @param address of value to receive alpha component
      );

/* @func mgbool | mgMeshGetVtxColorAlpha | retrieves the Alpha color value
	for a vertex in a mesh.

	@desc This function retrieves the alpha <p alpha> color value of the
	vertex at index <p vtxIndex> in the vertex pool of mesh node <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	have color values.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshSetVtxColorRGB>, 
	<f mgMeshGetVtxNormal>, <f mgMeshGetVtxUV>,
	<f mgMeshSetVtxColorRGBA>, <f mgMeshSetVtxColorRGB>, <f mgMeshSetVtxColorAlpha>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxColorAlpha (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		short* alpha		// @param address of value to receive alpha component
      );

/* @func mgbool | mgMeshGetVtxNormal | retrieves the normal vector for
	a vertex in a mesh.

	@desc This function retrieves the <p i>, <p j>, and <p k> values of the
	normal vector of the vertex at index <p vtxIndex> in the vertex pool of
	mesh node <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	have normals.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>, 
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxUV>, <f mgMeshSetVtxNormal>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxNormal (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		float* i,			// @param address of value to receive i component of normal vector
		float* j, 			// @param address of value to receive j component of normal vector
		float* k				// @param address of value to receive k component of normal vector
		);

/* @func mgbool | mgMeshGetVtxUV | retrieves the u,v texture coordinate
	for a vertex in a mesh.

	@desc This function retrieves the <p u> and <p v> texture coordinate
	values for layer <p layerNo> of the vertex at index <p vtxIndex> in
	the vertex pool of mesh node <p rec>.
	@desc Note: The first vertex in a meshes vertex pool is at index 0.

	@return Returns <e mgbool.MG_TRUE> if the vertex data was retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.  This function can fail
	if <p rec> is not a valid mesh node, if the vertex at <p vtxIndex>
	does not exist in the mesh, or if the vertices in the mesh do not
	have texture coordinates for layer <p layerNo>.

	@access Level 1
	@see <f mgMeshGetVtxMask>, <f mgMeshPrimitiveGetNumVtx>, 
	<f mgMeshPrimitiveGetVtxIndexArray>,
	<f mgMeshGetVtxCoord>, <f mgMeshGetVtxColor>,
	<f mgMeshGetVtxColorRGBA>, <f mgMeshGetVtxColorRGB>, <f mgMeshGetVtxColorAlpha>, 
	<f mgMeshGetVtxNormal>, <f mgMeshSetVtxUV>
*/
extern MGAPIFUNC(mgbool) mgMeshGetVtxUV (
		mgrec* rec,			// @param the <flt fltMesh> node
		int vtxIndex,		// @param the vertex number in the mesh starting at 0
		int layerNo,		// @param the layer number 0..7
		float* u,			// @param address of value to receive u texture coordinate
		float* v 			// @param address of value to receive v texture coordinate
		);

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */


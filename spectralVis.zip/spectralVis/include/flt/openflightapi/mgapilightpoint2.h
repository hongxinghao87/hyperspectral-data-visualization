/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPILIGHTPOINT2_H_
#define MGAPILIGHTPOINT2_H_
// @doc EXTERNAL LIGHTPOINTFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"
#include "mgapilightpoint1.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgLightPointAnimationSequenceSet | sets the sequence items of
	a light point animation record

	@desc <f mgLightPointAnimationSequenceSet> sets the items of an animation
	sequence of a light point animation record from an array <p sequenceData>. 
	The size of the array is specified by <p n>.  The number of items actually
	set is returned. 

	@return The number of sequence items set.  If successful, this number should
	be equal to the input parameter <p n>.

	@see	<f mgLightPointAnimationSequenceGet>
 
	@access Level 2
*/
MGAPIFUNC(int) mgLightPointAnimationSequenceSet (
	mgrec* lpaRec,														// @param the light point animation record
	mglightpointanimationsequencedata sequenceData[],		// @param the array of sequence records to use to set
	int n																	// @param the number of items in <p sequenceData>
	);

/*============================================================================*/
/*                                                                            */
/*	@func mgrec * | mgNewLightPointAppearance | creates a new entry in the
	light point appearance palette

   @desc <f mgNewLightPointAppearance> creates a new light point appearance 
	palette entry for database <p db>.  The new entry is assigned the specified
	<p name> and returned if created successfully.  The index assigned to the new
	entry is also returned in <p index>.  The attributes of the new entry
	can be set using <f mgSetAttList>.

	@return Returns the light point appearance palette entry record if successful, 
	<m MG_NULL> otherwise.  If successful, the parameter <p index> will contain
	the index of the new entry, otherwise this value is undefined.

	@access Level 2

	@see <f mgGetLightPointAppearance>, 
	<f mgSetLightPointAppearance>,
	<f mgNewLightPointAnimation>
*/
extern MGAPIFUNC(mgrec *) mgNewLightPointAppearance (
	mgrec* db,		// @param the database node
	char* name, 	// @param name to assign to the new light point appearance
	int* index		// @param address of value to receive index assigned to 
						// new entry in the palette
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgDeleteLightPointAppearance | deletes an entry in the light
	point appearance palette

   @desc <f mgDeleteLightPointAppearance> deletes a light point appearance 
	palette entry for database <p db>.  The entry deleted is specified by <p index>.

	@return Returns <e mgbool.MG_TRUE> if the entry was deleted successfully, 
	<e mgbool.MG_FALSE> otherwise.

	@access Level 2

	@see <f mgNewLightPointAppearance>, 
	<f mgGetLightPointAppearance>,
	<f mgDeleteLightPointAnimation>
*/
extern MGAPIFUNC(mgbool) mgDeleteLightPointAppearance (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to delete
	);

/*============================================================================*/
 

/*============================================================================*/
/*                                                                            */
/*	@func mgrec * | mgNewLightPointAnimation | creates a new entry in the
	light point animation palette

   @desc <f mgNewLightPointAnimation> creates a new light point animation 
	palette entry for database <p db>.  The new entry is assigned the specified
	<p name> and returned if created successfully.  The index assigned to the new
	entry is also returned in <p index>.  The attributes of the new entry
	can be set using <f mgSetAttList>.

	@return Returns the light point animation palette entry record if successful, 
	<m MG_NULL> otherwise.  If successful, the parameter <p index> will contain
	the index of the new entry, otherwise this value is undefined.

	@access Level 2

	@see <f mgGetLightPointAnimation>, 
	<f mgSetLightPointAnimation>,
	<f mgNewLightPointAppearance>
*/
extern MGAPIFUNC(mgrec *) mgNewLightPointAnimation (
	mgrec* db,		// @param the database node
	char* name, 	// @param name to assign to the new light point animation
	int* index		// @param address of value to receive index assigned to 
						// new entry in the palette
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgDeleteLightPointAnimation | deletes an entry in the light
	point animation palette

   @desc <f mgDeleteLightPointAnimation> deletes a light point animation 
	palette entry for database <p db>.  The entry deleted is specified by <p index>.

	@return Returns <e mgbool.MG_TRUE> if the entry was deleted successfully, 
	<e mgbool.MG_FALSE> otherwise. 

	@access Level 2

	@see <f mgNewLightPointAnimation>, 
	<f mgGetLightPointAnimation>,
	<f mgDeleteLightPointAppearance>
*/
extern MGAPIFUNC(mgbool) mgDeleteLightPointAnimation (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to delete
	);

/*============================================================================*/
 
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgWriteLightPointFile | writes a database�s light point
	appearance and animation palettes as a disk file
	@desc Given a database node, <p db>, <f mgWriteLightPointFile> 
	writes the database�s light point appearance and animation palettes
	to disk with the file name <p fileName>.  

	@desc Note that even though the light point appearance and animation palettes
	are really separate, this function, as well as <f mgReadLightPointFile> groups
	the entries in both into one single file.

	@return Returns <e mgbool.MG_TRUE> if the light point appearance
	file was written successfully, otherwise <e mgbool.MG_FALSE>. 

  	@see <f mgReadLightPointFile>

	@access Level 2
*/
extern MGAPIFUNC(mgbool) mgWriteLightPointFile (
		mgrec* db,			// @param the database node that contains the light
								// point appearance and animation palettes to write
		char* fileName		// @param the light point palette file name
		);

/*============================================================================*/


/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

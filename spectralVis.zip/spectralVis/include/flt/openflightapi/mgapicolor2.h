/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPICOLOR2_H_
#define MGAPICOLOR2_H_
/* @doc EXTERNAL COLORFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgNewColorName | adds a name to a color palette 
	entry�s name list.
	@desc Given a database node, <p db>, and an index into the color palette, 
	<p index>, <f mgNewColorName> adds the color name <p name> to the color 
	name list for <p index>.  It is assumed that <p name> is not already in 
	the color name list of any index, therefore no search is performed.

   @desc Color palette entries can have multiple names assigned, one of which
	is the "current" name for that entry.  The current name of a color palette
	entry is not assigned by default.  You must explicitly call 
	<f mgSetCurrentColorName> to set the current name for a color
	palette entry.
	
	@param mgrec * | db_rec | the database node
	@param int | index |	the color palette index
	@param char * | name | the name to add to the name list of <p index>

	@return Returns <e mgbool.MG_TRUE> if the name was successfully added 
	to the name table, otherwise returns <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgDeleteColorName>, <f mgSetCurrentColorName>
*/
extern MGAPIFUNC(mgbool) mgNewColorName ( mgrec* db_rec, int index, char *name );
/* add new name to index's name list; assuming that name is not in any index's */
/* name list already. */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgDeleteColorName | deletes a name from a color 
	palette entry�s color name list.
	@desc Given a database node, <p db>, and an index into the color palette, 
	<p index>, <f mgDeleteColorName> deletes the color name <p name> from 
	the color name list for <p index>.  
	An index of -1 means "search the entire color palette."

	@param mgrec * | db_rec | the database node
	@param int | index |	the color palette index, or -1 for the entire palette 
	@param char * | name | the color name to delete from the entry�s name list

	@return Returns <e mgbool.MG_TRUE> if the name was successfully deleted from the 
	name list, otherwise returns <e mgbool.MG_FALSE> 

	@access Level 2
	@see <f mgNewColorName>, <f mgSetCurrentColorName>, <f mgGetColorIndexByName>
*/
extern MGAPIFUNC(mgbool) mgDeleteColorName ( mgrec* db_rec, int index, char *name );
/* remove name from index's name list; index = -1 means to search entire palette */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetCurrentColorName | sets the current name of a 
	particular color palette entry.
	@desc Each color palette entry can have a list of names associated with it.  
	One of these names is always the current name for that entry.  
	Given a database node, <p db>, and an index of a color palette entry, 
	<p index>, <f mgSetCurrentColorName> sets the current name of the given 
	color index to <p name>. An index of -1 causes the routine to search 
	the color name table for <p name>, and make it the current name for it�s 
	own index.

	@param mgrec * | db_rec | the database node
	@param int | index |	the index in the color palette, 
	-1 to search the name symbol table 
	@param char * | name | the current name for the given color palette entry

	@return Returns <e mgbool.MG_TRUE> on success, otherwise returns <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgDeleteColorName>, <f mgNewColorName>, <f mgGetCurrentColorName>
*/
extern MGAPIFUNC(mgbool) mgSetCurrentColorName ( mgrec* db_rec, int index, char *name );
/* set current name from given index and name; index = -1 means to search from name symbol table */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetPolyColorName | sets the color name of a 
	<flt fltPolygon> record.
	@desc Given a <flt fltPolygon> record, <p polyrec>, and a string, <p name>, 
	<f mgSetPolyColorName> stores <p name> as the color name for the 
	<flt fltPolygon> record. If the name given is not in the color palette, 
	<f mgSetPolyColorName> returns <e mgbool.MG_FALSE>.

	@param mgrec * | polyrec | a <flt fltPolygon> record
	@param char * | name | the color name

	@return Returns <e mgbool.MG_TRUE> on success, otherwise returns <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgGetPolyColorName>, <f mgNewColorName>
*/
extern MGAPIFUNC(mgbool) mgSetPolyColorName ( mgrec* polyrec, char *name );
/* set the color name and index of a polygon (name must already be in the color palette) */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetPolyAltColorName | sets the alternate color name 
	of a <flt fltPolygon> record.
	@desc Given a <flt fltPolygon> record, <p polyrec>, and a string, <p name>, 
	<f mgSetPolyAltColorName> stores <p name> as the alternate color name for the 
	<flt fltPolygon> record. If the name given is not in the color palette, 
	<f mgSetPolyAltColorName> returns <e mgbool.MG_FALSE>.

	@param mgrec * | polyrec | a <flt fltPolygon> record
	@param char * | name | the alternate color name

	@return Returns <e mgbool.MG_TRUE> on success, otherwise returns <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgGetPolyAltColorName>, <f mgNewColorName>
*/
extern MGAPIFUNC(mgbool) mgSetPolyAltColorName ( mgrec* polyrec, char *name );
/* set the alt color name and index of a polygon (name must already be in the color palette) */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func  mgbool | mgWriteDefaultColorPalette | writes the default 
	color palette as a file on disk.
	@desc Given a color file name, <p fileName>, <f mgWriteDefaultColorPalette> 
	writes the default color palette to disk with this fileName.

	@param char * | fileName | the color file name

	@return Returns <e mgbool.MG_TRUE> if the file was written successfully, 
	otherwise returns <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgReadColorPalette>, <f mgReadDefaultColorPalette>, <f mgWriteColorPalette>
*/
extern MGAPIFUNC(mgbool) mgWriteDefaultColorPalette ( char *fileName );
/* writes default color palette to disk */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgWriteColorPalette | writes a database�s color 
	palette as a file on disk.
	@desc Given a database node <p db>, and color file name <p fileName>, 
	writes the database�s color palette to disk as a text file.

	@param mgrec * | db_rec | the database node which contains the color 
	palette to write
	@param char * | fileName | the color file name

	@return Returns <e mgbool.MG_TRUE> if the file was written successfully, 
	otherwise returns <e mgbool.MG_FALSE>. 

	@access Level 2
	@see <f mgReadColorPalette>, <f mgReadDefaultColorPalette>, 
	<f mgWriteDefaultColorPalette>
*/
extern MGAPIFUNC(mgbool) mgWriteColorPalette ( mgrec* db_rec, char *fileName );
/* writes database's current color palette to disk */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetColorIndex | sets a color palette entry to the 
	given red, green, and blue values.
	@desc Given a database node <p db>, a color palette index <p index>, 
	and red, green and blue values <p r>, <p g>, and <p b>, 
	<p mgSetColorIndex> sets the color of the given index in the 
	database�s color palette. 

	@param mgrec * | db_rec | the database node
	@param int | index |	the color palette index to change 
	@param short | r |	the red value, which ranges from 0 to 255  
	@param short | g |	the green value, which ranges from 0 to 255  
	@param short | b |	the blue value, which ranges from 0 to 255  

	@return Returns <e mgbool.MG_TRUE> if db contains a valid database, 
	otherwise returns <e mgbool.MG_FALSE>.

	@access Level 2
	@see <f mgRGB2Index>, <f mgGetColorIndexByName>
*/
extern MGAPIFUNC(mgbool) mgSetColorIndex ( mgrec *db, int index, short r, short g, short b );
/* assigns rgb values to color index in the color palette for db */
/*                                                                            */
/*============================================================================*/


/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

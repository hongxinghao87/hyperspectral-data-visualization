/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef _MGAPIMATRIX_H
#define _MGAPIMATRIX_H
// @doc EXTERNAL 
/*----------------------------------------------------------------------------*/

// @type mgmatrix | a double precision 4 x 4 matrix used for transformations
typedef double mgmatrix  [16];
// docced deprecated comment in mgapi_obsolete.h
typedef mgmatrix mgMatrix;

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

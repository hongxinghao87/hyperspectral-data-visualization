/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIUTIL1_H_
#define MGAPIUTIL1_H_
// @doc EXTERNAL ATTRIBUTEFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgGetPolyNormal | retrieves the normal vector from a 
	polygon record.

	@desc <f mgGetPolyNormal> retrieves the <p i>, <p j>, and <p k> values of the 
	polygon normal vector from a polygon record <p rec>.  

	@return <e mgbool.MG_TRUE> if the polygon has a normal vector,
	<e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgGetVtxNormal>
*/
extern MGAPIFUNC(mgbool) mgGetPolyNormal (
	mgrec* rec,		// @param a polygon record
	double* i,		// @param address of value to receive i component of normal vector
	double* j, 		// @param address of value to receive j component of normal vector
	double* k		// @param address of value to receive k component of normal vector
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgIsPolyConcave | determines if a polygon 
	is concave.

	@desc Given the <flt fltPolygon> record <p poly>, <f mgIsPolyConcave> determines 
	if this polygon is concave.  If any line on the plane of the polygon  
	crosses more than two edges of the polygon, then the polygon is concave.  

	@return Returns <e mgbool.MG_TRUE> if the polygon is concave,
	<e mgbool.MG_FALSE> otherwise.

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgIsPolyConcave (
	mgrec* rec		// @param a polygon record
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgGetVtxNormal | retrieves the normal vector from a 
	vertex record.

	@desc <f mgGetVtxNormal> retrieves the <p i>, <p j>, and <p k> values of the 
	vertex normal vector from a vertex record <p rec>.  

	@return Returns <e mgbool.MG_TRUE> if the vertex has a normal vector,
	<e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgGetPolyNormal>
*/
extern MGAPIFUNC(mgbool) mgGetVtxNormal (
	mgrec* rec,			// @param a vertex record
	float *i,			// @param address of value to receive i component of normal vector
	float *j, 			// @param address of value to receive j component of normal vector
	float *k				// @param address of value to receive k component of normal vector
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/*	@func mgbool | mgGetVtxCoord | retrieves the x,y,z coordinate from a 
	vertex record.

	@desc <f mgGetVtxCoord> retrieves the <p x>, <p y>, and <p z> values of the 
	vertex coordinate from a vertex record <p rec>.  

	@return Returns <e mgbool.MG_TRUE> if the coordinate values were retrieved 
	successfully, <e mgbool.MG_FALSE> otherwise.

	@access Level 1
	@see <f mgSetVtxCoord>, <f mgGetCoord3d>
*/
extern MGAPIFUNC(mgbool) mgGetVtxCoord (
	mgrec* rec,			// @param a vertex record
	double *x,			// @param address of value to receive x coordinate
	double *y, 			// @param address of value to receive y coordinate
	double *z			// @param address of value to receive z coordinate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

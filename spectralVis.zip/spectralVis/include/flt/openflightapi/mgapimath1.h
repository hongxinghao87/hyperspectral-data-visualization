/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIMATH1_H_
#define MGAPIMATH1_H_

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"
#include "mgapicoord.h"
#include "mgapimatrix.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

	
/*============================================================================*/
/* @doc EXTERNAL GEOMETRYFUNC */
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReversePoly | Reverses the order of the vertices in a polygon.

	@desc <f mgReversePoly> reverses the order of the vertices in the specified
	polygon <p poly>.  This has the effect of reversing which side of the polygon
	is considered the "front".

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.  If successful, the vertices of <p poly>
	will be in the reverse order after the function completes, otherwise
	the vertex order will be unchanged.

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgReversePoly (
	mgrec* poly				// @param the polygon whose vertices are to be reversed
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgTransformCoord | transforms a coordinate using
	a specified matrix.

	@desc <f mgTransformCoord> applies the specified <p matrix> to the
	specified 3D double precision floating point coordinate <p coord> and
	returns the resulting coordinate.

	@desc The original coordinate <p coord> is not affected.

	@return Returns the transformed double precision 3D coordinate record.

	@see <t mgcoord3d>, <t mgmatrix>, <f mgTransformVector>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord3d) mgTransformCoord (
	mgmatrix matrix,			// @param the matrix to apply to <p coord>
	mgcoord3d* coord			// @param the coordinate to transform
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgvectord | mgTransformVector | transforms a vector using
	a specified matrix.

	@desc <f mgTransformVector> applies the specified <p matrix> to the
	specified double precision floating point vector <p v> and
	returns the resulting vector.

	@desc The original vector <p v> is not affected.

	@return Returns the transformed double precision vector record.

	@see <t mgvectord>, <t mgmatrix>, <f mgTransformCoord>

	@access Level 1
*/
extern MGAPIFUNC(mgvectord) mgTransformVector (
	mgmatrix matrix,			// @param the matrix to apply to <p v>
	mgvectord* v				// @param the vector to transform
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgAddCoord | calculates the sum of
	two 3D coordinates.

	@desc <f mgAddCoord> calculates the sum of two 3D double
	precision floating point coordinates, <p coord1> + <p coord2>.

	@desc The original coordinates <p coord1> and <p coord2> are
	not affected.

	@return Returns a double precision 3D coordinate record.

	@see <t mgcoord3d>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord3d) mgAddCoord (
	mgcoord3d* coord1,			// @param address of first coordinate to add
	mgcoord3d* coord2				// @param address of second coordinate to add
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/*                                                                            */
/* @func mgvectord | mgVectorFromLine | makes a vector from a line record.

	@desc <f mgVectorFromLine> returns a double precision vector record
	representing the vector from the first coordinate to the second coordinate
	of the specified line record, <p line>.

	@desc The original line record <p line> is not affected.  The resulting
	vector is not unitized.

	@return Returns double precision vector record.

	@see <t mglined>, <t mgvectord>

	@access Level 1
*/
extern MGAPIFUNC(mgvectord) mgVectorFromLine (
	mglined* line					// @param the line used to derive vector 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgUnitizeVector | unitize a vector.

	@desc <f mgUnitizeVector> uses the specified double precision
	vector record <p v>.

	@desc This function changes the components of the vector passed 
	directly. 

	@see <t mgvectord>

	@access Level 1
*/
extern MGAPIFUNC(void) mgUnitizeVector (
	mgvectord* v					// @param address of vector to unitize.
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func double | mgDistance | calculates the distance between two
	3D coordinates.

	@desc <f mgDistance> calculates the distance between two 3D double
	precision floating point coordinates, <p coord1> and <p coord2>.

	@desc The original coordinates <p coord1> and <p coord2> are
	not affected.

	@return Returns a double precision floating point value.

	@see <t mgcoord3d>

	@access Level 1
*/
extern MGAPIFUNC(double) mgDistance (
	mgcoord3d* coord1,		// @param address of first coordinate
	mgcoord3d* coord2			// @param address of second coordinate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3f | mgMakeCoord3f | makes a 3 dimensional single precision
	floating point coordinate from individual values.

	@desc <f mgMakeCoord3f> returns a 3 dimensional single precision
	floating point record representing the coordinate whose X, Y and Z
	values are <p x>, <p y> and <p z>, respectively.

	@return Returns a 3 dimensional single precision floating point coordinate
	record.

	@see <t mgcoord3f>, <f mgMakeCoord3d>, <f mgMakeCoord2d>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord3f) mgMakeCoord3f (
	float x,				// @param the X value for the coordinate
	float y,				// @param the Y value for the coordinate
	float z				// @param the Z value for the coordinate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgMakeCoord3d | makes a 3 dimensional double precision
	floating point coordinate from individual values.

	@desc <f mgMakeCoord3d> returns a 3 dimensional double precision
	floating point record representing the coordinate whose X, Y and Z
	values are <p x>, <p y> and <p z>, respectively.

	@return Returns a 3 dimensional double precision floating point coordinate
	record.

	@see <t mgcoord3d>, <f mgMakeCoord2d>, <f mgMakeCoord3f>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord3d) mgMakeCoord3d (
	double x,			// @param the X value for the coordinate
	double y,			// @param the Y value for the coordinate
	double z				// @param the Z value for the coordinate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord2d | mgMakeCoord2d | makes a 2 dimensional double precision
	floating point coordinate from individual values.

	@desc <f mgMakeCoord3d> returns a 2 dimensional double precision
	floating point record representing the coordinate whose X and Y values
	are <p x> and <p y>, respectively.

	@return Returns a 2 dimensional double precision floating point coordinate
	record.

	@see <t mgcoord2d>, <f mgMakeCoord3d>, <f mgMakeCoord3f>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord2d) mgMakeCoord2d (
	double x,			// @param the X value for the coordinate
	double y				// @param the Y value for the coordinate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord2i | mgMakeCoord2i | makes a 2 dimensional integer
	coordinate from individual values.

	@desc <f mgMakeCoord3d> returns a 2 dimensional integer record representing
	the coordinate whose X and Y values are <p x> and <p y>, respectively.

	@return Returns a 2 dimensional integer coordinate
	record.

	@see <t mgcoord2i>, <f mgMakeCoord3d>, <f mgMakeCoord2d>, <f mgMakeCoord3f>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord2i) mgMakeCoord2i (
	int x,				// @param the X value for the coordinate
	int y					// @param the Y value for the coordinate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgvectord | mgMakeVector | makes a vector from two points.

	@desc <f mgMakeVector> returns a double precision vector record
	representing the vector from <p coord1> to <p coord2>.

	@desc The original coordinates <p coord1> and <p coord2> are not affected.
	@return Returns a double precision vector record.  If either <p coord1> 
	or <p coord2> are <m MG_NULL>, the vector returned by this function 
	is undefined.

	@see <t mgvectord>, <f mgMakeUnitVector>

	@access Level 1
*/
extern MGAPIFUNC(mgvectord) mgMakeVector (
	mgcoord3d* coord1,		// @param address of first coordinate that defines the vector
	mgcoord3d* coord2			// @param address of second coordinate that defines the vector
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgvectord | mgMakeUnitVector | makes a unitized vector from two points.

	@desc Like <f mgMakeVector>, <f mgMakeUnitVector> returns a double precision
	vector record representing the vector from <p coord1> to <p coord2>.  The
	vector returned by this function, however, is unitized.

	@desc The original coordinates <p coord1> and <p coord2> are not affected.
	@return Returns a unitized double precision vector record.  If either <p coord1> 
	or <p coord2> are <m MG_NULL>, the vector returned by this function 
	is undefined.

	@see <t mgvectord>, <f mgMakeVector>

	@access Level 1
*/
extern MGAPIFUNC(mgvectord) mgMakeUnitVector (
	mgcoord3d* coord1,		// @param address of first coordinate that defines the vector
	mgcoord3d* coord2			// @param address of second coordinate that defines the vector
	);
/*                                                                            */
/*============================================================================*/

/* @deprecated mgCrossProdVector | Use <f mgVectorCross> */
extern MGAPIFUNC(mgvectord) mgCrossProdVector (
	mgvectord* vector1,
	mgvectord* vector2
	);

/*============================================================================*/
/*                                                                            */
/* @func mgvectord | mgVectorCross | calculates the cross product of
	two vectors.

	@desc <f mgVectorCross> calculates and returns a double precision
	vector record representing the cross product of the two vectors 
	<p vector1> x <p vector2>.

	@desc The original vectors <p vector1> and <p vector2> are
	not affected.
	@return Returns a double precision vector record (<p vector1> x <p vector2>).

	@see <t mgVectorDot>

	@access Level 1
*/
extern MGAPIFUNC(mgvectord) mgVectorCross (
	mgvectord* vector1,		// @param address of first vector
	mgvectord* vector2		// @param address of second vector
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func double | mgVectorDot | calculates the dot product of
	two vectors.

	@desc <f mgVectorDot> calculates and returns the dot product of
	the two vectors <p vector1> DOT <p vector2>.

	@desc The original vectors <p vector1> and <p vector2> are not affected.
	@return Returns a double precision floating point value (<p vector1> DOT <p vector2>).

	@see <t mgVectorCross>

	@access Level 1
*/
extern MGAPIFUNC(double) mgVectorDot (
	mgvectord* vector1,		// @param address of first vector
	mgvectord* vector2		// @param address of second vector
	);
/*                                                                            */
/*============================================================================*/

// @type mgmatrixstack | An opaque pointer type used to represent a matrix stack
//	@see <t mgmatrix>, <f mgFreeMatrixStack>, 
//	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
//	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
//	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
//	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
//	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
//	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>
typedef void* mgmatrixstack;

/*============================================================================*/
/* @doc EXTERNAL MATRIXFUNC */
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormRotate | forms a rotation matrix for rotation
	about a vector.

	@desc <f mgMatrixFormRotate> calculates a rotation matrix for rotation
	about a vector specified as direction cosines.

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameters <p a>, <p b>, and <p c> (direction cosines) are the 
	unitized components of a vector about which the rotation is applied.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormTranslate>, <f mgMatrixFormScale>, 
	<f mgMatrixFormRotateX>, 
	<f mgMatrixFormRotateY>, <f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormRotate (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	double theta,				// @param angle to rotate measured counter-clockwise
									// in degrees about vector (right hand rule) 
	double a,					// @param the unitized x component of vector
	double b,					// @param the unitized y component of vector
	double c						// @param the unitized z component of vector
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormRotateX | forms a rotation matrix for rotation
	about the X axis.

	@desc <f mgMatrixFormRotateX> calculates a rotation matrix for rotation
	about the X axis.

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormTranslate>, <f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>,
	<f mgMatrixFormRotateY>, <f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormRotateX (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	double theta				// @param angle to rotate measured counter-clockwise
									// in degrees about X axis (right hand rule) 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixRotateX | multiply an X-axis rotation matrix
	into the given matrix.

	@desc <f mgMatrixRotateX> calculates a rotation matrix for rotation
	about the X axis and multiplies that matrix into the given matrix
	<p matrix>.

	@desc Call the rotation matrix representing the rotation of <p theta>
	degrees about the X coordinate axis <p R>.  Call the value (on input)
	of <p matrix> <p M>.  The resulting matrix will be the product 
	<p R> X <p M> and will be stored in the output parameter, <p resultMatrix>.
	This function operates safely when the input and output matrices
	are the same matrix.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE>
	otherwise.  If successful, the output parameter <p resultMatrix> will
	contain the resulting matrix as described above, otherwise it is undefined.

	@see <f mgMatrixFormTranslate>,
	<f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>,
	<f mgMatrixFormRotateY>,
	<f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixRotateX (
	mgmatrix matrix,			// @param the matrix to multiply
	double theta,				// @param angle to rotate measured counter-clockwise
									// in degrees about X axis (right hand rule) 
	mgmatrix* resultMatrix	// @param the address of matrix to receive resulting matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormRotateY | forms a rotation matrix for rotation
	about the Y axis.

	@desc <f mgMatrixFormRotateY> calculates a rotation matrix for rotation
	about the Y axis.

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormTranslate>, <f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>, <f mgMatrixFormRotateX>, 
	<f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormRotateY (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	double theta				// @param angle to rotate measured counter-clockwise
									// in degrees about Y axis (right hand rule) 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixRotateY | multiply an Y-axis rotation matrix
	into the given matrix.

	@desc <f mgMatrixRotateY> calculates a rotation matrix for rotation
	about the Y axis and multiplies that matrix into the given matrix
	<p matrix>.

	@desc Call the rotation matrix representing the rotation of <p theta>
	degrees about the Y coordinate axis <p R>.  Call the value (on input)
	of <p matrix> <p M>.  The resulting matrix will be the product 
	<p R> X <p M> and will be stored in the output parameter, <p resultMatrix>.
	This function operates safely when the input and output matrices
	are the same matrix.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE>
	otherwise.  If successful, the output parameter <p resultMatrix> will
	contain the resulting matrix as described above, otherwise it is undefined.

	@see <f mgMatrixFormTranslate>,
	<f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>,
	<f mgMatrixFormRotateY>,
	<f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixRotateY (
	mgmatrix matrix,			// @param the matrix to multiply
	double theta,				// @param angle to rotate measured counter-clockwise
									// in degrees about Y axis (right hand rule) 
	mgmatrix* resultMatrix	// @param the address of matrix to receive resulting matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormRotateZ | forms a rotation matrix for rotation
	about the Z axis.

	@desc <f mgMatrixFormRotateZ> calculates a rotation matrix for rotation
	about the Z axis.

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormTranslate>, <f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>, <f mgMatrixFormRotateX>, 
	<f mgMatrixFormRotateY>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormRotateZ (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	double theta				// @param angle to rotate measured counter-clockwise
									// in degrees about Z axis (right hand rule) 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixRotateZ | multiply an Z-axis rotation matrix
	into the given matrix.

	@desc <f mgMatrixRotateZ> calculates a rotation matrix for rotation
	about the Z axis and multiplies that matrix into the given matrix
	<p matrix>.

	@desc Call the rotation matrix representing the rotation of <p theta>
	degrees about the Z coordinate axis <p R>.  Call the value (on input)
	of <p matrix> <p M>.  The resulting matrix will be the product 
	<p R> X <p M> and will be stored in the output parameter, <p resultMatrix>.
	This function operates safely when the input and output matrices
	are the same matrix.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE>
	otherwise.  If successful, the output parameter <p resultMatrix> will
	contain the resulting matrix as described above, otherwise it is undefined.

	@see <f mgMatrixFormTranslate>,
	<f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>,
	<f mgMatrixFormRotateY>,
	<f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixRotateZ (
	mgmatrix matrix,			// @param the matrix to multiply
	double theta,				// @param angle to rotate measured counter-clockwise
									// in degrees about Z axis (right hand rule) 
	mgmatrix* resultMatrix	// @param the address of matrix to receive resulting matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormScale | forms a scale matrix.

	@desc <f mgMatrixFormScale> calculates a scale matrix for scaling about
	a local origin (0.0, 0.0, 0.0).

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameters <p x>, <p y>, and <p z> are the scale factors to
	apply along the coordinate axes, X, Y, and Z, respectively.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormTranslate>,
	<f mgMatrixFormRotate>, <f mgMatrixFormRotateX>, 
	<f mgMatrixFormRotateY>, <f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormScale (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	double x,					// @param the scale factor in the X direction
	double y,					// @param the scale factor in the Y direction
	double z						// @param the scale factor in the Z direction
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixScale | multiply a scale matrix into the given matrix.

	@desc <f mgMatrixScale> calculates a scale matrix for scaling about
	a local origin (0.0, 0.0, 0.0) and multiplies that matrix into the
	given matrix <p matrix>.

	@desc Call the scale matrix representing the scale by <p x>, <p y> and <p z>
	along the coordinate axes X, Y and Z, respectively, <p S>.  Call the value
	(on input) of <p matrix> <p M>.  The resulting matrix will be the product 
	<p S> X <p M> and will be stored in the output parameter, <p resultMatrix>.
	This function operates safely when the input and output matrices
	are the same matrix.

	@desc The resulting matrix is filled in the output parameter, <p resultMatrix>.
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix
	as described above, otherwise it is undefined.

	@see <f mgMatrixFormTranslate>,
	<f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>,
	<f mgMatrixFormRotateY>,
	<f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixScale (
	mgmatrix matrix,			// @param the matrix to multiply
	double x,					// @param the scale factor in the X direction
	double y,					// @param the scale factor in the Y direction
	double z,					// @param the scale factor in the Z direction
	mgmatrix* resultMatrix	// @param the address of matrix to receive resulting matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormTranslate | forms a translation matrix.

	@desc <f mgMatrixFormTranslate> calculates a translation matrix for 
	translating along the coordinate axes X, Y and Z.

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameters <p x>, <p y>, and <p z> are the translation values to
	apply along the coordinate axes, X, Y, and Z, respectively.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>, <f mgMatrixFormRotateX>, 
	<f mgMatrixFormRotateY>, <f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormTranslate (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	double x,					// @param the translation in the X direction
	double y,					// @param the translation in the Y direction
	double z						// @param the translation in the Z direction
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixTranslate | multiply a translation matrix into the
	given matrix.

	@desc <f mgMatrixTranslate> calculates a translation matrix for translating by
	<p x>, <p y> and <p z> and multiplies that matrix into the given matrix <p matrix>.

	@desc Call the translation matrix representing the translations <p x>, <p y> and <p z>
	along the coordinate axes X, Y and Z, respectively, <p T>.  Call the value
	(on input) of <p matrix> <p M>.  The resulting matrix will be the product 
	<p T> X <p M> and will be stored in the output parameter, <p resultMatrix>.
	This function operates safely when the input and output matrices
	are the same matrix.

	@desc The resulting matrix is filled in the output parameter, <p resultMatrix>.
	
	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix
	as described above, otherwise it is undefined.

	@see <f mgMatrixFormTranslate>,
	<f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>,
	<f mgMatrixFormRotateY>,
	<f mgMatrixFormRotateZ>,
	<f mgMatrixFormQuadToQuad>, <f mgMatrixMultiply>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixTranslate (
	mgmatrix matrix,			// @param the matrix to multiply
	double x,					// @param the translation in the X direction
	double y,					// @param the translation in the Y direction
	double z,					// @param the translation in the Z direction
	mgmatrix* resultMatrix	// @param the address of matrix to receive resulting matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixFormQuadToQuad | forms a "quad to quad" transformation
	matrix.

	@desc <f mgMatrixFormQuadToQuad> calculates a transformation matrix that 
	transforms one quadrilateral to another.  The "from" quadrilateral is
	specified by four points, <p from1>, <p from2>, <p from3> and <p from4>.
	Similarly, the "to" quadrilateral is specified by <p to1>, <p to2>, <p to3> 
	and <p to4>.

	@desc The resulting matrix is filled in the output parameter, <p matrix>.
	@desc The parameters <p x>, <p y>, and <p z> are the translation values to
	apply along the coordinate axes, X, Y, and Z, respectively.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the resulting matrix,
	otherwise it is undefined.

	@see <f mgMatrixFormTranslate>, <f mgMatrixFormScale>, 
	<f mgMatrixFormRotate>, <f mgMatrixFormRotateX>, 
	<f mgMatrixFormRotateY>, <f mgMatrixFormRotateZ>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>,
	<f mgMatrixMultiply>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixFormQuadToQuad (
	mgmatrix* matrix,			// @param address of matrix to receive resulting matrix
	mgcoord3d* from1,			// @param the first point of the "from" quadrilateral
	mgcoord3d* from2,			// @param the second point of the "from" quadrilateral
	mgcoord3d* from3,			// @param the third point of the "from" quadrilateral
	mgcoord3d* from4,			// @param the third point of the "from" quadrilateral
	mgcoord3d* to1,			// @param the first point of the "to" quadrilateral
	mgcoord3d* to2,			// @param the second point of the "to" quadrilateral
	mgcoord3d* to3,			// @param the third point of the "to" quadrilateral
	mgcoord3d* to4				// @param the third point of the "to" quadrilateral
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgmatrix* | mgNewMatrix | allocates and returns a new matrix.

	@desc <f mgNewMatrix> allocates and returns a new matrix initialized with
	the identity matrix.

   @desc In most cases it will be sufficient to declare and use an object
	of type <t mgmatrix> in local scope, rather then dynamically creating one. 
	However, if you do need to dynamically allocate an object of type <t mgmatrix>,
	this function should be used.

	@return Returns a pointer to a newly allocated matrix (initialized with
	the identity matrix) if creation is successful, <m MG_NULL> otherwise.

	@see <t mgmatrix>, 
	<f mgFreeMatrix>, <f mgMatrixIdentity>, <f mgMatrixIsIdentity>,
	<f mgMatrixInvert>, <f mgMatrixMultiply>, <f mgMatrixCopy>

	@access Level 1
*/
extern MGAPIFUNC(mgmatrix*) mgNewMatrix ( void );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgFreeMatrix | deallocates a matrix created by <f mgNewMatrix>.

	@desc <f mgFreeMatrix> deallocates a matrix that was created previously by
	a call <f mgNewMatrix>.

	@see
	<f mgNewMatrix>, <f mgMatrixIdentity>, <f mgMatrixIsIdentity>,
	<f mgMatrixInvert>, <f mgMatrixMultiply>, <f mgMatrixCopy>

	@access Level 1
*/
extern MGAPIFUNC(void) mgFreeMatrix (
	mgmatrix* matrix			// @param matrix to deallocate
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixIdentity | forms the identity matrix.

	@desc <f mgMatrixIdentity> creates and returns the identity matrix.

	@desc The identity matrix is written into the output parameter, <p matrix>.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p matrix> will contain the identity matrix,
	otherwise it is undefined.

	@see <f mgNewMatrix>, <f mgFreeMatrix>, <f mgMatrixIsIdentity>,
	<f mgMatrixInvert>, <f mgMatrixMultiply>, <f mgMatrixCopy>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixIdentity (
	mgmatrix* matrix			// @param address of matrix to receive inverse matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixInvert | forms the inverse of a matrix.

	@desc <f mgMatrixInvert> inverts the specified <p matrix>.

	@desc The resulting matrix is written into the output parameter, <p invMatrix>.

	@return Returns <e mgbool.MG_TRUE> if <p matrix> is invertible, 
	<e mgbool.MG_FALSE> otherwise.  If successful, 
	the output parameter <p invMatrix> will contain the inverse matrix,
	otherwise it is undefined.

	@see <f mgNewMatrix>, <f mgFreeMatrix>, <f mgMatrixIdentity>, 
	<f mgMatrixIsIdentity>, <f mgMatrixMultiply>, <f mgMatrixCopy>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixInvert (
	mgmatrix matrix,			// @param matrix to invert
	mgmatrix* invMatrix		// @param address of matrix to receive inverse matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixMultiply | multiplies two matrices.

	@desc <f mgMatrixMultiply> multiplies two matrices <p matrixA> and <p matrixB>
	to form a third matrix, <p resultMatrix>.

	@desc The resulting matrix (<p matrixA> X <p matrixB>) is written into the
	output parameter, <p resultMatrix>.  
	This function operates safely when either of the input matrices and the
	output matrix are the same matrix.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p resultMatrix> will contain the result
	of the matrix multiplication, otherwise it is undefined.

	@see <f mgNewMatrix>, <f mgFreeMatrix>, <f mgMatrixIdentity>,
	<f mgMatrixIsIdentity>, <f mgMatrixInvert>, <f mgMatrixCopy>,
	<f mgMatrixRotateX>, <f mgMatrixRotateY>, <f mgMatrixRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixMultiply (
	mgmatrix matrixA,			// @param matrix to multiply
	mgmatrix matrixB,			// @param matrix to multiply
	mgmatrix* resultMatrix	// @param address of matrix to receive result
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixCopy | copies one matrix into another.

	@desc <f mgMatrixCopy> copies one matrix, <p srcMatrix>, into another,
	<p dstMatrix>.

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.
	If successful, the output parameter <p dstMatrix> will contain a copy of
	<p matrix>, otherwise it is undefined.

	@see <f mgNewMatrix>, <f mgFreeMatrix>, <f mgMatrixIdentity>,
	<f mgMatrixIsIdentity>, <f mgMatrixInvert>, <f mgMatrixMultiply>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixCopy (
	mgmatrix* dstMatrix,			// @param address of matrix to receive copy
	mgmatrix srcMatrix			// @param matrix to copy
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixIsIdentity | checks to see if a matrix is the
	identity matrix.

	@desc <f mgMatrixIsIdentity> checks <p matrix> to see if it is the
	identity matrix.

	@return Returns <e mgbool.MG_TRUE> if <p matrix> is the identity matrix,
	<e mgbool.MG_FALSE> otherwise.

	@see
	<f mgNewMatrix>, <f mgFreeMatrix>, <f mgMatrixIdentity>,
	<f mgMatrixInvert>, <f mgMatrixMultiply>, <f mgMatrixCopy>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixIsIdentity (
	mgmatrix matrix			// @param matrix to check
	);
/*                                                                            */
/*============================================================================*/


/*============================================================================*/
/* @doc EXTERNAL MATRIXSTACKFUNC */
/*============================================================================*/
/*                                                                            */
/* @func mgmatrixstack | mgNewMatrixStack | creates and returns a matrix
	stack object.

	@desc <f mgNewMatrixStack> creates and returns a matrix stack object which
	can be used to perform matrix stack operations.
	
	@return Returns a matrix stack object (initialized with the identity matrix)
	if creation is successful, <m MG_NULL> otherwise.

	@see <t mgmatrixstack>, <t mgmatrix>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

  @access Level 1
*/
extern MGAPIFUNC(mgmatrixstack) mgNewMatrixStack ( void );
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgFreeMatrixStack | deallocates a matrix stack object
	created by <f mgNewMatrixStack>.

	@desc <f mgFreeMatrixStack> deallocates a matrix stack object that was
	created previously by a call <f mgNewMatrixStack>.
	
	@see <t mgmatrix>, <f mgNewMatrixStack>,
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(void) mgFreeMatrixStack (
	mgmatrixstack matrixStack			// @param the matrix stack to free
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackPush | push a matrix stack.

	@desc <f mgMatrixStackPush> pushes the specified matrix stack <p matrixStack>.
	The current top matrix is copied to the new top-of-stack.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackPush ( 
	mgmatrixstack matrixStack		// @param the matrix stack to push
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackPop | pop a matrix stack.

	@desc <f mgMatrixStackPop> pops the specified matrix stack <p matrixStack>.
	The current top matrix is discarded.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackPop ( 
	mgmatrixstack matrixStack		// @param the matrix stack to pop
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackLoadIdentity | load an identity matrix onto 
	a matrix stack.

	@desc <f mgMatrixStackLoadIdentity> loads an identity matrix onto the 
	specified matrix stack <p matrixStack>.  An identity matrix replaces
	the current top-of-stack matrix in <p matrixStack>.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackLoadIdentity (
	mgmatrixstack matrixStack		// @param the matrix stack to load the identity
											// matrix onto the top-of-stack
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackLoadMatrix | load a matrix onto a matrix stack.

	@desc <f mgMatrixStackLoadMatrix> loads a given <p matrix> onto the
	specified matrix stack <p matrixStack>.  A copy of <p matrix> replaces
	the current top-of-stack matrix in <p matrixStack>.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackLoadMatrix ( 
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	mgmatrix matrix					// @param the matrix to copy onto the top-of-stack
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackGetMatrix | get the current top-of-stack
	matrix from a matrix stack.

	@desc <f mgMatrixStackGetMatrix> gets the current top-of-stack matrix
	from a specified matrix stack <p matrixStack>.  The top-of-stack matrix
	is returned in the ouput parameter <p matrix>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise. If successful, the output parameter <p matrix>
	will contain the current top-of-stack matrix, otherwise it is undefined.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackGetMatrix (
	mgmatrixstack matrixStack,		// @param the matrix stack to get top matrix from
	mgmatrix* matrix					// @param address of matrix to receive top matrix
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackIsIdentity | checks to see if the top-of-stack
	matrix on a matrix stack is the identity matrix.

	@desc <f mgMatrixStackIsIdentity> checks the specified matrix stack, <p matrixStack>
	to see if the top matrix on it is the identity matrix.

	@return Returns <e mgbool.MG_TRUE> if the top-of-stack matrix on <p matrixStack>
	is the identity matrix, <e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackIsIdentity (
	mgmatrixstack matrixStack		// @param the matrix stack to pop
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackMultiply | multiplies a matrix into a matrix stack.

	@desc <f mgMatrixStackMultiply> multiplies the current top-of-stack matrix
	in the specified matrix stack, <p matrixStack> by a given <p matrix>. 
	
	@desc If the top-of-stack matrix is <p T> before this function, the new top-of-stack
	matrix after this function will be the product <p matrix> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackMultiply (
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	mgmatrix matrix					// @param the matrix to multiply into the top-of-stack
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackScale | multiplies a scale matrix into a
	matrix stack.

	@desc <f mgMatrixStackScale> calculates a scale matrix representing the scale
	factors, <p x>, <p y> and <p z> along the coordinate axes X, Y and Z, respectively,
	and multiplies that matrix by the current top-of-stack matrix in the specified
	matrix stack <p matrixStack>.  The resulting matrix replaces the top-of-stack
	matrix in <p matrixStack>.

	@desc If the top-of-stack matrix is <p T> before this function,
	and the scale matrix representing the scale factors, <p x>, <p y> and <p z>
	along the coordinate axes X, Y and Z, respectively, is <p S>, the new
	top-of-stack matrix after this function will be the product <p S> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackScale (
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	double x,							// @param the scale factor in the X direction
	double y,							// @param the scale factor in the Y direction
	double z								// @param the scale factor in the Z direction
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackRotate | multiplies a rotation matrix into a
	matrix stack.

	@desc <f mgMatrixStackRotate> calculates a rotation matrix representing the rotation
	of <p theta> degrees about the vector <p a>,<p b>,<p c> and multiplies that matrix
	by the current top-of-stack matrix in the specified matrix stack <p matrixStack>. 
	The resulting matrix replaces the top-of-stack matrix in <p matrixStack>.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).

	@desc If the top-of-stack matrix is <p T> before this function,
	and the rotation matrix representing the rotation
	of <p theta> degrees about the vector <p a>,<p b>,<p c> is <p R>, the new
	top-of-stack matrix after this function will be the product <p R> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

   @access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackRotate (
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	double theta,						// @param angle to rotate measured counter-clockwise
											// in degrees about vector (right hand rule) 
	double a,							// @param the unitized x component of vector
	double b,							// @param the unitized y component of vector
	double c								// @param the unitized z component of vector
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackRotateX | multiplies a rotation matrix into a
	matrix stack.

	@desc <f mgMatrixStackRotateX> calculates a rotation matrix representing the
	rotation of <p theta> degrees about the X coordinate axis and multiplies that
	matrix by the current top-of-stack matrix in the specified matrix stack
	<p matrixStack>. The resulting matrix replaces the top-of-stack matrix in
	<p matrixStack>.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).

	@desc If the top-of-stack matrix is <p T> before this function,
	and the rotation matrix representing the rotation of <p theta> degrees
	about the X coordinate axis is <p R>, the new top-of-stack matrix
	after this function will be the product <p R> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

   @access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackRotateX (
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	double theta						// @param angle to rotate measured counter-clockwise
											// in degrees about vector (right hand rule) 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackRotateY | multiplies a rotation matrix into a
	matrix stack.

	@desc <f mgMatrixStackRotateY> calculates a rotation matrix representing the
	rotation of <p theta> degrees about the Y coordinate axis and multiplies that
	matrix by the current top-of-stack matrix in the specified matrix stack
	<p matrixStack>. The resulting matrix replaces the top-of-stack matrix in
	<p matrixStack>.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).

	@desc If the top-of-stack matrix is <p T> before this function,
	and the rotation matrix representing the rotation of <p theta> degrees
	about the Y coordinate axis is <p R>, the new top-of-stack matrix
	after this function will be the product <p R> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateZ>

   @access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackRotateY ( 
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	double theta						// @param angle to rotate measured counter-clockwise
											// in degrees about vector (right hand rule) 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackRotateZ | multiplies a rotation matrix into a
	matrix stack.

	@desc <f mgMatrixStackRotateZ> calculates a rotation matrix representing the
	rotation of <p theta> degrees about the Z coordinate axis and multiplies that
	matrix by the current top-of-stack matrix in the specified matrix stack
	<p matrixStack>. The resulting matrix replaces the top-of-stack matrix in
	<p matrixStack>.

	@desc The parameter <p theta> specifies the angle (in degrees) to rotate
	counter-clockwise (right hand rule).

	@desc If the top-of-stack matrix is <p T> before this function,
	and the rotation matrix representing the rotation of <p theta> degrees
	about the Z coordinate axis is <p R>, the new top-of-stack matrix
	after this function will be the product <p R> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackTranslate>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>

   @access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackRotateZ (
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	double theta						// @param angle to rotate measured counter-clockwise
											// in degrees about vector (right hand rule) 
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgMatrixStackTranslate | multiplies a translation matrix into a
	matrix stack.

	@desc <f mgMatrixStackTranslate> calculates a translation matrix representing the 
	translations <p x>, <p y> and <p z> along the coordinate axes X, Y and Z, respectively,
	and multiplies that matrix by the current top-of-stack matrix in the specified
	matrix stack <p matrixStack>.  The resulting matrix replaces the top-of-stack
	matrix in <p matrixStack>.

	@desc If the top-of-stack matrix is <p T> before this function,
	and the translation matrix representing the 
	translations <p x>, <p y> and <p z> along the coordinate axes X, Y and Z,
	respectively, is <p D>, the new
	top-of-stack matrix after this function will be the product <p D> X <p T>.

	@return Returns <e mgbool.MG_TRUE> if the operation was successful, 
	<e mgbool.MG_FALSE> otherwise.

	@see <t mgmatrix>, <f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgMatrixStackTranslate (
	mgmatrixstack matrixStack,		// @param the matrix stack to apply operation
	double x,							// @param the translation in the X direction
	double y,							// @param the translation in the Y direction
	double z								// @param the translation in the Z direction
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcoord3d | mgMatrixStackTransformCoord | transforms a coordinate using
	the current top-of-stack matrix from a matrix stack.

	@desc <f mgMatrixStackTransformCoord> applies the top-of-stack matrix in 
	the specified matrix stack <p matrixStack> to the specified 3D double
	precision floating point coordinate <p coord> and returns the resulting
	coordinate.

	@desc The original coordinate <p coord> is not affected.

	@return Returns the transformed double precision 3D coordinate record.

	@see <t mgmatrix>,
	<f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>,
	<f mgMatrixStackTransformVector>

	@access Level 1
*/
extern MGAPIFUNC(mgcoord3d) mgMatrixStackTransformCoord (
	mgmatrixstack matrixStack,		// @param the matrix stack whose top-of-stack matrix
											// is to be applied to <p coord>
	mgcoord3d* coord					// @param the coordinate to transform
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgvectord | mgMatrixStackTransformVector | transforms a vector using
	the current top-of-stack matrix from a matrix stack.

	@desc <f mgMatrixStackTransformVector> applies the top-of-stack matrix in 
	the specified matrix stack <p matrixStack> to the specified double
	precision floating point vector <p v> and returns the resulting
	vector.

	@desc The original vector <p v> is not affected.

	@return Returns the transformed double precision vector record.

	@see <t mgmatrix>,
	<f mgNewMatrixStack>, <f mgFreeMatrixStack>, 
	<f mgMatrixStackPush>, <f mgMatrixStackPop>,
	<f mgMatrixStackLoadIdentity>, <f mgMatrixStackIsIdentity>,
	<f mgMatrixStackLoadMatrix>, <f mgMatrixStackGetMatrix>,
	<f mgMatrixStackMultiply>, <f mgMatrixStackScale>,
	<f mgMatrixStackRotate>, <f mgMatrixStackRotateX>,
	<f mgMatrixStackRotateY>, <f mgMatrixStackRotateZ>,
	<f mgMatrixStackTransformCoord>

	@access Level 1
*/
extern MGAPIFUNC(mgvectord) mgMatrixStackTransformVector (
	mgmatrixstack matrixStack,		// @param the matrix stack whose top-of-stack matrix
											// is to be applied to <p v>
	mgvectord* v						// @param address of vector to transform
	);
/*                                                                            */
/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

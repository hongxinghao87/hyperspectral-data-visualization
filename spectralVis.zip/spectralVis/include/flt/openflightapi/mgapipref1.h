/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIPREF1_H_
#define MGAPIPREF1_H_
// @doc EXTERNAL PREFFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif
	
/*============================================================================*/
/*                                                                            */
/*	@func void | mgSetOpenCreateFlag | sets the preference that 
	determines if a new database is created when <f mgOpenDb> is instructed 
	to open a file that does not exist.

	@desc <f mgSetOpenCreateFlag> tells <f mgOpenDb> how to act when it 
	is asked to open a database that does not exist.  
	If <p flag> is <e mgbool.MG_TRUE>, <f mgNewDb> is called to create a new file.  
	If <p flag> is <e mgbool.MG_FALSE> (the default), <f mgOpenDb> fails and returns.  

	@ex | 
   mgrec* db;
   mgSetOpenCreateFlag ( MG_TRUE );
   db = mgOpenDb ( "file1.flt" );

	@access Level 1
	@see <f mgOpenDb>, <f mgNewDb>, <f mgSetNewOverwriteFlag>
*/
extern MGAPIFUNC(void) mgSetOpenCreateFlag ( 
	mgbool flag			// @param whether or not to create a new database
	);
/*                                                                            */
/*============================================================================*/
 
   
/*============================================================================*/
/*                                                                            */
/*	@func void | mgSetNewOverwriteFlag | sets the preference that 
	determines if <f mgNewDb> and <f mgSaveAsDb> overwrite a file when 
	instructed to create a file that already exists.

	@desc <f mgSetNewOverwriteFlag> tells <f mgNewDb> and <f mgSaveAsDb> 
	how to act when asked to create a file that already exists.  If <p flag> is 
	<e mgbool.MG_TRUE>, <f mgNewDb>, and <f mgSaveAsDb> overwrite the existing 
	file.  If <p flag> is <e mgbool.MG_FALSE> (the default), <f mgNewDb> 
	and <f mgSaveAsDb> fail and return.  

	@ex | 
   mgrec* db;
   mgSetNewOverwriteFlag ( MG_TRUE );
   db = mgNewDb ( "file1.flt" );

	@access Level 1
	@see <f mgSaveAsDb>, <f mgNewDb>
*/
extern MGAPIFUNC(void) mgSetNewOverwriteFlag (
	mgbool flag			// @param whether or not to overwrite an existing file
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/*	@func void | mgSetReadExtFlag | sets the preference that determines if 
	<f mgOpenDb> reads external reference database files contained in 
	database files being opened.
	
	@desc <f mgSetReadExtFlag> tells <f mgOpenDb> how to act when it finds
	an external reference node in a database being opened.  If <p flag> is 
	<e mgbool.MG_TRUE>, <f mgOpenDb> will read external references.  If 
	<p flag> is <e mgbool.MG_FALSE> (the default), <f mgOpenDb> 
	will not read external references.  

	@access Level 1
	@see <f mgOpenDb>
*/
extern MGAPIFUNC(void) mgSetReadExtFlag (
	mgbool flag			// @param whether or not to read external references
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/*	@func void | mgSetSaveNonIndexedLightPoints | sets the preference that
	determines how light point records are saved in an OpenFlight file.
		
	@desc <f mgSetSaveNonPaletteLightPoints> tells <f mgWriteDb> and <f mgSaveAsDb>
	how to write light point records in the OpenFlight file.  If <p flag> is 
	<e mgbool.MG_TRUE>, light points will be saved in the "non-indexed" format
	used in OpenFlight 15.7 and earlier.  This format is represented in the
	OpenFlight format as raw record code 111.  If <p flag> is <e mgbool.MG_FALSE> 
	(the default), light points will be saved in the "indexed" format introduced
	in OpenFlight 15.8.  This format is represented in the
	OpenFlight format as raw record code 130.

	@access Level 1
	@see <f mgWriteDb>, <f mgSaveAsDb>
*/
extern MGAPIFUNC(void) mgSetSaveNonIndexedLightPoints (
	mgbool flag			// @param whether or not to save light points in the
							// non-indexed format
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

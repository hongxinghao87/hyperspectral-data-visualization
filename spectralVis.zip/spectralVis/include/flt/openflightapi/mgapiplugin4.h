/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIPLUGIN4_H_
#define MGAPIPLUGIN4_H_
/* @doc EXTERNAL REQUIREDFUNC */

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapibase.h"
#include "mgapistd.h"
#include "mgapitexture1.h"

/*============================================================================*\
	Platform dependent typedefs
\*============================================================================*/

// @type mgmodulehandle | Platform-specific type used to represent a plug-in module
// library object.  Use this to load a resource.
// @desc On Windows NT, this is type HINSTANCE.
// @see <f mgGetModuleHandle>, <f mgLoadResource>
typedef void* mgmodulehandle;

/*----------------------------------------------------------------------------*/

#define MVENDOR_MULTIGEN		"MultiGen, Inc."
#define MHELPFILE_MULTIGEN		"mgcreator.hlp"

/*============================================================================*/
/*                                                                            */
/* @func | mgDeclarePlugin | Declares a plug-in module.
	@desc You must instantiate this macro at the outer most
	scope of your source code so that your plug-in is properly recognized.
	@param | vendor | a string representing the name of the vendor of the plug-in   
	@param | name | a string representing the name of the plug-in 
	@param | uuid | a Universally Unique Identifier to identify the plug-in  
	On Windows NT, use the <f uuidgen> utility to generate this identifier 
	@access Instantiated by Plug-in Module
	@see <f mgpInit>, <f mgpExit>
*/
#define mgDeclarePlugin(vendor,name,uuid) \
MGPIDECLARE(const char*) mgpVendor = vendor; \
MGPIDECLARE(const char*) mgpIDString = name; \
MGPIDECLARE(const char*) mgpUUIDString = uuid; \
MGPIDECLARE(const char*) mgpVersion = MVERSION_API

/*                                                                            */
/*============================================================================*/

/*----------------------------------------------------------------------------*/

/* plug-in tool attribute names */

/* common attributes for all tool types */

#define MTA_VERSION				"Version"					// @msg MTA_VERSION | Tool Attribute <p Version>.  
																		// @desc This string attribute is displayed in the 
																		// Help on Plugins dialog and may be used by a
																		// plug-in tool to identify a version or other
																		// vendor-specific information applicable to the tool.																		
																		// @see <f mgRegisterImporter>, <f mgRegisterExporter>,
																		// <f mgRegisterImageImporter>, <f mgRegisterViewer>,
																		// <f mgRegisterEditor>, <f mgRegisterInputDevice>

#define MTA_HELPCONTEXT			"HelpContext"				// @msg MTA_HELPCONTEXT | Tool Attribute <p Help Context>
																		// @desc This string attribute specifies the help topic for
																		// context sensitive help for your plug-in tool.  The help 
																		// context identifies the location in your help file where
																		// the plug-in tool context sensitive help is found.
																		// @see <f mgRegisterImporter>, <f mgRegisterExporter>,
																		// <f mgRegisterImageImporter>, <f mgRegisterViewer>,
																		// <f mgRegisterEditor>, <f mgRegisterInputDevice>

/* import/export common tool attribute names */
#define MTA_FILTER				"Filter"						// @msg MTA_FILTER | Tool Attribute <p Filter String>
																		// @desc This string attribute specifies the pattern string that
																		// is used in the appropriate File Selection Dialog
																		// to match files for database and image importer and 
																		// database exporter tools. 
																		// @desc This attribute is typically of the form "*.xyz" where
																		// xyz is the suffix used to identify applicable files for the
																		// importer or exporter tool.
																		// @see <f mgRegisterImporter>, <f mgRegisterExporter>
																		// <f mgRegisterImageImporter>

#define MTA_FILETYPE				"FileType"					// @msg MTA_FILETYPE | Tool Attribute <p File Type String>
																		// @desc This string attribute specifies the description text that
																		// is used in the appropriate File Selection Dialog to describe
																		// the applicable files for database and image importer and 
																		// database exporter tools.
																		// @see <f mgRegisterImporter>, <f mgRegisterExporter>
																		// <f mgRegisterImageImporter>

/* editor/viewer common tool attribute names */
#define MTA_PALETTELOCATION	"PaletteLocation"			// @msg MTA_PALETTELOCATION | Tool Attribute <p Palette Location>
																		// @desc Specify this tool attribute if you want your
																		// viewer or editor tool to be launched from a tool palette.
																		// @desc This string attribute specifies the tool palette where 
																		// the corresponding palette icon <m MTA_PALETTEICON> is 
																		// placed for a tool.  
																		// @desc You must specify both <m MTA_PALETTELOCATION> and
																		// <m MTA_PALETTEICON> if you want your tool to be launched from
																		// a tool palette.
																		// @desc Possible values for this tool attribute are: <nl>
																		// <m MPAL_FACETOOLS> - Face Tools palette <nl> 
																		// <m MPAL_GEOMETRYTOOLS> - Geometry Tools palette <nl>
																		// <m MPAL_MANEUVERTOOLS> - Maneuver Tools palette <nl> 
																		// <m MPAL_DUPLICATE> - Duplicate palette <nl> 
																		// <m MPAL_MODIFYGEOMETRY> - Modify Geometry palette <nl> 
																		// <m MPAL_MODIFYFACE> - Modify Face palette <nl> 
																		// <m MPAL_MODIFYVERTEX> - Modify Vertex palette <nl> 
																		// <m MPAL_PROPERTIES> - Properties palette <nl> 
																		// <m MPAL_MAPTEXTURE> - Map Texture palette <nl> 
																		// <m MPAL_MODIFYTEXTURE> - Modify Texture palette <nl> 
																		// <m MPAL_EDGETOOLS> - Edge Tools palette <nl> 
																		// <m MPAL_VERTEXTOOLS> - Vertex Tools palette <nl> 
																		// <m MPAL_CREATETOOLS> - Create Tools palette <nl> 
																		// <m MPAL_HIERARCHYTOOLS> - Hierarchy Tools palette
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_PALETTEICON			"PaletteIcon"				// @msg MTA_PALETTEICON | Tool Attribute <p Palette Icon>
																		// @desc This <f mgpixmap> attribute specifies the tool icon that
																		// is placed in the corresponding tool palette <m MTA_PALETTELOCATION>
																		// for a tool. When the user clicks on this icon, the plug-in tool 
																		// is launched.
																		// @desc You must specify both <m MTA_PALETTELOCATION> and
																		// <m MTA_PALETTEICON> if you want your tool to be launched from
																		// a tool palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_MENULOCATION		"MenuLocation"				// @msg MTA_MENULOCATION | Tool Attribute <p Menu Location>
																		// @desc Specify this tool attribute if you want your
																		// viewer or editor tool to be launched from a menu.
																		// @desc This string attribute specifies the menu where 
																		// the corresponding menu label <m MTA_MENULABEL> is
																		// placed for a tool.
																		// @desc You must specify both <m MTA_MENULOCATION> and
																		// <m MTA_MENULABEL> if you want your tool to be launched from
																		// a menu.
																		// @desc Possible values for this tool attribute are: <nl>
																		// <m MMENU_FILE> - File menu <nl>
																		// <m MMENU_EDIT> - Edit menu <nl>
																		// <m MMENU_VIEW> - View menu <nl>
																		// <m MMENU_INFO> - Info menu <nl>
																		// <m MMENU_SELECT> - Select menu <nl>
																		// <m MMENU_ATTRIBUTES> - Attributes menu <nl>
																		// <m MMENU_LOD> - LOD menu <nl>
																		// <m MMENU_LOCALDOF> - Local-DOF menu <nl>
																		// <m MMENU_PALETTES> - Palette menu <nl>
																		// <m MMENU_TERRAIN> - Terrain menu <nl>
																		// <m MMENU_ROAD> - Road menu	<nl>
																		// <m MMENU_GEOFEATURE> - GeoFeature menu	<nl>
																		// <m MMENU_SOUND> - Sound menu	<nl>
																		// <m MMENU_INSTRUMENTS> - Instruments menu	<nl>
																		// <m MMENU_BSP> - BSP menu <nl>
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_MENUPOSITION      "MenuPosition"				// @msg MTA_MENUPOSITION | Tool Attribute <p Menu Position>
																		// @desc When you want your viewer or editor tool to be
																		// launched from a menu, you can select another item in the
																		// menu before or after which your new menu item is to be located.
																		// @desc This string attribute specifies an existing item in the
																		// menu you specify by <m MTA_MENULOCATION>.
																		// To place your new menu item after the item specified by this
																		// attribute, precede the menu item with the "<gt>" character. 
																		// To place your new menu item before the specifiied item, use the
																		// "<lt>" character.  If you do not specify "<gt>" or "<lt>", your
																		// new menu item will be placed after the specified item.
																		// See the examples that follow.
																		// @ex Specify the following values for this attribute to add
																		// your new menu item before/after the "Open" menu item:|
																		// "<Open"    - Add new menu item before the "Open" menu item.
																		//  
																		// ">Open..." - Add new menu item after the "Open" menu item.
																		// Note: The "..." are not required and if included are ignored.
																		//  
																		// "Open"     - Add new menu item after the "Open" menu item.
																		// Note: In the absence of ">" and "<", ">" is the default.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_MENUSUBMENU      "MenuSubmenu"				// @msg MTA_MENUSUBMENU | Tool Attribute <p Menu Submenu>
																		// @desc When you specify that your viewer or editor tool is to
																		// be launched from a menu, you can specify the submenu that will
																		// contain your new menu item.  If the submenu already exists, your
																		// new menu item is simply added to that submenu.  If the submenu
																		// does not exist, it will be created for you.
																		// @desc This string attribute specifies the submenu where your
																		// new menu item will be placed.  If you are specifying an existing
																		// submenu, specify the label string of the existing submenu (just
																		// as it appears in the menu) as the value of this attribute.
																		// If you are specifying a new submenu to create, specify the
																		// label text you want to appear on the submenu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_MENULABEL			"MenuLabel"					// @msg MTA_MENULABEL | Tool Attribute <p Menu Label>
																		// @desc This string attribute specifies the menu label that
																		// is placed in the corresponding menu <m MTA_MENULOCATION>
																		// for a tool.  When the user selects this menu item, the plug-in
																		// tool is launched.
																		// @desc You must specify both <m MTA_MENULOCATION> and
																		// <m MTA_MENULABEL> if you want your tool to be launched from
																		// a menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_TOOLTIP				"ToolTip"					// @msg MTA_TOOLTIP | Tool Attribute <p Tool Tip>
																		// @desc This string attribute specifies the tool tip text that
																		// is displayed when the user positions the mouse over the
																		// the palette icon <m MTA_PALETTEICON> associated with this tool.
																		// @desc The default tool tip for editor and viewer tools launched
																		// from a tool palette is the tool name.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MTA_LAUNCHINFO			"LaunchInfo"				// Internal use only by MultiGen-Paradigm

/* editor only ttribute names */
#define MTA_ACTIVATETYPE		"ActivateType"				// Internal use only by MultiGen-Paradigm

/* valid arguments for the file dialog */ 
#define MPFA_TITLE				"PromptFileTitle"			// @msg MPFA_TITLE | File Browser parameter for specifying Title 
																		// @desc Specify this as a parameter followed by a string for the 
																		// <f mgPromptDialogFile> if you want a title for the file browser
																		// @desc If no value is specified for this attribute, default value 
																		// of Open/Save As is assumed
																		// @see <f mgPromptDialogFile>

#define MPFA_FLAGS				"PromptFileFlags"			// @msg MPFA_FLAGS | File Browser parameter for specifying Flags 
																		// @desc Specify this as a parameter followed by a integer for the 
																		// <f mgPromptDialogFile> indicating the flags for the file browser
																		// @desc If no value is specified for this attribute none of the flags
																		// are set.
																		// @desc Valid values for MPFA_FLAGS include
																		// @desc <m MPFF_OVERWRITEPROMPT> - Specify whether the user should be prompted 
																		// with a warning if he tries to overwrite an existing file
																		// @desc <m MPFF_FILEMUSTEXIST> - Specify whether the user should be prompted
																		// with a warning if he tries to open a non-existent file
																		// @desc <m MPFF_MULTISELECT> - Specify if the user is allowed to select multiple
																		// files from the file browser
																		// @see <f mgPromptDialogFile>

#define MPFA_DIRECTORY			"PromptFileDirectory"	// @msg MPFA_DIRECTORY | File Browser parameter for specifying initial 
																		// directory 
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by a string indicating the flags for the file browser.
																		// @desc If no value is specified for this attribute the initial directory 
																		// will be the last directory visited or the desktop directory
																		// @see <f mgPromptDialogFile>

#define MPFA_PATTERN				"PromptFilePattern"		// @msg MPFA_PATTERN | File Browser parameter for specifying the filters
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by a string which specifies one or more description-extension pairs.
																		// Each description-extension pair is separated using the '\|' character
																		// as shown below:
																		// @desc Flight Files \| *.flt
																		// @desc Successive pairs are delimited using the "\|\|" character sequence 
																		// as shown below:
																		// @desc Flight Files \| *.flt \|\| Text Files \| *.txt
																		// @desc If no value is specified for this attribute the default pattern
																		// will be used:
																		// @desc All Files \| *.*
																		// @see <f mgPromptDialogFile>

#define MPFA_FILENAME			"PromptFileFilename"		// @msg MPFA_FILENAME | File Browser parameter for specifying the intial 
																		// file
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by a string specifying the file to be selected as the initial file.
																		// @desc If no value is specified for this attribute no initial file is 
																		// selected.
																		// @see <f mgPromptDialogFile>

#define MPFA_FULLFILENAME		"PromptFileFullFilename"// @msg MPFA_FULLFILENAME | File Browser parameter for specifying the complete 
																		// filename including the path
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by a string specifying the initial file  with the path
																		// @see <f mgPromptDialogFile>

#define MPFA_DIALOGID			"PromptFileDialogId"		// @msg MPFA_DIALOGID | File Browser parameter for specifying a custom
																		// dialog template to be used to create the file browser
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by the identifier of your custom dialog template in your resource file.
																		// @desc If you specify either this attribute or <m MPFA_RESOURCE>,
																		// you must specify them both.
																		// @see <f mgPromptDialogFile>

#define MPFA_RESOURCE			"PromptFileResource"		// @msg MPFA_RESOURCE | File Browser parameter for specifying your 
																		// resource when using a custom dialog template for your file browser
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by the <t mgresource> of your plugin containing your dialog template.
																		// @desc If you specify either this attribute or <m MPFA_DIALOGID>,
																		// you must specify them both.
																		// @see <f mgPromptDialogFile>, <m MPFA_DIALOGID>

#define MPFA_DIALOGFUNC			"PromptFileDialogFunc"	// @msg MPFA_DIALOGFUNC | File Browser parameter for specifying a 
																		// dialog function for your file browser
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by the <t mgdialogfunc> you want to be called as the dialog function
																		// of your file browser.
																		// @desc If you specify either this attribute or <m MPFA_CALLBACKMASK>,
																		// you must specify them both.
																		// @see <f mgPromptDialogFile>, <m MPFA_CALLBACKMASK>, 
																		// <f mgResourceGetDialog>, <f mgResourceModalDialog>

#define MPFA_CALLBACKMASK		"PromptFileCallbackMask"// @msg MPFA_CALLBACKMASK | File Browser parameter for specifying the 
																		// callback mask for your dialog function of your file browser
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by an unsigned integer value representing the bitwise combination of
																		// dialog events selected for the dialog function of your file browser.
																		// @desc If you specify either this attribute or <m MPFA_DIALOGFUNC>,
																		// you must specify them both.
																		// @see <f mgPromptDialogFile>, <m MPFA_DIALOGFUNC>, 
																		// <f mgResourceGetDialog>, <f mgResourceModalDialog>

#define MPFA_PATTERNINDEX		"PromptFilePatternIndex"// @msg MPFA_PATTERNINDEX | File Browser parameter for specifying the 
																		// address of an integer value to receive the index of the selected
																		// pattern at the time the user chooses one or more files in the browser
																		// @desc Specify this as a parameter for <f mgPromptDialogFile> followed 
																		// by the address of the integer value to receive the selected pattern 
																		// index.
																		// @desc The index returned will be '1' if the user selected the first
																		// pattern specified by the attribute <m MPFA_PATTERN>, '2' if they selected
																		// the second, and so on.  Since the default "All Files" pattern is always
																		// added after the patterns you specify with <m MPFA_PATTERN>, the index
																		// returned will one greater than the number of patterns you specified if 
																		// the user selected the "All Files" pattern.  If the user cancels the 
																		// selection in the file browser, the index returned is not defined.
																		// @see <f mgPromptDialogFile>, <m MPFA_PATTERN>

/* valid values for the file dialog flags and modes */
/* See also mgplugin_cdlg.c*/
#define MPFF_FILEMUSTEXIST				0x00000001  
													// @msg MPFF_FILEMUSTEXIST | File Browser flag 
													// @desc This may follow the <p MPFA_FLAGS>. Specifies that the user can type
													// only names of existing files in the File Name entry field. If this flag is 
													// specified and the user enters an invalid name, the dialog box procedure displays a 
													// warning in a message box
													// @see <f mgPromptDialogFile>
#define MPFF_MULTISELECT				0x00000002
													// @msg MPFF_MULTISELECT | File Browser flag 
													// @desc Specifies that the File browser list box allows multiple selections
													// @see <f mgPromptDialogFile>
#define MPFF_OVERWRITEPROMPT			0x00000004
													// @msg MPFF_OVERWRITEPROMPT | File Browser flag for overwrite prompting
													// @desc This may follow the <p MPFA_FLAGS> and specifies that the file browser
													// should prompt the user if he tries to overwrite an existing file.
													// @see <f mgPromptDialogFile>

#define MPFM_OPEN							0	// @msg MPFM_OPEN | File Browser flag for specifying the type of browser
													// @desc Specifies that the File browser default type is Open
													// @see <f mgPromptDialogFile>
#define MPFM_SAVE							1	// @msg MPFM_SAVE | File Browser flag for specifying the type of browser
													// @desc Specifies that the File browser default type is Save
													// @see <f mgPromptDialogFile>


/* valid values for tool attribute MTA_ACTIVATETYPE */
#define MACT_EXCLUSIVE					0						// Internal use only by MultiGen-Paradigm	  
#define MACT_CONCURRENT					1						// Internal use only by MultiGen-Paradigm
#define MACT_TRANSIENT					2						// Internal use only by MultiGen-Paradigm

/* valid values for tool attribute MTA_PALETTELOCATION */
#define MPAL_FACETOOLS			"FaceToolsPalette"		// @msg MPAL_FACETOOLS | Palette Location <p Face Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Face Tools> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_GEOMETRYTOOLS		"GeometryToolsPalette"	// @msg MPAL_GEOMETRYTOOLS | Palette Location <p Geometry Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Geometry Tools> palette.

#define MPAL_MANEUVERTOOLS		"ManeuverToolsPalette"	// @msg MPAL_MANEUVERTOOLS | Palette Location <p Maneuver Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Maneuver Tools> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_DUPLICATE			"DuplicatePalette"		// @msg MPAL_DUPLICATE | Palette Location <p Duplicate>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Duplicate> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_MODIFYGEOMETRY	"ModifyGeometryPalette"	// @msg MPAL_MODIFYGEOMETRY | Palette Location <p Modify Geometry>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Modify Geometry> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_MODIFYFACE			"ModifyFacePalette"		// @msg MPAL_MODIFYFACE | Palette Location <p Modify Face>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Modify Face> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_MODIFYVERTEX		"ModifyVertexPalette"	// @msg MPAL_MODIFYVERTEX | Palette Location <p Modify Vertex>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Modify Vertex> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_PROPERTIES			"PropertiesPalette"		// @msg MPAL_PROPERTIES | Palette Location <p Properties>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Properties> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_MAPTEXTURE			"MapTexturePalette"		// @msg MPAL_MAPTEXTURE | Palette Location <p Map Texture>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Map Texture> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_MODIFYTEXTURE		"ModifyTexturePalette"	// @msg MPAL_MODIFYTEXTURE | Palette Location <p Modify Texture>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Modify Texture> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_EDGETOOLS			"EdgeToolsPalette"		// @msg MPAL_EDGETOOLS | Palette Location <p Edge Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Edge Tools> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_VERTEXTOOLS		"VertexToolsPalette"		// @msg MPAL_VERTEXTOOLS | Palette Location <p Vertex Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Vertex Tools> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_CREATETOOLS		"CreateToolsPalette"		// @msg MPAL_CREATETOOLS | Palette Location <p Create Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Create Tools> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MPAL_HIERARCHYTOOLS	"HierarchyToolsPalette"	// @msg MPAL_HIERARCHYTOOLS | Palette Location <p Hierarchy Tools>
																		// @desc This is a valid value for Tool Attribute <p Palette Location>
																		// <m MTA_PALETTELOCATION>
																		// @desc If you specify this value for <m MTA_PALETTELOCATION> when
																		// you register an editor or viewer tool, the palette icon for your
																		// tool is placed in the <p Hierarchy Tools> palette.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>


/* valid values for tool attribute MTA_MENULOCATION */
#define MMENU_FILE				"File"						// @msg MMENU_FILE | Menu Location <p File>
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p File> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_EDIT				"Edit"						// @msg MMENU_EDIT | Menu Location <p Edit>
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Edit> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_VIEW				"View"						// @msg MMENU_VIEW | Menu Location <p View>
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p View> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_INFO				"Info"						// @msg MMENU_INFO | Menu Location <p Info>
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Info> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_SELECT				"Select"						// @msg MMENU_SELECT	 | Menu Location <p Select>
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Select> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_ATTRIBUTES		"Attributes"				// @msg MMENU_ATTRIBUTES | Menu Location <p Attributes> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Attributes> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_LOD					"LOD"							// @msg MMENU_LOD | Menu Location <p LOD>
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p LOD> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_LOCALDOF			"Local-DOF"					// @msg MMENU_LOCALDOF | Menu Location <p Local-DOF> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Local-DOF> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_PALETTES			"Palettes"					// @msg MMENU_PALETTES | Menu Location <p Palettes> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Palettes> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>


#define MMENU_TERRAIN			"Terrain"					// @msg MMENU_TERRAIN | Menu Location <p Terrain> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Terrain> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_ROAD				"Road"						// @msg MMENU_ROAD | Menu Location <p Road> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Road> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_GEOFEATURE		"GeoFeature"				// @msg MMENU_GEOFEATURE | Menu Location <p GeoFeature> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p GeoFeature> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_SOUND				"Sound"						// @msg MMENU_SOUND | Menu Location <p Sound> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Sound> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>


#define MMENU_INSTRUMENTS		"Instruments"				// @msg MMENU_INSTRUMENTS | Menu Location <p Instruments> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p Instruments> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>

#define MMENU_BSP					"BSP"							// @msg MMENU_BSP | Menu Location <p BSP> 
																		// @desc This is a valid value for Tool Attribute <p Menu Location>
																		// <m MTA_MENULOCATION>
																		// @desc If you specify this value for <m MTA_MENULOCATION> when
																		// you register an editor or viewer tool, the menu item for your
																		// tool is placed in the <p BSP> menu.
																		// @see <f mgRegisterViewer>, <f mgRegisterEditor>


/* Texture Importer/Exporter capability bit flags */

#define MGP_IMAGEWHOLE			0x00000001					// @msg MGP_IMAGEWHOLE | Image importer capability value 
																		// @see <f mgRegisterImageImporter>

#define MGP_IMAGERESOLUTION	0x00000002					// @msg MGP_IMAGERESOLUTION | Image importer capability value 
																		// @see <f mgRegisterImageImporter>

#define MGP_IMAGEGEOINFO		0x00000040					// @msg MGP_IMAGEGEOINFO | Image importer capability value 
																		// @see <f mgRegisterImageImporter>

/*----------------------------------------------------------------------------*/

// @type mgplugin | Abstract type used to represent a plug-in module
typedef struct mgplugin_t*     			mgplugin;

// @type mgplugintool | Abstract type used to represent a plug-in tool
typedef struct mgplugintool_t*			mgplugintool;

// @type mgpluginsite | Abstract type used to represent a plug-in data extension
typedef struct mgplugintool_t*			mgpluginsite;

// @type mgtoolactivation | Abstract type used to represent a tool activation object
typedef struct mgtoolactivation_t* 		mgtoolactivation;

// @type mgresource | Abstract type used to represent a plug-in resource
typedef struct mgresource_t*				mgresource;

// @type mgpixmap | Abstract type used to represent a pixmap object
typedef struct mgpixmap_t*					mgpixmap;

// @type mgcursor | Abstract type used to represent a cursor object
typedef struct mgcursor_t*					mgcursor;

// @cb mgbool | mgpinitfunc | Plug-in initialization function   
// @desc This is the signature for the plug-in initialization function you
// must declare in your source code so that your plug-in is properly
// recognized.
// @see <f mgpInit>  
typedef mgbool ( *mgpinitfunc )( 
		mgplugin plugin,					// @param the plug-in module being initialized
		int* argc,							// @param reserved for future enhancement
		char* argv []						// @param reserved for future enhancement
		);
/*============================================================================*/
/*                                                                            */
/* @func MGPIDECLARE(mgbool) | mgpInit | plug-in initialization function.
	@desc This is the plug-in initialization function required for all plug-in
	modules.  You must supply this function so that your plug-in is
   properly recognized.

	@desc You must declare 
	this function exactly as shown here, using the <m MGPIDECLARE> macro, so
	that it is properly exported from your plug-in module library.

	@desc This function is called by the plug-in runtime environment at 
	startup.  In this function a plug-in module performs any initialization
	processing required.  Typically, a plug-in module registers plug-in tools
	and/or data extensions for the runtime environment as well as load a 
	resource containing GUI definitions required by the plug-in.

	@param mgplugin | plugin | the plug-in module being initialized
	@param int* | argc | a pointer to the number of arguments contained in argv
	@param char* | argv [] | array of arguments passed to the program when it
	was started

	@return Returns <e mgbool.MG_TRUE> if the plug-in was successfully initialized,
	<e mgbool.MG_FALSE> otherwise.

	@see <f mgpExit>, <f mgDeclarePlugin>, <f mgRegisterImporter>, 
	<f mgRegisterExporter>, <f mgRegisterViewer>, <f mgRegisterEditor>,
	<f mgRegisterImageImporter>, <f mgRegisterSite>, <f mgRegisterInputDevice>,
	<f mgLoadResource>

	@access Declared by Plug-in Module
*/
/*============================================================================*/
		
// @cb void | mgpexitfunc | Plug-in exit function   
// @desc This is the signature for the plug-in exit function you
// must declare in your source code so that your plug-in is properly
// recognized.
// @see <f mgpExit>  
typedef void ( *mgpexitfunc )(
		mgplugin plugin					// @param the plug-in module being exited
		);

/*============================================================================*/
/*                                                                            */
/* @func MGPIDECLARE(void) | mgpExit | plug-in termination function
	@desc This is the plug-in termination function required for all plug-in
	modules.  You must supply this function so that your plug-in is
   properly recognized.

	@desc You must declare 
	this function exactly as shown here, using the <m MGPIDECLARE> macro, so
	that it is properly exported from your plug-in module library.

	@desc This function will be called by the plug-in runtime environment at 
	termination.  In this function, a plug-in module will perform any termination
	processing required.  Typically a plug-in module will unregister any 
	registered plug-in tools and/or data extensions and unload any loaded resources.

	@param mgplugin | plugin | the plug-in module being exited
	@see <f mgpInit>, <f mgDeclarePlugin>, <f mgUnregisterAllTools>, 
	<f mgUnloadResource>

	@access Declared by Plug-in Module
*/
/*============================================================================*/


// @cb mgstatus | mgtoolstartfunc | Start Function for Database Importer/Exporter, 
// Viewer and Editor Tools.   
// @desc This is the signature for plug-in tool start functions.
// When you register a plug-in tool, provide a start function
// of this form that is called when your plug-in tool is invoked in Creator.
// @return Currently the value returned by <t mgtoolstartfunc> is ignored and
// reserved for future enhancement.  For now always return <m MSTAT_OK>.
// @see <f mgRegisterImporter>, <f mgRegisterExporter>, <f mgRegisterViewer>,
// <f mgRegisterEditor>
typedef mgstatus ( *mgtoolstartfunc )(
		mgplugintool pluginTool,		// @param the plug-in tool
		void* userData,					// @param user defined data specified when tool registered.
		void* callData						// @param pointer to tool specific callback record. <nl>
												// For image importers this points to
												// an <t mgimportercallbackrec> record.<nl>
												// For image exporters this points to
												// an <t mgexportercallbackrec> record.<nl>
												// For viewers this points to
												// an <t mgviewercallbackrec> record.<nl>
												// For editors this points to
												// an <t mgeditorcallbackrec> record.
		);


// @cb mgstatus | mgimageopenfunc | Image Open function for Image Importer Tools.   
// @desc This is the signature for image open functions.
// When you register an image importer plug-in tool, provide an open function
// of this form that is called when the API needs your tool to open an image file.
// @return <m MIMG_NO_ERROR> if successful, otherwise applicable texture error code.
// If successful, the parameter <p imageId> should be filled in with a unique integer
// value that will be used to identify the opened image in subsequent interactions
// between the API and your image importer tool.
// @see <f mgRegisterImageImporter>, <f mgSetReadImageGeoInfoFunc>
typedef mgstatus ( *mgimageopenfunc )(
		mgplugintool pluginTool,		// @param the plug-in tool
		void* userData,					// @param user defined data specified when tool registered.
		const char* filename,			// @param name of image file to open
		const char* filemode,			// @param mode to open file 'r for read, 'w' for write, 
												// currently only 'r' supported for image importers 
		int* imageid						// @param address of image identifier filled in by
												// image importer to identify this image for subsequent
												// interactions between API and tool.
		);


// @cb mgstatus | mgimageclosefunc | Image Close function for Image Importer Tools. 
// @desc This is the signature for image close functions.
// When you register an image importer plug-in tool, provide a close function
// of this form that is called when the API needs your tool to close an image file.
// @return Returns <m MIMG_NO_ERROR> if successful, otherwise returns applicable texture error code.
// @see <f mgRegisterImageImporter>, <f mgSetReadImageGeoInfoFunc>
typedef mgstatus ( *mgimageclosefunc )(
		mgplugintool pluginTool,		// @param the plug-in tool
		void* userData,					// @param user defined data specified when tool registered.
		int imageid							// @param image identifier indicating which image to close.
												// This is the value returned by the image open function when
												// the image was first opened.
		);


// @cb mgstatus | mgimagegetinfofunc | Image Get Info function for Image Importer Tools. 
// @desc This is the signature for image get info functions.
// When you register an image importer plug-in tool, provide a get info function
// of this form that is called when the API needs to get information about an image
// that your tool has opened.
// @return Returns <m MIMG_NO_ERROR> if successful, otherwise returns applicable texture error code.
// If successful, the parameter <p imageInfo> should be filled in with all pertinent
// image information using the <f mgSetTextureXXX> functions listed below.
// @see <f mgRegisterImageImporter>, <f mgSetReadImageGeoInfoFunc>,
// <f mgSetTextureWidth>, <f mgSetTextureHeight>,
// <f mgSetTextureType>, <f mgSetTextureSampleSize>, <f mgSetTextureTiledFlag>,
// <f mgSetTextureMinMax>, <f mgSetTextureTransparentValue>, <f mgSetTextureSignedFlag>
typedef mgstatus ( *mgimagegetinfofunc )(
		mgplugintool pluginTool,		// @param the plug-in tool
		void* userData,					// @param user defined data specified when tool is registered.
		int imageid,						// @param image identifier indicating which image to get info for.
												// This is the value returned by the image open function when
												// the image was first opened.
		mgimageinfo imageInfo			// @param image info object that your tool loads values into
												// for info attributes width, height, type, etc corresponding to
												// the specified image.
		);


// @cb mgstatus | mgimagegetgeoinfofunc | Image Get GeoInfo function for Image Importer Tools. 
// @desc This is the signature for image get geoinfo functions.
// When you register an image importer plug-in tool, you can add a get geoinfo function
// of this form that is called when the API needs to get georeferencing information about an image
// that your tool has opened.
// @return Returns <m MIMG_NO_ERROR> if successful, otherwise returns applicable texture error code.
// If successful, the parameter <p imageGeoInfo> must be filled in with all pertinent
// image information using the <f mgSetTextureXXX> functions listed below.  If not successful,
// no georeferencing data will be added to the imported image.
// @see <f mgRegisterImageImporter>, <f mgSetReadImageGeoInfoFunc>,
// <f mgSetTextureGeoType>, <f mgSetTextureGeoProjection>,
// <f mgSetTextureGeoEarthModel>, <f mgSetTextureGeoUTMZone>, <f mgSetTextureGeoUTMHemisphere>, 
// <f mgSetTextureGeoImageOrigin>,
// <f mgSetTextureGeoNumCtlPts>, <f mgSetTextureGeoCtlPt>

typedef mgstatus ( *mgimagegetgeoinfofunc )(
		mgplugintool pluginTool,		// @param the plug-in tool
		void* userData,					// @param user defined data specified when tool is registered.
		int imageid,						// @param image identifier indicating which image to get info for.
												// This is the value returned by the image open function when
												// the image was first opened.
		mgimagegeoinfo imageGeoInfo	// @param image geoinfo object that your tool loads values into
												// for geo info attributes Latitude, Longitude, type,
												// map projection, etc corresponding to the specified image.
		);


// @cb mgstatus | mgimagegettexelsfunc | Image Get Texels function for Image Importer Tools. 
// @desc This is the signature for image get texels functions.
// When you register an image importer plug-in tool, provide a get texels function
// of this form that is called when the API needs to get the texels for all or part
// of an image that your tool has opened.
// @return Returns <m MIMG_NO_ERROR> if successful, otherwise returns applicable texture error code.
// If successful, the parameter <p texels> should be filled in with the
// texels extracted from the image.
// @see <f mgRegisterImageImporter>, <f mgSetReadImageGeoInfoFunc>
typedef mgstatus ( *mgimagegettexelsfunc )(
		mgplugintool pluginTool,		// @param the plug-in tool
		void* userData,					// @param user defined data specified when tool registered
		int imageid,						// @param image identifier indicating which image to get texels for
												// This is the value returned by the image open function when
												// the image was first opened.
		int resolution,					// @param the reduction factor of the texels to be returned
												// (reserved for future enhancement), currently always 1
		unsigned char* texels			// @param the texels extracted from the image
		);

									
// @structtype | mgimportercallbackrec | 
// callback structure for database importer tool start functions.
// @desc When a database importer tool is launched, the corresponding
// start function is called.  The start function is passed a
// pointer to a record of this type in the <p callData> parameter. 
// @desc This record contains the name of the file selected by the 
// user in the Import File Dialog.  This is the file whose contents
// your tool is to import.  Also in this record is tool activation object
// from which you can obtain the identity of the database to which
// the imported database items are to be attached.
// @see <t mgtoolstartfunc>, <f mgGetActivationDb>
typedef struct {
	mgtoolactivation 	toolActivation;		// @field Tool activation
	char*             fileName;				// @field Name of file to import
} mgimportercallbackrec;

// @structtype | mgexportercallbackrec | 
// callback structure for database exporter tool start functions.
// @desc When a database exporter tool is launched, the corresponding
// start function is this type in the <p callData> parameter. 
// @desc This record contains a tool activation object from which
// you can obtain the identity of the database to export.  Also in this
// record is the name of the file selected by the user in the Export
// File Dialog.  This is the name of the file into which your tool 
// writes the exported file contents.
// @see <t mgtoolstartfunc>, <f mgGetActivationDb>
typedef struct {
	mgtoolactivation 	toolActivation;		// @field Tool activation
	char*					fileName;				// @field Name of file to export to
} mgexportercallbackrec;

// @structtype | mgviewercallbackrec | 
// callback structure for viewer tool start functions.
// @desc When a viewer tool is launched, the corresponding
// start function is called.  The start function is passed a
// pointer to a record of this type in the <p callData> parameter. 
// @desc This record contains a tool activation object from which
// you can obtain the identity of the top (focus) database.
// @see <t mgtoolstartfunc>, <f mgGetActivationDb>
typedef struct {
	mgtoolactivation 	toolActivation;		// @field Tool activation
} mgviewercallbackrec;

/*============================================================================*/

/* @doc EXTERNAL TOOLREGISTERFUNC */

/*============================================================================*/
/*                                                                            */
/* @func mgmodulehandle | mgGetModuleHandle | returns a native plug-in module handle.
	@desc <f mgGetModuleHandle> returns a platform specific handle to the specified
	plug-in module <p plugin>.

	@return For Windows NT, this function returns an object of type HINSTANCE.

	@access Level 4
	@see <f mgLoadResource>, <f mgGetModuleFilename>
*/
MGAPIFUNC(mgmodulehandle) mgGetModuleHandle (
		mgplugin plugin			// @param the plug-in module being queried
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetModuleFilename | returns the path and file name 
   associated with a plug-in.

	@desc <f mgGetModuleFilename> returns the full path and file name 
	specification for the plug-in module <p plugin>.

	@desc Storage for the file name is dynamically allocated by <f mgGetModuleFilename>.
	The user is responsible for deallocating the dynamically allocated memory with 
	<f mgFree>.

	@return Returns the path and file name if successful, otherwise <m MG_NULL>.	

	@access Level 4
	@see <f mgLoadResource>, <f mgGetModuleHandle>
*/
MGAPIFUNC(char*) mgGetModuleFilename (
		mgplugin plugin			// @param the plug-in module being queried
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetRegistryRoot | returns the root name of the Creator registry

	@desc <f mgGetRegistryRoot> returns the root path of the registry currently in
	use by Creator.  The output string is truncated and null terminated if it is
	longer than <p maxLen> characters. 

   @desc This function is only applicable on the Windows operation system platform
	in the Creator modeler environment.  This function will always return <e mgbool.MG_FALSE>
	when called by a stand-alone application or from any code running on IRIX.

	@return Returns <e mgbool.MG_TRUE> if the the root was found, <e mgbool.MG_FALSE>
	otherwise. If successful, the output parameter <p rootString> will contain the
	root path, otherwise it is undefined.

	@access Level 4
	@see <f mgGetRegistryString>, <f mgSetRegistryString>, 
	<f mgLoadResource>, <f mgGetModuleHandle>
*/
MGAPIFUNC(mgbool) mgGetRegistryRoot (
		char* rootString,		// @param character buffer to hold the root path
		int maxLen				// @param maximum number of characters to store in <p rootString>
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetRegistryString | returns the value of a Creator registry key

	@desc <f mgGetRegistryString> returns the value of the specified Creator registry
	key <p keyName> in the output string <p keyString>.  The output string is truncated
	and null terminated if it is longer than <p maxLen> characters. 

   @desc This function is only applicable on the Windows operation system platform
	in the Creator modeler environment.  This function will always return <e mgbool.MG_FALSE>
	when called by a stand-alone application or from any code running on IRIX.

	@desc The key is looked up in the Windows system registry corresponding to that
	currently in use by the running version of Creator.

	@return Returns <e mgbool.MG_TRUE> if the the key was found, <e mgbool.MG_FALSE>
	otherwise. If successful, the output parameter <p keyString> will contain the
	value of the key, otherwise it is undefined.

	@access Level 4
	@see <f mgSetRegistryString>, <f mgGetRegistryRoot>,
	<f mgLoadResource>, <f mgGetModuleHandle>
*/
MGAPIFUNC(mgbool) mgGetRegistryString (
		char* keyName,			// @param the name of the key to look up in the Creator
									// registry
		char* keyString,		// @param character buffer to hold the key value
		int maxLen				// @param maximum number of characters to store in <p keyString>
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetRegistryString | sets the value of a Creator registry key

	@desc <f mgSetRegistryString> sets the value of the specified Creator registry
	key <p keyName> to the string specified by <p keyString>.  

   @desc This function is only applicable on the Windows operation system platform
	in the Creator modeler environment.  This function will always return <e mgbool.MG_FALSE>
	when called by a stand-alone application or from any code running on IRIX.

	@desc The key is written to the Windows system registry corresponding to that
	currently in use by the running version of Creator.

	@return Returns <e mgbool.MG_TRUE> if the the key was set successfully, 
	<e mgbool.MG_FALSE> otherwise.

	@access Level 4
	@see <f mgGetRegistryString>, <f mgGetRegistryRoot>,
	<f mgLoadResource>, <f mgGetModuleHandle>
*/
MGAPIFUNC(mgbool) mgSetRegistryString (
		char* keyName,			// @param the name of the key to set in the Creator
									// registry
		char* keyString		// @param the value for the key
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgplugintool | mgRegisterImporter | registers a database importer tool.
	@desc <f mgRegisterImporter> registers a database importer tool for
	the specified plug-in module <p plugin> with the specified tool attributes.

	@desc The required tool attributes include the name of the tool <p toolName>,
	a start function for the tool, <p startFunc> and user defined callback data,
	<p userData> (may be <m MG_NULL>) that is passed to the start function
	when it is called.

	@desc Additional required tool attributes include 
	<m MTA_FILTER> and <m MTA_FILETYPE>.  Additional optional tool attributes 
	include <m MTA_VERSION>.  These additional tool attributes are passed
	using variable argument style and must be terminated with 
	<m MG_NULL>.

	@return Handle to plug-in tool registered if successful, <m MG_NULL>
	otherwise.

	@access Level 4
	@see <f mgRegisterExporter>
*/
MGAPIFUNC(mgplugintool) mgRegisterImporter ( 
		mgplugin plugin,					// @param the plug-in module registering the tool
		const char* toolName,			// @param the name of the tool
		mgtoolstartfunc startFunc,		// @param the tool start function that is called
												// when the tool is launched
		void* userData,					// @param user defined data that will be passed to
												// <p startFunc> when it is called
		...									// @param | ... | additional database importer
												// tool specific attributes in variable argument 
												// style
		);
/*                                                                            */
/*============================================================================*/
															 
/*============================================================================*/
/*                                                                            */
/* @func mgplugintool | mgRegisterExporter | registers a database exporter tool
	@desc <f mgRegisterExporter> registers a database exporter tool for
	the specified plug-in module <p plugin> with the specified tool attributes.

	@desc The required tool attributes include the name of the tool <p toolName>,
	a start function for the tool, <p startFunc> and user defined callback data,
	<p userData> (may be <m MG_NULL>) that is passed to the start function
	when it is called.

	@desc Additional required database exporter tool attributes include 
	<m MTA_FILTER> and <m MTA_FILETYPE>.  These additional tool attributes
	are passed using variable argument style and must be terminated with 
	<m MG_NULL>.

	@return handle to plug-in tool registered if successful, <m MG_NULL>
	otherwise.

	@access Level 4
	@see <f mgRegisterImporter>
*/
MGAPIFUNC(mgplugintool) mgRegisterExporter ( 
		mgplugin plugin,					// @param the plug-in module registering the tool
		const char* toolName,			// @param the name of the tool
		mgtoolstartfunc startFunc,		// @param the tool start function that is called
												// when the tool is launched
		void* userData,					// @param user defined data that will be passed to
												// <p startFunc> when it is called
		...									// @param | ... | additional database exporter
												// tool specific attributes in variable argument
												// style
		);
/*                                                                            */
/*============================================================================*/
															 
/*============================================================================*/
/*                                                                            */
/* @func mgplugintool | mgRegisterEditor | registers an editor tool
	@desc <f mgRegisterEditor> registers an editor tool for
	the specified plug-in module <p plugin> with the specified tool attributes.

	@desc The required tool attributes include the name of the tool <p toolName>,
	a start function for the tool, <p startFunc> and user defined callback data,
	<p userData> (may be <m MG_NULL>) that is passed to the start function
	when it is called.

	@desc Additional required tool attributes include launch location attributes.
	Your tool can be launched from either a tool palette or menu. If your tool
	is to be launched from a tool palette, you must specify
	<m MTA_PALETTELOCATION> and <m MTA_PALETTEICON>.  If your tool is to be
	launched from a menu, you must specify <m MTA_MENULOCATION> and
	<m MTA_MENULABEL>.  Additional optional tool attributes for tools launched
	from a menu include <m MTA_MENUPOSITION> and <m MTA_MENUSUBMENU>.

	@desc Additional optional tool attributes for all editor tools
	include <m MTA_VERSION>, <m MTA_HELPCONTEXT> and <m MTA_TOOLTIP>.  
	If you specify that your tool be launched from a tool palette and
	do not specify <m MTA_TOOLTIP>, the default
	tool tip text displayed is the name of your tool as specified in the
	parameter <p toolName>.

	@desc All additional (required and optional) tool attributes are passed
	using variable argument style and must be terminated with 
	<m MG_NULL>.

	@return Handle to plug-in tool registered if successful, <m MG_NULL>
	otherwise.

	@access Level 4
	@see <f mgRegisterViewer>
	<f mgEditorSetVertexFunc>,
	<f mgEditorSetPointFunc>, <f mgEditorSetPickFunc>,
	<f mgEditorSetTerminateFunc>, <f mgEditorSetCreateDialogFunc>,
	<f mgEditorSetButtonFunc>, 
	
*/
MGAPIFUNC(mgplugintool) mgRegisterEditor ( 
		mgplugin plugin,					// @param the plug-in module registering the tool
		const char* toolName,			// @param the name of the tool
		mgtoolstartfunc startFunc,		// @param the tool start function that is called
												// when the tool is launched
		void* userData,					// @param user defined data that will be passed to
												// <p startFunc> when it is called
		...									// @param | ... | additional editor tool
												// specific attributes in variable argument style 
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgplugintool | mgRegisterViewer | registers a viewer tool
	@desc <f mgRegisterViewer> registers a viewer tool for
	the specified plug-in module <p plugin> with the specified tool attributes.

	@desc The required tool attributes include the name of the tool <p toolName>,
	a start function for the tool, <p startFunc> and user defined callback data,
	<p userData> (may be <m MG_NULL>) that is passed to the start function
	when it is called.

	@desc Additional required tool attributes include launch location attributes.
	Your tool can be launched from either a tool palette or menu.
	If your tool is to be launched from a tool palette, you must specify
	<m MTA_PALETTELOCATION> and <m MTA_PALETTEICON>.
	If your tool is to be launched from a menu, you must specify
	<m MTA_MENULOCATION> and <m MTA_MENULABEL>.  Additional optional tool
	attributes for tools launched from a menu include <m MTA_MENUPOSITION>
	and <m MTA_MENUSUBMENU>.

	@desc Additional optional tool attributes for all viewer tools include 
	<m MTA_VERSION>, <m MTA_HELPCONTEXT> and <m MTA_TOOLTIP>.  If you specify that
	your tool be launched from a tool	palette and do not specify <m MTA_TOOLTIP>,
	the default tool tip text displayed is the name of your tool as specified in
	the parameter <p toolName>.

	@desc All additional (required and optional) tool attributes are passed
	using variable argument style and must be terminated with 
	<m MG_NULL>.

	@return Handle to plug-in tool registered if successful, <m MG_NULL>
	otherwise.

	@access Level 4
	@see <f mgRegisterEditor>
*/
MGAPIFUNC(mgplugintool) mgRegisterViewer ( 
		mgplugin plugin,					// @param the plug-in module registering the tool
		const char* toolName,			// @param the name of the tool
		mgtoolstartfunc startFunc,		// @param the tool start function that is called
												// when the tool is launched
		void* userData,					// @param user defined data that will be passed to
												// <p startFunc> when it is called
		...									// @param | ... | additional viewer tool
												// specific attributes in variable argument style
		);
/*                                                                            */
/*============================================================================*/
															 

/*============================================================================*/
/*                                                                            */
/* @func mgplugintool | mgRegisterImageImporter | registers an image importer tool
	@desc <f mgRegisterImageImporter> registers an image importer tool for
	the specified plug-in module <p plugin> with the specified tool attributes.

	@desc The required tool attributes include the name of the tool <p toolName>,
	a start function for the tool, <p startFunc> and user defined callback data,
	<p userData> (may be <m MG_NULL>) that is passed to the start function
	when it is called.

	@desc Additional required tool attributes include 
	<m MTA_FILTER> and <m MTA_FILETYPE>.  Additional optional tool attributes 
	include <m MTA_VERSION>.  These additional tool attributes are passed
	using variable argument style and must be terminated with 
	<m MG_NULL>.

	@return Handle to plug-in tool registered if successful, <m MG_NULL>
	otherwise.

	@access Level 4
	@see <f mgSetReadImageGeoInfoFunc>
*/

MGAPIFUNC(mgplugintool) mgRegisterImageImporter ( 
		mgplugin plugin,								// @param the plug-in module registering the tool
		const char* toolName,						// @param the name of the tool
		int importFlags,								// @param image importer capability flags (reserved
															// for future enhancement)
		mgimageopenfunc openFunc,					// @param open callback function for image importer
		mgimageclosefunc closeFunc,				// @param close callback function for image importer
		mgimagegetinfofunc getInfoFunc,			// @param get info callback function for image importer
		mgimagegettexelsfunc getTexelsFunc,		// @param get texels callback function for image importer
		void* userData,								// @param user defined data that will be passed to
															// your import action functions <p openFunc>, 
															// <p closeFunc>, <p getInfoFunc> and 
															// <p getTexelsFunc> when they are called
		...												// @param | ... | additional viewer tool
															// specific attributes in variable argument style
		);
/*                                                                            */
/*============================================================================*/
															 
/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgSetReadImageGeoInfoFunc | sets a get geoinfo function 
	for an image importer plug-in tool.

	@desc When you register an image importer plug-in tool, you can add a 
	get geoinfo function using <f mgSetReadImageGeoInfoFunc>.  The function
	you register is called when the API needs to get georeferencing information
	about an image that your tool has opened.

	@return Use macro <m MSTAT_ISOK> to check return value for success.

	@access Level 4
	@see <f mgRegisterImageImporter>
*/

MGAPIFUNC(mgstatus) mgSetReadImageGeoInfoFunc (
		mgplugin plugin,								// @param the plug-in module that registered
															// the image importer plug-in tool
		mgplugintool pluginTool,					// @param the image importer plug-in tool to
															// which the get geoinfo function is to be
															// added
		mgimagegetgeoinfofunc getGeoInfoFunc,	// @param the get geoinfo function
		void* userData									// @param user defined data that 
															// will be passed to <p getGeoInfoFunc>
															// when it is called
		);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func void | mgUnregisterAllTools | unregisters all tools for a plug-in
	@desc <f mgUnregisterAllTools> unregisters all previously registered tools
	for a specified plug-in module <f plugin>.

	@desc After calling this function, all tools registered for the plug-in
	become inaccessible.  You should only call this function from your
	plug-in termination function <f mgpExit>. 

	@access Level 4

	@see <f mgRegisterImporter>, <f mgRegisterExporter>, <f mgRegisterViewer>, 
	<f mgRegisterEditor>, <f mgRegisterImageImporter>
*/
MGAPIFUNC(void) mgUnregisterAllTools (
		mgplugin plugin		// @param the plug-in module to unregister all tools for.
		);
/*                                                                            */
/*============================================================================*/

MGAPIFUNC(mgbool) mgLicenseIsReadOnly ( mgplugin pluginDesc );
															 												
/*============================================================================*/
		
#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */



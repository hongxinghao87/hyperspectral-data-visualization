/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIIO2_H_
#define MGAPIIO2_H_
/* @doc EXTERNAL IOFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgWriteDb | writes a database to disk
	@desc Given the database node, <p db>, <f mgWriteDb> writes this 
	database to disk using the file name stored in the database header. 
	The file name must first be opened and initialized with either the 
	<f mgOpenDb> or <f mgNewDb> functions, which associate the database 
	with a file name.  

	@desc Note: This function is for use in stand alone applications only, 
	and should not be called from inside a plug-in.  Doing so may yield
	undefined results.

	@param mgrec * | db | the database node of the database to write

	@return   returns <e mgbool.MG_TRUE> on success; 
	otherwise returns <e mgbool.MG_FALSE> 

	@ex  |
	mgrec *db1, *db2;
	db1 = mgOpenDb ( "file1.flt" );
	db2 = mgNewDb ( "newfile.flt" );
   
	//  Perform updates to databases

	mgWriteDb ( db1 );
	mgWriteDb ( db2 );

	@access Level 2
	@see <f mgOpenDb>, <f mgNewDb>, <f mgCloseDb>

*/
extern MGAPIFUNC(mgbool) mgWriteDb ( mgrec* db );
/*                                                                            */
/*============================================================================*/
 
   
/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSaveAsDb | writes a database to disk with a 
	different name than the name with which it was opened
	@desc Given the database node, <p db>, and a filename, <p fileName>, 
	<f mgSaveAsDb> writes this database to disk using the filename. 
	The given filename is stored in the database record as the new file name.  

	@param mgrec * | db | the database node of the database to write
	@param char * | fileName | the new file name

	@return   returns <e mgbool.MG_TRUE> on success; 
	otherwise returns <e mgbool.MG_FALSE> 

	@ex | 
	mgrec *db1;
	db1 = mgOpenDb ( "file1.flt" );
	mgSaveAsDb ( db1, "newname.flt" );

	@access Level 2
	@see <f mgOpenDb>, <f mgNewDb>, <f mgCloseDb>, <f mgWriteDb>, 
	<f mgSetNewOverwriteFlag>
*/
extern MGAPIFUNC(mgbool) mgSaveAsDb ( mgrec *db, char *fileName );
/*                                                                            */
/*============================================================================*/
 
   
/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

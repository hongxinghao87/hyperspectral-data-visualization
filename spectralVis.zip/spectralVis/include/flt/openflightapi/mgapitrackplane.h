/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPITRACKPLANE_H_
#define MGAPITRACKPLANE_H_
// @doc EXTERNAL GRAPHICVIEWFUNC

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif
/*============================================================================*\
	include files
\*============================================================================*/

#include "mgapibase.h"

/*============================================================================*\
	public constants
\*============================================================================*/

/*============================================================================*\
	private types
\*============================================================================*/

/*============================================================================*\
	public types
\*============================================================================*/

/*============================================================================*\
	public methods
\*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentTrackPlane | gets the current modeling trackplane

	@desc <f mgGetCurrentTrackPlane> returns the equation of the current modeling 
	trackplane in a <t mgplaned> structure.

	@return <e mgbool.MG_TRUE> if sucessful; <e mgbool.MG_FALSE> otherwise. If
	successful, the output parameter <p trackplane> will be filled in with the
	corresponding values, otherwise it will be undefined.

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentTrackPlane ( 
	mgrec* db,					// @param the database
	mgplaned* trackplane		// @param the current track plane equation
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetCurrentGridMatrix | gets the current modeling grid
	matrix

	@desc <f mgGetCurrentGridMatrix> returns a matrix that can be used to
	normalize the position of the current grid in the Creator graphic view.
	This matrix, returned in the output parameter, <p matrix> describes the
	transformation that moves the grid from its current position and
	orientation to the database origin aligned with the X and Y axes.

	@desc The function <f mgMatrixInvert> can be used to obtain the inverse
	of this grid matrix.  This inverse matrix describes the
	transformation that transforms a coordinate in world space
	back onto the grid in its current position and orientation.

	@return <e mgbool.MG_TRUE> if sucessful; <e mgbool.MG_FALSE> otherwise. If
	successful, the output parameter <p gridIn> will be filled
	in with the matrix described above, otherwise it will be undefined.

	@access Level 4
*/
extern MGAPIFUNC(mgbool) mgGetCurrentGridMatrix ( 
	mgrec* db,					// @param the database
	mgmatrix* matrix			// @param address of matrix to receive grid matrix
	);
/*                                                                            */
/*============================================================================*/


/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPITRACKPLANE_H_ */
/* DON'T ADD STUFF AFTER THIS #endif */

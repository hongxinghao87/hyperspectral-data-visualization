/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPIDIALOG_H_
#define MGAPIDIALOG_H_

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#ifdef API_LEV5
#include "mgapidialog4.h"
#include "mgapires.h"
#endif

#ifdef API_LEV4
#include "mgapidialog4.h"
#include "mgapires.h"
#endif

#ifdef API_LEV3
#include "mgapidialog4.h"
#endif

#ifdef API_LEV2
#endif

#ifdef API_LEV1
#endif

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */


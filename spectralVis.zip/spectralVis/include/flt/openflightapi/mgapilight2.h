/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPILIGHT2_H_
#define MGAPILIGHT2_H_
// @doc EXTERNAL LIGHTSOURCEFUNC

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/*	@func mgrec * | mgNewLightSource | creates a new entry in the light
	source palette

   @desc <f mgNewLightSource> creates a new light source 
	palette entry for database <p db>.  The new entry is assigned the specified
	<p name> and returned if created successfully.  The index assigned to the new
	entry is also returned in <p index>.  The attributes of the new entry
	can be set using <f mgSetAttList>.

	@return Returns the light source palette entry record if successful, 
	<m MG_NULL> otherwise.  If successful, the parameter <p index> will contain
	the index of the new entry, otherwise this value is undefined.

	@access Level 2
	@see <f mgGetLightSource>
*/
extern MGAPIFUNC(mgrec *) mgNewLightSource (
	mgrec* db,		// @param the database node
	char* name, 	// @param name to assign to the new light source
	int* index		// @param address of value to receive index assigned to 
						// new entry in the palette
	);
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgDeleteLightSource | deletes an entry in the light
	source palette

   @desc <f mgDeleteLightSource> deletes a light source 
	palette entry for database <p db>.  The entry deleted is specified by <p index>.

	@return Returns <e mgbool.MG_TRUE> if the entry was deleted successfully, 
	<e mgbool.MG_FALSE> otherwise. 

	@access Level 2
	@see <f mgNewLightSource>
*/
extern MGAPIFUNC(mgbool) mgDeleteLightSource (
	mgrec* db,		// @param the database node
	int index		// @param the index of the entry to delete
	);
/* @deprecated mgDelLightSource | Use <f mgDeleteLightSource> */
/*============================================================================*/
 

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgWriteLightSourceFile | writes a light source palette 
	as a disk file
   
	@desc <f mgWriteLightSourceFile> writes the light source palette for
	database <p db> to a disk file named <p fileName>.

	@return Returns <e mgbool.MG_TRUE> if the file was written successfully, 
	<e mgbool.MG_FALSE> otherwise.

	@access Level 2
*/
extern MGAPIFUNC(mgbool) mgWriteLightSourceFile (
	mgrec* db,			// @param the database node
	char* fileName		// @param the name of the file to write
	);
/*                                                                            */
/*============================================================================*/
 


/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

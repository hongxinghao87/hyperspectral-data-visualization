/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIALL_H_
#define MGAPIALL_H_

/*----------------------------------------------------------------------------*/

#include "mgapistd.h"
#include "mgapixform.h"
#include "mgapicoord.h"
#include "mgapidecl.h"
#include "mgdddecl.h"
#include "mgapill.h"
#include "mgapiattr.h"
#include "mgapibase.h"
#include "mgapicolor.h"
#include "mgapigeom.h"
#include "mgapiinfo.h"
#include "mgapiio.h"
#include "mgapilight.h"
#include "mgapilightpoint.h"
#include "mgapisound.h"
#include "mgapimaterial.h"
#include "mgapimath.h"
#include "mgapimem.h"
#include "mgapipref.h"
#include "mgapistack.h"
#include "mgapistruc.h"
#include "mgapitexture.h"
#include "mgapieyepoint.h"
#include "mgapitxtrmap.h"
#include	"mgapiptrarray.h"
#include "mgapiutil.h"
#include "mgapiselect.h"
#include "mgapiplugin.h"
#include "mgapidialog.h"
#include "mgapieditor.h"
#include "mgapitoolactivation.h"
#include "mgapitrackplane.h"
#include "mgapiresource.h"
#include "mgapinotifier.h"
#include "mgapitimer.h"
#include "mgapigl.h"
#include "mgapiinputdev.h"
#include "mgapihelp.h"
#include "fltcode.h"
#include "mgapi_deprecated.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */

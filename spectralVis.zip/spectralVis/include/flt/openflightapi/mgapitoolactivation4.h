/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPITOOLACTIVATION4_H_
#define MGAPITOOLACTIVATION4_H_
/* @doc EXTERNAL TOOLACTIVATIONFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapidecl.h"
#include "mgapistd.h"
#include "mgapiplugin4.h"
#include "mgapimatrix.h"

/*============================================================================*\
	Typedefs
\*============================================================================*/


/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetActivationDb | retrieves the database node from a tool
	activation object.
	@desc <f mgGetActivationDb> retrieves the database node associated to
	the specific tool activation object <p toolActivation>.  

	@desc When a plug-in tool is launched, the corresponding start function 
	is called.  The start function is passed a tool specific callback
	record that is contain a tool activation object.  Among other things,
	this tool activation object contains the top database or focus database
	for which the tool was launched.

	@desc Use this function to extract the focus database from a tool
	activation object.

	@return Returns the database node referenced in the specified tool 
	activation object if the
	tool activation is valid, <m MG_NULL> otherwise.

	@access Level 4
	@see <t mgimportercallbackrec>, <t mgexportercallbackrec>, 
	<t mgviewercallbackrec>, <t mgeditorcallbackrec> 
*/
extern MGAPIFUNC(mgrec*) mgGetActivationDb (
	mgtoolactivation toolActivation			// @param the tool activation 
														// to get database node for
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetModelingParent | returns current modeling parent.
	@desc <f mgGetModelingParent> returns the current modeling parent node
	for the specified database <p db>. 

	@return Returns the current modeling parent node for database if one is set, 
	<m MG_NULL> otherwise.

	@access Level 4
	@see <f mgGetActivationDb>, <f mgGetModelingMode>, <f mgGetModelingParentMatrix>
*/
extern MGAPIFUNC(mgrec*) mgGetModelingParent (
	mgrec* db			// @param the database node to get modeling parent for
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetDefaultModelingParent | returns default modeling parent.

	@desc <f mgGetDefaultModelingParent> returns the default modeling parent node
	for the specified database <p db>.  
	
	@desc In Creator, the user specifies whether or not the default parent
	is allowed for modeling (this is set on the Preferences Window in Creator).
	If it is allowed, the default parent is always a node of type <f fltGroup>.

	@return Returns the default modeling parent node for database <p db> if this is
	allowed by the user,	<m MG_NULL> otherwise. 

	@access Level 4
	@see <f mgGetActivationDb>, <f mgGetModelingMode>, <f mgGetModelingParent>,
	<f mgGetModelingParentMatrix>
*/
extern MGAPIFUNC(mgrec*) mgGetDefaultModelingParent (
	mgrec* db				// @param the database node to get modeling parent for
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetModelingParentMatrix | returns current modeling parent
	and a matrix representing the cumulative transformation matrix applied
	to this parent node.

	@desc Similar to <f mgGetModelingParent>, <f mgGetModelingParentMatrix> returns
	the current modeling parent node for the specified database <p db>.  Additionally,
	<f mgGetModelingParentMatrix> returns a <p matrix> that represents the cumulative
	transformation matrix applied to the parent node returned.

	@desc The function <f mgMatrixInvert> can be used to obtain the inverse
	of this modeling parent matrix.  This inverse matrix describes the
	transformation that transforms a coordinate in world space back to local
	space under the current modeling parent.

	@return Returns the current modeling parent node for database if one is set, 
	<m MG_NULL> otherwise.  If a parent node is returned, the output parameter
	<p matrix> is loaded with the composite matrix representing the cumulative
	transformations aapplied to this parent node.

	@access Level 4
	@see <f mgGetActivationDb>, <f mgGetModelingMode>, <f mgGetModelingParent>
*/
extern MGAPIFUNC(mgrec*) mgGetModelingParentMatrix (
	mgrec* db,				// @param the database node to get modeling parent for
	mgmatrix* matrix		// @param address of matrix to receive parent matrix
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgcode | mgGetModelingMode | returns current modeling mode.
	@desc <f mgGetModelingMode> returns the current modeling mode
	for the specified database <p db>. 

	@return Returns current modeling mode for database if valid, 0 (zero) otherwise.

	@access Level 4
	@see <f mgGetActivationDb>, <f mgGetModelingParent>
*/
extern MGAPIFUNC(mgcode) mgGetModelingMode (
	mgrec* db			// @param the database node to get modeling mode for
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgSetModelingMode | sets current modeling mode.
	@desc <f mgSetModelingMode> sets the current modeling mode
	for the specified database <p db> to the specified level, <p mode>. 

	@return Returns <e mgbool.MG_TRUE> if successful, <e mgbool.MG_FALSE> otherwise.

	@access Level 4
	@see <f mgGetModelingMode>, <f mgGetModelingParent>
*/
extern MGAPIFUNC(mgbool) mgSetModelingMode (
	mgrec* db,			// @param the database node to set modeling mode for
	mgcode mode			// @param the modeling mode to set
	); 
/*                                                                            */
/*============================================================================*/

/*============================================================================*/

#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */



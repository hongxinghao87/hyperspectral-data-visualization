/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#ifndef MGAPIMATERIAL1_H_
#define MGAPIMATERIAL1_H_
/* @doc EXTERNAL MATERIALFUNC */

/*----------------------------------------------------------------------------*/

#include "mgapibase.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetMaterial | gets an entry record from a 
	database�s material palette.
	@desc <f mgGetMaterial> gets the material entry record defined by 
	<p index> from the material palette of database node <p db>. 

	@return Returns the material entry record if successfully found, 
	<m MG_NULL> if otherwise. 

	@access Level 1
	@see <f mgIndexOfMaterial>, <f mgNewMaterial>
*/
extern MGAPIFUNC(mgrec*) mgGetMaterial ( 
		mgrec* db,		/* @param the database node */
		int index		/* @param the material palette index */
		);
 
/*============================================================================*/
/*                                                                            */
/* @func int | mgIndexOfMaterial | gets the index of a named 
	material palette entry.
	@desc <p mgIndexOfMaterial> returns the index of the material palette 
	entry record named <p name> in the material table of database node 
	<p db>.

	@return Returns the index of the named material palette entry, 
	or -1 if no entry is found. 

	@access Level 1
	@see <f mgGetMaterial>, <f mgNewMaterial>
*/
extern MGAPIFUNC(int) mgIndexOfMaterial (
		mgrec* db,		/* @param the database node */
		char* name		/* @param the name of the material entry to search for */
		);
 
/*============================================================================*/
/*                                                                            */
/* @func char* | mgNameOfMaterial |  gets the name of a material 
	palette entry.
	@desc <p mgNameOfMaterial> returns a pointer, <p name>  to the name of the 
	material entry record <p index> in the material palette of database node 
	<p db>.  If the material with that index is not found, 
	<m MG_NULL> is returned.  Storage for the name is dynamically allocated by 
	<f mgNameOfMaterial>.  

	Note: the user is responsible for deallocating the dynamically 
	allocated memory with <f mgFree>.

	@return Returns a pointer to the name of the material,  
	if a material name was found; otherwise returns  <m MG_NULL>. 

	@access Level 1
	@see <f mgGetMaterial>, <f mgIndexOfMaterial>, <f mgNewMaterial>
*/
extern MGAPIFUNC(char*) mgNameOfMaterial (
		mgrec* db,		/* @param the database node */
		int index		/* @param the index of the material palette entry */
		);

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetMaterialCount |  gets the number of entries in a 
	database�s material palette.
	@desc Given a database node, <p db>, <f mgGetMaterialCount> gets the number 
	of entries in the database�s material palette.

	@return Returns the number of entries in the database�s material palette. 

	@access Level 1
	@see <f mgGetFirstMaterial>, <f mgGetNextMaterial>
*/
extern MGAPIFUNC(int) mgGetMaterialCount (
		mgrec* db		/* @param the database node */
		);

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetFirstMaterial | gets the first entry from a 
	database�s material palette.

	@desc Given a database node <p db>, <f mgGetFirstMaterial> gets the 
	first entry record from the database�s material palette. 
	The index of the material record is returned in  <p index>.  
	If the first material entry record is found, it is returned.  
	If it is not found, <m MG_NULL> is returned.

	@return Returns the first material palette entry in the database�s
	material palette. 

	@access Level 1
	@see <f mgGetMaterialCount>, <f mgGetNextMaterial>
*/
extern MGAPIFUNC(mgrec*) mgGetFirstMaterial (
		mgrec* db,		/* @param the database node */
		int* index		/* @param the returned index of the material  */
							/* palette entry record
							 */
		);

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetNextMaterial | gets the next material palette 
	entry record from the material palette.
	@desc Given a material record pointer <p matrec>, <f mgGetNextMaterial> 
	gets the next material entry record from the material palette. 
	The index of the next material record is returned in <p index>.  
	If successfully found, the next material entry record is returned.  
	If unsuccessful, <m MG_NULL> is returned.

	@return Returns the next material palette entry, <m MG_NULL> if unsuccessful. 

	@access Level 1
	@see <f mgGetMaterialCount>, <f mgGetFirstMaterial>
*/
extern MGAPIFUNC(mgrec*) mgGetNextMaterial (
		mgrec* matrec,		/* @param the previous material palette entry record */
		int* index			/* @param the index of the returned material palette  */
								/* entry record or -1 if there is none
								 */
		);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetMaterialElem | gets the material components of a record. 
	@desc Given a <flt fltIMaterial> or <flt fltPolygon> record, this function 
	extracts the individual material components of that record.  If <p rec>
	is a <flt fltIMaterial> record, this function extracts the components 
	directly from <p rec>.  If <p rec> is a <flt fltPolygon> record, this 
	function extracts the components from the material assigned to the polygon.

	@return Returns <e mgbool.MG_TRUE> if the material components are found. 
	Returns <e mgbool.MG_FALSE> if the record doesn�t have material properties. 

	@access Level 1
	@see <f mgGetFirstMaterial>, <f mgGetNextMaterial>
*/
extern MGAPIFUNC(mgbool) mgGetMaterialElem ( 
			mgrec* rec,				/* @param the material record pointer  */
			float* ambred,			/* @param the pointer for the ambient red value */
			float* ambgreen,		/* @param the pointer for the ambient green value */
			float* ambblue,		/* @param the pointer for the ambient blue value */
			float* difred,			/* @param the pointer for the diffuse red value */
			float* difgreen,		/* @param the pointer for the diffuse green value */
			float* difblue,		/* @param the pointer for the diffuse blue value */
			float* spered,			/* @param the pointer for the specular red value */
			float* spegreen,		/* @param the pointer for the specular green value */
			float* speblue,		/* @param the pointer for the specular blue value */
			float* emired,			/* @param the pointer for the emissive red value */
			float* emigreen,		/* @param the pointer for the emissive green value */
			float* emiblue,		/* @param the pointer for the emissive blue value */
			float* shine,			/* @param the pointer for the shininess value */
			float* alpha			/* @param the pointer for the alpha (transparency) value */
			);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadMaterialFile | reads in a material file as 
	a database�s current material palette.
	@desc Given a database node, <p db>, and a material file <p fileName>,
	<f mgReadMaterialFile> reads the material entries contained in the file
	and replaces the database's material palette with those entries read.

	@desc Existing material records all become invalid.

	@return Returns <e mgbool.MG_TRUE> if the material palette file was 
	read successfully, otherwise <e mgbool.MG_FALSE>. 

   @see <f mgWriteMaterialFile>

	@access Level 1
*/
extern MGAPIFUNC(mgbool) mgReadMaterialFile ( 
			mgrec* db,			/* @param the database node */
			char* fileName		/* @param the material file name */
			);

/*============================================================================*/


#ifdef __cplusplus
}
#endif

#endif
/* DON'T ADD STUFF AFTER THIS #endif */


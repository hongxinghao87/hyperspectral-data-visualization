/* 
 ============================================================================== 

                               MULTIGEN-PARADIGM 
                  Copyright (c) 1984-2003 by MultiGen-Paradigm 

   No part of this source code may be reproduced or distributed in any form 
   or by any means, or stored in a database or retrieval system, without the 
   prior written consent of MultiGen-Paradigm. 

 ============================================================================== 
*/

/*----------------------------------------------------------------------------*/

#pragma once
#ifndef MGAPITEXTURE1_H_
#define MGAPITEXTURE1_H_
/* @doc EXTERNAL TEXTUREFUNC */

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*\
	include files
\*============================================================================*/

#include "mgapibase.h"

/*============================================================================*\
	public constants
\*============================================================================*/

/*----------------------------------------------------------------------------*\
	Basic Image Types
\*----------------------------------------------------------------------------*/

#define MIMG_INT		2					// @msg MIMG_INT | Texture Image Type <p Intensity>
												// @desc This is a valid value for the image type attribute.
												// @see <f mgRegisterImageImporter>, <f mgSetTextureType>,
												// <f mgGetTextureType>

#define MIMG_INTA		3					// @msg MIMG_INTA | Texture Image Type <p Intensity/Alpha>
												// @desc This is a valid value for the image type attribute.
												// @see <f mgRegisterImageImporter>, <f mgSetTextureType>,
												// <f mgGetTextureType>

#define MIMG_RGB		4					// @msg MIMG_RGB | Texture Image Type <p RGB>
												// @desc This is a valid value for the image type attribute.
												// @see <f mgRegisterImageImporter>, <f mgSetTextureType>,
												// <f mgGetTextureType>

#define MIMG_RGBA		5					// @msg MIMG_RGBA | Texture Image Type <p RGBA>
												// @desc This is a valid value for the image type attribute.
												// @see <f mgRegisterImageImporter>, <f mgSetTextureType>,
												// <f mgGetTextureType>


#define MIMG_NO_ERROR			0		// @msg MIMG_NO_ERROR | [0] Texture return status indicating success
												// @see [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_MALLOC_ERR			-1		// @msg MIMG_MALLOC_ERR | (-1) Texture return status indicating allocation error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_OPEN_ERR			-2		// @msg MIMG_OPEN_ERR | (-2) Texture return status indicating open error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_READ_ERR			-3		// @msg MIMG_READ_ERR | (-3) Texture return status indicating read error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_WRITE_ERR			-4		// @msg MIMG_WRITE_ERR | (-4) Texture return status indicating write error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_SEEK_ERR			-5		// @msg MIMG_SEEK_ERR | (-5) Texture return status indicating seek error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_BAD_FILE_TYPE		-6		// @msg MIMG_BAD_FILE_TYPE | (-6) Texture return status indicating bad file error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_IMAGE_TOO_BIG		-7		// @msg MIMG_IMAGE_TOO_BIG | (-7) Texture return status indicating error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_BAD_DATA			-8		// @msg MIMG_BAD_DATA | (-8) Texture return status indicating error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_NO_TILE				-9		// @msg MIMG_NO_TILE | (-9) Texture return status indicating error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-10] <m MIMG_TILE_READ_ERR> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_TILE_READ_ERR		-10	// @msg MIMG_TILE_READ_ERR | (-10) Texture return status indicating error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-11] <m MIMG_TILE_WRITE_ERR>

#define MIMG_TILE_WRITE_ERR	-11	// @msg MIMG_TILE_WRITE_ERR | (-11) Texture return status indicating error
												// @see [0] <m MIMG_NO_ERROR> <nl>
												// [-1] <m MIMG_MALLOC_ERR> <nl>
												// [-2] <m MIMG_OPEN_ERR> <nl>
												// [-3] <m MIMG_READ_ERR> <nl>
												// [-4] <m MIMG_WRITE_ERR> <nl>
												// [-5] <m MIMG_SEEK_ERR> <nl>
												// [-6] <m MIMG_BAD_FILE_TYPE> <nl>
												// [-7] <m MIMG_IMAGE_TOO_BIG> <nl>
												// [-8] <m MIMG_BAD_DATA> <nl>
												// [-9] <m MIMG_NO_TILE> <nl>
												// [-10] <m MIMG_TILE_READ_ERR>

#define MIMG_GEOTYPE_CTRLPT		0	// @msg MIMG_GEOTYPE_CTRLPT | Texture Geographic Control Type <p Control Point>
												// @desc This is a valid value for the image geographic control type attribute.
												// @see <f mgGetTextureGeoType>, <f mgSetTextureGeoType>


#define MIMG_GEOPROJ_GEODETIC		0	// @msg MIMG_GEOPROJ_GEODETIC | Texture Geographic Projection <p Geodetic>
												// @desc This is a valid value for the image geographic projection attribute.
												// @see <f mgGetTextureGeoProjection>, <f mgSetTextureGeoProjection>

#define MIMG_GEOPROJ_UTM			4	// @msg MIMG_GEOPROJ_UTM | Texture Geographic Projection <p UTM>
												// @desc This is a valid value for the image geographic projection attribute.
												// @see <f mgGetTextureGeoProjection>, <f mgSetTextureGeoProjection>


#define MIMG_GEOEARTH_WGS84		0	// @msg MIMG_GEOEARTH_WGS84 | Texture Geographic Earth Model <p WGS84>
												// @desc This is a valid value for the image geographic Earth model attribute.
												// @see <f mgGetTextureGeoEarthModel>, <f mgSetTextureGeoEarthModel>

#define MIMG_GEOEARTH_WGS72		1	// @msg MIMG_GEOEARTH_WGS72 | Texture Geographic Earth Model <p WGS72>
												// @desc This is a valid value for the image geographic Earth model attribute.
												// @see <f mgGetTextureGeoEarthModel>, <f mgSetTextureGeoEarthModel>

#define MIMG_GEOEARTH_BESSEL		2	// @msg MIMG_GEOEARTH_BESSEL | Texture Geographic Earth Model <p Bessel>
												// @desc This is a valid value for the image geographic Earth model attribute.
												// @see <f mgGetTextureGeoEarthModel>, <f mgSetTextureGeoEarthModel>

#define MIMG_GEOEARTH_CLARK1866	3	// @msg MIMG_GEOEARTH_CLARK1866 | Texture Geographic Earth Model <p Clark 1866>
												// @desc This is a valid value for the image geographic Earth model attribute.
												// @see <f mgGetTextureGeoEarthModel>, <f mgSetTextureGeoEarthModel>


#define MIMG_GEOIMAGEORIGIN_LL	0	// @msg MIMG_GEOIMAGEORIGIN_LL | Texture Image Origin <p Upper Left>
												// @desc This is a valid value for the image origin attribute for geographic control.
												// @see <f mgGetTextureGeoImageOrigin>, <f mgSetTextureGeoImageOrigin>

#define MIMG_GEOIMAGEORIGIN_UL	1	// @msg MIMG_GEOIMAGEORIGIN_UL | Texture Image Origin <p Lower Right>
												// @desc This is a valid value for the image origin attribute for geographic control.
												// @see <f mgGetTextureGeoImageOrigin>, <f mgSetTextureGeoImageOrigin>


#define MIMG_GEOHEMISPHERE_NORTH	1	// @msg MIMG_GEOHEMISPHERE_NORTH | Texture Geographic Hemisphere <p Northern>
												// @desc This is a valid value for the image geographic hemisphere attribute.
												// @see <f mgGetTextureGeoUTMHemisphere>, <f mgSetTextureGeoUTMHemisphere>

#define MIMG_GEOHEMISPHERE_SOUTH	0	// @msg MIMG_GEOHEMISPHERE_SOUTH | Texture Geographic Hemisphere <p Southern>
												// @desc This is a valid value for the image geographic hemisphere attribute.
												// @see <f mgGetTextureGeoUTMHemisphere>, <f mgSetTextureGeoUTMHemisphere>

/*============================================================================*\
	public types
\*============================================================================*/

// @type mgimageinfo | Abstract type used to represent an image object
// @desc An image object is used to describe an image and contains fields
// such as width, height, type, sample size and other flags.
// @see <f mgRegisterImageImporter>, <f mgReadImageInfo>
typedef struct mgimageinfo_t*				mgimageinfo;

// @type mgimagegeoinfo | Abstract type used to represent a georeference 
// info object for an image object
// @desc A geoimage object is used to describe a geographic control of 
// a georeference info and contains fields such as type, projection,
// earth model, UTM info, origin and geo control points.
// @see <f mgRegisterImageImporter>, <f mgReadImageGeoInfo>
typedef struct mggeoinfo_t*				mgimagegeoinfo;

// @type mggeocoorddata | Geospecific Coordinate data
// @desc Use an array of <t mggeocoorddata> to add and get geospecific
// coordinates.
// @see <f mgGeoCoordGet>, <f mgGeoCoordAdd>
typedef struct {
	double u;		// @field x coordinate in image
	double v;		// @field y coordinate in image
	double lat;		// @field latitude position that maps to x coordinate
	double lon;		// @field longitude position that maps to y coordinate
} mggeocoorddata;

#define MIMG_MAXNAMELEN		32
		// @msg MIMG_MAXNAMELEN | Maximum Subtexture Name Length
		// @desc This is the maximum number of characters allowed
		// for a subtexture name.
		// @see <t mgsubtexturedata>, <f mgSubTextureGet>,  <f mgSubTextureAdd>

// @type mgsubtexturedata | Subtexture Definition data
// @desc Use an array of <t mgsubtexturedata> to add and get subtexture
// records.
// @see <f mgSubTextureGet>, <f mgSubTextureAdd>
typedef struct {
	char name[MIMG_MAXNAMELEN];		// @field name of subtexture in image
	int l;		// @field lower left x coordinate of subtexture in image
	int b;		// @field lower left y coordinate of subtexture in image
	int r;		// @field upper right x coordinate of subtexture in image
	int t;		// @field upper right y coordinate of subtexture in image
} mgsubtexturedata;

/*============================================================================*\
	public methods
\*============================================================================*/

/*----------------------------------------------------------------------------*\
	Basic Image File Read
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgReadImage | reads an image from disk
	@desc Given an image file name, <f mgReadImage> allocates a pixel array
	to hold the texels of the image, reads the image from disk into the pixel
	array allocated and returns information about the image read.

	@desc The image <p pixels>, <p type>, <p width> and <p height> are
	returned through arguments. 
	
	@desc It is the responsibility of the caller to deallocate
	the <p pixels> returned when they are no longer needed using
	the function <f mgFree>.

	@return Returns <m MIMG_NO_ERROR> if successful, otherwise applicable
	texture error code.

	@see <f mgWriteImage>, <f mgReadImageHeader>, <f mgReadTexture>,
	<f mgInsertTexture>, <f mgFree>

	@access Level 1
*/
MGAPIFUNC(int) mgReadImage (
	char* imageFileName,				// @param the name of the image file on disk
	unsigned char** pixels,			// @param address of pixels read from disk
	int* type,							// @param address of value to receive image type
											// possible values returned are <m MIMG_INT>, 
											// <m MIMG_INTA>, <m MIMG_RGB>, and <m MIMG_RGBA>
	int* width,							// @param address of value to receive image width
	int* height							// @param address of value to receive image height
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgReadImageHeader | reads the header information from an image file
	@desc <f mgReadImageHeader> reads the header information of an image from the
	specified file <p imageFileName>.  The header information is returned in the
	output parameters, <p type>, <p width> and <p height>.

	@return <m MIMG_NO_ERROR> if successful, otherwise applicable texture
	error code.
	@see <f mgReadImage>, <f mgWriteImage>

	@access Level 1
*/
MGAPIFUNC(int) mgReadImageHeader (
	char* imageFileName,				// @param the name of the image file on disk
	int* type,							// @param address of value to receive image type
											// Possible values returned are <m MIMG_INT>, 
											// <m MIMG_INTA>, <m MIMG_RGB>, and <m MIMG_RGBA>
	int* width,							// @param address of value to receive image width
	int* height							// @param address of value to receive image height
	);

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgReadImageAttributes | reads an image's attribute file from disk
	@desc <f mgReadImageAttributes> reads an image's attribute file from disk and returns
	the data in an attributes record.  The <p imageFileName> passed to this function
	is the name of the image file.  The attributes file name is <p imageFileName>
	appended with ".attr".

	@return Returns the image attributes record if successful, <m MG_NULL> otherwise.
	@see <f mgReadImage>, <f mgWriteImageAttributes>

	@access Level 1
*/
MGAPIFUNC(mgrec*) mgReadImageAttributes (
	char* imageFileName		// @param the name of the image on disk
	);

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgReadImageInfo | reads the header information from 
	an image file.

	@desc <f mgReadImageInfo> reads the header of an image on disk and then
	allocates and fills an image info object with the information read.  
	The parameter <p imageFileName> is the name of the image file. 

	@desc When you are through with the returned image info object, you
	must free it by calling <f mgFreeImageInfo>.

	@return Returns <m MIMG_NO_ERROR> if successful, otherwise applicable
	texture error code.

	@see <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgstatus) mgReadImageInfo (
	char* imageFileName,			// @param the name of the image file
	mgimageinfo* textureInfo	// @param address of object to receive image 
										// info object allocated and filled
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureWidth | gets width attribute from an image 
	info object.

	@desc <f mgGetTextureWidth> gets the width attribute from the specified
	image info object <p textureInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureWidth (
	mgimageinfo textureInfo,	// @param the image info object
	int* width						// @param address of integer to receive width
										// attribute
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureHeight | gets height attribute from an image
	info object.

	@desc <f mgGetTextureHeight> gets the height attribute from the specified
	image info object <p textureInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureHeight (
	mgimageinfo textureInfo,	// @param the image info object
	int* height						// @param address of integer to receive height
										// attribute
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureType | gets type attribute from an image info
	object.

	@desc <f mgGetTextureType> gets the type attribute from the specified
	image info object <p textureInfo>.

	@desc Valid values for the image type attribute returned in <p type>
	are <m MIMG_INT>, <m MIMG_INTA>,
	<m MIMG_RGB>, and <m MIMG_RGBA>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	�  �rwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureType (
	mgimageinfo textureInfo,	// @param the image info object
	int* type						// @param address of integer to receive type
										// attribute
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureSampleSize | gets sample size attribute from
	an image info object.

	@desc <f mgGetTextureSampleSize> gets the sample size attribute from the
	specified image info object <p textureInfo>.  The sample size specifies
	the number of bits per texel per component.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureSampleSize (
	mgimageinfo textureInfo,	// @param the image info object
	int* sampleSize				// @param address of integer to receive 
										// sample size attribute
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureTiledFlag | gets tiled flag attribute from
	an image info object.

	@desc <f mgGetTextureTiledFlag> gets the tiled flag attribute from the
	specified image info object <p textureInfo>.  The tiled flag specifies
	whether or not the image is stored in memory in a tiled format.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureTiledFlag (
	mgimageinfo textureInfo,	// @param the image info object
	mgbool* tiled					// @param address of boolean to receive 
										// tiled flag attribute
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureMinMax | gets the minimum and maximum texel
	values from an image info object.

	@desc <f mgGetTextureMinMax> gets the minimum and maximum texel values
	from the specified image info object <p textureInfo>.  These values can
	be used to scale non-8bit images to 8 bits.

	@return Returns <e mgbool.MG_TRUE> if min and maximum values are returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureMinMax (
	mgimageinfo textureInfo,	// @param the image info object
	float* min,						// @param address of float to receive 
										// minimum texel value
	float* max						// @param address of float to receive 
										// maximum texel value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgHasTextureTransparentValue | gets transparent value flag
	attribute from an image info object.

	@desc <f mgHasTextureTransparentValue> gets the transparent value flag
	attribute from the specified image info object <p textureInfo>.  The 
	transparent value flag specifies whether or not the image
	has a value marked as transparent.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>,
	<f mgGetTextureTransparentValue>, <f mgGetTextureSignedFlag>, 
	<f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgHasTextureTransparentValue (
	mgimageinfo textureInfo,	// @param the image info object
	mgbool* hastranspval			// @param address of boolean to receive 
										// transparent value flag attribute
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureTransparentValue | gets transparent value
	attribute from an image info object.

	@desc <f mgGetTextureTransparentValue> gets the transparent value
	attribute from the specified image info object <p textureInfo>.  If the
	transparent value flag obtained from <f mgHasTextureTransparentValue> 
	is <e mgbool.MG_FALSE> the value returned by this function
	should be ignored.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureSignedFlag>, <f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureTransparentValue (
	mgimageinfo textureInfo,	// @param the image info object
	int* transpval					// @param address of integer to receive 
										// transparent texel value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureSignedFlag | gets tiled flag attribute from
	an image info object.

	@desc <f mgGetTextureSignedFlag> gets the tiled flag attribute from the
	specified image info object <p textureInfo>.  The signed flag specifies
	whether or not the image texels should be interpreted as signed values.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>, <f mgGetTextureHeight>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>, <f mgGetTextureTiledFlag>,
	<f mgGetTextureMinMax>, <f mgHasTextureTransparentValue>, 
	<f mgGetTextureTransparentValue>, <f mgFreeImageInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureSignedFlag (
	mgimageinfo textureInfo,	// @param the image info object
	mgbool* issigned				// @param address of boolean to receive
										// is signed flag
	);

/*============================================================================*/
/*                                                                            */
/* @func void | mgFreeImageInfo | frees an image info object.

	@desc <f mgFreeImageInfo> frees an image info object that was 
	allocated and returned by the function <f mgReadImageInfo>.

	@see <f mgReadImageInfo>

	@access Level 1
*/
MGAPIFUNC(void) mgFreeImageInfo (
	mgimageinfo textureInfo		// @param the image info object to free
	);

/*============================================================================*/
/*                                                                            */
/* @func mgstatus | mgReadImageGeoInfo | reads the georeference information
	from an image file.	

  	@desc <f mgReadImageGeoInfo> reads the georeference information of an 
	image on disk and then allocates and fills a georeference info object
	with the geo specific data read (if present).  
	The parameter <p imageFileName> is the name of the image file.
	
	@desc This function reads georeference information from the image
	file itself, not the image attribute file.  This implies that the 
	file must contain georeference information for this function to
	succeed.
	
	@desc When you are through with the returned georeference info object,
	you must free it by calling <f mgFreeImageGeoInfo>.

	@return Returns <m MIMG_NO_ERROR> if successful, otherwise applicable
	texture error code.

	@see <f mgGetTextureGeoType>, <f mgGetTextureGeoProjection>,
	<f mgGetTextureGeoEarthModel>, <f mgGetTextureGeoUTMZone>, 
	<f mgGetTextureGeoUTMHemisphere>, <f mgGetTextureGeoImageOrigin>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>
	
	@access Level 1
*/
MGAPIFUNC(mgstatus) mgReadImageGeoInfo (
	char* imageFileName,			// @param the name of the image file
	mgimagegeoinfo* geoInfo		// @param address of object to receive 
										// georeference info object allocated 
										// and filled
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoType | gets geographic control type from
	a georeference info object.

	@desc <f mgGetTextureGeoType> gets the geographic control type from
	the specified georeference info object <p geoInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@desc Valid values for the geographic control type attribute 
	are <m MIMG_GEOTYPE_CTRLPT>.

	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoProjection>,
	<f mgGetTextureGeoEarthModel>, <f mgGetTextureGeoUTMZone>, 
	<f mgGetTextureGeoUTMHemisphere>, <f mgGetTextureGeoImageOrigin>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoType (
	mgimagegeoinfo geoInfo,			// @param the georeference info object
	int* type							// @param address of integer to receive
											// geographic control type
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoProjection | gets map projection from 
	a georeference info object.

	@desc <f mgGetTextureGeoProjection> gets the map projection from the
	specified georeference info object <p geoInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@desc Valid values for the projection attribute 
	are <m MIMG_GEOPROJ_GEODETIC>, and <m MIMG_GEOPROJ_UTM>.
	
	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>,
	<f mgGetTextureGeoEarthModel>, <f mgGetTextureGeoUTMZone>, 
	<f mgGetTextureGeoUTMHemisphere>, <f mgGetTextureGeoImageOrigin>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoProjection (
	mgimagegeoinfo geoInfo,			// @param the georeference info object
	int* projection					// @param address of integer to receive
											// projection value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoEarthModel | gets Earth model (Ellipsoid) 
	from a georeference info object.

	@desc <f mgGetTextureGeoEarthModel> gets the Earth model (Ellipsoid)
	from the specified georeference info object <p geoInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@desc Valid values for the Earth model attribute 
	are <m MIMG_GEOEARTH_WGS84>, <m MIMG_GEOEARTH_WGS72>,
	<m MIMG_GEOEARTH_BESSEL>, and <m MIMG_GEOEARTH_CLARK1866>.
	
	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>, 
	<f mgGetTextureGeoProjection>, <f mgGetTextureGeoUTMZone>, 
	<f mgGetTextureGeoUTMHemisphere>, <f mgGetTextureGeoImageOrigin>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoEarthModel (
	mgimagegeoinfo geoInfo,			// @param the georeference info object
	int* earthModel					// @param address of integer to receive
											// earth model value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoUTMZone | gets UTM zone from a
	georeference info object.

	@desc <f mgGetTextureGeoUTMZone> gets the UTM zone from the specified
	georeference info object <p geoInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@desc Valid values for the UTM zone attribute are 1 through 60.

	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>,
	<f mgGetTextureGeoProjection>, <f mgGetTextureGeoEarthModel>, 
	<f mgGetTextureGeoUTMHemisphere>, <f mgGetTextureGeoImageOrigin>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoUTMZone (
	mgimagegeoinfo geoInfo,			// @param the georeference info object
	int* zone							// @param address of integer to receive
											// UTM zone value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoUTMHemisphere | gets hemisphere from a
	georeference info object.

	@desc <f mgGetTextureGeoUTMHemisphere> gets the hemisphere from the
	specified image info object <p geoInfo>.

	@desc Valid values for the hemisphere attribute 
	are <m MIMG_GEOHEMISPHERE_NORTH>, and <m MIMG_GEOHEMISPHERE_SOUTH>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>,
	<f mgGetTextureGeoProjection>, <f mgGetTextureGeoEarthModel>,
	<f mgGetTextureGeoUTMZone>, <f mgGetTextureGeoImageOrigin>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoUTMHemisphere (
	mgimagegeoinfo geoInfo,			// @param the georeference info object
	int* hemisphere					// @param address of integer to receive
											// UTM hemisphere value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoImageOrigin | gets image origin from a
	georeference info object.

	@desc <f mgGetTextureGeoImageOrigin> gets the width attribute from the
	specified georeference info object <p geoInfo>.  The image origin
	specifies the origin and the positive y direction used by image
	geographic control points.

	@desc Valid values for the image origin attribute 
	are <m MIMG_GEOIMAGEORIGIN_LL> (the image origin is in the lower left corner
	and y increases toward the top), and <m MIMG_GEOIMAGEORIGIN_UL> (the image
	origin is in the upper left corner of the image and increases toward the bottom).

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>, 
	<f mgGetTextureGeoProjection>, <f mgGetTextureGeoEarthModel>,
	<f mgGetTextureGeoUTMZone>, <f mgGetTextureGeoUTMHemisphere>,
	<f mgGetTextureGeoNumCtlPts>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoImageOrigin (
	mgimagegeoinfo geoInfo,		// @param the georeference info object
	int* imageorigin				// @param address of integer to receive
										// image origin value
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoNumCtlPts | gets number of control points
	from a georeference info object.

	@desc <f mgGetTextureGeoNumCtlPts> gets the number of control points from
	the specified georeference info object <p geoInfo>.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>,
	<f mgGetTextureGeoProjection>, <f mgGetTextureGeoEarthModel>,
	<f mgGetTextureGeoUTMZone>, <f mgGetTextureGeoUTMHemisphere>,
	<f mgGetTextureGeoImageOrigin>, <f mgGetTextureGeoCtlPt>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoNumCtlPts (
	mgimagegeoinfo geoInfo,		// @param the georeference info object
	int* numCoords					// @param address of integer to receive
										// number of control points
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTextureGeoCtlPt | gets nth geo reference control
	point from a georeference info object.

	@desc <f mgSetTextureGeoCtlPt> gets a specified control point, <p index> used
	to geo reference the image for the specified image geo info object, <p geoInfo>.
	<p imagex> and <p imagey> specify the location of the control point in image
	coordinates relative to the origin specified by <f mgGetTextureGeoImageOrigin>.
	<p projx> and <p projy> specify the location of the control point in the
	projected coordinate system specified by <f mgGetTextureGeoProjection>.  If the
	projection was specified as <m MIMG_GEOPROJ_GEODETIC>, these coordinates will be
	in degrees Longitude and Latitude respectively.  If the projection was specified
	as <m MIMG_GEOPROJ_UTM>, these coordinates will be in meters of Northing and
	Easting respectively.

	@return Returns <e mgbool.MG_TRUE> if attribute value is returned, 
	otherwise <e mgbool.MG_FALSE>.

	@see <f mgReadImageGeoInfo>, <f mgGetTextureGeoType>,
	<f mgGetTextureGeoProjection>, <f mgGetTextureGeoEarthModel>,
	<f mgGetTextureGeoUTMZone>, <f mgGetTextureGeoUTMHemisphere>,
	<f mgGetTextureGeoImageOrigin>, <f mgGetTextureGeoNumCtlPts>,
	<f mgFreeImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTextureGeoCtlPt (
	mgimagegeoinfo geoInfo,		// @param the georeference info object
	int index,						// @param the index of control point to get
	double* imagex,				// @param address of double to receive
										// image x value
	double* imagey,				// @param address of double to receive
										// image y value
	double* projx,					// @param address of double to receive
										// projection x value
	double* projy					// @param address of double to receive
										// projection y value
	);

/*============================================================================*/
/*                                                                            */
/* @func void | mgFreeImageGeoInfo | frees a georeference info object

	@desc <f mgFreeImageGeoInfo> frees a georeference info object that was
	allocated and returned by the function <f mgReadImageGeoInfo>.
	@see <f mgReadImageGeoInfo>

	@access Level 1
*/
MGAPIFUNC(void) mgFreeImageGeoInfo (
	mgimagegeoinfo geoInfo		// @param the georeference info object to free
	);

/*----------------------------------------------------------------------------*\
	Texture Palette Loading
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadTexture | loads a texture and creates a new entry
	in a database's texture palette at a specified location and index.

	@desc <f mgReadTexture> loads a texture (image and attributes) into the
	palette of the specified database <p db>.  The palette entry is loaded
	at the specified <p index> and lower left hand location <p x>, <p y>.  

	@desc The attributes are read from the file specified by the texture
	file name appended with ".attr".  If there is no attributes file, default
	attributes are assigned.

	@return Returns <e mgbool.MG_TRUE> if the image is read successfully, 
	<e mgbool.MG_FALSE> otherwise. 

	@see <f mgReadTextureAndAlpha>, <f mgInsertTexture>, <f mgInsertTextureAndAlpha>, 
	<f mgWriteTexture>, <f mgReadImage> 

	@access Level 1
*/
MGAPIFUNC(mgbool) mgReadTexture (
	mgrec* db,						// @param the database node
	char* textureFileName,		// @param the name of the texture file on disk
	int index,						// @param the index to assign to the texture
										// palette entry created
	int x,							// @param the x position of the texture in the
										// palette (in pixels)
	int y								// @param the y position of the texture in the
										// palette (in pixels)
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgReadTextureAndAlpha | loads a texture and alpha mask as a 
	single texture palette entry at a specified location and index.

	@desc <f mgReadTextureAndAlpha> loads a texture and alpha mask from files
	<p textureFileName> and <p alphaFileName>, respectively, into the texture
	palette for database <p db>.  The palette entry is loaded
	at the specified <p index> and lower left hand location <p x>, <p y>. 

	@return Returns <e mgbool.MG_TRUE> if the image is read successfully, 
	<e mgbool.MG_FALSE> otherwise. 
	@see <f mgReadTexture>, <f mgInsertTexture>, <f mgInsertTextureAndAlpha>, 
	<f mgWriteTexture>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgReadTextureAndAlpha (
	mgrec* db,						// @param the database node
	char* textureFileName,		// @param the name of the texture file on disk
	char* alphaFileName,			// @param the name of the alpha mask file on disk
	char* mergeTextureName,		// @param the name to associate with the merged
										// texture in the palette
	int index,						// @param the index to assign to the texture
										// palette entry created
	int x,							// @param the x position of the texture in the
										// palette (in pixels)
	int y								// @param the y position of the texture in the
										// palette (in pixels)
);

/*============================================================================*/
/*                                                                            */
/* @func int | mgInsertTexture | loads a texture and creates a new entry
	in a database's texture palette.
	@desc <f mgInsertTexture> loads a texture from file
	<p textureFileName> into the texture palette for database <p db>.
	The created palette entry is automatically positioned in the palette such
	that no other textures are covered.  The index of the new texture is
	also automatically assigned.

	@return Returns the index assigned to the new palette entry if successful, -1 otherwise.
	@see <f mgReadTexture>,  <f mgInsertTextureAndAlpha>,  <f mgReadTextureAndAlpha>,
	<f mgWriteTexture> 

	@access Level 1
*/
MGAPIFUNC(int) mgInsertTexture (
	mgrec* db,						// @param the database node
	char* textureFileName		// @param the name of the texture file to load
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgInsertTextureAndAlpha | loads a texture and alpha mask as a
	single texture palette entry.

	@desc <f mgInsertTextureAndAlpha> loads a texture and alpha mask from files
	<p textureFileName> and <p alphaFileName>, respectively, into the texture
	palette for database <p db>.  The created palette entry is automatically
	positioned in the palette such that no other textures are covered.
	The index of the new texture is also automatically assigned.

	@return Returns the index assigned to the new palette entry if successful, or returns -1 otherwise.
	@see <f mgReadTexture>,  <f mgInsertTexture>,  <f mgReadTextureAndAlpha>,
	<f mgWriteTexture> 

	@access Level 1
*/
MGAPIFUNC(int) mgInsertTextureAndAlpha ( 
	mgrec* db,						// @param the database node
	char* textureFileName,		// @param the name of the texture file on disk
	char* alphaFileName,			// @param the name of the alpha mask file on disk
	char* mergeTextureName		// @param the name to associate with the merged
										// texture in the palette
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgReadTexturePalette | reads a texture palette file from disk
	@desc <f mgReadTexturePalette> loads the textures listed in the texture
	palette file, <p paletteFileName>, into the texture palette for	database <p db>.
	 
	@desc If the existing texture palette for the database contains entries with
	the same indices as the ones in the texture palette file, the existing entries
	are overwritten with those from the texture palette file.

	@return Returns the number of textures loaded if successful, or returns -1 otherwise.
	@see <f mgWriteTexturePalette>

	@access Level 1
*/
MGAPIFUNC(int) mgReadTexturePalette (
	mgrec* db,						// @param the database node
	char* paletteFileName		// @param the name of the texture 
										// palette file to read
	);

/*----------------------------------------------------------------------------*\
	Get Texture Info
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetTextureIndex | gets the index of a texture palette entry
	from its name.

	@desc <f mgGetTextureIndex> returns the index of a texture palette entry
	named <p textureName> contained in the texture palette of database <p db>.

	@desc The name of the texture is the filename that was opened to read the 
	texture (including the path).  One exception to this is if the texture was
	read in as a texture with alpha mask using <f mgReadTextureAndAlpha> or
	<f mgInsertTextureAndAlpha>.  In these cases, the texture name is the
	<p mergeTextureName> specified when the texture and alpha mask were loaded.
 
	@return Returns the index of the texture palette entry if found, or returns -1 otherwise. 
	@see <f mgGetTextureName>, <f mgGetFirstTexture>, <f mgGetNextTexture> 

	@access Level 1
*/
MGAPIFUNC(int) mgGetTextureIndex (
	mgrec* db,						// @param the database node
	char* textureName				// @param the name of the texture palette entry
	);

/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetTextureName | gets the full name of a texture 
	palette entry from its index.
	@desc <f mgGetTextureName> returns the full name of a texture palette
	entry at the specified <p index> contained in the texture palette of 
	database <p db>.
	
	@desc If the texture was located when it was loaded, the full name
	includes the full path specification of the file where it was found
	on disk.  If the texture was not located at load time, the name
	returned by this function will be the same name returned by 
	<f mgGetTextureSaveName>.
	
	@desc The character string returned is a dynamically allocated copy of 
	the texture name.  It is the responsibility of the caller to deallocate
	this string when it is no longer needed using the function <f mgFree>.
 
	@return Returns the name of the texture palette entry if found, 
	<m MG_NULL> otherwise. 
	@see <f mgGetTextureIndex>, <f mgGetFirstTexture>, <f mgGetNextTexture>,
	<f mgGetTextureSaveName>, <f mgFree>

	@access Level 1
*/
MGAPIFUNC(char*) mgGetTextureName (
	mgrec* db,					// @param the database node
	int index					// @param the index of the texture palette entry
	);

/*============================================================================*/
/*                                                                            */
/* @func char* | mgGetTextureSaveName | gets the save name of a texture 
	palette entry from its index.
	@desc <f mgGetTextureName> returns the save name of a texture palette
	entry at the specified <p index> contained in the texture palette of 
	database <p db>.
	
	@desc The save name of a texture is the actual name that is saved
	in the OpenFlight database file for this texture palette entry.  The
	save name may or may not include the full path specification of the
	texture file.  If the texture files for a database are
	saved using relative texture names, the save name of a texture will
	be a relative name and will begin with the character sequence "./". 
	If the texture files are saved using absolute
	texture names, the save name will include the full path specification
	of the texture.  If the texture files are saved with no path, the save 
	name will simply be the name of the file.
  
	@desc The character string returned is a dynamically allocated copy of 
	the texture name.  It is the responsibility of the caller to deallocate
	this string when it is no longer needed using the function <f mgFree>.
 
	@return Returns the name of the texture palette entry if found, 
	<m MG_NULL> otherwise. 
	@see <f mgGetTextureIndex>, <f mgGetFirstTexture>, <f mgGetNextTexture>,
	<f mgGetTextureName>, <f mgFree>

	@access Level 1
*/
MGAPIFUNC(char*) mgGetTextureSaveName (
	mgrec* db,					// @param the database node
	int index					// @param the index of the texture palette entry
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetTexturePosition | gets the position of a texture
	palette entry.

	@desc <f mgGetTexturePosition> gets the position of the texture palette 
	entry at the specified <p index> contained in the texture palette of 
	database <p db>. 

	@desc The position of a texture palette entry is the lower left corner 
	where it is displayed in the texture palette.  This position is measured
	in pixels.

	@return Returns <e mgbool.MG_TRUE> if texture palette entry found, 
	<e mgbool.MG_FALSE> otherwise. 
	If successful, the parameters <p x> and <p y> are filled in with
	the position coordinates, otherwise these values are undefined.

	@see <f mgSetTexturePosition>, <f mgGetTextureName>, 
	<f mgGetFirstTexture>, <f mgGetNextTexture>,

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetTexturePosition (
	mgrec* db,					// @param the database node
	int index,					// @param the index of the texture palette entry
	int* x,						// @param address to receive x coordinate of position
	int* y						// @param address to receive y coordinate of position
	);

/*============================================================================*/
/*                                                                            */
/* @func mgrec* | mgGetTextureAttributes | gets the attributes record for
	a texture palette entry.
	@desc <f mgGetTextureAttributes> gets the attributes record for
	a texture palette entry at the specified <p index> contained in
	the texture palette of database <p db>. 

	@return Returns the texture attributes record if found, <m MG_NULL> otherwise.
	@see <f mgSetTextureAttributes>, <flt fltImage>

	@access Level 1
*/
MGAPIFUNC(mgrec*) mgGetTextureAttributes (
	mgrec* db,					// @param the database node
	int index					// @param the index of the texture palette entry
	);

/*============================================================================*/
/*                                                                            */
/* @func unsigned char* | mgGetTextureTexels | gets the texels for
	a texture palette entry.
	@desc <f mgGetTextureTexels> gets the texels for
	a texture palette entry at the specified <p index> contained in
	the texture palette of database <p db>. 

	@desc Note: The texels returned are the actual texels, not a copy.
	For that reason, you should not modify or free them.
	
	@return Returns the pointer to the texels of the texture palette 
	entry if found, <m MG_NULL> otherwise.  This pointer should not
	be freed by the caller.
	
	@see <f mgSetTextureTexels>

	@access Level 1
*/
MGAPIFUNC(unsigned char*) mgGetTextureTexels (
	mgrec* db,					// @param the database node
	int index					// @param the index of the texture palette entry
	);

/*----------------------------------------------------------------------------*\
	Texture Palette Query
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIsTextureInPalette | determines if a texture is in a 
	palette.

	@desc <f mgIsTextureInPalette> determines whether or not the named texture
	palette entry <p textureName> is contained in the texture palette of the
	database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if the texture palette entry is found,
	<e mgbool.MG_FALSE> otherwise.
	
	@see <f mgIsTextureDefault>, <f mgGetTextureCount>, <f mgIsTextureIndexInPalette>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgIsTextureInPalette (
	mgrec* db,					// @param the database node 
	char* textureName			// @param the name of the texture palette entry 
									// to lookup
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIsTextureIndexInPalette | determines if a texture index
	is in a palette.

	@desc <f mgIsTextureIndexInPalette> determines whether or not the texture
	with the specified <p index> is contained in the texture palette of the
	database <p db>. 

	@return Returns <e mgbool.MG_TRUE> if the texture palette entry is found,
	<e mgbool.MG_FALSE> otherwise.
	
	@see <f mgIsTextureDefault>, <f mgGetTextureCount>, <f mgIsTextureInPalette>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgIsTextureIndexInPalette (
	mgrec* db,					// @param the database node 
	int index					// @param the index of the texture palette entry 
									// to lookup
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetFirstTexture | gets the first entry in a texture palette.
	@desc <f mgGetFirstTexture> get the index and name of the first texture
	contained in the texture palette of database <p db>.

	@ex The following example traverses all the texture palette entries for 
	database <p db> |
   mgbool gotOne;
   int index;
   char name[200];

   gotOne = mgGetFirstTexture ( db, &index, name );
   while ( gotOne )
   {
      // do something with texture palette entry
      gotOne = mgGetNextTexture ( db, &index, name );
   }

	@return Returns <e mgbool.MG_TRUE> if the texture palette entry is found,
	<e mgbool.MG_FALSE> otherwise. 
	If successful, the parameters <p index> and <p textureName> will be filled
	in with the index and name of the entry found, otherwise these values
	will be undefined.

	@see <f mgGetNextTexture>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetFirstTexture ( 
	mgrec* db,					// @param the database node
	int* index,					// @param address of value to receive index 
	char* textureName			// @param address of string to receive texture name
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgGetNextTexture | gets successive entries in a texture palette.

	@desc <f mgGetNextTexture> get the index and name of the next texture
	contained in the texture palette of database <p db>.

	@desc After calling <f mgGetFirstTexture>, successive calls to <f mgGetNextTexture>
	returns successive texture palette entries.

	@desc Example code is shown in <f mgGetFirstTexture>.

	@return Returns <e mgbool.MG_TRUE> if the texture palette entry is found,
	<e mgbool.MG_FALSE> otherwise. 
	If successful, the parameters <p index> and <p textureName> are filled
	in with the index and name of the entry found, otherwise these values
	are undefined.

	@see <f mgGetFirstTexture>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgGetNextTexture (
	mgrec* db,					// @param the database node 
	int* index,					// @param address of value to receive index 
	char* textureName			// @param address of string to receive texture name
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgIsTextureDefault | determines if the default texture 
	pattern has been substituted for a texture palette entry.

	@desc When a texture palette entry is loaded into the texture palette, the
	file containing the image may or may not be found.  In either case, the palette
	still contains the entry but when the image file is not found or cannot be
	read, the texels and/or attributes will be unknown.
	When this happens for a texture palette entry, a default pattern (a black X on
	a white background) is substituted in the palette for the missing texels.

	<f mgIsTextureDefault> determines whether the texels for a texture palette 
	entry at the specified <p index> contained in the texture palette of 
	database <p db> have been substituted by the default pattern texels.

	@return Returns <e mgbool.MG_TRUE> if the texels for the entry have been substituted
	by the default pattern, <e mgbool.MG_FALSE> otherwise. 

	@see <f mgIsTextureInPalette> 

	@access Level 1
*/
MGAPIFUNC(mgbool) mgIsTextureDefault (
	mgrec* db,					// @param the database node
	int index					// @param the index of the texture palette entry
	);

/*----------------------------------------------------------------------------*\
	Texture Palette Statistics
\*----------------------------------------------------------------------------*/

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetTextureCount | gets the number of entries contained
	in a texture palette.

	@desc <f mgGetTextureCount> returns the number of entries contained
	in the texture palette of database <p db>. 

	@return Returns the number of texture palette entries if successful, or returns -1 otherwise.

	@see <f mgGetTextureSize>, <f mgGetTextureTotalSize>

	@access Level 1
*/
MGAPIFUNC(int) mgGetTextureCount (
	mgrec* db					// @param the database node
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetTextureTotalSize | gets the total size of the
	all the textures in a palette.

	@desc <f mgGetTextureTotalSize> returns the total size (in bytes) of all
	entries contained in the texture palette of database <p db>. 

	@return Returns the total size of all texture palette entries (in bytes) if 
	successful, or returns -1 otherwise.

	@see <f mgGetTextureCount>, <f mgGetTextureSize>

	@access Level 1
*/
MGAPIFUNC(int) mgGetTextureTotalSize (
	mgrec* db					// @param the database node
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetTextureSize | gets the size of a texture
	palette entry.

	@desc <f mgGetTextureSize> returns the size (in bytes) of the texture palette 
	entry at the specified <p index> contained in the texture palette of 
	database <p db>. 

	@desc The position of a texture palette entry is the lower left corner 
	where it is displayed in the texture palette.  This position is measured
	in pixels.

	@return the size of the texture palette entry (in bytes) if found, -1 otherwise.

	@see <f mgGetTextureCount>, <f mgGetTextureTotalSize>

	@access Level 1
*/
MGAPIFUNC(int) mgGetTextureSize (
	mgrec* db,					// @param the database node
	int index					// @param the index of the texture palette entry
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgGetImageRowWidth | gets the padded width of an image row

	@desc <f mgGetTextureSize> is a convenience function which computes the padded
	width of an image row. 

	@return the padded width (in bytes).  Also fills the pad size (in bytes).

	@see <f mgReadImageInfo>, <f mgGetTextureWidth>,
	<f mgGetTextureType>, <f mgGetTextureSampleSize>

	@access Level 1
*/
MGAPIFUNC(int) mgGetImageRowWidth (
	int width,					// @param the unpadded width of the image.
	int sampleSize,			// @param the number of bits per texel per channel
	int type,					// @param the image type
	int* pad						// @param address to write pad value
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgGeoCoordGet | gets the geospecific coordinates from a 
	texture attribute record

	@desc <f mgGeoCoordGet> gets the geospecific coordinates into an array
	<p geoCoordData>. The size of the array is specified by <p n>. The number
	of coordinates actually written into the array is returned.  The actual
	number of geospecific coordinates can be found by querying the attribute
	<flt fltTGNumCoords>

	@return The number of coordinates actually written into the array 
	<p geoCoordData>

   @see <f mgGeoCoordAdd>, <f mgGeoCoordDelete>, <f mgGeoCoordCount>
   @ex |
   mgrec* imgRec = mgGetTextureAttributes ( dbRec, tindex );
   int numCoords = mgGeoCoordCount ( imgRec );
   if ( numCoords > 0 ) {
      int num;
      mggeocoorddata gcData[10];
      num = mgGeoCoordGet ( imgRec, gcData, 10 );
      // num will be minimum of 10 and numCoords
   }

	@access Level 1
*/
MGAPIFUNC(int) mgGeoCoordGet (
	mgrec* imgRec,						// @param the texture attribute record
	mggeocoorddata geoCoordData[],// @param the array of geospecific coordinates to be filled in
	int n									// @param the size of the array <p geoCoordData>
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgGeoCoordCount | gets the number of geospecific coordinates
	in a texture attribute record

	@desc <f mgGeoCoordGet> returns the number of geospecific coordinates
	in the specified texture attribute record <p imgRec>.

	@return The number of coordinates contained in the texture attribute
	record.

	@see <f mgGeoCoordAdd>, <f mgGeoCoordDelete>, <f mgGeoCoordGet>

	@access Level 1
*/
MGAPIFUNC(int) mgGeoCoordCount (
	mgrec* imgRec						// @param the texture attribute record
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgSubTextureGet | gets the subtexture definitions from a 
	texture attribute record

	@desc <f mgSubTextureGet> gets the subtexture definitions into an array
	<p subTextureData>. The size of the array is specified by <p n>. The number
	of subtexture definitions actually written into the array is returned.  You
	can determine the actual number of subtexture definitions contained in
	a texture attribute record by calling <f mgSubTextureCount>.

	@return The number of subtextures actually written into the array 
	<p subTextureData>.

	@see <f mgSubTextureAdd>, <f mgSubTextureDelete>, <f mgSubTextureCount>
   @ex |
	mgrec* imgRec = mgGetTextureAttributes ( dbRec, tindex );
	int numSubTextures;
	numSubTextures = mgSubTextureCount ( imgRec );
	if ( numSubTextures > 0 ) {
		int num;
		mgsubtexturedata* stData;
		stData = mgMalloc ( numSubTextures * sizeof(mgsubtexturedata) );
		num = mgSubTextureGet ( imgRec, stData, numSubTextures );
	}

	@access Level 1
*/
MGAPIFUNC(int) mgSubTextureGet (
	mgrec* imgRec,								// @param the texture attribute record
	mgsubtexturedata subTextureData[],	// @param the array of subtexture records to be filled in
	int n											// @param the size of the array <p subTextureData>
	);

/*============================================================================*/
/*                                                                            */
/* @func int | mgSubTextureCount | gets the number of subtextures defined
	in a texture attribute record

	@desc <f mgSubTextureGet> returns the number of subtextures
	in the specified texture attribute record <p imgRec>.

	@return The number of subtextures contained in the texture attribute
	record.

	@see <f mgSubTextureAdd>, <f mgSubTextureDelete>, <f mgSubTextureGet>

	@access Level 1
*/
MGAPIFUNC(int) mgSubTextureCount (
	mgrec* imgRec						// @param the texture attribute record
	);

/*============================================================================*/
/*                                                                            */
/* @func mgbool | mgTextureSetLocatorFunc | sets the texture file locator
	function.

	@desc <f mgTextureSetLocatorFunc> allows you to setup a texture file 
	locator function used by the API to "locate" texture files referenced
	within OpenFlight databases.  When a database file is opened using the
	API, the current texture file locator function set will be called to
	locate the texture file.  In this way, your application can override
	the way the API locates texture files.

	@desc Note: This function is for use in stand alone applications only, 
	and should never be called from inside a plug-in.  Doing so may yield
	undefined results.

	@return Returns <e mgbool.MG_TRUE> if texture locator function
	could be set, otherwise <e mgbool.MG_FALSE>.

	@see <f mgTextureGetLocatorFunc>, <f mgExtRefSetLocatorFunc>

	@access Level 1
*/
MGAPIFUNC(mgbool) mgTextureSetLocatorFunc (
	mgfilelocatorfunc locatorFunc,	// @param the texture file locator function
	void* userData							// @param user defined data that will be 
												// passed to <p locatorFunc> when it is 
												// called
	);

/*============================================================================*/
/*                                                                            */
/* @func mgfilelocatorfunc | mgTextureGetLocatorFunc | gets the current 
	texture file locator function.

	@desc <f mgTextureGetLocatorFunc> returns the current texture file 
	locator function.  In this way, you can query the current locator
	function and then call it as part of the locator function you set
	up or call it directly for other file location processing your
	application or plug-in requires.

	@desc Note: Although only stand-alone applications can override
	the texture file locator, stand-alone applications as well as
	plug-ins can obtain it.  This allows both stand-alone applications
	and plug-ins to "mimic" the behavior of the default file locator
	when locating files as part of their processing.

	@see <f mgTextureSetLocatorFunc>, <f mgExtRefGetLocatorFunc>,
	<t mgfilelocatorfunc>	

	@access Level 1
*/
MGAPIFUNC(mgfilelocatorfunc) mgTextureGetLocatorFunc ( void );

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif		/* MGAPITEXTURE1_H_ */
/* DON'T ADD STUFF AFTER THIS #endif */


template<class datatype>
class CDataList
{
protected:
	struct dataNode
{
	datatype *pData;
	dataNode *pNext;
};
public:
	unsigned long m_length;
	dataNode *m_pHead;
	dataNode *m_pTail;
	dataNode *m_pcurrent;
public:
	CDataList();
	~CDataList();
public:
	bool isEmpty();
	unsigned long getLength(){return m_length;};
	void addTail(datatype *pd);
	void deleteHead();
	void releaseList();
	void steppCurrent();
	void resetpCurrent();
};
template<class datatype>
CDataList<datatype>::CDataList()
{
	m_length=0;
	m_pHead=NULL;
	m_pTail=NULL;
	m_pcurrent=NULL;
}

template<class datatype>
CDataList<datatype>::~CDataList()
{
	releaseList();
}
//
template<class datatype>
bool CDataList<datatype>::isEmpty()
{
	return(m_pHead==NULL); 
}

template<class datatype>
void CDataList<datatype>::addTail(datatype *pd)
{
	dataNode *p;
	p=new dataNode;
	p->pData=pd;
	p->pNext=NULL;
	if(isEmpty())
	{
		m_pHead=p;
		m_pTail=p;
	}
	else
	{
		m_pTail->pNext=p;
		m_pTail=p;
	}
	m_length++;
}

template<class datatype>
void CDataList<datatype>::deleteHead()
{
	if(isEmpty())
		return;
	dataNode *q;
	q=m_pHead->pNext;
	delete m_pHead->pData;
	delete m_pHead;
    m_pHead=q;
	m_length--;
}

template<class datatype>
void CDataList<datatype>::releaseList()
{
	while (m_pHead!=NULL)
	{
		deleteHead();
	}
	m_length=0;
	m_pHead=NULL;
	m_pTail=NULL;
	m_pcurrent=NULL;
}
template<class datatype>
void CDataList<datatype>::steppCurrent()
{
	m_pcurrent=m_pcurrent->pNext;
}

template<class datatype>
void CDataList<datatype>::resetpCurrent()
{
	m_pcurrent=m_pHead;
}
//template<class datatype>
//dataNode *CDataList<datatype>::getAt(unsigned long pos)
//{
//	if(pos<0||pos>=m_length||m_pHead==NULL)
//		return NULL;
//	
//	dataNode *p=m_pHead;
//	while(pos>0)
//	{
//		p=p->pNext;
//		pos--;
//	}
//	return p;
//}

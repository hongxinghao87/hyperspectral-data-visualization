#pragma once

#ifdef _DEBUG
# include "assert.h"
#else
# define assert(x) { }
#endif

#ifndef CONST
#define CONST const
#endif


#define PI 3.14159265358979323846

#define MaxFloatValue (3.402823466e+38)
#define MinFloatValue (-3.402823466e+38)

#define Epsilon   (4.94066e-324)
#define MaxDoubleValue   (1.79769e+308)
#define MinDoubleValue   (-1.79769e+308)

/* Definitions of useful mathematical constants
* M_E        - e
* M_LOG2E    - log2(e)
* M_LOG10E   - log10(e)
* M_LN2      - ln(2)
* M_LN10     - ln(10)
* M_PI       - pi
* M_PI_2     - pi/2
* M_PI_4     - pi/4
* M_1_PI     - 1/pi
* M_2_PI     - 2/pi
* M_2_SQRTPI - 2/sqrt(pi)
* M_SQRT2    - sqrt(2)
* M_SQRT1_2  - 1/sqrt(2)
* M_PI_180   - PI/180
* M_180_PI   - 180/PI
*/

#define M_E        2.71828182845904523536
#define M_LOG2E    1.44269504088896340736
#define M_LOG10E   0.434294481903251827651
#define M_LN2      0.693147180559945309417
#define M_LN10     2.30258509299404568402
#define M_PI       3.14159265358979323846
#define M_2PI	   6.283185307179586476925
#define M_PI_2     1.57079632679489661923
#define M_PI_4     0.785398163397448309616
#define M_1_PI     0.318309886183790671538
#define M_2_PI     0.636619772367581343076
#define M_2_SQRTPI 1.12837916709551257390
#define M_SQRT2    1.41421356237309504880
#define M_SQRT1_2  0.707106781186547524401
#define M_PI_180   0.0174532925199432957692
#define M_180_PI   57.295779513082320876798


template <class T> 
struct GLVECTOR2 {
	union
	{
		struct  
		{
			T x, y;
		};
		T v[2];
	};
};


template <class T>
 struct GLVECTOR3 {
	union
	{
		struct  
		{
			T x, y, z;
		};

		struct  
		{
			T X, Y, Z;
		};
		
		T v[3];
	};
	
};

template <class T>
 struct GLVECTOR4 {
	 union
	 {
		 struct  
		 {
			 union
			 {
				 T x;
				 T r;
			 };
			 union
			 {
				 T y;
				 T g;
			 };
			 union
			 {
				 T z;
				 T b;
			 };
			 union
			 {
				 T w;
				 T a;
			 };			  
		 };
		 T v[4];
	 };
};


 template <class T>
 struct GLMATRIX3 {
	 union {
		 struct {
			 T        _00, _10, _20;
			 T        _01, _11, _21;
			 T        _02, _12, _22;
		 };
		 T m[9];
	 };
 } ;

 typedef GLMATRIX3<float> matrix3f;

 template <class T>
 struct GLMATRIX4 {
	 union {
		 struct {
			 T        _00, _10, _20, _30;
			 T        _01, _11, _21, _31;
			 T        _02, _12, _22, _32;
			 T        _03, _13, _23, _33;
		 };
		 struct {
			 T        M11, M12, M13, M14;
			 T        M21, M22, M23, M24;
			 T        M31, M32, M33, M34;
			 T        M41, M42, M43, M44;
		 };
		 T M[16];
		 T m[4][4];
	 };
 } ;

#include <iostream>
#include <cmath>

 class CViewport;
 template<class T> class Matrix;

template <class T>
class Vec3D : public GLVECTOR3<T>
{
public:

	Vec3D(T x0 = 0.0f, T y0 = 0.0f, T z0 = 0.0f) 
	{
		x = x0;
		y = y0;
		z = z0; 
	}

	Vec3D(const Vec3D& v)  
	{
		x = v.x;
		y = v.y;
		z = v.z;
	}

	Vec3D& operator= (const Vec3D &v) {
		x = v.x;
		y = v.y;
		z = v.z;
		return *this;
	}

	Vec3D operator+ (const Vec3D &v) const
	{		
		return Vec3D(x+v.x,y+v.y,z+v.z);
	}

	Vec3D operator- (const Vec3D &v) const
	{		
		return Vec3D(x-v.x,y-v.y,z-v.z);
	}

	Vec3D operator- () const
	{		
		return Vec3D(-x,-y,-z);
	}

	T operator* (const Vec3D &v) const
	{
		return x*v.x + y*v.y + z*v.z;
	}

	Vec3D operator* (T d) const
	{		
		return Vec3D(x*d,y*d,z*d);
	}

	Vec3D operator/ (T d) const
	{		
		return Vec3D(x/d,y/d,z/d);
	}

	friend Vec3D operator* (T d, const Vec3D& v)
	{
		return v * d;
	}

	friend Vec3D operator/ (T d, const Vec3D& v)
	{
		return v / d;
	}

	Vec3D operator% (const Vec3D &v) const
	{		
		return Vec3D(y*v.z-z*v.y, z*v.x-x*v.z, x*v.y-y*v.x);
	}

	bool operator<(const Vec3D &v)const
	{
		return (x-v.x) < 0 && (y-v.y) < 0 && (z-v.z) < 0 ;
	}

	Vec3D& operator+= (const Vec3D &v)
	{
		x += v.x;
		y += v.y;
		z += v.z;
		return *this;
	}

	Vec3D& operator-= (const Vec3D &v)
	{
		x -= v.x;
		y -= v.y;
		z -= v.z;
		return *this;
	}

	Vec3D& operator*= (T d)
	{
		x *= d;
		y *= d;
		z *= d;
		return *this;
	}

	Vec3D& operator/= (T d)
	{
		x /= d;
		y /= d;
		z /= d;
		return *this;
	}

	T lengthSquared() const
	{
		return x*x+y*y+z*z;
	}

	T length() const
	{
		return sqrt(x*x+y*y+z*z);
	}

	Vec3D normalize()
	{
		Vec3D<T> vec = Vec3D<T>(x, y, z);
		vec *= (1.0f/vec.length());
		return vec;
	}

	void Normalize()
	{
		this->operator*= (1.0f/length());
	}

	Vec3D operator~ () const
	{
		Vec3D r(*this);
		r.normalize();
		return r;
	}

	void TransformCoord(const Matrix<T>& matrix)
	{
		T norm;
		Vec3D<T> pv = Vec3D<T>(x, y, z);

		norm = matrix.m[0][3] * pv.x + matrix.m[1][3] * pv.y + matrix.m[2][3] * pv.z + matrix.m[3][3];

		if ( norm )
		{
			this->x = (matrix.m[0][0] * pv.x + matrix.m[1][0] * pv.y + matrix.m[2][0] * pv.z + matrix.m[3][0]) / norm;
			this->y = (matrix.m[0][1] * pv.x + matrix.m[1][1] * pv.y + matrix.m[2][1] * pv.z + matrix.m[3][1]) / norm;
			this->z = (matrix.m[0][2] * pv.x + matrix.m[1][2] * pv.y + matrix.m[2][2] * pv.z + matrix.m[3][2]) / norm;
		}
		else
		{
			this->x = 0.0f;
			this->y = 0.0f;
			this->z = 0.0f;
		}
	}

	void Project(CViewport& viewport, Matrix<T> &projection, Matrix<T> &view, Matrix<T> &world)
	{
		Matrix<T> m1, m2;
		
		m1 = world * view;
		m2 = m1 * projection;
		this->TransformCoord(m2);
		
		this->x = T(viewport.X +  ( 1.0 + this->x ) * viewport.Width / 2.0);
		this->y = T(viewport.Y +  ( 1.0 - this->y ) * viewport.Height / 2.0);
		this->z = T(viewport.MinZ + this->z * ( viewport.MaxZ - viewport.MinZ ));
	}
	void Unproject(CViewport& viewport, Matrix<T> &projection, Matrix<T> &view, Matrix<T> &world)
	{
		Matrix<T> m1, m2;		

		m1 = world * view;
		m2 = m1 * projection;

		m2.invert();
		this->x = T(2.0 * ( this->x - viewport.X ) / viewport.Width - 1.0);
		this->y = T(1.0 - 2.0 * ( this->y - viewport.Y ) / viewport.Height);
		this->z = T(( this->z - viewport.MinZ) / ( viewport.MaxZ - viewport.MinZ ));
		
		this->TransformCoord(m2);	
	}

	friend std::istream& operator>>(std::istream& in, Vec3D& v)
	{
		in >> v.x >> v.y >> v.z;
		return in;
	}

	operator T*()
	{
		return (T*)this;
	}	
};

typedef	Vec3D<int> vec3i;
typedef Vec3D<float> vec3f;
typedef Vec3D<double> vec3d;

template<class T>
class Vec2D :public GLVECTOR2<T>
{
public:

	Vec2D(T x0 = 0.0f, T y0 = 0.0f) 
	{
		x = x0;
		y = y0;
	}

	Vec2D(const Vec2D& v) 
	{
		x = v.x;
		y = v.y;
	}

	Vec2D& operator= (const Vec2D &v) {
		x = v.x;
		y = v.y;
		return *this;
	}

	Vec2D operator+ (const Vec2D &v) const
	{		
		return Vec2D(x+v.x,y+v.y);
	}

	Vec2D operator- (const Vec2D &v) const
	{		
		return Vec2D(x-v.x,y-v.y);
	}

	T operator* (const Vec2D &v) const
	{
		return x*v.x + y*v.y;
	}

	Vec2D operator* (T d) const
	{		
		return Vec2D(x*d,y*d);
	}

	Vec2D operator/ (T d) const
	{		
		return Vec2D(x/d,y/d);
	}

	friend Vec2D operator* (T d, const Vec2D& v)
	{
		return v * d;
	}

	Vec2D& operator+= (const Vec2D &v)
	{
		x += v.x;
		y += v.y;
		return *this;
	}

	Vec2D& operator-= (const Vec2D &v)
	{
		x -= v.x;
		y -= v.y;
		return *this;
	}

	Vec2D& operator*= (T d)
	{
		x *= d;
		y *= d;
		return *this;
	}

	T lengthSquared() const
	{
		return x*x+y*y;
	}

	T length() const
	{
		return sqrtf(x*x+y*y);
	}

	Vec2D& normalize()
	{
		this->operator*= (1.0f/length());
		return *this;
	}

	Vec2D operator~ () const
	{
		Vec2D r(*this);
		r.normalize();
		return r;
	}


	friend std::istream& operator>>(std::istream& in, Vec2D& v)
	{
		in >> v.x >> v.y;
		return in;
	}

	operator T*()
	{
		return (T*)this;
	}

};

typedef Vec2D<float> vec2f;
typedef Vec2D<double> vec2d;

template<class T>
class Vec4D :public GLVECTOR4<T>
{
public:

	Vec4D(T x0=0.0f, T y0=0.0f, T z0=0.0f, T w0=0.0f) 
	{
		x = x0;
		y = y0;
		z = z0;
		w = w0; 
	}

	Vec4D(const Vec4D<T>& v) 
	{
		x = v.x;
		y = v.y;
		z = v.z;
		w = v.w;
	}

	Vec4D(const Vec3D<T>& v, const T w0) 
	{
		x = v.x;
		y = v.y;
		z = v.z;
		w = w0;
	}

	Vec4D& operator= (const Vec4D<T> &v) {
		x = v.x;
		y = v.y;
		z = v.z;
		w = v.w;
		return *this;
	}

	const Vec4D operator+ (const Vec4D<T> &v) const
	{		
		return Vec4D(x+v.x,y+v.y,z+v.z,w+v.w);
	}

	const Vec4D operator- (const Vec4D<T> &v) const
	{		
		return Vec4D(x-v.x,y-v.y,z-v.z,w-v.w);
	}

	const Vec4D operator* (T d) const
	{
		
		return Vec4D(x*d,y*d,z*d,w*d);
	}

	friend Vec4D operator* (T d, const Vec4D<T>& v)
	{
		return v * d;
	}

	Vec4D& operator+= (const Vec4D<T> &v)
	{
		x += v.x;
		y += v.y;
		z += v.z;
		w += v.w;
		return *this;
	}

	Vec4D& operator-= (const Vec4D<T> &v)
	{
		x -= v.x;
		y -= v.y;
		z -= v.z;
		w -= v.w;
		return *this;
	}

	Vec4D& operator*= (T d)
	{
		x *= d;
		y *= d;
		z *= d;
		w *= d;
		return *this;
	}

	T operator* (const Vec4D<T> &v) const
	{
		return x*v.x + y*v.y + z*v.z + w*v.w;
	}

	T lengthSquared() const
	{
		return x*x+y*y+z*z+w*w;
	}

	T length() const
	{
		return sqrt(x*x+y*y+z*z+w*w);
	}

	void Normalize()
	{
		this->operator*= (1.0f/length());		
	}

	Vec4D& normalize()
	{
		this->operator*= (1.0f/length());
		return *this;
	}

	operator T*()
	{
		return (T*)this;
	}

	Vec3D<T> xyz() const
	{
		return Vec3D(x,y,z);
	}
};

typedef Vec4D<float> vec4f;

template<class T>
class Quaternion: public Vec4D<T> {
public:
	Quaternion(T x0=0.0f, T y0=0.0f, T z0=0.0f, T w0=1.0f): Vec4D(x0,y0,z0,w0) {}

	Quaternion(const Vec4D<T>& v) : Vec4D(v) {}

	Quaternion(const Vec3D<T>& v, const T w0) : Vec4D(v, w0) {}

	static const Quaternion<T> slerp(const T t, const Quaternion<T> &q0, const Quaternion<T> &q1)
	{
		double cosom = q0.x * q1.x + q0.y * q1.y + q0.z * q1.z + q0.w * q1.w;
		double tmp0, tmp1, tmp2, tmp3;
		if (cosom < 0.0)
		{
			cosom = -cosom;
			tmp0 = -q1.x;
			tmp1 = -q1.y;
			tmp2 = -q1.z;
			tmp3 = -q1.w;
		}
		else
		{
			tmp0 = q1.x;
			tmp1 = q1.y;
			tmp2 = q1.z;
			tmp3 = q1.w;
		}

		/* calc coeffs */
		double scale0, scale1;

		if ((1.0 - cosom) > Epsilon)
		{
			// standard case (slerp)
			double omega =  acos (cosom);
			double sinom = sin (omega);
			scale0 =  sin ((1.0 - t) * omega) / sinom;
			scale1 =  sin (t * omega) / sinom;
		}
		else
		{
			/* just lerp */
			scale0 = 1.0 - t;
			scale1 = t;
		}

		Quaternion<T> q;

		q.x = scale0 * q0.x + scale1 * tmp0;
		q.y = scale0 * q0.y + scale1 * tmp1;
		q.z = scale0 * q0.z + scale1 * tmp2;
		q.w = scale0 * q0.w + scale1 * tmp3;

		return q;
		//// SLERP
		//T dot = v1*v2;

		//if (fabs(dot) > 0.9995f) {
		//	// fall back to LERP
		//	return Quaternion::lerp(r, v1, v2);
		//}

		//T a = acos(dot) * r;
		//Quaternion q = (v2 - v1 * dot);
		//q.normalize();

		//return v1 * cos(a) + q * sin(a);
	}

	friend Quaternion<T> operator*(Quaternion<T> &a, Quaternion<T> &b)
	{
		return Quaternion<T>(
			a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
			a.w * b.y + a.y * b.w + a.z * b.x - a.x * b.z,
			a.w * b.z + a.z * b.w + a.x * b.y - a.y * b.x,
			a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z);
	}

	static T Dot(Quaternion<T>& a, Quaternion<T>& b)
	{
		return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
	}

	static const Quaternion<T> lerp(const T r, const Quaternion<T> &v1, const Quaternion<T> &v2)
	{
		return v1*(1.0f-r) + v2*r;
	}

	static Quaternion<T> EulerToQuaternion(double yaw, double pitch, double roll)
	{
		double cy = cos(yaw * 0.5);
		double cp = cos(pitch * 0.5);
		double cr = cos(roll * 0.5);
		double sy = sin(yaw * 0.5);
		double sp = sin(pitch * 0.5);
		double sr = sin(roll * 0.5);

		double qw = cy*cp*cr + sy*sp*sr;
		double qx = sy*cp*cr - cy*sp*sr;
		double qy = cy*sp*cr + sy*cp*sr;
		double qz = cy*cp*sr - sy*sp*cr;

		return Quaternion<T>(qx, qy, qz, qw);
	}


	static Vec3D<T> QuaternionToEuler(Quaternion<T>& q)
	{
		T q0 = q.w;
		T q1 = q.x;
		T q2 = q.y;
		T q3 = q.z;	

		T x = atan2( 2 * (q2*q3 + q0*q1), (q0*q0 - q1*q1 - q2*q2 + q3*q3));
		T y = asin( -2 * (q1*q3 - q0*q2));
		T z = atan2( 2 * (q1*q2 + q0*q3), (q0*q0 + q1*q1 - q2*q2 - q3*q3));

		return Vec3D<T>(x, y, z);
	}


};

typedef Quaternion<float> rotationf;
typedef Quaternion<double> Quaternion4d;

inline void rotate(float x0, float y0, float *x, float *y, float angle)
{
	float xa = *x - x0, ya = *y - y0;
	*x = xa*cosf(angle) - ya*sinf(angle) + x0;
	*y = xa*sinf(angle) + ya*cosf(angle) + y0;
}

template<class T>
class Matrix : public GLMATRIX4<T>{
public:
	
	Matrix()
	{
	}

	Matrix(const Matrix& p)
	{
		for (size_t j=0; j<4; j++) {
			for (size_t i=0; i<4; i++) {
				m[j][i] = p.m[j][i];
			}
		}
	}

	Matrix& operator= (const Matrix& p)
	{
		for (size_t j=0; j<4; j++) {
			for (size_t i=0; i<4; i++) {
				m[j][i] = p.m[j][i];
			}
		}
		return *this;
	}


	void zero()
	{
		m[0][1] = 0.0;
		m[0][2] = 0.0;
		m[0][3] = 0.0;
		m[1][0] = 0.0;
		m[1][2] = 0.0;
		m[1][3] = 0.0;
		m[2][0] = 0.0;
		m[2][1] = 0.0;
		m[2][3] = 0.0;
		m[3][0] = 0.0;
		m[3][1] = 0.0;
		m[3][2] = 0.0;
		m[0][0] = 0.0;
		m[1][1] = 0.0;
		m[2][2] = 0.0;
		m[3][3] = 0.0;
	}

	void unit()
	{
		zero();
		m[0][0] = m[1][1] = m[2][2] = m[3][3] = 1.0f;
	}

	void translation(T x, T y, T z)
	{
		/*
		1000
		0100
		0010
		###1
		*/
		unit();
		m[3][0]=x;
		m[3][1]=y;
		m[3][2]=z;
	}

	void translation(const Vec3D<T>& tr)
	{
		/*
		1000
		0100
		0010
		###1
		*/
		unit();
		m[3][0]=tr.x;
		m[3][1]=tr.y;
		m[3][2]=tr.z;
	}

	static const Matrix newTranslation(const Vec3D<T>& tr)
	{
		Matrix t;
		t.translation(tr);
		return t;
	}

	void scale(const Vec3D<T>& sc)
	{
		/*
		#000
		0#00
		00#0
		0001
		*/
		zero();
		m[0][0]=sc.x;
		m[1][1]=sc.y;
		m[2][2]=sc.z;
		m[3][3]=1.0f;
	}

	static const Matrix newScale(const Vec3D<T>& sc)
	{
		Matrix t;
		t.scale(sc);
		return t;
	}

	void quaternionRotate(const Quaternion<T>& q)
	{
		/*
		###0
		###0
		###0
		0001
		*/
		m[0][0] = 1.0f - 2.0f * q.y * q.y - 2.0f * q.z * q.z;
		m[0][1] = 2.0f * q.x * q.y + 2.0f * q.w * q.z;
		m[0][2] = 2.0f * q.x * q.z - 2.0f * q.w * q.y;
		m[1][0] = 2.0f * q.x * q.y - 2.0f * q.w * q.z;
		m[1][1] = 1.0f - 2.0f * q.x * q.x - 2.0f * q.z * q.z;
		m[1][2] = 2.0f * q.y * q.z + 2.0f * q.w * q.x;
		m[2][0] = 2.0f * q.x * q.z + 2.0f * q.w * q.y;
		m[2][1] = 2.0f * q.y * q.z - 2.0f * q.w * q.x;
		m[2][2] = 1.0f - 2.0f * q.x * q.x - 2.0f * q.y * q.y;
		m[0][3] = m[1][3] = m[2][3] = m[3][0] = m[3][1] = m[3][2] = 0;
		m[3][3] = 1.0f;
	}

	static const Matrix<T> newQuatRotate(const Quaternion<T>& qr)
	{
		Matrix<T> t;
		t.quaternionRotate(qr);
		return t;
	}

	inline float &operator()(int x, int y)
	{
		return M[x*4 + y];
	}

	// -- public -----------------------------------------------------------------
	// inline float Matrix3d::operator()(int x, int y) const
	// Index operator
	//----------------------------------------------------------------------------
	inline float operator()(int x, int y) const
	{
		return M[x*4 + y];
	}

	Vec3D<T> operator* (const Vec3D<T>& v) const //
	{
		Vec3D<T> o;
		o.x = m[0][0]*v.x + m[0][1]*v.y + m[0][2]*v.z + m[0][3];
		o.y = m[1][0]*v.x + m[1][1]*v.y + m[1][2]*v.z + m[1][3];
		o.z = m[2][0]*v.x + m[2][1]*v.y + m[2][2]*v.z + m[2][3];
		return o;
	}

	Vec4D<T> operator* (const Vec4D<T>& v) const//
	{
		Vec4D<T> o;
		o.x = m[0][0]*v.x + m[1][0]*v.y + m[2][0]*v.z + m[3][0]*v.w;
		o.y = m[0][1]*v.x + m[1][1]*v.y + m[2][1]*v.z + m[3][1]*v.w;
		o.z = m[0][2]*v.x + m[1][2]*v.y + m[2][2]*v.z + m[3][2]*v.w;
		o.w = m[0][3]*v.x + m[1][3]*v.y + m[2][3]*v.z + m[3][3]*v.w;
		return o;
	}

	Matrix<T> operator* (const Matrix<T>& p) const
	{
		Matrix<T> o;
		o.m[0][0] = m[0][0]*p.m[0][0] + m[0][1]*p.m[1][0] + m[0][2]*p.m[2][0] + m[0][3]*p.m[3][0];
		o.m[0][1] = m[0][0]*p.m[0][1] + m[0][1]*p.m[1][1] + m[0][2]*p.m[2][1] + m[0][3]*p.m[3][1];
		o.m[0][2] = m[0][0]*p.m[0][2] + m[0][1]*p.m[1][2] + m[0][2]*p.m[2][2] + m[0][3]*p.m[3][2];
		o.m[0][3] = m[0][0]*p.m[0][3] + m[0][1]*p.m[1][3] + m[0][2]*p.m[2][3] + m[0][3]*p.m[3][3];

		o.m[1][0] = m[1][0]*p.m[0][0] + m[1][1]*p.m[1][0] + m[1][2]*p.m[2][0] + m[1][3]*p.m[3][0];
		o.m[1][1] = m[1][0]*p.m[0][1] + m[1][1]*p.m[1][1] + m[1][2]*p.m[2][1] + m[1][3]*p.m[3][1];
		o.m[1][2] = m[1][0]*p.m[0][2] + m[1][1]*p.m[1][2] + m[1][2]*p.m[2][2] + m[1][3]*p.m[3][2];
		o.m[1][3] = m[1][0]*p.m[0][3] + m[1][1]*p.m[1][3] + m[1][2]*p.m[2][3] + m[1][3]*p.m[3][3];

		o.m[2][0] = m[2][0]*p.m[0][0] + m[2][1]*p.m[1][0] + m[2][2]*p.m[2][0] + m[2][3]*p.m[3][0];
		o.m[2][1] = m[2][0]*p.m[0][1] + m[2][1]*p.m[1][1] + m[2][2]*p.m[2][1] + m[2][3]*p.m[3][1];
		o.m[2][2] = m[2][0]*p.m[0][2] + m[2][1]*p.m[1][2] + m[2][2]*p.m[2][2] + m[2][3]*p.m[3][2];
		o.m[2][3] = m[2][0]*p.m[0][3] + m[2][1]*p.m[1][3] + m[2][2]*p.m[2][3] + m[2][3]*p.m[3][3];

		o.m[3][0] = m[3][0]*p.m[0][0] + m[3][1]*p.m[1][0] + m[3][2]*p.m[2][0] + m[3][3]*p.m[3][0];
		o.m[3][1] = m[3][0]*p.m[0][1] + m[3][1]*p.m[1][1] + m[3][2]*p.m[2][1] + m[3][3]*p.m[3][1];
		o.m[3][2] = m[3][0]*p.m[0][2] + m[3][1]*p.m[1][2] + m[3][2]*p.m[2][2] + m[3][3]*p.m[3][2];
		o.m[3][3] = m[3][0]*p.m[0][3] + m[3][1]*p.m[1][3] + m[3][2]*p.m[2][3] + m[3][3]*p.m[3][3];

		return o;
	}

	T determinant() const
	{
#define SUB(a,b) (m[2][a]*m[3][b] - m[3][a]*m[2][b])
		return
			m[0][0] * (m[1][1]*SUB(2,3) - m[1][2]*SUB(1,3) + m[1][3]*SUB(1,2))
			-m[0][1] * (m[1][0]*SUB(2,3) - m[1][2]*SUB(0,3) + m[1][3]*SUB(0,2))
			+m[0][2] * (m[1][0]*SUB(1,3) - m[1][1]*SUB(0,3) + m[1][3]*SUB(0,1))
			-m[0][3] * (m[1][0]*SUB(1,2) - m[1][1]*SUB(0,2) + m[1][2]*SUB(0,1));
#undef SUB
	}

	const T minor(size_t x, size_t y) const
	{
		T s[3][3];
		for (size_t j=0, v=0; j<4; j++) {
			if (j==y) continue;
			for (size_t i=0, u=0; i<4; i++) {
				if (i!=x) {
					s[v][u++] = m[j][i];
				}
			}
			v++;
		}
#define SUB(a,b) (s[1][a]*s[2][b] - s[2][a]*s[1][b])
		return s[0][0] * SUB(1,2) - s[0][1] * SUB(0,2) + s[0][2] * SUB(0,1);
#undef SUB
	}

	const Matrix<T> adjoint() const
	{
		Matrix<T> a;
		for (size_t j=0; j<4; j++) {
			for (size_t i=0; i<4; i++) {
				a.m[i][j] = (((i+j)&1)?-1.0f:1.0f) * minor(i,j);
			}
		}
		return a;
	}

	void invert()
	{
		Matrix<T> adj = this->adjoint();
		T invdet = 1.0f / this->determinant();
		for (size_t j=0; j<4; j++) {
			for (size_t i=0; i<4; i++) {
				m[j][i] = adj.m[j][i] * invdet;
			}
		}
	}

	void transpose()
	{
		for (size_t j=1; j<4; j++) {
			for (size_t i=0; i<j; i++) {
				T f = m[j][i];
				m[j][i] = m[i][j];
				m[i][j] = f;
			}
		}
	}

	static Matrix LookAtRH(Vec3D<T>& cameraPosition, Vec3D<T>& cameraTarget, Vec3D<T>& cameraUpVector)
	{
		Vec3D<T>	zaxis = (cameraPosition - cameraTarget).normalize();
		Vec3D<T>	xaxis = (cameraUpVector % zaxis).normalize();
		Vec3D<T>	yaxis = (zaxis % xaxis).normalize();

		Matrix<T> matrix;
		matrix.M11 = xaxis.x; matrix.M12 = yaxis.x; matrix.M13 = zaxis.x; matrix.M14 = 0;
		matrix.M21 = xaxis.y; matrix.M22 = yaxis.y; matrix.M23 = zaxis.y; matrix.M24 = 0;
		matrix.M31 = xaxis.z; matrix.M32 = yaxis.z; matrix.M33 = zaxis.z; matrix.M34 = 0;
		matrix.M41 = -(xaxis * cameraPosition); matrix.M42 = -(yaxis * cameraPosition); 
		matrix.M43 = -(zaxis * cameraPosition); matrix.M44 = 1;
			/*
			xaxis.x           yaxis.x           zaxis.x          0
			xaxis.y           yaxis.y           zaxis.y          0
			xaxis.z           yaxis.z           zaxis.z          0
			-dot(xaxis, cameraPosition)  -dot(yaxis, cameraPosition)  -dot(zaxis, cameraPosition)  1
			*/
		return matrix;
	}

	static Matrix PerspectiveFovRH(T fieldOfViewY, T aspectRatio, T znearPlane, T zfarPlane)
	{
		/*
		h = cot(fieldOfViewY/2). 
		w = h / aspectRatio
		w       0       0                                              0
		0       h       0                                              0
		0       0       zfarPlane/(znearPlane-zfarPlane)              -1
		0       0       znearPlane*zfarPlane/(znearPlane-zfarPlane)    0
		*/
		Matrix<T> matrix;
		matrix.zero();

		T h = T(1.0 / tan(fieldOfViewY / 2.0));
		T w = h / aspectRatio;

		matrix.M11 = w;
		matrix.M22 = h;
		matrix.M33 = zfarPlane / (znearPlane - zfarPlane);matrix.M34 = -1;
		matrix.M43 = znearPlane * zfarPlane / (znearPlane - zfarPlane);
		
		return matrix;
	}

	static Matrix RotationAxis(const Vec3D<T>& pv, T angle)
	{
		/*

		*/
		Vec3D<T> v;
		Matrix<T> matrix;
		matrix.zero();

		v = pv.normalize();

		T cosa = cos(angle);
		T sina = sin(angle);
		T mcosa = 1.0 - cosa;
		
		matrix.m[0][0] = mcosa * v.x * v.x + cosa;
		matrix.m[1][0] = mcosa * v.x * v.y - sina * v.z;
		matrix.m[2][0] = mcosa * v.x * v.z + sina * v.y;
		matrix.m[0][1] = mcosa * v.y * v.x + sina * v.z;
		matrix.m[1][1] = mcosa * v.y * v.y + cosa;
		matrix.m[2][1] = mcosa * v.y * v.z - sina * v.x;
		matrix.m[0][2] = mcosa * v.z * v.x - sina * v.y;
		matrix.m[1][2] = mcosa * v.z * v.y + sina * v.x;
		matrix.m[2][2] = mcosa * v.z * v.z + cosa;
		
		return matrix;
	}

	static Matrix RotationX(T angle)
	{
		/*
		1	 0		0	 0
		0 cos(angle) sin(angle) 0
		0 -sin(angle) cos(angle) 0
		0	0	0	1
		*/
		T cosa = cos(angle);
		T sina = sin(angle);

		Matrix<T> matrix;
		matrix.unit();
		matrix.M11 = 1;
		matrix.M22 = cosa;
		matrix.M23 = sina;
		matrix.M32 = -sina;
		matrix.M33 = cosa;
		return matrix;
	}

	static Matrix RotationY(T angle)
	{
		/*
		cos(angle)	 0		-sin(angle)	 0
		0	1		0	 0
		sin(angle)	0 cos(angle) 0
		0	0	0	1
		*/
		T cosa = cos(angle);
		T sina = sin(angle);

		Matrix<T> matrix;
		matrix.unit();
		matrix.M11 = cosa;
		matrix.M13 = -sina;
		matrix.M22 = 1;
		matrix.M31 = sina;
		matrix.M33 = cosa;
		return matrix;
	}

	static Matrix RotationZ(T angle)
	{
		/*
		cos(angle)	 sin(angle)		0		0
		-sin(angle)	cos(angle)		0	 0
		0	0	1	0
		0	0	0	1
		*/
		T cosa = cos(angle);
		T sina = sin(angle);

		Matrix<T> matrix;
		matrix.unit();
		matrix.M11 = cosa;
		matrix.M12 = sina;
		matrix.M21 = -sina;
		matrix.M22 = cosa;
		return matrix;
	}

	static Matrix RotationYawPitchRoll(T yaw, T pitch, T roll)
	 {
		 Matrix<T> matrix;

		 matrix = RotationZ(roll);

		 matrix *= RotationX(pitch);

		 matrix *= RotationY(yaw);

		 return matrix;
	 }

	Matrix<T>& operator*= (const Matrix<T>& p)
	{
		return *this = this->operator*(p);
	}

	operator T*()
	{
		return (T*)this;
	}

};

typedef Matrix<float> matrix4f;
typedef Matrix<double> matrix4d;

template<class T>
inline float glVec3Length
( CONST GLVECTOR3<T> *pV )
{
	assert(pV);
	return sqrtf(pV->x * pV->x + pV->y * pV->y + pV->z * pV->z);
}

template<class T>
inline float glVec3LengthSq
( CONST GLVECTOR3<T> *pV )
{
	assert(pV);
	return pV->x * pV->x + pV->y * pV->y + pV->z * pV->z;
}

template<class T>
inline float glVec3Dot
( CONST GLVECTOR3<T> *pV1, CONST GLVECTOR3<T> *pV2 )
{
	assert(pV1 && pV2);
	return pV1->x * pV2->x + pV1->y * pV2->y + pV1->z * pV2->z;
}

template<class T>
inline GLVECTOR3<T>* glVec3Cross
( GLVECTOR3<T> *pOut, CONST GLVECTOR3<T> *pV1, CONST GLVECTOR3<T> *pV2 )
{
	assert(pOut && pV1 && pV2);
	GLVECTOR3<T> v;

	v.x = pV1->y * pV2->z - pV1->z * pV2->y;
	v.y = pV1->z * pV2->x - pV1->x * pV2->z;
	v.z = pV1->x * pV2->y - pV1->y * pV2->x;

	*pOut = v;
	return pOut;
}

template<class T>
inline GLVECTOR3<T>* glVec3Add
( GLVECTOR3<T> *pOut, CONST GLVECTOR3<T> *pV1, CONST GLVECTOR3<T> *pV2 )
{
	assert(pOut && pV1 && pV2);
	pOut->x = pV1->x + pV2->x;
	pOut->y = pV1->y + pV2->y;
	pOut->z = pV1->z + pV2->z;
	return pOut;
}

template<class T>
inline void Matrix3Zero(GLMATRIX3<T>* NewObj)
{
	assert(NewObj);
	NewObj->_00 = NewObj->_01 = NewObj->_02 = 
		NewObj->_10 = NewObj->_11 = NewObj->_12 = 
		NewObj->_20 = NewObj->_21 = NewObj->_22 = 0.0f;
}

/**
* Sets this Matrix3 to identity.
*/
template<class T>
inline
static void Matrix3Identity(GLMATRIX3<T>* NewObj)
{
	assert(NewObj);
	Matrix3Zero(NewObj);

	//then set diagonal as 1
	NewObj->_00 = 
		NewObj->_11 = 
		NewObj->_22 = 1.0f;
}

/**
* Sets the value of this matrix to the matrix conversion of the
* quaternion argument. 
* @param q1 the quaternion to be converted 
*/
//$hack this can be optimized some(if s == 0)
template<class T>
inline
static void Matrix3fSetRotationFromQuat4f(GLMATRIX3<T>* NewObj, const GLVECTOR4<T>* q1)
{
	assert(NewObj && q1);
	T n, s;
	T xs, ys, zs;
	T wx, wy, wz;
	T xx, xy, xz;
	T yy, yz, zz;

	assert(NewObj && q1);

	n = (q1->x * q1->x) + (q1->y * q1->y) + (q1->z * q1->z) + (q1->w * q1->w);
	s = (n > 0.0f) ? (2.0f / n) : 0.0f;

	xs = q1->x * s;  ys = q1->y * s;  zs = q1->z * s;
	wx = q1->w * xs; wy = q1->w * ys; wz = q1->w * zs;
	xx = q1->x * xs; xy = q1->x * ys; xz = q1->x * zs;
	yy = q1->y * ys; yz = q1->y * zs; zz = q1->z * zs;

	NewObj->_00 = 1.0f - (yy + zz); NewObj->_01 =         xy - wz;  NewObj->_02 =         xz + wy;
	NewObj->_10 =         xy + wz;  NewObj->_11 = 1.0f - (xx + zz); NewObj->_12 =         yz - wx;
	NewObj->_20 =         xz - wy;  NewObj->_21 =         yz + wx;  NewObj->_22 = 1.0f - (xx + yy);
}

/**
* Sets the value of this matrix to the result of multiplying itself
* with matrix m1. 
* @param m1 the other matrix 
*/
template<class T>
inline void Matrix3fMulMatrix3f(GLMATRIX3<T>* NewObj, const GLMATRIX3<T>* m1)
{
	GLMATRIX3<T> Result; //safe not to initialize

	assert(NewObj && m1);

	// alias-safe way.
	Result._00 = (NewObj->_00 * m1->_00) + (NewObj->_01 * m1->_10) + (NewObj->_02 * m1->_20);
	Result._01 = (NewObj->_00 * m1->_01) + (NewObj->_01 * m1->_11) + (NewObj->_02 * m1->_21);
	Result._02 = (NewObj->_00 * m1->_02) + (NewObj->_01 * m1->_12) + (NewObj->_02 * m1->_22);

	Result._10 = (NewObj->_10 * m1->_00) + (NewObj->_11 * m1->_10) + (NewObj->_12 * m1->_20);
	Result._11 = (NewObj->_10 * m1->_01) + (NewObj->_11 * m1->_11) + (NewObj->_12 * m1->_21);
	Result._12 = (NewObj->_10 * m1->_02) + (NewObj->_11 * m1->_12) + (NewObj->_12 * m1->_22);

	Result._20 = (NewObj->_20 * m1->_00) + (NewObj->_21 * m1->_10) + (NewObj->_22 * m1->_20);
	Result._21 = (NewObj->_20 * m1->_01) + (NewObj->_21 * m1->_11) + (NewObj->_22 * m1->_21);
	Result._22 = (NewObj->_20 * m1->_02) + (NewObj->_21 * m1->_12) + (NewObj->_22 * m1->_22);

	//copy result back to this
	*NewObj = Result;
}

template<class T>
inline GLMATRIX4<T>* Matrix4Identity( GLMATRIX4<T> *pOut )
{
	assert(pOut);

	pOut->_01 = pOut->_02 = pOut->_03=
		pOut->_10 = pOut->_12 = pOut->_13=
		pOut->_20 = pOut->_21 = pOut->_23 =
		pOut->_30 = pOut->_31 = pOut->_32 = 0.0f;

	pOut->_00 = pOut->_11 = pOut->_22 = pOut->_33 = 1.0f;
	return pOut;
}

template<class T>
inline void Matrix4fSetRotationScaleFromMatrix4f
(GLMATRIX4<T>* NewObj, const GLMATRIX4<T>* m1)
{
	assert(NewObj && m1);

	NewObj->_00 = m1->_00; NewObj->_01 = m1->_01; NewObj->_02 = m1->_02;
	NewObj->_10 = m1->_10; NewObj->_11 = m1->_11; NewObj->_12 = m1->_12;
	NewObj->_20 = m1->_20; NewObj->_21 = m1->_21; NewObj->_22 = m1->_22;
}

/**
* Performs SVD on this matrix and gets scale and rotation.
* Rotation is placed into rot3, and rot4.
* @param rot3 the rotation factor(Matrix3d). if null, ignored
* @param rot4 the rotation factor(Matrix4) only upper 3x3 elements are changed. if null, ignored
* @return scale factor
*/
template<class T>
inline T Matrix4fSVD
(const GLMATRIX4<T>* NewObj, GLMATRIX3<T>* rot3, GLMATRIX4<T>* rot4)
{
	T s, n;

	assert(NewObj);

	// this is a simple svd.
	// Not complete but fast and reasonable.
	// See comment in Matrix3d.

	s = sqrtf(
		( (NewObj->_00 * NewObj->_00) + (NewObj->_10 * NewObj->_10) + (NewObj->_20 * NewObj->_20) + 
		(NewObj->_01 * NewObj->_01) + (NewObj->_11 * NewObj->_11) + (NewObj->_21 * NewObj->_21) +
		(NewObj->_02 * NewObj->_02) + (NewObj->_12 * NewObj->_12) + (NewObj->_22 * NewObj->_22) ) / 3.0f );

	if (rot3)   //if pointer not null
	{
		//this->getRotationScale(rot3);
		rot3->_00 = NewObj->_00; rot3->_10 = NewObj->_10; rot3->_20 = NewObj->_20;
		rot3->_01 = NewObj->_01; rot3->_11 = NewObj->_11; rot3->_21 = NewObj->_21;
		rot3->_02 = NewObj->_02; rot3->_12 = NewObj->_12; rot3->_22 = NewObj->_22;

		// zero-div may occur.

		n = 1.0f / sqrtf( (NewObj->_00 * NewObj->_00) +
			(NewObj->_10 * NewObj->_10) +
			(NewObj->_20 * NewObj->_20) );
		rot3->_00 *= n;
		rot3->_10 *= n;
		rot3->_20 *= n;

		n = 1.0f / sqrtf( (NewObj->_01 * NewObj->_01) +
			(NewObj->_11 * NewObj->_11) +
			(NewObj->_21 * NewObj->_21) );
		rot3->_01 *= n;
		rot3->_11 *= n;
		rot3->_21 *= n;

		n = 1.0f / sqrtf( (NewObj->_02 * NewObj->_02) +
			(NewObj->_12 * NewObj->_12) +
			(NewObj->_22 * NewObj->_22) );
		rot3->_02 *= n;
		rot3->_12 *= n;
		rot3->_22 *= n;
	}

	if (rot4)   //if pointer not null
	{
		if (rot4 != NewObj)
		{
			Matrix4fSetRotationScaleFromMatrix4f(rot4, NewObj);  // private method
		}

		// zero-div may occur.

		n = 1.0f / sqrtf( (NewObj->_00 * NewObj->_00) +
			(NewObj->_10 * NewObj->_10) +
			(NewObj->_20 * NewObj->_20) );
		rot4->_00 *= n;
		rot4->_10 *= n;
		rot4->_20 *= n;

		n = 1.0f / sqrtf( (NewObj->_01 * NewObj->_01) +
			(NewObj->_11 * NewObj->_11) +
			(NewObj->_21 * NewObj->_21) );
		rot4->_01 *= n;
		rot4->_11 *= n;
		rot4->_21 *= n;

		n = 1.0f / sqrtf( (NewObj->_02 * NewObj->_02) +
			(NewObj->_12 * NewObj->_12) +
			(NewObj->_22 * NewObj->_22) );
		rot4->_02 *= n;
		rot4->_12 *= n;
		rot4->_22 *= n;
	}

	return s;
}

template<class T>
inline void Matrix4fSetRotationScaleFromMatrix3f
(GLMATRIX4<T>* NewObj, const GLMATRIX3<T>* m1)
{
	assert(NewObj && m1);

	NewObj->_00 = m1->_00; NewObj->_01 = m1->_01; NewObj->_02 = m1->_02;
	NewObj->_10 = m1->_10; NewObj->_11 = m1->_11; NewObj->_12 = m1->_12;
	NewObj->_20 = m1->_20; NewObj->_21 = m1->_21; NewObj->_22 = m1->_22;
}

template<class T>
inline void Matrix4fMulRotationScale
(GLMATRIX4<T>* NewObj, T scale)
{
	assert(NewObj);

	NewObj->_00 *= scale; NewObj->_01 *= scale; NewObj->_02 *= scale;
	NewObj->_10 *= scale; NewObj->_11 *= scale; NewObj->_12 *= scale;
	NewObj->_20 *= scale; NewObj->_21 *= scale; NewObj->_22 *= scale;
}

/**
* Sets the rotational component (upper 3x3) of this matrix to the matrix
* values in the T precision Matrix3d argument; the other elements of
* this matrix are unchanged; a singular value decomposition is performed
* on this object's upper 3x3 matrix to factor out the scale, then this
* object's upper 3x3 matrix components are replaced by the passed rotation
* components, and then the scale is reapplied to the rotational
* components.
* @param m1 T precision 3x3 matrix
*/
template<class T>
inline void Matrix4fSetRotationFromMatrix3f
(GLMATRIX4<T>* NewObj, const GLMATRIX3<T>* m1)
{
	T scale;

	assert(NewObj && m1);

	scale = Matrix4fSVD(NewObj, (GLMATRIX3<T>*)NULL, (GLMATRIX4<T>*)NULL);

	Matrix4fSetRotationScaleFromMatrix3f(NewObj, m1);
	Matrix4fMulRotationScale(NewObj, scale);
}
extern vec3d SphericalDToCartesian(
								   double latitude,
								   double longitude,
								   double radius
								   );
extern vec3f SphericalDToCartesian(
								   float latitude,
								   float longitude,
								   float radius
								   );
extern vec3f SphericalToCartesian(
								  float latitude,
								  float longitude,
								  float radius
								  );
extern vec3d SphericalToCartesian(
								  double latitude,
								  double longitude,
								  double radius
								  );
extern vec3f CartesianToSpherical(float x, float y, float z);
extern vec3d CartesianToSpherical(double x, double y, double z);

inline double Distance(double lat0, double lon0, double att0, double lat1, double lon1, double att1)
{
	vec3d vec0 = SphericalDToCartesian(	lat0, lon0, 6378137 + att0);
	vec3d vec1 = SphericalDToCartesian(	lat1, lon1, 6378137 + att1);

	return (vec0 - vec1).length();
}

inline double SphericalDistance(double radLatA, double radLonA, double radLatB, double radLonB)
{
	return acos(
		cos(radLatA) * cos(radLatB) * cos(radLonA - radLonB) + 
		sin(radLatA) * sin(radLatB));
}

inline double DegreesToRadians(double degrees)
{
	return /*PI / 180.0*/M_PI_180 * degrees;
}

inline double RadiansToDegrees(double radians)
{
	return  radians * M_180_PI/*180.0 / PI*/;
}

inline int GetRowFromLatitude(double latitude, double tileSize)
{
	latitude = RadiansToDegrees(latitude);
	tileSize = RadiansToDegrees(tileSize);
	return (int)(fmod(abs(-90.0 - latitude), 180) / tileSize * 10 + 0.5) * 0.1;
}

inline int GetColFromLongitude(double longitude, double tileSize)
{
	longitude = RadiansToDegrees(longitude);
	tileSize = RadiansToDegrees(tileSize);
	return (int)(fmod(abs(-180.0 - longitude), 360) / tileSize * 10 + 0.5) * 0.1;
}

///////////////////////////////

template<class T>
inline T Rand_T() { return ((T) (rand() % 20000)/ 20000) ; }
inline void SRand_T(int x) { srand(x); }

template<class T>
inline T sqr_T(T f) { return f * f; }
/// Return a random number with a normal distribution.
template<class T>
inline T NRand_T(T sigma = 1.0f)
{
	const T P_ONE_OVER_SIGMA_EXP = (1.0f / 0.7975f);

	if(sigma == 0) return 0;

	T y;
	do {
		y = -log(Rand_T<T>());
	}
	while(Rand_T<T>() > exp(-sqr_T(y - 1.0f)*0.5f));

	if(rand() & 0x1)
		return y * sigma * P_ONE_OVER_SIGMA_EXP;
	else
		return -y * sigma * P_ONE_OVER_SIGMA_EXP;
}

template<class T>
inline Vec3D<T> RandVec()
{
	return Vec3D<T>(Rand_T(), Rand_T(), Rand_T());
}

template<class T>
inline Vec3D<T> NRandVec(T stdev)
{
	return Vec3D<T>(NRand_T(stdev), NRand_T(stdev), NRand_T(stdev));
}

////////////////////////////////////////////////

inline void Message (char* strinfo, ...)
{
	va_list  		vl;
	char        buf[1024];

	va_start (vl, strinfo);
	vsprintf (buf, strinfo, vl); 
	va_end (vl);
	MessageBox (NULL, buf, NULL, MB_ICONSTOP | MB_OK | MB_TASKMODAL);

}

inline void DebugMessage(char* strinfo, ...)
{
	va_list  		vl;
	char        buf[1024];

	va_start (vl, strinfo);
	vsprintf (buf, strinfo, vl); 
	va_end (vl);

	OutputDebugString(buf);
}

inline int printOglError(char *file, int line)     
{
	//
	// Returns 1 if an OpenGL error occurred, 0 otherwise.
	//
	GLenum glErr;
	int    retCode = 0;

	glErr = glGetError();

	while (glErr != GL_NO_ERROR)
	{

		DebugMessage("glError: %s   %s : %d\n", 
			gluErrorString(glErr), file, line);

		retCode = 1;

		glErr = glGetError();
	}

	return retCode;
}

#define printOpenGLError() printOglError(__FILE__, __LINE__)

////////////////////////////////////////////////////////////////////////////////

inline bool powerOf2(unsigned int n)
{
	return (n & (n-1)) == 0;
}

/*
* Return the next power of 2 that is equal or larger than n
*/
inline unsigned int nextPowerOf2(unsigned int n)
{
	if (powerOf2(n)) return n;

	unsigned int p;

	for(int i=31; i>=0; i--) 
	{
		p = n & (1 << i);

		if (p) 
		{
			p = (1 << (i+1));
			break;
		}
	}

	return p;
}
//////////////////////////////////////////////////////////////////////////////
// clamp x to be between a and b
inline float clamp(float x, float a, float b)
{
	return (x < a ? a : (x > b ? b : x));
}
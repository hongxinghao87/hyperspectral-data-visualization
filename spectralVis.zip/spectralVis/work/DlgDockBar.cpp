// DlgDockBar.cpp : implementation file
//

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "DlgDockBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDockBar dialog


CDlgDockBar::CDlgDockBar(CWnd* pParent /*=NULL*/)
{
	//{{AFX_DATA_INIT(CDlgDockBar)
	//}}AFX_DATA_INIT
	m_pControlWnd = NULL;
	m_pVolumeRender = NULL;
	m_nselIndex = -1;
	m_nselAlpha = -1;
	m_nSelHisAlpha = -1;
	m_bHistAlpha = false;
	m_bInitlize = false;
}


void CDlgDockBar::DoDataExchange(CDataExchange* pDX)
{
	CBCGPDialogBar::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDockBar)
	DDX_Control(pDX, IDC_COMBO1, m_AlphaComb);
	DDX_Control(pDX, IDC_COLOR_SLIDE, m_wndColorSlide);
	DDX_Control(pDX, IDC_COLOR_PICK, m_wndColorPalette);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDockBar, CBCGPDialogBar)
	//{{AFX_MSG_MAP(CDlgDockBar)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONUP()
	ON_BN_CLICKED(IDC_COLOR_PICK, OnColorPick)
	ON_BN_CLICKED(IDC_COLOR_SLIDE, OnColorSlide)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeAlphaCombo)
	ON_WM_KEYDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDockBar message handlers

int CDlgDockBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CBCGPDialogBar::OnCreate(lpCreateStruct) == -1)
		return -1;
		CClientDC dc (this);

		int nColors = 256;	// Use 256 first entries
		UINT nSize = sizeof(LOGPALETTE) + (sizeof(PALETTEENTRY) * nColors);
		LOGPALETTE *pLP = (LOGPALETTE *) new BYTE[nSize];

		pLP->palVersion = 0x300;
		pLP->palNumEntries = (USHORT) nColors;

		::GetSystemPaletteEntries (dc.GetSafeHdc (), 0, nColors, pLP->palPalEntry);

		m_palSys.CreatePalette (pLP);

		delete[] pLP;
		m_wndColorPalette.SetType(CBCGPColorPickerCtrl::PICKER);
		m_wndColorPalette.SetPalette (&m_palSys);
		m_wndColorPalette.SetColor (RGB (0, 255, 0));
		
		m_wndColorSlide.SetType (CBCGPColorPickerCtrl::LUMINANCE);
		m_wndColorSlide.SetPalette (&m_palSys);
		m_wndColorSlide.SetColor (RGB (0, 255, 0));
		
	return 0;
}

void CDlgDockBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	DrawControlArea(&dc);
	if (!m_bInitlize)
	{
		Initlize();
		m_bInitlize = true;
	}
	CBCGPDialogBar::OnPaint();
}
void CDlgDockBar::DrawControlArea(CDC *pDC)
{
	int i;
	if (m_pControlWnd&&m_pVolumeRender)
	{
		CBrush *pOldBrush,*pNewBrush,*pSelBrush;
		CPen *pOldPen,*pNewPen,*pSelPen,*pLinePen;
		CPoint xy,xy1;

		pNewBrush = new CBrush(RGB(236, 233,216));
		pNewPen   = new CPen(PS_SOLID,1,RGB(236, 233,216));
		pSelBrush = new CBrush(RGB(128, 128,64));
		pSelPen   = new CPen(PS_SOLID,1,RGB(128, 128,64));
		pLinePen   = new CPen(PS_SOLID,1,RGB(192, 192,192));
		pOldBrush = pDC->SelectObject(pNewBrush);
		pOldPen = pDC->SelectObject(pNewPen);
		pDC->FillRect(&m_ControlRect,&CBrush(RGB(0,0,0)));
		HDC lWndDC= pDC->GetSafeHdc();   
		RECT  lrtRect;   
		lrtRect.left = m_ControlRect.left;   
		lrtRect.top = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH;   
		lrtRect.right = m_ControlRect.right;   
		lrtRect.bottom = m_ControlRect.bottom - COLORBAR_TO_BOTTOM;   
		COLORREF col_from = RGB(255, 0,0);   
		COLORREF col_to = RGB(0, 255,0);   
		BOOL vert_grad=FALSE;   
		TRIVERTEX        vert[2];   
		GRADIENT_RECT    mesh;
		int ColorLength = m_ControlRect.Width() - COLORBAR_TO_LEFT - COLORBAR_TO_RIGHT;

		//���Ʊ��
		pDC->SelectObject(pLinePen);
		xy.x = m_ControlRect.left + COLORBAR_TO_LEFT;
		xy.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR;
		xy1.x = m_ControlRect.right - COLORBAR_TO_RIGHT;
		xy1.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR;
		pDC->MoveTo(xy);
		pDC->LineTo(xy1);
		int nStaffNum = 10;
		int nStaffWidth = m_ControlRect.Width() - COLORBAR_TO_LEFT - COLORBAR_TO_RIGHT;
		int nStaffHigh = 5;
		double dStaffStep = (float)nStaffWidth/nStaffNum;
		double dMinData = m_pVolumeRender->minsnb;
		double dMaxData = m_pVolumeRender->maxsnb;

		for(int i = 0;i<nStaffNum + 1;i++)
		{
			xy.x = m_ControlRect.left + COLORBAR_TO_LEFT + i*dStaffStep;
			xy.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR;
			xy1.x = xy.x;
			xy1.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR + nStaffHigh;
			pDC->MoveTo(xy);
			pDC->LineTo(xy1);
		}

		CString strStaff;
		int nWordWidth = 30;
		pDC->SetBkColor(RGB(0,0,0));
		pDC->SetTextColor(RGB(255,255,255));
		xy.x = m_ControlRect.left + COLORBAR_TO_LEFT;
		xy.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR + nStaffHigh + 5;
		strStaff.Format("%.4f",dMinData);
		pDC->TextOut(xy.x,xy.y,strStaff);

		xy.x = m_ControlRect.left + COLORBAR_TO_LEFT + dStaffStep*nStaffNum/2-nWordWidth/2;
		xy.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR + nStaffHigh + 5;
		strStaff.Format("%.4f",(dMinData + dMaxData)/2);
		pDC->TextOut(xy.x,xy.y,strStaff);

		xy.x = m_ControlRect.left + COLORBAR_TO_LEFT + dStaffStep*nStaffNum -nWordWidth;
		xy.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM + STAFF_TO_COLORBAR + nStaffHigh + 5;
		strStaff.Format("%.4f",dMaxData);
		pDC->TextOut(xy.x,xy.y,strStaff);

		if (m_bHistAlpha&&m_nSelHisAlpha > -1)
		{
			if (m_nSelHisAlpha < m_arrHistAlphaPoints.GetSize())
			{
				if (m_arrHistAlphaPoints[m_nSelHisAlpha].m_bAlphaSel)
				{
					double midpos = m_arrHistAlphaPoints[m_nSelHisAlpha].m_fMidPos;
					double drealPos =dMinData + (dMaxData - dMinData)*midpos;
					xy.x = m_ControlRect.right - COLORBAR_TO_RIGHT - 50;
					xy.y = m_ControlRect.top + HIST_TO_TOP  + 10;
					strStaff.Format("%.1f",drealPos);
					pDC->TextOut(xy.x,xy.y,strStaff);

				}
			}
		}

		//����ɫ��
		for (i = 0;i<m_pVolumeRender->m_ColorPoint.GetSize()-1;i++)
		{
			CColorPoint color =m_pVolumeRender->m_ColorPoint[i];
			col_from = RGB(color.m_Color.x*255, color.m_Color.y*255,color.m_Color.z*255);
			vert[0].x      = lrtRect.left + COLORBAR_TO_LEFT + color.m_fPos*ColorLength; 
			vert[0].y      = lrtRect.top;
			vert[0].Alpha  = 0x0000;
			vert[0].Blue   = GetBValue(col_from)<<8;   
			vert[0].Green  = GetGValue(col_from)<<8;   
			vert[0].Red    = GetRValue(col_from)<<8;
			if (!color.m_bColorSel)
			{
				pDC->SelectObject(pNewBrush);
				pDC->SelectObject(pNewPen);
			}else
			{
				pDC->SelectObject(pSelBrush);
				pDC->SelectObject(pSelPen);
			}
			CPoint ptX[3] = {CPoint(vert[0].x,lrtRect.bottom),
				CPoint(vert[0].x-2,lrtRect.bottom+5),
				CPoint(vert[0].x+2,lrtRect.bottom+5)};
			pDC->Polygon(ptX,3);
			

			color =m_pVolumeRender->m_ColorPoint[i+1];
			col_to = RGB(color.m_Color.x*255, color.m_Color.y*255,color.m_Color.z*255);
			vert[1].x      = lrtRect.left + COLORBAR_TO_LEFT + color.m_fPos*ColorLength;
			vert[1].y      = lrtRect.bottom;    
			vert[1].Alpha  = 0x0000;   
			vert[1].Blue   = GetBValue(col_to) <<8;   
			vert[1].Green  = GetGValue(col_to) <<8;   
			vert[1].Red    = GetRValue(col_to) <<8;   
			mesh.UpperLeft  = 0;   
			mesh.LowerRight = 1;   
			if (i == m_pVolumeRender->m_ColorPoint.GetSize()-2)
			{
				if (!color.m_bColorSel)
				{
					pDC->SelectObject(pNewBrush);
					pDC->SelectObject(pNewPen);
				}else
				{
					pDC->SelectObject(pSelBrush);
					pDC->SelectObject(pSelPen);
				}
				CPoint ptX[3] = {CPoint(vert[1].x,lrtRect.bottom),
					CPoint(vert[1].x-2,lrtRect.bottom+5),
					CPoint(vert[1].x+2,lrtRect.bottom+5)};
				pDC->Polygon(ptX,3);
			}
			GradientFill( lWndDC, vert, 2, &mesh, 1, vert_grad ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H );
		}
		
		//������״ͼ
		if(pNewPen)
			delete pNewPen;
		pNewPen   = new CPen(PS_SOLID,1,RGB(255, 255,0));
		pDC->SelectObject(pNewPen);
		pDC->MoveTo(CPoint(m_ControlRect.left+COLORBAR_TO_LEFT-2,m_ControlRect.bottom - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM));
		pDC->LineTo(CPoint(m_ControlRect.right-COLORBAR_TO_RIGHT+2,m_ControlRect.bottom - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM));
		pDC->LineTo(CPoint(m_ControlRect.right-COLORBAR_TO_RIGHT+2,m_ControlRect.top + HIST_TO_TOP));
		pDC->LineTo(CPoint(m_ControlRect.left+COLORBAR_TO_LEFT-2,m_ControlRect.top + HIST_TO_TOP));
		pDC->LineTo(CPoint(m_ControlRect.left+COLORBAR_TO_LEFT-2,m_ControlRect.bottom - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM));
		CRect rect;
		int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
		for (i=0;i<HIST_NUM;i++)
		{
			rect.left = m_ControlRect.left+COLORBAR_TO_LEFT + (float)(ColorLength)*i/HIST_NUM;
			rect.right = m_ControlRect.left+COLORBAR_TO_LEFT + (float)(ColorLength)*(i+1)/HIST_NUM;
			rect.bottom = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM;
			rect.top = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - nHistHigh*m_pVolumeRender->m_nDataHist[i]/m_pVolumeRender->m_nMaxHist;
			pDC->FillRect(&rect,&CBrush(RGB(60, 255,255)));
		}
		
		if (!m_bHistAlpha)
		{
			//����alpha����
			for (i=0;i<m_pVolumeRender->m_AlphaPoint.GetSize();i++)
			{
				CAlphaPoint onealpha = m_pVolumeRender->m_AlphaPoint[i];
				xy.x = m_ControlRect.left + COLORBAR_TO_LEFT + onealpha.m_fAlphapos*ColorLength;
				xy.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - nHistHigh*onealpha.m_Alpha;
				if (i<m_pVolumeRender->m_AlphaPoint.GetSize()-1)
				{
					pDC->SelectObject(pLinePen);
					CAlphaPoint onealpha1 = m_pVolumeRender->m_AlphaPoint[i+1];
					xy1.x = m_ControlRect.left + COLORBAR_TO_LEFT + onealpha1.m_fAlphapos*ColorLength;
					xy1.y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - nHistHigh*onealpha1.m_Alpha;
					pDC->MoveTo(xy.x,xy.y);
					pDC->LineTo(xy1.x,xy1.y);
				}
				if (!onealpha.m_bAlphaSel)
				{
					pDC->SelectObject(pNewBrush);
					pDC->SelectObject(pNewPen);
				}else
				{
					pDC->SelectObject(pSelBrush);
					pDC->SelectObject(pSelPen);
				}
				int nPolyWidth = 2;
				CPoint ptX[4] = {CPoint(xy.x-nPolyWidth,xy.y-nPolyWidth),
					CPoint(xy.x+nPolyWidth,xy.y-nPolyWidth),
					CPoint(xy.x+nPolyWidth,xy.y+nPolyWidth),
					CPoint(xy.x-nPolyWidth,xy.y+nPolyWidth)};
				pDC->Polygon(ptX,4);
			}
		}else
		{
			//����ֱ��Alpha
			CHisAlpha OneAlpha;
			CPoint ptX[4];
			for (i=0;i<m_arrHistAlphaPoints.GetSize();i++)
			{
				OneAlpha = m_arrHistAlphaPoints.GetAt(i);
				if (!OneAlpha.m_bAlphaSel)
				{
					pDC->SelectObject(pNewBrush);
					pDC->SelectObject(pNewPen);
				}else
				{
					pDC->SelectObject(pSelBrush);
					pDC->SelectObject(pSelPen);
				}
				double dx = OneAlpha.m_fMidPos - OneAlpha.m_fWidth/2.0;
				double dy = 0;
				ptX[0].x = m_ControlRect.left + COLORBAR_TO_LEFT + dx*ColorLength;
				ptX[0].y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - dy*nHistHigh;
				dx = OneAlpha.m_fMidPos - OneAlpha.m_fWidth/2.0 + OneAlpha.m_fWidth/20.0;
				dy = OneAlpha.m_fAlpha;
				ptX[1].x = m_ControlRect.left + COLORBAR_TO_LEFT + dx*ColorLength;
				ptX[1].y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - dy*nHistHigh;
				dx = OneAlpha.m_fMidPos + OneAlpha.m_fWidth/2.0 - OneAlpha.m_fWidth/20.0;
				dy = OneAlpha.m_fAlpha;
				ptX[2].x = m_ControlRect.left + COLORBAR_TO_LEFT + dx*ColorLength;
				ptX[2].y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - dy*nHistHigh;
				dx = OneAlpha.m_fMidPos + OneAlpha.m_fWidth/2.0;
				dy = 0;
				ptX[3].x = m_ControlRect.left + COLORBAR_TO_LEFT + dx*ColorLength;
				ptX[3].y = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - dy*nHistHigh;
				pDC->Polygon(ptX,4);
			}
		}

		if(pNewBrush)
			delete pNewBrush;
		if(pNewPen)
			delete pNewPen;
		if(pSelBrush)
			delete pSelBrush;
		if(pSelPen)
			delete pSelPen;
		if(pLinePen)
			delete pLinePen;
		
		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
		DeleteDC(lWndDC);   		
	}

}
void CDlgDockBar::OnSize(UINT nType, int cx, int cy) 
{
	CBCGPDialogBar::OnSize(nType, cx, cy);
	
	m_pControlWnd = GetDlgItem(IDC_BUTTON_CONTROL);
	if (m_pControlWnd) {
		m_pControlWnd->GetWindowRect(&m_ControlRect);
		ScreenToClient(&m_ControlRect);
	}
	
}
void CDlgDockBar::SetVolumeRenderLay(CVolumeRender *pVolumeRender)
{
	m_pVolumeRender = pVolumeRender;
}

void CDlgDockBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (nFlags&MK_LBUTTON)
	{
		if (m_nselIndex > 0&&m_nselIndex < m_pVolumeRender->m_ColorPoint.GetSize() - 1&&m_pVolumeRender)
		{
			double dx = (point.x - m_ControlRect.left - COLORBAR_TO_LEFT)/(float)(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT);
			CColorPoint leftColor = m_pVolumeRender->m_ColorPoint[m_nselIndex-1];
			CColorPoint rightColor = m_pVolumeRender->m_ColorPoint[m_nselIndex+1];
			if (dx < leftColor.m_fPos)
			{
				dx = leftColor.m_fPos;
			}
			if (dx > rightColor.m_fPos)
			{
				dx = rightColor.m_fPos;
			}
			m_pVolumeRender->m_ColorPoint[m_nselIndex].m_fPos = dx;
			m_pVolumeRender->bNeedrefreshColormap = true;
			theApp.pView->Invalidate(false);
			Invalidate(false);
		}

		//����͸���ȿ���
		if (!m_bHistAlpha)
		{
			if (m_nselAlpha > -1&&m_nselAlpha < m_pVolumeRender->m_AlphaPoint.GetSize()&&m_pVolumeRender)
			{
				if (m_nselAlpha > 0&&m_nselAlpha < m_pVolumeRender->m_AlphaPoint.GetSize()-1)
				{
					double dx = (point.x - m_ControlRect.left - COLORBAR_TO_LEFT)/(float)(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT);
					int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
					int nDis = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - point.y;
					double dy = (float)nDis/nHistHigh;
					if (dy < 0)
					{
						dy = 0;
					}
					if (dy > 1)
					{
						dy = 1;
					}
					CAlphaPoint leftAlpha = m_pVolumeRender->m_AlphaPoint[m_nselAlpha-1];
					CAlphaPoint rightAlpha = m_pVolumeRender->m_AlphaPoint[m_nselAlpha+1];
					if (dx < leftAlpha.m_fAlphapos)
					{
						dx = leftAlpha.m_fAlphapos;
					}
					if (dx > rightAlpha.m_fAlphapos)
					{
						dx = rightAlpha.m_fAlphapos;
					}
					m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_fAlphapos = dx;
					m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_Alpha = dy;
				}
				else
				{
					int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
					int nDis = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - point.y;
					double dy = (float)nDis/nHistHigh;
					if (dy < 0)
					{
						dy = 0;
					}
					if (dy > 1)
					{
						dy = 1;
					}
					m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_Alpha = dy;
				}
				m_pVolumeRender->bNeedrefreshColormap = true;
				theApp.pView->Invalidate(false);
				Invalidate(false);
				
			}
		}
		else//ֱ��͸���ȿ���
		{
			if (nFlags&MK_SHIFT)
			{
				if (m_nSelHisAlpha > -1&&m_nSelHisAlpha<m_arrHistAlphaPoints.GetSize())
				{
					double dx = (point.x - m_ControlRect.left - COLORBAR_TO_LEFT)/(float)(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT);
					int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
					int nDis = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - point.y;
					double dy = (float)nDis/nHistHigh;
					m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth = 2*(dx-m_arrHistAlphaPoints[m_nSelHisAlpha].m_fMidPos);
					m_arrHistAlphaPoints[m_nSelHisAlpha].m_fAlpha = dy;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha].m_fAlphapos = dx - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+1].m_fAlphapos = dx - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0 + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/20.0;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+1].m_Alpha = dy;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+2].m_fAlphapos = dx + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0 - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/20.0;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+2].m_Alpha = dy;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+3].m_fAlphapos = dx + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					m_pVolumeRender->bNeedrefreshColormap = true;
					theApp.pView->Invalidate(false);
					Invalidate(false);				
				}
			}else if (m_nSelHisAlpha > -1&&m_nSelHisAlpha<m_arrHistAlphaPoints.GetSize())
			{
				double dx = (point.x - m_ControlRect.left - COLORBAR_TO_LEFT)/(float)(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT);
				double dleft,dright;
				if (m_nSelHisAlpha == 0&&m_nSelHisAlpha == m_arrHistAlphaPoints.GetSize()-1)
				{
					dleft = m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					dright = 1 - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
				}else if (m_nSelHisAlpha == 0)
				{
					dleft = m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					dright = m_arrHistAlphaPoints[m_nSelHisAlpha+1].m_fMidPos - m_arrHistAlphaPoints[m_nSelHisAlpha+1].m_fWidth/2.0 - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
				}else if (m_nSelHisAlpha == m_arrHistAlphaPoints.GetSize()-1)
				{
					dleft = m_arrHistAlphaPoints[m_nSelHisAlpha-1].m_fMidPos + m_arrHistAlphaPoints[m_nSelHisAlpha-1].m_fWidth/2.0 + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					dright = 1 - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
				}else
				{
					dleft = m_arrHistAlphaPoints[m_nSelHisAlpha-1].m_fMidPos + m_arrHistAlphaPoints[m_nSelHisAlpha-1].m_fWidth/2.0 + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					dright = m_arrHistAlphaPoints[m_nSelHisAlpha+1].m_fMidPos - m_arrHistAlphaPoints[m_nSelHisAlpha+1].m_fWidth/2.0 - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
				}
				if (dx > dleft && dx < dright)
				{
					m_arrHistAlphaPoints[m_nSelHisAlpha].m_fMidPos = dx;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha].m_fAlphapos = dx - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+1].m_fAlphapos = dx - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0 + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/20.0;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+2].m_fAlphapos = dx + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0 - m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/20.0;
					m_pVolumeRender->m_AlphaPoint[1+4*m_nSelHisAlpha+3].m_fAlphapos = dx + m_arrHistAlphaPoints[m_nSelHisAlpha].m_fWidth/2.0;
					m_pVolumeRender->bNeedrefreshColormap = true;
					theApp.pView->Invalidate(false);
					Invalidate(false);				
				}
			}
		}
	}
	CBCGPDialogBar::OnMouseMove(nFlags, point);
}

void CDlgDockBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	
	CBCGPDialogBar::OnLButtonUp(nFlags, point);
}

void CDlgDockBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (m_nselAlpha > -1&&m_nselAlpha<m_pVolumeRender->m_AlphaPoint.GetSize())
	{
		m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_bAlphaSel = false;
		m_nselAlpha = -1;
	}
	if (m_nselIndex > -1&&m_nselIndex<m_pVolumeRender->m_ColorPoint.GetSize())
	{
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_bColorSel = false;
		m_nselIndex = -1;
	}
	if (m_nSelHisAlpha > -1&&m_nSelHisAlpha<m_arrHistAlphaPoints.GetSize())
	{
		m_arrHistAlphaPoints[m_nSelHisAlpha].m_bAlphaSel = false;
		m_nSelHisAlpha = -1;
	}
	int nDis = point.y - m_ControlRect.bottom + COLORBAR_TO_BOTTOM;
	double dx = (point.x - (m_ControlRect.left + COLORBAR_TO_LEFT))/(float)(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT);
	//ѡ��ɫ���·����Ƶ�
	if (nDis >= 0&&nDis <= 5&&dx >= 0&&dx <= 1)
	{
		SelectColorPoint(dx);
	}
	if (!m_bHistAlpha)
	{
		//ѡ��͸���ȿ��Ƶ�
		int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
		int nHistWidth = m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT;
		nDis = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - point.y;
		double dy = (float)nDis/nHistHigh;
		if (dy > -2.0/nHistHigh&&dy<0)
		{
			dy = 0;
		}
		if (dx > -2.0/nHistWidth&&dx<0)
		{
			dx = 0;
		}
		if (dx < 1 + 2.0/nHistWidth&&dx>1)
		{
			dx = 1;
		}
		if (dx>= 0&&dx <= 1&&dy >= 0 && dy <= 1 )
		{
			SelectAlphaPoint(dx,dy);
		}
	}else
	{
		//ѡ��ֱ��͸���ȿ��Ƶ�
		for(int i =0;i<m_arrHistAlphaPoints.GetSize();i++)
		{
			if (SelectHistAlphaPoint(point,m_arrHistAlphaPoints[i]))
			{
				m_arrHistAlphaPoints[i].m_bAlphaSel = true;
				m_nSelHisAlpha = i;
			}else
			{
				m_arrHistAlphaPoints[i].m_bAlphaSel = false;
			}
		}
		Invalidate(false);
	}

	CBCGPDialogBar::OnLButtonDown(nFlags, point);
}
bool CDlgDockBar::SelectHistAlphaPoint(CPoint pt,CHisAlpha HisAlphaPt)
{
	int nBottom,nTop,nLeft,nRight;
	double dx,dy;
	int ColorLength = m_ControlRect.Width() - COLORBAR_TO_LEFT - COLORBAR_TO_RIGHT;
	int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
	dx = HisAlphaPt.m_fMidPos - HisAlphaPt.m_fWidth/2.0;
	nLeft = m_ControlRect.left + COLORBAR_TO_LEFT + dx*ColorLength;
	dx = HisAlphaPt.m_fMidPos + HisAlphaPt.m_fWidth/2.0;
	nRight = m_ControlRect.left + COLORBAR_TO_LEFT + dx*ColorLength;
	nBottom = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM;
	dy = HisAlphaPt.m_fAlpha;
	nTop = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - dy*nHistHigh;
	if (pt.x > nLeft&&pt.x < nRight&&pt.y>nTop&&pt.y<nBottom)
	{
		return true;
	}
	return false;
}
bool CDlgDockBar::SelectAlphaPoint(double dx,double dy)
{
	bool bseled = false;
	CAlphaPoint alphapoint;
	int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
	for(int i=0;i<m_pVolumeRender->m_AlphaPoint.GetSize();i++)
	{
		alphapoint = m_pVolumeRender->m_AlphaPoint[i];
		if (fabs(alphapoint.m_fAlphapos-dx)*(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT)<=4&&
			fabs(alphapoint.m_Alpha-dy)*nHistHigh<=4)
		{
			m_pVolumeRender->m_AlphaPoint[i].m_bAlphaSel = true;
			bseled = true;
			m_nselAlpha = i;
			if (m_nselIndex > -1&&m_nselIndex<m_pVolumeRender->m_ColorPoint.GetSize())
			{
				m_pVolumeRender->m_ColorPoint[m_nselIndex].m_bColorSel = false;
				m_nselIndex = -1;
			}
		}else
		{
			m_pVolumeRender->m_AlphaPoint[i].m_bAlphaSel = false;
		}
	}
	Invalidate(false);
	return bseled;
}
bool CDlgDockBar::SelectColorPoint(double dx)
{
	bool bseled = false;
	CColorPoint color;
	for(int i=0;i<m_pVolumeRender->m_ColorPoint.GetSize();i++)
	{
		color = m_pVolumeRender->m_ColorPoint[i];
		if (fabs(color.m_fPos-dx)*(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT)<=5)
		{
			m_pVolumeRender->m_ColorPoint[i].m_bColorSel = true;
			bseled = true;
			m_nselIndex = i;

			COLORREF rgbcolor = RGB(color.m_Color.x*255,color.m_Color.y*255,color.m_Color.z*255);
			
			m_wndColorPalette.SetColor (rgbcolor);
			m_wndColorSlide.SetColor (rgbcolor);
			if (m_nselAlpha > -1&&m_nselAlpha<m_pVolumeRender->m_AlphaPoint.GetSize())
			{
				m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_bAlphaSel = false;
				m_nselAlpha = -1;
			}
		}else
		{
			m_pVolumeRender->m_ColorPoint[i].m_bColorSel = false;
		}
	}
	Invalidate(false);
	return bseled;
}
void CDlgDockBar::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	
	CBCGPDialogBar::OnLButtonDblClk(nFlags, point);
}

void CDlgDockBar::OnRButtonUp(UINT nFlags, CPoint point) 
{
	int nDis = point.y - m_ControlRect.bottom + COLORBAR_TO_BOTTOM;
	double dx = (point.x - (m_ControlRect.left + COLORBAR_TO_LEFT))/(float)(m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT);
	//ѡ��ɫ���·����Ƶ�
	if (nDis >= 0&&nDis <= 5&&dx > 0&&dx < 1)
	{
		InsertColorPoint(dx);
	}

	if (!m_bHistAlpha)
	{
		//ѡ��͸���ȿ��Ƶ�
		int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
		int nHistWidth = m_ControlRect.Width()-COLORBAR_TO_LEFT-COLORBAR_TO_RIGHT;
		nDis = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - point.y;
		double dy = (float)nDis/nHistHigh;
		if (dx> 0&&dx < 1&&dy > 0 && dy < 1 )
		{
			InsertAlphaPoint(dx,dy);
		}
	}else
	{
		//ѡ��͸���ȿ���ֱ��
		int nHistHigh = m_ControlRect.Height() - COLORBAR_TO_BOTTOM-COLORBAR_HIGH-HIST_TO_BOTTOM-HIST_TO_TOP-5;
		nDis = m_ControlRect.bottom - COLORBAR_TO_BOTTOM - COLORBAR_HIGH - HIST_TO_BOTTOM - point.y;
		double dy = (float)nDis/nHistHigh;
		if (dx> 0&&dx < 1&&dy > 0 && dy < 1 )
		{
			InsertAlphaHist(dx,dy);
		}		
	}
	
	CBCGPDialogBar::OnRButtonUp(nFlags, point);
}
bool CDlgDockBar::InsertAlphaHist(double dx,double dy)
{
	CHisAlpha rightAlpha;
	CAlphaPoint onePoint;
	for(int i=0;i<m_arrHistAlphaPoints.GetSize();i++)
	{
		rightAlpha = m_arrHistAlphaPoints[i];
		if (rightAlpha.m_fMidPos > dx)
		{
			CHisAlpha newPoint;
			newPoint.m_fMidPos = dx;
			newPoint.m_bAlphaSel = true;
			newPoint.m_fAlpha = dy;
			if (m_nSelHisAlpha > -1&&m_nSelHisAlpha<m_arrHistAlphaPoints.GetSize())
			{
				m_arrHistAlphaPoints[m_nSelHisAlpha].m_bAlphaSel = false;
			}
			m_nSelHisAlpha = i;
			m_arrHistAlphaPoints.InsertAt(i,newPoint,1);

			ResetHistAlpha();
			return true;
		}else if (i == m_arrHistAlphaPoints.GetSize()-1)
		{
			CHisAlpha newPoint;
			newPoint.m_fMidPos = dx;
			newPoint.m_bAlphaSel = true;
			newPoint.m_fAlpha = dy;
			if (m_nSelHisAlpha > -1&&m_nSelHisAlpha<m_arrHistAlphaPoints.GetSize())
			{
				m_arrHistAlphaPoints[m_nSelHisAlpha].m_bAlphaSel = false;
			}
			m_nSelHisAlpha = i+1;
			m_arrHistAlphaPoints.Add(newPoint);
			ResetHistAlpha();

			return true;
		}
	}
	return false;
}
bool CDlgDockBar::InsertAlphaPoint(double dx,double dy)
{
	CAlphaPoint rightAlpha;
	for(int i=0;i<m_pVolumeRender->m_AlphaPoint.GetSize();i++)
	{
		rightAlpha = m_pVolumeRender->m_AlphaPoint[i];
		if (rightAlpha.m_fAlphapos > dx)
		{
			CAlphaPoint newPoint;
			newPoint.m_fAlphapos = dx;
			newPoint.m_bAlphaSel = true;
			newPoint.m_Alpha = dy;
			if (m_nselAlpha > -1&&m_nselAlpha<m_pVolumeRender->m_AlphaPoint.GetSize())
			{
				m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_bAlphaSel = false;
			}
			m_nselAlpha = i;
			m_pVolumeRender->m_AlphaPoint.InsertAt(i,newPoint,1);
			m_pVolumeRender->bNeedrefreshColormap = true;
			Invalidate(false);
			theApp.pView->Invalidate(false);
			return true;
		}
	}
	return false;

}
bool CDlgDockBar::InsertColorPoint(double dx)
{
	CColorPoint rightcolor,leftcolor;
	for(int i=0;i<m_pVolumeRender->m_ColorPoint.GetSize();i++)
	{
		rightcolor = m_pVolumeRender->m_ColorPoint[i];
		if (rightcolor.m_fPos > dx)
		{
			leftcolor = m_pVolumeRender->m_ColorPoint[i-1];
			CColorPoint newPoint;
			newPoint.m_fPos = dx;
			newPoint.m_bColorSel = true;
			newPoint.m_Color = leftcolor.m_Color + (rightcolor.m_Color - leftcolor.m_Color)*(dx - leftcolor.m_fPos)/(rightcolor.m_fPos - leftcolor.m_fPos);
			if (m_nselIndex > -1&&m_nselIndex<m_pVolumeRender->m_ColorPoint.GetSize())
			{
				m_pVolumeRender->m_ColorPoint[m_nselIndex].m_bColorSel = false;
			}
			m_nselIndex = i;
			m_pVolumeRender->m_ColorPoint.InsertAt(i,newPoint,1);
			m_pVolumeRender->bNeedrefreshColormap = true;
			Invalidate(false);
			return true;
		}
	}
	return false;
}


void CDlgDockBar::OnColorPick() 
{
	COLORREF color = m_wndColorPalette.GetColor ();
	if (m_nselIndex > -1&&m_nselIndex < m_pVolumeRender->m_ColorPoint.GetSize())
	{
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_Color.x = GetRValue (color)/255.0;
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_Color.y = GetGValue (color)/255.0;
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_Color.z = GetBValue (color)/255.0;
		m_pVolumeRender->bNeedrefreshColormap = true;
		theApp.pView->Invalidate(false);
	}
	m_wndColorSlide.SetColor (color);
	Invalidate(false);
}
void CDlgDockBar::Initlize()
{
	m_AlphaComb.AddString("���Կ���");
	m_AlphaComb.AddString("ֱ������");
	m_AlphaComb.SetCurSel(0);
	CHisAlpha oneHisAlpha;
	oneHisAlpha.m_fAlpha = 0.6;
	oneHisAlpha.m_fMidPos = 0.2;
	m_arrHistAlphaPoints.Add(oneHisAlpha);
	//oneHisAlpha.m_fAlpha = 0.3;
	//oneHisAlpha.m_fMidPos = 0.4;
	//m_arrHistAlphaPoints.Add(oneHisAlpha);
	//oneHisAlpha.m_fAlpha = 0.6;
	//oneHisAlpha.m_fMidPos = 0.6;
	//m_arrHistAlphaPoints.Add(oneHisAlpha);
	//m_btnCtrOK.SetState(true);
}
void CDlgDockBar::OnColorSlide() 
{
	COLORREF color = m_wndColorSlide.GetColor ();
	if (m_nselIndex > -1&&m_nselIndex < m_pVolumeRender->m_ColorPoint.GetSize())
	{
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_Color.x = GetRValue (color)/255.0;
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_Color.y = GetGValue (color)/255.0;
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_Color.z = GetBValue (color)/255.0;
		m_pVolumeRender->bNeedrefreshColormap = true;
		theApp.pView->Invalidate(false);
	}
	Invalidate(false);
	
}

void CDlgDockBar::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch(nChar)
	{
	case VK_DELETE:
		if (m_nselIndex > 0&&m_nselIndex < m_pVolumeRender->m_ColorPoint.GetSize()-1)
		{
			if (AfxMessageBox("�Ƿ�ɾ������ɫ��?",MB_OKCANCEL)==IDOK)
			{
				m_pVolumeRender->m_ColorPoint.RemoveAt(m_nselIndex);
				Invalidate(false);
				m_pVolumeRender->bNeedrefreshColormap = true;
				theApp.pView->Invalidate(false);
				m_nselIndex = -1;
			}
		}else if (m_nselAlpha > 0&&m_nselAlpha < m_pVolumeRender->m_AlphaPoint.GetSize()-1)
		{
			if (AfxMessageBox("�Ƿ�ɾ����Alpha��?",MB_OKCANCEL)==IDOK)
			{
				m_pVolumeRender->m_AlphaPoint.RemoveAt(m_nselAlpha);
				Invalidate(false);
				m_pVolumeRender->bNeedrefreshColormap = true;
				theApp.pView->Invalidate(false);
				m_nselAlpha = -1;
			}
		}else if (m_nSelHisAlpha > -1&&m_nSelHisAlpha < m_arrHistAlphaPoints.GetSize())
		{
			if (AfxMessageBox("�Ƿ�ɾ����Alphaֱ��?",MB_OKCANCEL)==IDOK)
			{
				m_arrHistAlphaPoints.RemoveAt(m_nSelHisAlpha);
				ResetHistAlpha();
				m_nselAlpha = -1;
			}
		}
		break;
	default:
	    break;
	}
		
	CBCGPDialogBar::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CDlgDockBar::OnSelchangeAlphaCombo() 
{
	if (!m_pVolumeRender)
	{
		return;
	}
	int i;
	int nsel = m_AlphaComb.GetCurSel();
	if (nsel == 0&&m_bHistAlpha&&m_arrLineAlphaPoints.GetSize() > 0)
	{
		m_pVolumeRender->m_AlphaPoint.RemoveAll();
		for (i = 0;i<m_arrLineAlphaPoints.GetSize();i++)
		{
			m_pVolumeRender->m_AlphaPoint.Add(m_arrLineAlphaPoints.GetAt(i));
		}
		m_pVolumeRender->bNeedrefreshColormap = true;
		theApp.pView->Invalidate(false);
		Invalidate(false);
		m_bHistAlpha = false;
	}
	if (nsel == 1&&!m_bHistAlpha&&m_arrHistAlphaPoints.GetSize() > 0)
	{
		m_arrLineAlphaPoints.RemoveAll();
		for (i = 0;i<m_pVolumeRender->m_AlphaPoint.GetSize();i++)
		{
			m_arrLineAlphaPoints.Add(m_pVolumeRender->m_AlphaPoint.GetAt(i));
		}
		m_pVolumeRender->m_AlphaPoint.RemoveAll();
		CHisAlpha oneAlpha;
		CAlphaPoint onePoint;
		onePoint.m_Alpha = 0;
		onePoint.m_fAlphapos =0;
		onePoint.m_bAlphaSel = false;
		m_pVolumeRender->m_AlphaPoint.Add(onePoint);

		for (i=0;i<m_arrHistAlphaPoints.GetSize();i++)
		{
			oneAlpha = m_arrHistAlphaPoints.GetAt(i);
			onePoint.m_Alpha = 0;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos - oneAlpha.m_fWidth/2.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);

			onePoint.m_Alpha = oneAlpha.m_fAlpha;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos - oneAlpha.m_fWidth/2.0 + oneAlpha.m_fWidth/20.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);

			onePoint.m_Alpha = oneAlpha.m_fAlpha;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos + oneAlpha.m_fWidth/2.0 - oneAlpha.m_fWidth/20.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);

			onePoint.m_Alpha = 0;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos + oneAlpha.m_fWidth/2.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);
		}
		onePoint.m_Alpha = 0;
		onePoint.m_fAlphapos =1;
		onePoint.m_bAlphaSel = false;
		m_pVolumeRender->m_AlphaPoint.Add(onePoint);
		m_pVolumeRender->bNeedrefreshColormap = true;
		theApp.pView->Invalidate(false);
		Invalidate(false);
		m_bHistAlpha = true;
	}
	this->SetFocus();
}

void CDlgDockBar::OnRButtonDown(UINT nFlags, CPoint point) 
{
	if (m_nselAlpha > -1&&m_nselAlpha<m_pVolumeRender->m_AlphaPoint.GetSize())
	{
		m_pVolumeRender->m_AlphaPoint[m_nselAlpha].m_bAlphaSel = false;
		m_nselAlpha = -1;
	}
	if (m_nselIndex > -1&&m_nselIndex<m_pVolumeRender->m_ColorPoint.GetSize())
	{
		m_pVolumeRender->m_ColorPoint[m_nselIndex].m_bColorSel = false;
		m_nselIndex = -1;
	}
	if (m_nSelHisAlpha > -1&&m_nSelHisAlpha<m_arrHistAlphaPoints.GetSize())
	{
		m_arrHistAlphaPoints[m_nSelHisAlpha].m_bAlphaSel = false;
		m_nSelHisAlpha = -1;
	}
	if (m_bHistAlpha)
	{
		//ѡ��ֱ��͸���ȿ��Ƶ�
		for(int i =0;i<m_arrHistAlphaPoints.GetSize();i++)
		{
			if (SelectHistAlphaPoint(point,m_arrHistAlphaPoints[i]))
			{
				m_arrHistAlphaPoints[i].m_bAlphaSel = true;
				m_nSelHisAlpha = i;
			}else
			{
				m_arrHistAlphaPoints[i].m_bAlphaSel = false;
			}
		}
		Invalidate(false);
	}
		
	CBCGPDialogBar::OnRButtonDown(nFlags, point);
}
void CDlgDockBar::ResetHistAlpha()
{
	int i;
	if (m_bHistAlpha)
	{
		m_pVolumeRender->m_AlphaPoint.RemoveAll();
		CHisAlpha oneAlpha;
		CAlphaPoint onePoint;
		onePoint.m_Alpha = 0;
		onePoint.m_fAlphapos =0;
		onePoint.m_bAlphaSel = false;
		m_pVolumeRender->m_AlphaPoint.Add(onePoint);

		for (i=0;i<m_arrHistAlphaPoints.GetSize();i++)
		{
			oneAlpha = m_arrHistAlphaPoints.GetAt(i);
			onePoint.m_Alpha = 0;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos - oneAlpha.m_fWidth/2.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);

			onePoint.m_Alpha = oneAlpha.m_fAlpha;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos - oneAlpha.m_fWidth/2.0 + oneAlpha.m_fWidth/20.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);

			onePoint.m_Alpha = oneAlpha.m_fAlpha;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos + oneAlpha.m_fWidth/2.0 - oneAlpha.m_fWidth/20.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);

			onePoint.m_Alpha = 0;
			onePoint.m_fAlphapos = oneAlpha.m_fMidPos + oneAlpha.m_fWidth/2.0;
			onePoint.m_bAlphaSel = false;
			m_pVolumeRender->m_AlphaPoint.Add(onePoint);
		}
		onePoint.m_Alpha = 0;
		onePoint.m_fAlphapos =1;
		onePoint.m_bAlphaSel = false;
		m_pVolumeRender->m_AlphaPoint.Add(onePoint);
		m_pVolumeRender->bNeedrefreshColormap = true;
		theApp.pView->Invalidate(false);
		Invalidate(false);
	}

}

void CDlgDockBar::OnBnClickedCheck1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

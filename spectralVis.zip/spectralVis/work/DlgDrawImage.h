#pragma once
#include "afxcmn.h"


// CDlgDrawImage �Ի���

class CDlgDrawImage : public CDialog
{
	DECLARE_DYNAMIC(CDlgDrawImage)

public:
	CDlgDrawImage(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgDrawImage();

// �Ի�������
	enum { IDD = IDD_DLG_DRAWIMAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	void SetImageData(double * pdata, int ix, int iy, int iz);
	double *m_voldata;
	double *m_drawdata;
	int m_xsize;
	int m_ysize;
	int m_zsize;
	int m_iSpectnum;
	float m_IndexColor[256][4]; //��ɫ����
	afx_msg void OnBnClickedButDraw();
	void SetColorIndex(float *m_pcolor);
	CSliderCtrl m_SlideSpectIndes;
	afx_msg void OnNMReleasedcaptureSlideSpectralidx(NMHDR *pNMHDR, LRESULT *pResult);
};

// Camera.h: interface for the CCamera class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAMERA_H__D18D7CA8_A27F_4B21_B02D_D7C424BEAC44__INCLUDED_)
#define AFX_CAMERA_H__D18D7CA8_A27F_4B21_B02D_D7C424BEAC44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "glut.h"
#include "glmvmath.h"
class CCamera  
{
public:
	vec3f cameraPos;
	vec3f lookatPos;
	vec3f upDirect;
	double m_dAzim;
	double m_dTilt;
	double m_dDis;
	bool   m_bAuto;
	CPoint m_prePoint;
	bool   m_bLBDown;
	bool   m_bRBDown;
	vec3f  precameraPos;
	vec3f  prelookatPos;
	double m_predAzim;
	double m_predTilt;
	int	   m_ncx,m_ncy;
	matrix4d modelviewInverse,projmatrix;
	vec3f  m_preground,m_pointground;
	vec3f  m_preScreen,m_pointScreen;
	int    viewportmatrix[16];


public:
	void SetCamera();
	void SetCameraPos(vec3f pos);
	void SetLookatPos(vec3f pos);
	void SetUpDirect(vec3f dir);	
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnMouseMove(UINT nFlags, CPoint point);
	BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnRButtonDown(UINT nFlags, CPoint point);
	void OnRButtonUp(UINT nFlags, CPoint point);
	double CalcuAzim(vec3f camera,vec3f lookat);
	double CalcuTilt(vec3f camera,vec3f lookat);
	void CalcuCameraByDis();
	void CalcuCameraByAzim();
	void CalcuCameraByTilt();
	void Forwards();
	void Backwards();
	void Leftwards();
	void Rightwards();
	void OnSize(UINT nType, int cx, int cy);
	void Render();
public:
	CCamera();
	virtual ~CCamera();

};

#endif // !defined(AFX_CAMERA_H__D18D7CA8_A27F_4B21_B02D_D7C424BEAC44__INCLUDED_)

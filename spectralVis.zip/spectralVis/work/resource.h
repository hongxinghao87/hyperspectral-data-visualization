//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ElecEnvironmentDVR.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define IDR_MAINFRAME                   128
#define IDR_ELECENTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_WORKSPACE                   147
#define IDD_DLG_DVRCONTROL              154
#define IDI_CHECK                       155
#define IDI_UNCHECK                     156
#define IDD_DLG_DRAWSPECT               157
#define IDD_DLG_DRAWIMAGE               158
#define IDC_COMPANY_URL                 1041
#define IDC_BUTTON_CONTROL              1043
#define IDC_COLOR_PICK                  1044
#define IDC_COLOR_SLIDE                 1045
#define IDC_COMBO1                      1046
#define IDC_EDIT_X                      1054
#define IDC_EDIT_Y                      1055
#define IDC_BTN_Draw                    1056
#define IDC_SPECTNUM                    1057
#define IDC_BUT_DRAW                    1058
#define IDC_SLIDE_SPECTRALIDX           1059
#define IDC_SPIN1                       1060
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_WORKSPACE2              32792
#define ID_VIEW_WORKSPACE               32803
#define ID_VIEW_APPLOOK_2000            32833
#define ID_VIEW_APPLOOK_XP              32834
#define ID_VIEW_APPLOOK_2003            32835
#define ID_VIEW_APPLOOK_WIN_XP          32836
#define ID_TOOL_BOX                     32837
#define ID_B_RESET                      32838
#define ID_B_PICK                       32839
#define ID_VIEW_SPECT                   32840
#define ID_VISUAL_SPECT                 32841
#define ID_VISUAL_DRAWSPACEIMAGE        32842

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         32843
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif

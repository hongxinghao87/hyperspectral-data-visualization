#pragma once

#include <list>
namespace VolumeRender
{
	class CGLShaderProgram
	{
	public:

		CGLShaderProgram();
		virtual ~CGLShaderProgram();

		bool loadVertexShader(const char *filename);
		bool loadFragmentShader(const char *filename);
		bool loadShader(const char *filename, GLenum shaderType);

		bool loadVertexSource(const char *source);
		bool loadFragmentSource(const char *source);
		bool loadSource(const char *source, GLenum shaderType);

		void create();
		bool compile();
		int enable();
		void disable();

		GLint uniformLocation(const char *uniformName);

		static bool supported();

	protected:
		GLuint      _program;
		std::list<GLuint> _shaders;
	};

}
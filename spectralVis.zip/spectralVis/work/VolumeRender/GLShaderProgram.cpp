#include "stdafx.h"
#include "GLShaderProgram.h"
#include "glmvmath.h"
using namespace VolumeRender;
const GLchar *sourceBuffer;
//----------------------------------------------------------------------------
// Default constructor
//----------------------------------------------------------------------------
CGLShaderProgram::CGLShaderProgram()
{
	_program = 0;
	_shaders.clear();
}


//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------
CGLShaderProgram::~CGLShaderProgram()
{
	std::list<GLuint>::iterator iter;	
	for (iter=_shaders.begin(); iter != _shaders.end(); iter++)
	{
		GLuint shader = *iter;

		if (GLEW_VERSION_2_0)
		{
			glDeleteShader(shader);
		}
		else
		{
			glDeleteObjectARB(shader);
		}
	}

	if (GLEW_VERSION_2_0)
	{
		if (_program) glDeleteProgram(_program);
	}
	else
	{
		if (_program) glDeleteObjectARB(_program);
	}	
}


//----------------------------------------------------------------------------
// Load vertex shader source from a file. 
//----------------------------------------------------------------------------
bool CGLShaderProgram::loadVertexShader(const char *filename)
{
	return loadShader(filename, GL_VERTEX_SHADER);
}


//----------------------------------------------------------------------------
// Load fragment shader source from a file. 
//----------------------------------------------------------------------------
bool CGLShaderProgram::loadFragmentShader(const char *filename)
{
	return loadShader(filename, GL_FRAGMENT_SHADER);
}


//----------------------------------------------------------------------------
// Load shader source from a file. 
//
// The shader is assumed to live in the executable directory.
//----------------------------------------------------------------------------
bool CGLShaderProgram::loadShader(const char *filename, GLenum shaderType)
{
	//  int length = 2896;
	// static int count = 0;

	GLuint shader;

	//
	// Read the file (using Qt for platform independence). 
	//
	

	FILE* file;
	if((file = fopen(filename, "rb")) == NULL)
	{
		return false;
	}

	//
	// Create a shader object, and load it's source
	//
	fseek(file, 0, SEEK_END);
		
	int size = ftell(file);

	rewind(file);

	const GLchar *sourceBuffer = new GLchar[size];	
	fread((void*)sourceBuffer, size, 1, file);

	if (GLEW_VERSION_2_0)
	{
		shader = glCreateShader(shaderType);
		glShaderSource(shader, 1, &sourceBuffer, &size);

		printOpenGLError();

		glAttachShader(_program, shader);

		printOpenGLError();
	}
	else
	{
		shader = glCreateShaderObjectARB(shaderType);
		glShaderSourceARB(shader, 1, &sourceBuffer, &size);

		printOpenGLError();

		glAttachObjectARB(_program, shader);

		printOpenGLError();
	}

	_shaders.push_back(shader);

	fclose(file);
// 	delete[]sourceBuffer;

	return true;
}

//----------------------------------------------------------------------------
// Load vertex shader source from a string. 
//----------------------------------------------------------------------------
bool CGLShaderProgram::loadVertexSource(const char *source)
{
	return loadSource(source, GL_VERTEX_SHADER);
}


//----------------------------------------------------------------------------
// Load fragment shader source from a file. 
//----------------------------------------------------------------------------
bool CGLShaderProgram::loadFragmentSource(const char *source)
{
	return loadSource(source, GL_FRAGMENT_SHADER);
}

//----------------------------------------------------------------------------
// Create the shader from the char* source
//----------------------------------------------------------------------------
bool CGLShaderProgram::loadSource(const char *source, GLenum shaderType)
{
	GLuint shader;

	//
	// Create a shader object, and load it's source
	//
	int length = strlen(source);
	sourceBuffer = (GLchar*)source;

	if (GLEW_VERSION_2_0)
	{
		shader = glCreateShader(shaderType);
		glShaderSource(shader, 1, &sourceBuffer, &length);
		printOpenGLError();

		//
		// Attach the shader
		//
		glAttachShader(_program, shader);
		printOpenGLError();
	}
	else
	{
		shader = glCreateShaderObjectARB(shaderType);
		glShaderSourceARB(shader, 1, &sourceBuffer, &length);
		printOpenGLError();

		//
		// Attach the shader
		//
		glAttachObjectARB(_program, shader);
		printOpenGLError();
	}


	_shaders.push_back(shader);

	return true;
}

//----------------------------------------------------------------------------
// Create the shader program
//----------------------------------------------------------------------------
void CGLShaderProgram::create()
{
	if (GLEW_VERSION_2_0)
	{
		_program = glCreateProgram();
	}
	else
	{
		_program = glCreateProgramObjectARB();    
	}

	printOpenGLError();
}


//----------------------------------------------------------------------------
// Compile and link the shader program
//----------------------------------------------------------------------------
bool CGLShaderProgram::compile()
{
	std::list<GLuint>::iterator iter;
	//bool compiled = true;

	//
	// Compile all the shaders
	//
	for (iter=_shaders.begin(); iter != _shaders.end(); iter++)
	{
		GLuint shader = *iter;
		GLint infologLength = 0;
		GLint shaderCompiled;

		if (GLEW_VERSION_2_0)
		{
			//
			// Compile a single shader
			//
			glCompileShader(shader);
			glGetShaderiv(shader, GL_COMPILE_STATUS, &shaderCompiled);
			printOpenGLError();

			//compiled &= shaderCompiled;

			//
			// Print log information
			//
			glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infologLength);
			printOpenGLError();

			if (shaderCompiled != GL_TRUE && infologLength > 1)
			{
				GLchar *infoLog = new GLchar[infologLength];
				int nWritten  = 0;

				glGetShaderInfoLog(shader, infologLength, &nWritten, infoLog);

				DebugMessage("Shader InfoLog: %s\n", infoLog);

				delete infoLog;
				infoLog = NULL;
			}
		}
		else
		{
			//
			// Compile a single shader
			//
			glCompileShaderARB(shader);
			glGetObjectParameterivARB(shader, 
				GL_OBJECT_COMPILE_STATUS_ARB, 
				&shaderCompiled);
			printOpenGLError();

			//compiled &= shaderCompiled;

			//
			// Print log information
			//
			glGetObjectParameterivARB(shader, 
				GL_OBJECT_INFO_LOG_LENGTH_ARB, 
				&infologLength);
			printOpenGLError();

			if (shaderCompiled != GL_TRUE && infologLength > 1)
			{
				GLchar *infoLog = new GLchar[infologLength];
				int nWritten  = 0;

				glGetInfoLogARB(shader, infologLength, &nWritten, infoLog);

				DebugMessage("Shader InfoLog: %s\n", infoLog);

				delete infoLog;
				infoLog = NULL;
			}
		}

		//if (!compiled)
		if (!shaderCompiled)
		{
			return false;
		}
	}

	//
	// Link the program
	//
	GLint linked;

	if (GLEW_VERSION_2_0)
	{
		glLinkProgram(_program);
		glGetProgramiv(_program, GL_LINK_STATUS, &linked);
		printOpenGLError();

		//
		// Print log information
		//
		GLint infologLength = 0;
		glGetProgramiv(_program, GL_INFO_LOG_LENGTH, &infologLength);
		printOpenGLError();

		if (linked != GL_TRUE && infologLength > 1)
		{
			GLchar *infoLog = new GLchar[infologLength];
			int nWritten  = 0;

			glGetProgramInfoLog(_program, infologLength, &nWritten, infoLog);

			DebugMessage("Shader InfoLog: %s\n", infoLog);

			delete infoLog;
			infoLog = NULL;
		}
	}
	else
	{
		glLinkProgramARB(_program);
		glGetObjectParameterivARB(_program, GL_OBJECT_LINK_STATUS_ARB, &linked);
		printOpenGLError();

		//
		// Print log information
		//
		GLint infologLength = 0;
		glGetObjectParameterivARB(_program, 
			GL_OBJECT_INFO_LOG_LENGTH_ARB, &infologLength);
		printOpenGLError();

		if (linked != GL_TRUE && infologLength > 1)
		{
			GLchar *infoLog = new GLchar[infologLength];
			int nWritten  = 0;

			glGetInfoLogARB(_program, infologLength, &nWritten, infoLog);

			DebugMessage("Shader InfoLog: %s\n", infoLog);

			delete infoLog;
			infoLog = NULL;
		}
	}

	return (linked != 0);
}

//----------------------------------------------------------------------------
// Enable the shader program.
//----------------------------------------------------------------------------
int CGLShaderProgram::enable()
{
	if (GLEW_VERSION_2_0)
	{
		glUseProgram(_program);
	}
	else
	{
		glUseProgramObjectARB(_program);
	}

	if (printOpenGLError() != 0) return(-1);
	return(0);
}


//----------------------------------------------------------------------------
// Disable the shader program.
//----------------------------------------------------------------------------
void CGLShaderProgram::disable()
{
	if (GLEW_VERSION_2_0)
	{
		glUseProgram(0);
	}
	else
	{
		glUseProgramObjectARB(0);
	}

	printOpenGLError();
}


//----------------------------------------------------------------------------
// Find uniform location in the shader. 
//----------------------------------------------------------------------------
GLint CGLShaderProgram::uniformLocation(const char *uniformName)
{
	GLint location;

	if (GLEW_VERSION_2_0)
	{
		location = glGetUniformLocation(_program, uniformName);
	}
	else
	{
		location = glGetUniformLocationARB(_program, uniformName);
	}

	if (location == -1)
	{
		DebugMessage("uniform \"%s\" not found.\n", uniformName);
	}

	printOpenGLError();

	return location;
}


//----------------------------------------------------------------------------
// Determine if shader programming is supported. 
//----------------------------------------------------------------------------
bool CGLShaderProgram::supported()
{
	return (GLEW_VERSION_2_0 || GLEW_ARB_shader_objects);
}



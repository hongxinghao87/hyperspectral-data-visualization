//--DVRTexture3d.h -----------------------------------------------------------
//
// Copyright (C) 2005 Kenny Gruchalla.  All rights reserved.
//
// Abstract volume rendering engine based on 3d-textured view aligned slices. 
// Provides proxy geometry, color lookup should be provided by derived 
// classes. 
//
//----------------------------------------------------------------------------

#ifndef DVRTexture3d_h
#define DVRTexture3d_h

#include "glmvmath.h"
#include "TextureBrick.h"
#include <vector>
#include <map>

namespace VolumeRender 
{

	class BBox;
	class TextureBrick;

	class DVRTexture3d
	{

		//----------------------------------
		// sub class DVRTexture3d::RegionState
		//----------------------------------
		class RegionState
		{

		public:

			RegionState();
			virtual ~RegionState() {};

			bool update(int nx, int ny, int nz, 
				const int roi[6], const int box[6], const float extents[6],
				int tex_size);

			const int* roi()       { return _roi; }
			const int* box()       { return _box; }
			const float* extents() { return _ext; }

		protected:

			int   _dim[3];
			int   _roi[6];
			int   _box[6];
			float _ext[6];
			int _tex_size;
		};

	public:

		DVRTexture3d();		
		DVRTexture3d(GLint internalFormat, GLenum format, GLenum type);
		virtual ~DVRTexture3d();

		virtual int SetRegion(void *data, 
			int nx, int ny, int nz, 
			const int data_roi[6],
			const float extents[6],
			const int data_box[6],
			int level,
			double vscale[3]);

		virtual bool   GetRenderFast() const       { return _renderFast; }
		virtual void   SetRenderFast(bool fast)    { _renderFast = fast; }

		//test
	public:
		bool bEye;
		void Render()
		{
			/*
			_vmin.x
			_vmin.y
			_vmin.z
			_vmax.x
			_vmax.y
			_vmax.z
			*/
			glColor3f(1, 1, 1);
			glLineWidth(2.0f);
			glBegin(GL_LINE_LOOP);
			glVertex3f(_vmin.x,	_vmin.y, _vmin.z);
			glVertex3f(_vmax.x,	_vmin.y, _vmin.z);
			glVertex3f(_vmax.x,	_vmax.y, _vmin.z);
			glVertex3f(_vmin.x,	_vmax.y, _vmin.z);
			glEnd();

			glBegin(GL_LINE_LOOP);
			glVertex3f(_vmin.x,	_vmin.y, _vmax.z);
			glVertex3f(_vmax.x,	_vmin.y, _vmax.z);
			glVertex3f(_vmax.x,	_vmax.y, _vmax.z);
			glVertex3f(_vmin.x,	_vmax.y, _vmax.z);
			glEnd();

			glBegin(GL_LINES);
			glVertex3f(_vmin.x,	_vmin.y, _vmin.z);
			glVertex3f(_vmin.x,	_vmin.y, _vmax.z);
			glVertex3f(_vmax.x,	_vmin.y, _vmin.z);
			glVertex3f(_vmax.x,	_vmin.y, _vmax.z);

			glVertex3f(_vmin.x,	_vmax.y, _vmin.z);
			glVertex3f(_vmin.x,	_vmax.y, _vmax.z);
			glVertex3f(_vmax.x,	_vmax.y, _vmin.z);
			glVertex3f(_vmax.x,	_vmax.y, _vmax.z);

			glEnd();


			if(bEye)
				calculateSampling();
			glColor3f(1, 0, 0);
			renderBricks();
		}

		virtual void loadTexture(TextureBrick *brick)
		{
			printOpenGLError();

			brick->load();
			printOpenGLError();
		}

	protected:

		virtual void calculateSampling();

		virtual void drawViewAlignedSlices(const TextureBrick *brick,
			const matrix4f &modelview,
			const matrix4f &modelviewInverse);

		virtual void renderBrick(const TextureBrick *brick,
			const matrix4f &modelview,
			const matrix4f &modelviewInverse);

		void renderBricks();

#define MAXSIZE 6

		int  intersect(const vec4f &sp, const vec4f &spn, 
			const BBox &volumeBox,  vec4f verts[MAXSIZE],
			const BBox &textureBox, vec4f tverts[MAXSIZE],
			const BBox &rotatedBox, vec4f rverts[MAXSIZE]);

		void findVertexOrder(const vec4f verts[MAXSIZE], int order[MAXSIZE], int degree);

		void buildBricks(int level, const int bbox[6], const int data_roi[6],
			int nx, int ny, int nz, double vscale[3]);
		void sortBricks(const matrix4f &modelview);

		int maxTextureSize(GLint internalFormat, GLenum format, GLenum type);

		virtual void SetMaxTexture(int texsize);


	protected:

		// data dimensions
		int    _nx;
		int    _ny;
		int    _nz;

		void   *_data;

		// brick dimensions
		int    _bx;  
		int    _by;
		int    _bz;

		bool   _renderFast;

		float  _delta;
		float  _samples;
		float  _samplingRate;
		int    _minimumSamples;
		int    _maxTexture;
		int    _maxBrickDim;

		int _max_texture;

		// Texture bricks
		std::vector<TextureBrick*> _bricks;

		// Voxel extents
		vec3f _dmin;
		vec3f _dmax;

		// Data extents
		vec3f _vmin;
		vec3f _vmax;

		// Texture extents
		vec3f _tmin;
		vec3f _tmax;

		// Region state
		RegionState _lastRegion;

		// Texture internal data format
		GLenum _internalFormat; 

		// Texture data format
		GLenum _format;

		// Voxel type
		GLenum _type;

	};

}


#endif 


#pragma once

#include "glmvmath.h"

namespace VolumeRender {

  class BBox 
  {
    
  public:
    BBox();
    BBox(const vec3f& min, const vec3f& max);
    BBox(const BBox&);

    BBox& operator=(const BBox&);

    ~BBox();

    // Transform the bounding box 
    void transform(const matrix4f &m);

    vec3f center() const;

    // Return the minimum & maximum extents
    inline const vec4f& minZ() const { return _corners[_minIndex]; }
    inline const vec4f& maxZ() const { return _corners[_maxIndex]; }

    inline int minIndex() const { return _minIndex; }
    inline int maxIndex() const { return _maxIndex; }

    // return the corner point
    inline const vec4f& operator[](int i) const { return _corners[i]; };

  private:

    int _minIndex;
    int _maxIndex;
    
    vec4f _corners[8];

    //       6*--------*7
    //       /|       /|
    //      / |      / |
    //     /  |     /  |
    //    /  4*----/---*5
    //  2*--------*3  /
    //   |  /     |  /
    //   | /      | /
    //   |/       |/
    //  0*--------*1
    //             

  };
} 

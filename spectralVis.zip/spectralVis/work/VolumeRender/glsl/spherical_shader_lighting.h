#version 110
uniform sampler1D colormap;
uniform sampler3D volumeTexture;
uniform vec3 tmin;
uniform vec3 tmax;
uniform vec3 dmin;
uniform vec3 dmax;
uniform vec3 permutation;
uniform vec3 dimensions;
uniform bvec2 clip;
uniform vec3 lightDirection;
uniform float kd;
uniform float ka;
uniform float ks;
uniform float expS;
varying vec3 view;

//-------------------------------------------------------------------------
// Rearrange the vector into (lon, lat, radius) order 
//-------------------------------------------------------------------------
vec3 permute(vec3 v)
{
	vec3 p = v;

	// 
	// Unfortunately, GLSL 2.0 doesn't seem to allow 
	// a uniform to be used as an index. We'll do it 
	// the long way. 
	// 
	if (permutation.x == 2.0) p.z = v.x;
	else if (permutation.x == 1.0) p.y = v.x;

	if (permutation.y == 2.0) p.z = v.y;
	else if (permutation.y == 0.0) p.x = v.y;

	if (permutation.z == 0.0) p.x = v.z;
	else if (permutation.z == 1.0) p.y = v.z;

	return p;
}

//-------------------------------------------------------------------------
// Rearrange the vector from (lon, lat, radius) order into the original order
//-------------------------------------------------------------------------
vec3 invPermute(vec3 v)
{
	vec3 p = v;

	// 
	// Unfortunately, GLSL 2.0 doesn't seem to allow
	// a uniform to be used as an index. We'll do it
	// the long way.
	// 
	if (permutation.x == 2.0) p.x = v.z;
	else if (permutation.x == 1.0) p.x = v.y;

	if (permutation.y == 2.0) p.y = v.z;
	else if (permutation.y == 0.0) p.y = v.x;

	if (permutation.z == 0.0) p.z = v.x;
	else if (permutation.z == 1.0) p.z = v.y;

	return p;
}


//-------------------------------------------------------------------------
// Cartesian -> Spherical transform
//-------------------------------------------------------------------------
vec3 cart2sph(vec3 cartesian)
{
	const float pi = 3.14159;

	vec3 spherical;

	spherical.z = length(cartesian.xyz);
	spherical.x = asin(clamp(cartesian.y / length(cartesian.yz), -1.0, 1.0));
	spherical.y = acos(clamp(cartesian.x / spherical.z, -1.0, 1.0));

	if (cartesian.z >= 0.0)
	{
		if (spherical.x < 0.0) spherical.x += 2.0*pi;
	}
	else
	{
		spherical.x = pi - spherical.x;
	}

	// Spherical coordinates 
	// spherical.y (0, pi) 
	// spherical.x (0, 2pi) 

	spherical.y = (spherical.y / (pi));
	spherical.x = (spherical.x / (2.0*pi));

	// Normalized spherical coordinates 
	// spherical.z (0, 1) 
	// spherical.y (0, 1) 
	// spherical.x (0, 1) 
	spherical = (spherical - dmin) * ((tmax - tmin) / (dmax - dmin)) + tmin;

	return spherical;
}

//--------------------------------------------------------------------- 
// Compute the data gradient
//--------------------------------------------------------------------- 
vec3 dataGradient(vec3 coord)
{
	const float pi = 3.14159;

	vec3 sgradient;
	vec3 gradient;

	float dx = 0.5/(dimensions.x);
	float dy = 0.5/(dimensions.y);
	float dz = 0.5/(dimensions.z);

	vec3 a0;
	vec3 a1;

	a0.x = texture3D(volumeTexture, coord + vec3(dx,0,0)).x;
	a1.x = texture3D(volumeTexture, coord + vec3(-dx,0,0)).x;
	a0.y = texture3D(volumeTexture, coord + vec3(0,dy,0)).x;
	a1.y = texture3D(volumeTexture, coord + vec3(0,-dy,0)).x;
	a0.z = texture3D(volumeTexture, coord + vec3(0,0,dz)).x;
	a1.z = texture3D(volumeTexture, coord + vec3(0,0,-dz)).x;

	// 
	// Compute the spherical gradient 
	// 
	sgradient = permute((a1-a0)/2.0);
	//sgradient.x = (sgradient.x / (coord.z * sin(coord.y*pi-pi/2.0)));
	//sgradient.y = (sgradient.y / coord.z); 

	// 
	// Transform the vector into the cartesian coordinate space 
	// 
	float sinphi = sin(sgradient.x * 2.0*pi-pi);
	float cosphi = cos(sgradient.x * 2.0*pi-pi);
	float sintheta = sin(sgradient.y * pi - pi/2.0);
	float costheta = cos(sgradient.y * pi - pi/2.0);

	mat3 t = mat3(-sinphi, costheta*cosphi,   sintheta*cosphi,
		cosphi,  sintheta*sintheta, costheta*sinphi,
		0,       costheta,          -sintheta);

	gradient = t * sgradient;

	return gradient;
}

//----------------------------------------------------------------- 
// Fragment shader main 
//----------------------------------------------------------------- 
void main(void)
{
	const float pi = 3.14159;

	vec3 cartesian = permute(gl_TexCoord[0].xyz);
	vec3 spherical;

	cartesian = dmax.z * (cartesian * 2.0 - 1.0);

	spherical.z = length(cartesian.xyz);

	if (spherical.z > dmax.z || spherical.z < dmin.z)
	{
		gl_FragColor = vec4(0,0,0,0);
	}
	else
	{
		spherical.x = asin(clamp(cartesian.y / length(cartesian.yz), -1.0, 1.0));
		spherical.y = acos(clamp(cartesian.x / spherical.z, -1.0, 1.0));

		if (cartesian.z >= 0.0)
		{
			if (spherical.x < 0.0) spherical.x += 2.0*pi;
		}
		else
		{
			spherical.x = pi - spherical.x;
		}

		// Spherical coordinates 
		// spherical.y (0, pi) 
		// spherical.x (0, 2pi) 

		spherical.y = 1.0 - (spherical.y / (pi));
		spherical.x = (spherical.x / (2.0*pi));

		// Normalized spherical coordinates 
		// spherical.z (0, 1) 
		// spherical.y (0, 1) 
		// spherical.x (0, 1) 

		if ((clip.y && (spherical.y < dmin.y || spherical.y > dmax.y)) ||
			(clip.x && (spherical.x < dmin.x || spherical.x > dmax.x)))
		{
			gl_FragColor = vec4(1,1,1,0);
		}
		else
		{
			// Texture coordinates (dmin, dmax) -> (tmin, tmax) 
			spherical = (spherical - dmin) * ((tmax - tmin)/(dmax - dmin)) + tmin;

			vec3 gradient = gl_NormalMatrix * dataGradient(invPermute(spherical));

			if (length(gradient) <= 0.001)
			{
				gl_FragColor = vec4(0,0,0,0);
			}
			else
			{
				gradient = normalize(gradient);

				// 
				// TBD -- There is something squirely with the lighting direction 
				// The problem is most likely in the gradient calculation 
				// and this modelview multiplication should go away. 
				// 
				vec3 light = (gl_ModelViewMatrix * vec4(lightDirection,0)).xyz;
				vec3 halfv = normalize(light + gradient);

				float d  = kd * abs(dot(normalize(light), gradient));
				float s = ks * pow(abs(dot(halfv, normalize(view))), expS);

				vec4 intensity = vec4(texture3D(volumeTexture,invPermute(spherical)));
				gl_FragColor = vec4 (texture1D(colormap, intensity.x)) * (d + s + ka);
			}
		}
	}
}
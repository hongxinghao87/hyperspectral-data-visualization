uniform sampler1D colormap;
uniform sampler3D volumeTexture;
//------------------------------------------------------------------
// Fragment shader main
//------------------------------------------------------------------
void main(void)
{
	vec4 intensity = vec4 (texture3D(volumeTexture, gl_TexCoord[0].xyz));
	vec4 color     = vec4 (texture1D(colormap, intensity.x));
	gl_FragColor = color;
}
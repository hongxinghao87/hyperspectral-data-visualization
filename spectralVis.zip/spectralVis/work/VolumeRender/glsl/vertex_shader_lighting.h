//-----------------------------------------------------------------------
// Vertex shader main
//-----------------------------------------------------------------------
#version 110
varying vec3 view;
void main(void)
{
	gl_TexCoord[0] = gl_MultiTexCoord0;
	gl_Position    = ftransform();
	view           = normalize(-gl_Position.xyz);
}

// tex crds of far bounding box boundary
uniform sampler1D colormap;
uniform sampler2D texcrd_buffer;
uniform sampler2DShadow depth_buffer;
uniform sampler3D volumeTexture;

uniform float zN;
uniform float zF;
//uniform int numiso;

// Sampling distance
uniform float delta;

// Lighting parameters

uniform vec3 lightDirection;
uniform float kd;
uniform float ka;
uniform float ks;
uniform float expS;
uniform vec3 dimensions;

varying vec4 position;
varying vec3 view;

vec3 Gradient(in vec3, in vec3);

//------------------------------------------------------------------
// Fragment shader main
//------------------------------------------------------------------
void main(void)
{

	vec3 lightColor = vec3(1.0, 1.0, 1.0);
	// Normalized window coordinates of this frament

	vec2 texCoord2D = ((position.xy / position.w) + 1.0) / 2.0;
	// Starting and finishing texture coordinate of ray

	vec3 texStart = texture2D(texcrd_buffer, texCoord2D).xyz;
	vec3 texStop = gl_TexCoord[0].xyz;
	// Ray direction

	vec3 dir = texStop - texStart;
	vec3 dirUnit = normalize(dir);
	float len = length(dir);

	// Nvidia linux driver does bad things if we use more than 256 ray segs
	int nsegs = int(min((len / delta), 256.0));
	float delta1 = len / float(nsegs);
	vec3 deltaVec = dirUnit * delta1;

	// Starting and stop window coordinates of ray (normalized, and screen

	float zStartNorm = shadow2D(depth_buffer, vec3(texCoord2D,0.0)).x;
	float zStart = (zN*zF) / (zF-(zStartNorm*(zF-zN)));
	float zStopNorm = gl_FragCoord.z;
	float zStop = (zN*zF) / (zF-(zStopNorm*(zF-zN)));
	float zdelta = (zStop-zStart) / float(nsegs);

	vec3 texCoord0 = texStart;
	vec3 texCoord1 = texCoord0+deltaVec;
	float s0 = texture3D(volumeTexture, texCoord0).x;
	float s1 = texture3D(volumeTexture, texCoord1).x;

	float fragDepth = zStopNorm;
	vec4 fragColor =  vec4(0.0, 0.0, 0.0, 0.0);

	// Make sure gl_FragDepth is set for all execution paths

	gl_FragDepth = zStartNorm;

	// Composite from back to front

	for (int i = 0; i<nsegs; i++) 
	{			
		float var2 = texture3D(volumeTexture,texCoord0).x;
		vec4 color = vec4(texture1D(colormap, var2));
		
		// find texture coord of isovalue with linear interpolation
		vec3 grad_dd = 0.5 / dimensions;
		vec3 gradient = gl_NormalMatrix * Gradient(grad_dd, texCoord0);

		vec3 ambient = ka * color.xyz;
		vec3 diffuse;
		vec3 specular;

		if (length(gradient) > 0.0) 
		{
			vec3 gradient_unit = normalize(gradient);
			vec3 light      = normalize(lightDirection);
			vec3 halfv      = normalize(light + gradient_unit);

			diffuse  = kd * abs(dot(light, gradient_unit)) * lightColor * color.xyz;
			specular = ks * pow(abs(dot(halfv, normalize(view))), expS) * lightColor;

		}
		else 
		{
			diffuse  = vec3(0.0);
			specular = vec3(0.0);
		}

		color.xyz = ambient + diffuse + specular;
		// blend fragment
		//fragColor = (color * vec4(color.a)) + (fragColor * (vec4(1.0) - vec4(color.a)));
		fragColor.rgb = mix(fragColor.rgb, color.rgb, color.a);
		fragColor.a = mix(color.a, 1.0, fragColor.a);
		fragDepth = zStart + (float(i) * zdelta);


		texCoord0 = texCoord0+deltaVec;		
	}

	if (fragColor.a == 0.0) discard;

	// Convert from screen window coords back to normalized depth

	gl_FragDepth = (1.0/zN - 1.0/fragDepth) / (1.0/zN - 1.0/zF);
	gl_FragColor = fragColor;
}

//-----------------------------------------------------------------------
// Compute the gradient 
//-----------------------------------------------------------------------
vec3 Gradient(in vec3 delta, in vec3 tc)
{
	vec3 gradient;


	float dx = delta.x;
	float dy = delta.y;
	float dz = delta.z;
	vec3 a0;
	vec3 a1;

	a0.x = texture3D(volumeTexture, tc + vec3(dx,0,0)).x;
	a1.x = texture3D(volumeTexture, tc - vec3(dx,0,0)).x;
	a0.y = texture3D(volumeTexture, tc + vec3(0,dy,0)).x;
	a1.y = texture3D(volumeTexture, tc - vec3(0,dy,0)).x;
	a0.z = texture3D(volumeTexture, tc + vec3(0,0,dz)).x;
	a1.z = texture3D(volumeTexture, tc - vec3(0,0,dz)).x;

	//gradient = (a1-a0)/(2.0*delta);
	gradient = (a1-a0)/2.0;

	return gradient;
}
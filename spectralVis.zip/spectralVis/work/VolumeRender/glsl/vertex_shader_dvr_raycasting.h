//-----------------------------------------------------------------------
// Vertex shader main
//-----------------------------------------------------------------------
#version 110
uniform mat4 glModelViewProjectionMatrix;
varying vec4 position;
void main(void)
{
	gl_TexCoord[0] = gl_MultiTexCoord0;
	gl_Position    = ftransform();
	position       = gl_Position;
}
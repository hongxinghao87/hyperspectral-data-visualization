uniform sampler2D colormap;
uniform sampler3D volumeTexture;
uniform vec3 dimensions;
uniform vec3 lightDirection;
uniform float kd;
uniform float ka;
uniform float ks;
uniform float expS;
varying vec3 view;

vec3 alphaGradient();

//-----------------------------------------------------------------------
// Fragment shader main
//-----------------------------------------------------------------------
void main(void)
{
	vec2 intensity;
	intensity.x = texture3D(volumeTexture, gl_TexCoord[0].xyz).x;
	intensity.y = texture3D(volumeTexture, gl_TexCoord[1].xyz).x;
	vec4 color = vec4 (texture2D(colormap, intensity));

	vec3 gradient = gl_NormalMatrix * alphaGradient();

	if (length(gradient) <= 0.0001)
	{
		gradient = vec3 (0,0,1);
	}
	else
	{
		gradient = normalize(gradient);
	}

	vec3 light      = normalize(lightDirection);
	vec3 halfv      = normalize(light + gradient);

	float diffuse  = kd * abs(dot(light, gradient));
	float specular = ks * pow(abs(dot(halfv, normalize(view))), expS);

	gl_FragColor = color * (diffuse + specular + ka);
}

//-----------------------------------------------------------------------
// Compute the gradient using the alpha channel
//-----------------------------------------------------------------------
vec3 alphaGradient()
{
	vec3 gradient;

	float dx = 0.5/(dimensions.x);
	float dy = 0.5/(dimensions.y);
	float dz = 0.5/(dimensions.z);

	float v  = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(dx,0,0)).x;
	float x0 = texture2D(colormap, vec2(v,v)).a;

	v        = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(-dx,0,0)).x;
	float x1 = texture2D(colormap, vec2(v,v)).a;

	v        = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,dy,0)).x;
	float y0 = texture2D(colormap, vec2(v,v)).a;

	v        = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,-dy,0)).x;
	float y1 = texture2D(colormap, vec2(v,v)).a;

	v        = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,0,dz)).x;
	float z0 = texture2D(colormap, vec2(v,v)).a;

	v        = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,0,-dz)).x;
	float z1 = texture2D(colormap, vec2(v,v)).a;

	gradient.x = (x1-x0)/2.0;
	gradient.y = (y1-y0)/2.0;
	gradient.z = (z1-z0)/2.0;

	return gradient;
}
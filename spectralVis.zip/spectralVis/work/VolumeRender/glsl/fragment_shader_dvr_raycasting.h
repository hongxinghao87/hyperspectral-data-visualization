//const int maxiso = 8;

uniform sampler1D colormap;
uniform sampler2D texcrd_buffer;
uniform sampler2DShadow depth_buffer;
uniform sampler3D volumeTexture;
//uniform float isovalues[maxiso];
//uniform float isovalues;
uniform float zN;
uniform float zF;
//uniform int numiso;
uniform float delta;

varying vec4 position;


//------------------------------------------------------------------
// Fragment shader main
//------------------------------------------------------------------
void main(void)
{

	vec2 texCoord2D = ((position.xy / position.w) + 1.0) / 2.0;
	vec3 texStart = texture2D(texcrd_buffer, texCoord2D).xyz;
	vec3 texStop = gl_TexCoord[0].xyz;
	vec3 dir = texStop - texStart;
	vec3 dirUnit = normalize(dir);
	float len = length(dir);

	// Nvidia linux driver does bad things if we use more than 256 ray segs
	int nsegs = int(min((len / delta), 512.0));
	float delta1 = len / float(nsegs);
	vec3 deltaVec = dirUnit * delta1;

	float zStartNorm = shadow2D(depth_buffer, vec3(texCoord2D,0.0)).x;
	float zStart = (zN*zF) / (zF-(zStartNorm*(zF-zN)));
	float zStopNorm = gl_FragCoord.z;
	float zStop = (zN*zF) / (zF-(zStopNorm*(zF-zN)));
	float zdelta = (zStop-zStart) / float(nsegs);

	vec3 texCoord0 = texStart;
	
	float fragDepth = zStopNorm;	

	// Make sure gl_FragDepth is set for all execution paths
	gl_FragDepth = zStopNorm;

	// Composite from back to front

	float var2 = texture3D(volumeTexture,texCoord0).x;	
	vec4 fragColor =  vec4(texture1D(colormap, var2));;//vec4(0.0, 0.0, 0.0, 0.0);
	texCoord0 = texCoord0+deltaVec;	
	for (int i = 1; i<nsegs; i++)
	{		
		float var2 = texture3D(volumeTexture,texCoord0).x;
		vec4 color = vec4(texture1D(colormap, var2));

		// blend fragment
		//fragColor = (color * (vec4(color.a))) + (fragColor * (vec4(1.0) - vec4(color.a)));

		fragColor.rgb = mix(fragColor.rgb, color.rgb, color.a);
		fragColor.a = mix(color.a, 1.0, fragColor.a);
		fragDepth = zStart + (float(i) * zdelta);

		texCoord0 = texCoord0+deltaVec;		
	}

	if (fragColor.a == 0.0) discard;

	gl_FragDepth = (1.0/zN - 1.0/fragDepth) / (1.0/zN - 1.0/zF);
	gl_FragColor = fragColor;
}
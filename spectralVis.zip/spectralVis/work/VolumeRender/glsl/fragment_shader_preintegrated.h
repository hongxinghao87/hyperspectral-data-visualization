uniform sampler2D colormap;
uniform sampler3D volumeTexture;
//------------------------------------------------------------------
// Fragment shader main
//------------------------------------------------------------------
void main(void)
{
	vec2 intensity;
	intensity.x = texture3D(volumeTexture, gl_TexCoord[0].xyz).x;
	intensity.y = texture3D(volumeTexture, gl_TexCoord[1].xyz).x;
	vec4 color     = vec4 (texture2D(colormap, intensity));
	gl_FragColor = color;
}
uniform sampler1D colormap;
uniform sampler3D volumeTexture;
uniform vec3 dimensions;
uniform vec3 lightDirection;
uniform float kd;
uniform float ka;
uniform float ks;
uniform float expS;
varying vec3 view;

vec3 alphaGradient();
vec3 alphaGradient0();

//-----------------------------------------------------------------------
// Fragment shader main
//-----------------------------------------------------------------------
void main(void)
{
	vec4 intensity = vec4 (texture3D(volumeTexture, gl_TexCoord[0].xyz));
	vec4 color     = vec4 (texture1D(colormap, intensity.x));


	vec3 gradient = gl_NormalMatrix * alphaGradient();

	if (length(gradient) <= 0.0001)
	{
		gradient = vec3 (0,0,1);
	}
	else
	{
		gradient = normalize(gradient);
	}

	vec3 light      = normalize(lightDirection);
	vec3 halfv      = normalize(light + gradient);

	float diffuse  = kd * abs(dot(light, gradient));
	float specular = ks * pow(abs(dot(halfv, normalize(view))), expS);

	gl_FragColor = color * (diffuse + specular + ka);
}

//-----------------------------------------------------------------------
// Compute the gradient using the alpha channel
//-----------------------------------------------------------------------
vec3 alphaGradient()
{
	vec3 gradient;

	float dx = 0.5/(dimensions.x);
	float dy = 0.5/(dimensions.y);
	float dz = 0.5/(dimensions.z);

	vec3 a0;
	vec3 a1;

	a0.x = texture1D(colormap, 
		texture3D(volumeTexture, 
		gl_TexCoord[0].xyz + vec3(dx,0,0)).x).a;
	a1.x = texture1D(colormap, 
		texture3D(volumeTexture, 
		gl_TexCoord[0].xyz + vec3(-dx,0,0)).x).a;

	a0.y = texture1D(colormap, 
		texture3D(volumeTexture, 
		gl_TexCoord[0].xyz + vec3(0,dy,0)).x).a;
	a1.y = texture1D(colormap, 
		texture3D(volumeTexture, 
		gl_TexCoord[0].xyz + vec3(0,-dy,0)).x).a;

	a0.z = texture1D(colormap, 
		texture3D(volumeTexture, 
		gl_TexCoord[0].xyz + vec3(0,0,dz)).x).a;
	a1.z = texture1D(colormap, 
		texture3D(volumeTexture, 
		gl_TexCoord[0].xyz + vec3(0,0,-dz)).x).a;

	gradient = (a1-a0)/2.0;

	return gradient;
}

vec3 alphaGradient0()
{
	vec3 gradient;

	float dx = 0.5/(dimensions.x);
	float dy = 0.5/(dimensions.y);
	float dz = 0.5/(dimensions.z);

	vec3 a0;
	vec3 a1;

	//a0.x = texture1D(colormap, 
	//                 texture3D(volumeTexture, 
	//                           gl_TexCoord[0].xyz + vec3(dx,0,0)).x).a;
	a0.x = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(dx,0,0)).x;
	//a1.x = texture1D(colormap, 
	//                 texture3D(volumeTexture, 
	//                           gl_TexCoord[0].xyz + vec3(-dx,0,0)).x).a;
	a1.x = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(-dx,0,0)).x;

	//a0.y = texture1D(colormap, 
	//                 texture3D(volumeTexture, 
	//                          gl_TexCoord[0].xyz + vec3(0,dy,0)).x).a;
	a0.y = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,dy,0)).x;
	//a1.y = texture1D(colormap, 
	//                 texture3D(volumeTexture, 
	//                           gl_TexCoord[0].xyz + vec3(0,-dy,0)).x).a;
	a1.y = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,-dy,0)).x;

	//a0.z = texture1D(colormap, 
	//                 texture3D(volumeTexture, 
	//                           gl_TexCoord[0].xyz + vec3(0,0,dz)).x).a;
	a0.z = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,0,dz)).x;
	//a1.z = texture1D(colormap, 
	//                 texture3D(volumeTexture, 
	//                           gl_TexCoord[0].xyz + vec3(0,0,-dz)).x).a;
	a1.z = texture3D(volumeTexture, gl_TexCoord[0].xyz + vec3(0,0,-dz)).x;

	gradient = (a1-a0)/2.0;

	return gradient;
}
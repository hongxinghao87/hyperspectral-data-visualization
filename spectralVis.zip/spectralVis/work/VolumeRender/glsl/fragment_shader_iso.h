
const int maxiso = 8;
uniform sampler2D texcrd_buffer;
uniform sampler2DShadow depth_buffer;
uniform sampler3D volumeTexture;
uniform float isovalues[maxiso];
uniform vec4 isocolors[maxiso];
//uniform float isovalues;
//uniform vec4 isocolors;
uniform float zN;
uniform float zF;
uniform int numiso; // < 8
uniform float delta;

varying vec4 position;


//------------------------------------------------------------------
// Fragment shader main
//------------------------------------------------------------------
void main(void)
{

	vec2 texCoord2D = ((position.xy / position.w) + 1.0) / 2.0;
	vec3 texStart = texture2D(texcrd_buffer, texCoord2D).xyz;
	vec3 texStop = gl_TexCoord[0].xyz;
	vec3 dir = texStop - texStart;
	vec3 dirUnit = normalize(dir);
	float len = length(dir);

	// Nvidia linux driver does bad things if we use more than 256 ray segs
	int nsegs = int(min((len / delta), 256.0));
	float delta1 = len / float(nsegs);
	vec3 deltaVec = dirUnit * delta1;
	float zStartNorm = shadow2D(depth_buffer, vec3(texCoord2D,0.0)).x;
	float zStart = (zN*zF) / (zF-(zStartNorm*(zF-zN)));
	float zStopNorm = gl_FragCoord.z;
	float zStop = (zN*zF) / (zF-(zStopNorm*(zF-zN)));
	float zdelta = (zStop-zStart) / float(nsegs);

	vec3 texCoord0 = texStart;
	vec3 texCoord1 = texCoord0+deltaVec;
	float s0 = texture3D(volumeTexture, texCoord0).x;
	float s1 = texture3D(volumeTexture, texCoord1).x;

	float fragDepth = zStopNorm;
	vec4 fragColor =  vec4(0.0, 0.0, 0.0, 0.0);

	// Make sure gl_FragDepth is set for all execution paths
	gl_FragDepth = zStartNorm;

	// Composite from back to front

	for (int i = 0; i<nsegs; i++) {
		for (int ii=0; ii<numiso; ii++) {
			// If sign changes we have an isosurface
			if (((isovalues[ii]-s1) * (isovalues[ii]-s0)) < 0.0) {
				//if (((isovalues-s1) * (isovalues-s0)) < 0.0) {

				float weight = (isovalues[ii]-s0) / (s1-s0);
				//float weight = (isovalues-s0) / (s1-s0);
				vec4 color = isocolors[ii];
				//vec4 color = isocolors;

				// blend fragment
				fragColor = (color * vec4(color.a)) + (fragColor * (vec4(1.0) - vec4(color.a)));
				fragDepth = zStart + (float(i) * zdelta) + (zdelta*weight);

			}

		}
		texCoord0 = texCoord1;
		texCoord1 = texCoord1+deltaVec;
		s0 = s1;
		s1 = texture3D(volumeTexture, texCoord1).x;
	}

	if (fragColor.a == 0.0) discard;

	gl_FragDepth = (1.0/zN - 1.0/fragDepth) / (1.0/zN - 1.0/zF);
	gl_FragColor = fragColor;
}
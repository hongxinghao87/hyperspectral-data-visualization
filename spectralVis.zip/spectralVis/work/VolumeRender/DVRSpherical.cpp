//--DVRSpherical.cpp ----------------------------------------------------------
//   
//                   Copyright (C)  2004
//     University Corporation for Atmospheric Research
//                   All Rights Reserved
//
// Kenny Gruchalla
// National Center for Atmospheric Research
// PO 3000, Boulder, Colorado
//
//
// A 3d texture-based direct volume renderer for spherical grids.
//
// NOTE: This code is currently in a rough proof-of-concept state. It is not 
//       intended for any analytical use. There are known sampling issues with
//       the current approach, and generally much kludginess about.
//
//----------------------------------------------------------------------------
#include "stdafx.h"
#include "glew.h"
#include <GL/gl.h>
#include <GL/glu.h>

#include "DVRSpherical.h"
#include "TextureBrick.h"
#include "GLShaderProgram.h"
#include "BBox.h"
//#include "shaders.h"


#ifndef MAX
#define MAX(a,b)        ((a) > (b) ? (a) : (b))
#endif

using namespace VolumeRender;

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------
DVRSpherical::DVRSpherical(
	GLint internalFormat, GLenum format, GLenum type
) : DVRShader(internalFormat, format, type),
  _nr(0),
  _shellWidth(1.0),
  _permutation(3),
  _clip(3)
{
  _shaders[DEFAULT]        = NULL;
  _shaders[LIGHT]          = NULL;
  _shaders[PRE_INTEGRATED] = NULL;

  _permutation[0] = 0;
  _permutation[1] = 1;
  _permutation[2] = 2;

  _clip[0] = false;
  _clip[1] = false;
  _clip[2] = false;
}

//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------
DVRSpherical::~DVRSpherical() 
{
  delete _shaders[DEFAULT];
  _shaders[DEFAULT] = NULL;

  delete _shaders[LIGHT];
  _shaders[LIGHT] = NULL;

  delete [] _colormap;
  _colormap = NULL;
}


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRSpherical::GraphicsInit() 
{
  glewInit();

  if (initTextures() < 0) return(-1);

  //
  // Create, Load & Compile the default shader program
  //
  if (!createShader(DEFAULT, 
                    NULL, 
                    NULL, 
                    "spherical_shader_default.h", 
                    NULL))
  {
    return -1;
  }

  //
  // Create, Load & Compile the lighting shader program
  //
  if (!createShader(LIGHT,
                    "vertex_shader_lighting.h",
                    NULL,
                    "spherical_shader_lighting.h",
                    NULL))
  {
    return -1;
  }

  //
  // Set up initial uniform values
  //
  if (_shaders[DEFAULT]->enable() < 0) return(-1);

  if (GLEW_VERSION_2_0)
  {
    glUniform1i(_shaders[DEFAULT]->uniformLocation("colormap"), 1);
    glUniform1i(_shaders[DEFAULT]->uniformLocation("volumeTexture"), 0);
  }
  else
  {
    glUniform1iARB(_shaders[DEFAULT]->uniformLocation("colormap"), 1);
    glUniform1iARB(_shaders[DEFAULT]->uniformLocation("volumeTexture"), 0);
  }

  _shaders[DEFAULT]->disable();


  //
  // Set the current shader
  //
  _shader = _shaders[DEFAULT];

  return 0;
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRSpherical::SetRegionSpherical(void *data,
                                     int nx, int ny, int nz,
                                     const int data_roi[6],
                                     const float extents[6],
                                     const int data_box[6],
                                     int level,
                                     size_t /*fullHeight*/,
                                     const std::vector<long> &permutation,
                                     const std::vector<bool> &clip)
{ 
  assert(permutation.size() == 3 && clip.size() == 3);

  for(int i=0; i<permutation.size(); i++)
  {
    _permutation[i] = permutation[i];
    _clip[i] = clip[i];
  }
 
  //
  // Set the texture data
  //
  if (_nx != nx || _ny != ny || _nz != nz)
  {
    _data = data;
  }

  //
  // Set the geometry extents
  //
  _data = data;

  if (_lastRegion.update(nx, ny, nz, data_roi, data_box, extents, _maxTexture))
  {
    _level = level;

    if (_nx != nx || _ny != ny || _nz != nz)
    {
      _nx = _bx = nextPowerOf2(nx); 
      _ny = _by = nextPowerOf2(ny); 
      _nz = _bz = nextPowerOf2(nz);
    }
    
    //
    // Hard-code the volume extents to the unit cube 
    //
    _vmin.x = 0;//extents[0];
    _vmin.y = 0;//extents[1];
    _vmin.z = 0;//extents[2];
    _vmax.x = 1;//extents[3];
    _vmax.y = 1;//extents[4];
    _vmax.z = 1;//extents[5];
    
    _delta = fabs(_vmin.z-_vmax.z) / (2.0*nz); 
    
    for (int i=0; i<_bricks.size(); i++)
    {
      delete _bricks[i];
      _bricks[i] = NULL;
    }
    
    _bricks.clear();
    
    if (_nx <= _maxTexture && _ny <= _maxTexture && _nz <= _maxTexture)
    {
      //
      // The data will fit completely within texture memory, so no bricking is 
      // needed. We can save a few cycles by setting up the single brick here,
      // rather than calling buildBricks(...). 
      //
      _bricks.push_back(new TextureBrick(_internalFormat, _format, _type));
      
      _bricks[0]->volumeMin(_vmin.x, _vmin.y, _vmin.z);
      _bricks[0]->volumeMax(_vmax.x, _vmax.y,_vmax.z);

      _bricks[0]->textureMin(0, 0, 0);
      _bricks[0]->textureMax(1, 1, 1);
      
      _bricks[0]->fill((GLubyte*)data, nx, ny, nz);
      
      loadTexture(_bricks[0]);
    } 
    else
    {
      //
      // The data will not fit completely within texture memory, need to 
      // subdivide into multiple bricks.
      //

      // TBD 
      // buildBricks(level, data_box, data_roi, nx, ny, nz);

      DebugMessage("Bricking is currently unsupported for spherical rendering");
    }

    initShaderVariables();

    calculateSampling();
  }
  else
  {
    //
    // Only the data has changed; therefore, we'll refill and reuse the
    // the existing bricks (texture objects).
    //
    for (int i=0; i<_bricks.size(); i++)
    {
      _bricks[i]->refill((GLubyte*)data);
    }
  }

  return 0;
}

//----------------------------------------------------------------------------
// Draw the proxy geometry optmized to a spherical shell
//----------------------------------------------------------------------------
void DVRSpherical::drawViewAlignedSlices(const TextureBrick *brick,
                                         const matrix4f &modelview,
                                         const matrix4f &modelviewInverse)
{
  float tmpv[3];
  const float *extents = _lastRegion.extents();
    
  permute(_permutation, tmpv, extents[0], extents[1], extents[2]);
  float r0 = tmpv[2]/2.0; // inner shell radius

  permute(_permutation, tmpv, extents[3], extents[4], extents[5]);
  float r1 = tmpv[2]/2.0; // outer shell raduis

  //
  //  
  //
  BBox volumeBox  = brick->volumeBox();
 // BBox textureBox = brick->textureBox();
  //BBox rotatedBox(volumeBox);
  //
  ////
  //// transform the volume into world coordinates
  ////
  //rotatedBox.transform(modelview);

  //
  // Calculate the slice plane normal (i.e., the view plane normal transformed
  // into model space). 
  //
  // slicePlaneNormal = modelviewInverse * viewPlaneNormal; 
  //                                       (0,0,1);
  //
  vec3f slicePlaneNormal(modelviewInverse(2,0), 
                          modelviewInverse(2,1),
                          modelviewInverse(2,2)); 
  //Vect3d slicePlaneNormal(0,0,1);
  slicePlaneNormal.Normalize();

  //
  // Calculate the distance between slices
  //
  vec3f sliceDelta = slicePlaneNormal * _delta;

  //
  // Define the slice view aligned slice plane. The plane will be positioned
  // one delta inside the outer radius of the shell.
  //
  vec3f center =  volumeBox.center();
  vec3f slicePoint = center - (r1 * slicePlaneNormal) + sliceDelta;

  vec3f sliceOrtho;

  if ((slicePlaneNormal * vec3f(1,1,0)) != 0.0)
  {
    sliceOrtho = slicePlaneNormal % (vec3f(1,1,0));
  }
  else
  {
    sliceOrtho = slicePlaneNormal % (vec3f(0,1,0));
  }

  sliceOrtho.Normalize();

  //
  // Calculate edge intersections between the plane and the spherical shell
  //

  //
  // TBD -- This code creates proxy geometry for the full spherical shell,
  // ignoring the brick's extents. This won't work once we support spherical
  // bricking. Also, when less than a full region has been selected, this
  // code superflously samples empty space. The shader handles that; however,
  // it still incurs the expensive coordinate transform. This should be 
  // fixed.
  //
  for(int i = 0 ; i <= _samples; i++)
  { 
    float d = (center - slicePoint).length();

    if (r1 > d)
    {
      float rg0 = 0.0;
      float rg1 = sqrt(r1*r1 - d*d);

      if (r0 > d)
      {
        rg0 = sqrt(r0*r0 - d*d);
      }

      //
      // Draw donut (shell-plane intersection) and texture map it
      //
      glBegin(GL_QUAD_STRIP); 
      {
        for (float theta=-M_PI/20.0; theta<=2.0*M_PI; theta+=M_PI/20.0)
        {
          vec3f v = (cos(theta)*sliceOrtho +
                      sin(theta)*slicePlaneNormal % (sliceOrtho));

          v.Normalize();

          vec3f v0 = slicePoint + v * rg0;
          vec3f v1 = slicePoint + v * rg1;

          glTexCoord3f(v0.x, v0.y, v0.z);          
          glVertex3f(v0.x, v0.y, v0.z);

          glTexCoord3f(v1.x, v1.y, v1.z);          
          glVertex3f(v1.x, v1.y, v1.z);

        }
      }
      glEnd();
    }

    //
    // increment the slice plane by the slice distance
    //
    slicePoint += sliceDelta;    
  }

  glFlush();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
bool DVRSpherical::supported()
{
  return (CGLShaderProgram::supported() && GLEW_ARB_multitexture);
}

//----------------------------------------------------------------------------
// Calculate the sampling distance
//----------------------------------------------------------------------------
void DVRSpherical::calculateSampling()
{
  //
  // Get the modelview matrix and its inverse
  //
  matrix4f modelview;   
  matrix4f modelviewInverse;

  glGetFloatv(GL_MODELVIEW_MATRIX, modelview); 
  glGetFloatv(GL_MODELVIEW_MATRIX, modelviewInverse);
  modelviewInverse.invert();

  BBox volumeBox(_vmin, _vmax);

  volumeBox.transform(modelview);

  // 
  // Calculate the the minimum and maximum z-position of the rotated bounding
  // boxes. Equivalent to but quicker than:
  //
  // Vect3d maxv(0, 0, rotatedBox.maxZ().z); 
  // Vect3d minv(0, 0, rotatedBox.minZ().z); 
  // maxv = modelviewInverse * maxd;
  // minv = modelviewInverse * mind;
  //
  vec3f maxv(modelviewInverse(2,0)*volumeBox.maxZ().z,
              modelviewInverse(2,1)*volumeBox.maxZ().z,
              modelviewInverse(2,2)*volumeBox.maxZ().z);
  vec3f minv(modelviewInverse(2,0)*volumeBox.minZ().z,
              modelviewInverse(2,1)*volumeBox.minZ().z,
              modelviewInverse(2,2)*volumeBox.minZ().z);

  if (_renderFast)
  {
    _samples = MAX(_nx, MAX(_ny, _nz));
  }
  else
  {
    _samples = _nr * ((maxv - minv).length() / _shellWidth);
  }

  _delta = (maxv - minv).length() / _samples; 
  _samplingRate = (1.0/(float)(_level+1))*(_shellWidth / _delta) / (float)_nr;
  
  // TBD -- The sampling rate & opacity correction delta are not quite right 
  // for spherical geometry. We need to work through how the spherical 
  // transform is warping the voxels and effecting the sampling. 
  // 
}

//----------------------------------------------------------------------------
// Rearrange the x, y, and z components according to the permutation matrix
//----------------------------------------------------------------------------
void DVRSpherical::permute(const std::vector<long>& permutation,
                           float result[3], float x, float y, float z)
{
  result[permutation[0]] = x;
  result[permutation[1]] = y;
  result[permutation[2]] = z;
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRSpherical::initShaderVariables()
{
  assert(_shader);
  if (_shader->enable() < 0) return;

  const int *data_roi  = _lastRegion.roi();
  const float *extents = _lastRegion.extents();

  if (GLEW_VERSION_2_0)
  {
  
    if (_lighting)
    {
      glUniform3f(_shader->uniformLocation("dimensions"), _nx, _ny, _nz);
      glUniform1f(_shader->uniformLocation("kd"), _kd);
      glUniform1f(_shader->uniformLocation("ka"), _ka);
      glUniform1f(_shader->uniformLocation("ks"), _ks);
      glUniform1f(_shader->uniformLocation("expS"), _expS);
      glUniform3f(_shader->uniformLocation("lightDirection"), 
                  _pos[0], _pos[1], _pos[2]);
    } 
    
    float tmpv[3];
    
    permute(_permutation, tmpv, _nx, _ny, _nz);
    
    _nr = (int)tmpv[2];
    
    permute(_permutation, tmpv, 
            (float)data_roi[0]/(_nx-1),
            (float)data_roi[1]/(_ny-1), 
            (float)data_roi[2]/(_nz-1));
    
    glUniform3f(_shader->uniformLocation("tmin"), 
                tmpv[0], tmpv[1], tmpv[2]);
      
    permute(_permutation, tmpv,
            (float)data_roi[3]/(_nx-1), 
            (float)data_roi[4]/(_ny-1), 
            (float)data_roi[5]/(_nz-1));
    
    glUniform3f(_shader->uniformLocation("tmax"), 
                tmpv[0], tmpv[1], tmpv[2]);
    
    permute(_permutation, tmpv, extents[0], extents[1], extents[2]);
    
    glUniform3f(_shader->uniformLocation("dmin"), 
                (tmpv[0] + 180.0) / 360.0,
                (tmpv[1] + 90.0) / 180.0,
                tmpv[2]);
    
    _shellWidth = tmpv[2];
    
    permute(_permutation, tmpv, extents[3], extents[4], extents[5]);
    
    glUniform3f(_shader->uniformLocation("dmax"), 
                (tmpv[0] + 180.0) / 360.0,
                (tmpv[1] + 90.0) / 180.0,
                tmpv[2]);
    
    assert(tmpv[2]);
    _shellWidth = (tmpv[2] - _shellWidth)/(2.0*tmpv[2]);
    
    glUniform3f(_shader->uniformLocation("permutation"), 
                _permutation[0], _permutation[1], _permutation[2]);
    
    glUniform2i(_shader->uniformLocation("clip"), 
                _clip[_permutation[0]], 
                _clip[_permutation[1]]);

  }
  else
  {
    if (_lighting)
    {
      glUniform3fARB(_shader->uniformLocation("dimensions"), _nx, _ny, _nz);
      glUniform1fARB(_shader->uniformLocation("kd"), _kd);
      glUniform1fARB(_shader->uniformLocation("ka"), _ka);
      glUniform1fARB(_shader->uniformLocation("ks"), _ks);
      glUniform1fARB(_shader->uniformLocation("expS"), _expS);
      glUniform3fARB(_shader->uniformLocation("lightDirection"), 
                     _pos[0], _pos[1], _pos[2]);
    }

    float tmpv[3];
    
    permute(_permutation, tmpv, 
            (float)data_roi[0]/(_nx-1),
            (float)data_roi[1]/(_ny-1), 
            (float)data_roi[2]/(_nz-1));
      
    glUniform3fARB(_shader->uniformLocation("tmin"), 
                   tmpv[0], tmpv[1], tmpv[2]);
    
    permute(_permutation, tmpv,
            (float)data_roi[3]/(_nx-1), 
            (float)data_roi[4]/(_ny-1), 
            (float)data_roi[5]/(_nz-1));
    
    glUniform3fARB(_shader->uniformLocation("tmax"), 
                   tmpv[0], tmpv[1], tmpv[2]);
    
    permute(_permutation, tmpv, extents[0], extents[1], extents[2]);
    
    glUniform3fARB(_shader->uniformLocation("dmin"), 
                   tmpv[0], tmpv[1], tmpv[2]);
    
    _shellWidth = tmpv[2];
    
    permute(_permutation, tmpv, extents[3], extents[4], extents[5]);
    
    glUniform3fARB(_shader->uniformLocation("dmax"), 
                   tmpv[0], tmpv[1], tmpv[2]);
    
    assert(tmpv[2]);
    _shellWidth = (tmpv[2] - _shellWidth)/(2.0*tmpv[2]);
    
    glUniform3fARB(_shader->uniformLocation("permutation"), 
                   _permutation[0], _permutation[1], _permutation[2]);
    
    glUniform2iARB(_shader->uniformLocation("clip"), 
                   _clip[_permutation[0]], 
                   _clip[_permutation[1]]);
  } 

  _shader->disable();
}

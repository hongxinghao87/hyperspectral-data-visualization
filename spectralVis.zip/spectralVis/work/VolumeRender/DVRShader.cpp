
#include "StdAfx.h"
#include "glew.h"
#include <GL/gl.h>
#include <GL/glu.h>

#include "DVRShader.h"
#include "TextureBrick.h"
#include "GLShaderProgram.h"
#include "BBox.h"
#include "glrender.h"
#include "../ElecEnvironmentDVR.h"
//#include "shaders.h"
#include <map>
using namespace std;

using namespace VolumeRender;

#ifndef MAX
#define MAX(a,b)        ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b)        ((a) < (b) ? (a) : (b))
#endif

#ifndef M_E
#define M_E 2.71828182845904523536
#endif

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------
DVRShader::DVRShader(
					 GLint internalFormat, GLenum format, GLenum type) : 
DVRTexture3d(internalFormat, format, type),
_colormap(NULL),
_shader(NULL),
_lighting(false),
_preintegration(false),
_kd(0.8),
_ka(0.1),
_ks(0.3),
_expS(20.0)
{
	_shaders[DEFAULT]              = NULL;
	_shaders[LIGHT]                = NULL;
	_shaders[PRE_INTEGRATED]       = NULL;
	_shaders[PRE_INTEGRATED_LIGHT] = NULL;

	_pos[0] = 0.0;
	_pos[1] = 0.0;
	_pos[2] = 1.0;

	for (int i=0; i<4; i++) {
		_vdir[i] = 0.0;
		_vpos[i] = 0.0;
	}


	m_bDrawDragBox = false;
	m_litteBoxList = -1;
	dragbox[0].nID = 1;
	dragbox[1].nID = 2;
	dragbox[2].nID = 3;
	dragbox[3].nID = 4;
	dragbox[4].nID = 5;
	dragbox[5].nID = 6;
	m_bInitLize = false;
}

//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------
DVRShader::~DVRShader() 
{
	map <int, CGLShaderProgram *>::iterator pos; 
	for(pos=_shaders.begin(); pos != _shaders.end(); ++pos) {
		if (pos->second) delete pos->second;
		pos->second = NULL;
	}

	if (_colormap) delete [] _colormap;
	_colormap = NULL;

	glDeleteTextures(2, _cmapid);
	if (glIsList(m_litteBoxList))
		glDeleteLists(m_litteBoxList,1);

}


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
bool DVRShader::createShader(ShaderType type, 
							 const char *vertexCommandLine,
							 const char *vertexSource,
							 const char *fragCommandLine,
							 const char *fragmentSource)
{
	_shaders[type] = new CGLShaderProgram();
	_shaders[type]->create();

	//
	// Vertex shader
	//
	if (vertexSource) {
		_shaders[type]->loadVertexSource(vertexSource);
	}
	else if(vertexCommandLine){
		_shaders[type]->loadVertexShader(vertexCommandLine);
	}

	//
	// Fragment shader
	//
	if (fragmentSource) {
		_shaders[type]->loadFragmentSource(fragmentSource);
	}
	else if (fragCommandLine)
	{
		_shaders[type]->loadFragmentShader(fragCommandLine);
	}

	if (!_shaders[type]->compile())
	{
		return false;
	}

	
	//
	// Set up initial uniform values
	//
	if (_shaders[type]->enable() < 0) return(false);

	if (GLEW_VERSION_2_0)
	{
		glUniform1i(_shaders[type]->uniformLocation("colormap"), 1);
		glUniform1i(_shaders[type]->uniformLocation("volumeTexture"), 0);
	}
	else
	{
		glUniform1iARB(_shaders[type]->uniformLocation("colormap"), 1);
		glUniform1iARB(_shaders[type]->uniformLocation("volumeTexture"), 0);
	}

	_shaders[type]->disable();


	return true;
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRShader::GraphicsInit() 
{
	glewInit();

	if (initTextures() < 0) return(-1);

	//
	// Create, Load & Compile the default shader program
	//
	if (!createShader(DEFAULT, 
		NULL, 
		NULL, 
		"fragment_shader_default.h", 
		NULL))
	{
		return -1;
	}

	//
	// Create, Load & Compile the lighting shader program
	//
	if (!createShader(LIGHT,
		"vertex_shader_lighting.h",
		NULL,
		"fragment_shader_lighting.h",
		NULL))
	{
		return -1;
	}

	//
	// Create, Load & Compile the pre-integrated shader program
	//
	if (!createShader(PRE_INTEGRATED,
		"vertex_shader_preintegrated.h",
		NULL,
		"fragment_shader_preintegrated.h",
		NULL))
	{
		return -1;
	}

	//
	// Create, Load & Compile the lighted pre-integrated shader program
	//
	if (!createShader(PRE_INTEGRATED_LIGHT,
		"vertex_shader_preintegrated_lighting.h",
		NULL,
		"fragment_shader_preintegrated_lighting.h",
		NULL))
	{
		return -1;
	}

	//
	// Set the current shader
	//
	_shader = _shaders[DEFAULT];

	initShaderVariables();

	printOpenGLError();

	return 0;
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRShader::SetRegion(void *data,
						 int nx, int ny, int nz,
						 const int roi[6],
						 const float extents[6],
						 const int box[6],
						 int level,
						 double volumescale[3]) 
{ 
	_nx = nx; _ny = ny; _nz = nz;
	_data = data;


	//
	// Set the geometry extents
	//
	return DVRTexture3d::SetRegion(data, nx, ny, nz, roi, extents, box, level, volumescale);
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::loadTexture(TextureBrick *brick)
{
	printOpenGLError();

	brick->load();
	printOpenGLError();
}


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRShader::Render()
{	
	if (m_bDrawDragBox)
	{
		vec3f _vmid = (_vmin+_vmax)*0.5;
		vec3f _vHalf = (_vmax-_vmin)*0.5;
		double dDragLength = 0.25;
		if (!m_bInitLize)
		{
			dragbox[0].dMove = _vmin.x - LEGHT_TO_DRAGBOX;
			dragbox[1].dMove = _vmax.x + LEGHT_TO_DRAGBOX;
			dragbox[2].dMove = _vmin.y - LEGHT_TO_DRAGBOX;
			dragbox[3].dMove = _vmax.y + LEGHT_TO_DRAGBOX;
			dragbox[4].dMove = _vmin.z - LEGHT_TO_DRAGBOX;
			dragbox[5].dMove = _vmax.z + LEGHT_TO_DRAGBOX;
			_vorimin = _vmin;
			_vorimax = _vmax;
			m_bInitLize = true;
		}
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(1, 1, 1);
		glLineWidth(2.0f);
		glBegin(GL_LINE_LOOP);
		glVertex3f(_vorimin.x,	_vorimin.y, _vorimin.z);
		glVertex3f(_vorimax.x,	_vorimin.y, _vorimin.z);
		glVertex3f(_vorimax.x,	_vorimax.y, _vorimin.z);
		glVertex3f(_vorimin.x,	_vorimax.y, _vorimin.z);
		glEnd();

		glBegin(GL_LINE_LOOP);
		glVertex3f(_vorimin.x,	_vorimin.y, _vorimax.z);
		glVertex3f(_vorimax.x,	_vorimin.y, _vorimax.z);
		glVertex3f(_vorimax.x,	_vorimax.y, _vorimax.z);
		glVertex3f(_vorimin.x,	_vorimax.y, _vorimax.z);
		glEnd();

		glBegin(GL_LINES);
		glVertex3f(_vorimin.x,	_vorimin.y, _vorimin.z);
		glVertex3f(_vorimin.x,	_vorimin.y, _vorimax.z);
		glVertex3f(_vorimax.x,	_vorimin.y, _vorimin.z);
		glVertex3f(_vorimax.x,	_vorimin.y, _vorimax.z);

		glVertex3f(_vorimin.x,	_vorimax.y, _vorimin.z);
		glVertex3f(_vorimin.x,	_vorimax.y, _vorimax.z);
		glVertex3f(_vorimax.x,	_vorimax.y, _vorimin.z);
		glVertex3f(_vorimax.x,	_vorimax.y, _vorimax.z);
		glEnd();

		glColor3f(1, 1, 1);
		glLineWidth(5.0f);
		glBegin(GL_LINE_LOOP);
		glVertex3f(_vmin.x,	_vmin.y, _vmin.z);
		glVertex3f(_vmax.x,	_vmin.y, _vmin.z);
		glVertex3f(_vmax.x,	_vmax.y, _vmin.z);
		glVertex3f(_vmin.x,	_vmax.y, _vmin.z);
		glEnd();

		glBegin(GL_LINE_LOOP);
		glVertex3f(_vmin.x,	_vmin.y, _vmax.z);
		glVertex3f(_vmax.x,	_vmin.y, _vmax.z);
		glVertex3f(_vmax.x,	_vmax.y, _vmax.z);
		glVertex3f(_vmin.x,	_vmax.y, _vmax.z);
		glEnd();

		glBegin(GL_LINES);
		glVertex3f(_vmin.x,	_vmin.y, _vmin.z);
		glVertex3f(_vmin.x,	_vmin.y, _vmax.z);
		glVertex3f(_vmax.x,	_vmin.y, _vmin.z);
		glVertex3f(_vmax.x,	_vmin.y, _vmax.z);

		glVertex3f(_vmin.x,	_vmax.y, _vmin.z);
		glVertex3f(_vmin.x,	_vmax.y, _vmax.z);
		glVertex3f(_vmax.x,	_vmax.y, _vmin.z);
		glVertex3f(_vmax.x,	_vmax.y, _vmax.z);
		glEnd();

		glEnable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glColor4f(1,0,0,0.4);
		glBegin(GL_LINES);
		glVertex3f(dragbox[0].dMove,_vmid.y, _vmid.z);
		glVertex3f(_vmin.x,_vmid.y, _vmid.z);
		glVertex3f(_vmax.x,_vmid.y, _vmid.z);
		glVertex3f(dragbox[1].dMove,_vmid.y, _vmid.z);

		glVertex3f(_vmid.x,dragbox[2].dMove, _vmid.z);
		glVertex3f(_vmid.x,_vmin.y, _vmid.z);
		glVertex3f(_vmid.x,_vmax.y, _vmid.z);
		glVertex3f(_vmid.x,dragbox[3].dMove, _vmid.z);

		glVertex3f(_vmid.x, _vmid.y,dragbox[4].dMove);
		glVertex3f(_vmid.x, _vmid.y,_vmin.z);
		glVertex3f(_vmid.x, _vmid.y,_vmax.z);
		glVertex3f(_vmid.x, _vmid.y,dragbox[5].dMove);
		glEnd();
		
		//������קС����--------------------------------------------
		double dBoxWidth = 0.05*_vHalf.x;
		if (!glIsList(m_litteBoxList))
		{
			m_litteBoxList = glGenLists(1);
			glNewList(m_litteBoxList,GL_COMPILE);
			glBegin(GL_LINE_LOOP);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0, dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, dBoxWidth/2.0);
			glEnd();
			glBegin(GL_LINE_LOOP);
			glVertex3f(- dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(- dBoxWidth/2.0,dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(- dBoxWidth/2.0,dBoxWidth/2.0, dBoxWidth/2.0);
			glVertex3f(- dBoxWidth/2.0,-dBoxWidth/2.0, dBoxWidth/2.0);
			glEnd();
			glBegin(GL_LINES);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0,-dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,dBoxWidth/2.0,-dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0, dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,-dBoxWidth/2.0,dBoxWidth/2.0);
			glEnd();
			
			glBegin(GL_QUADS);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0, dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, dBoxWidth/2.0);
			
			glVertex3f(- dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(- dBoxWidth/2.0,dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(- dBoxWidth/2.0,dBoxWidth/2.0, dBoxWidth/2.0);
			glVertex3f(- dBoxWidth/2.0,-dBoxWidth/2.0, dBoxWidth/2.0);
			
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,-dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,dBoxWidth/2.0, -dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0, -dBoxWidth/2.0);
			
			
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0,-dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,dBoxWidth/2.0,-dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,dBoxWidth/2.0,dBoxWidth/2.0);
			
			glVertex3f(-dBoxWidth/2.0,dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,-dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,dBoxWidth/2.0,dBoxWidth/2.0);
			
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,-dBoxWidth/2.0,dBoxWidth/2.0);
			glVertex3f(-dBoxWidth/2.0,-dBoxWidth/2.0,-dBoxWidth/2.0);
			glVertex3f(dBoxWidth/2.0,-dBoxWidth/2.0,-dBoxWidth/2.0);
			glEnd();
			glEndList();
		}

		//������קС��
		glInitNames();
		glPushName(-1);	
		glPushMatrix();
		glTranslatef(dragbox[0].dMove,_vmid.y, _vmid.z);
		if (glIsList(m_litteBoxList)&&theApp.pView->m_bShowLitteBox)
		{
			if (dragbox[0].bSelect)
				glColor4f(1,1,0,0.4);
			else
				glColor4f(1,0,0,0.4);
			glLoadName(dragbox[0].nID);
			glCallList(m_litteBoxList);
		}
		glPopMatrix();
		glPushMatrix();
		glTranslatef(dragbox[1].dMove,_vmid.y, _vmid.z);
		if (glIsList(m_litteBoxList)&&theApp.pView->m_bShowLitteBox)
		{
			if (dragbox[1].bSelect)
				glColor4f(1,1,0,0.4);
			else
				glColor4f(1,0,0,0.4);
			glLoadName(dragbox[1].nID);
			glCallList(m_litteBoxList);
		}
		glPopMatrix();
		glPushMatrix();
		glTranslatef(_vmid.x,dragbox[2].dMove, _vmid.z);
		if (glIsList(m_litteBoxList)&&theApp.pView->m_bShowLitteBox)
		{
			if (dragbox[2].bSelect)
				glColor4f(1,1,0,0.4);
			else
				glColor4f(1,0,0,0.4);
			glLoadName(dragbox[2].nID);
			glCallList(m_litteBoxList);
		}
		glPopMatrix();
		glPushMatrix();
		glTranslatef(_vmid.x,dragbox[3].dMove, _vmid.z);
		if (glIsList(m_litteBoxList)&&theApp.pView->m_bShowLitteBox)
		{
			if (dragbox[3].bSelect)
				glColor4f(1,1,0,0.4);
			else
				glColor4f(1,0,0,0.4);
			glLoadName(dragbox[3].nID);
			glCallList(m_litteBoxList);
		}
		glPopMatrix();
		glPushMatrix();
		glTranslatef(_vmid.x, _vmid.y,dragbox[4].dMove);
		if (glIsList(m_litteBoxList)&&theApp.pView->m_bShowLitteBox)
		{
			if (dragbox[4].bSelect)
				glColor4f(1,1,0,0.4);
			else
				glColor4f(1,0,0,0.4);
			glLoadName(dragbox[4].nID);
			glCallList(m_litteBoxList);
		}
		glPopMatrix();
		glPushMatrix();
		glTranslatef(_vmid.x, _vmid.y,dragbox[5].dMove);
		if (glIsList(m_litteBoxList)&&theApp.pView->m_bShowLitteBox)
		{
			if (dragbox[5].bSelect)
				glColor4f(1,1,0,0.4);
			else
				glColor4f(1,0,0,0.4);
			glLoadName(dragbox[5].nID);
			glCallList(m_litteBoxList);
		}
		glPopName();
		
		glPopMatrix();
		glPopAttrib();
	}

	if (_shader) if (_shader->enable() < 0) return(-1);

	glPolygonMode(GL_FRONT, GL_FILL);
	glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);

	if (_preintegration) {
		if (GLEW_VERSION_2_0) {
			glActiveTexture(GL_TEXTURE1);
		}
		else {
			glActiveTextureARB(GL_TEXTURE1_ARB);
		}
		glEnable(GL_TEXTURE_2D);  
		glBindTexture(GL_TEXTURE_2D, _cmapid[1]);
	}
	else {
		if (GLEW_VERSION_2_0) {
			glActiveTexture(GL_TEXTURE1);
		}
		else {
			glActiveTextureARB(GL_TEXTURE1_ARB);
		}
		glEnable(GL_TEXTURE_1D);
		glBindTexture(GL_TEXTURE_1D, _cmapid[0]);
	}

	if (GLEW_VERSION_2_0) {
		glActiveTexture(GL_TEXTURE0);
	}
	else {
		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	glEnable(GL_TEXTURE_3D);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);

	glDisable(GL_DITHER);

	renderBricks();

	if (GLEW_VERSION_2_0) {

		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, 0);
		glBindTexture(GL_TEXTURE_1D, 0);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_1D);

		glActiveTexture(GL_TEXTURE0);
	} else {

		glActiveTextureARB(GL_TEXTURE1_ARB);
		glBindTexture(GL_TEXTURE_2D, 0);
		glBindTexture(GL_TEXTURE_1D, 0);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_1D);

		glActiveTextureARB(GL_TEXTURE0_ARB);
	}

	glBindTexture(GL_TEXTURE_3D, 0);
	glDisable(GL_TEXTURE_3D);

	glDisable(GL_BLEND);
	glDisable(GL_CULL_FACE);

	if (_shader) _shader->disable();

// 	if(_preintegration)
// 	{
// 		CGLRender::Set2DMode();
// 
// 		glEnable(GL_TEXTURE_2D);
// 		glBindTexture(GL_TEXTURE_2D, _cmapid[1]);
// 
// 		glEnable(GL_BLEND);
// 
// 		glBegin(GL_QUADS);
// 
// 		glTexCoord2f(0, 0); glVertex2f(280, 10);
// 		glTexCoord2f(1, 0); glVertex2f(380, 10);
// 		glTexCoord2f(1, 1); glVertex2f(380, 110);
// 		glTexCoord2f(0, 1); glVertex2f(280, 110);
// 
// 		glEnd();
// 		
// 		CGLRender::Restore();
// 	}

// 	CGLRender::Set2DMode();
// 
// 	glDisable(GL_TEXTURE_2D);
// 	glEnable(GL_TEXTURE_1D);
// 	glBindTexture(GL_TEXTURE_1D, _cmapid[0]);

// 	glEnable(GL_BLEND);
// 	//glDisable(GL_BLEND);
// 	glBegin(GL_QUADS);
// 
// 	glTexCoord1f(0); glVertex2f(480, 10);
// 	glTexCoord1f(1); glVertex2f(680, 10);
// 	glTexCoord1f(1); glVertex2f(680, 50);
// 	glTexCoord1f(0); glVertex2f(480, 50);
// 	glEnd();
// 	glDisable(GL_TEXTURE_1D);
// 
// 	glBegin(GL_LINE_LOOP);
// 	glColor3f(0.3, 0.3, 0.3);
// 
// 	glVertex2f(480 - 2, 10 - 2);
// 	glVertex2f(680 + 2, 10 - 2);
// 	glVertex2f(680 + 2, 50 + 2);
// 	glVertex2f(480 - 2, 50 + 2);
// 	glEnd();

// 	CGLRender::Restore();

	glFlush();
	return 0;
}
int DVRShader::SetSelect(int nID)
{
	for(int i = 0;i<6;i++)
	{
		if (nID == dragbox[i].nID)
		{
			dragbox[i].bSelect = true;
			return i;
		}else
			dragbox[i].bSelect = false;
	}
	return -1;
}
//----------------------------------------------------------------------------
// Set the color table used to render the volume without any opacity 
// correction.
//----------------------------------------------------------------------------
void DVRShader::SetCLUT(const float ctab[256][4]) 
{
	for (int i=0; i<256; i++)
	{
		_colormap[i*4+0] = ctab[i][0];
		_colormap[i*4+1] = ctab[i][1];
		_colormap[i*4+2] = ctab[i][2];
		_colormap[i*4+3] = ctab[i][3];
	}

	glBindTexture(GL_TEXTURE_1D, _cmapid[0]);

	glTexSubImage1D(GL_TEXTURE_1D, 0, 0, 256, GL_RGBA,
		GL_FLOAT, _colormap);

	glFlush();
}

//----------------------------------------------------------------------------
// Set the color table used to render the volume applying an opacity 
// correction.
//----------------------------------------------------------------------------
void DVRShader::SetOLUT(const float atab[256][4], const int numRefinements)
{
	//
	// Compute the sampling distance and rate
	//
	calculateSampling();

	if (_preintegration)
	{
		SetPreIntegrationTable(atab, numRefinements);
		return;
	}

	//
	// Calculate opacity correction. Delta is 1 for the ffineest refinement, 
	// multiplied by 2^n (the sampling distance)
	//
	double delta = 2.0/_samplingRate * (double)(1<<numRefinements);

	for(int i=0; i<256; i++) 
	{
		double opac = atab[i][3];

		opac = 1.0 - pow((1.0 - opac), delta);

		if (opac > 1.0)
		{
			opac = 1.0;
		}

		_colormap[i*4+0] = atab[i][0];
		_colormap[i*4+1] = atab[i][1];
		_colormap[i*4+2] = atab[i][2];
		_colormap[i*4+3] = opac;
	}

	glBindTexture(GL_TEXTURE_1D, _cmapid[0]);

	glTexSubImage1D(GL_TEXTURE_1D, 0, 0, 256, GL_RGBA,
		GL_FLOAT, _colormap);

	glFlush();
}

double clamp(double v, double min, double max)
{
	return MAX(MIN(v, max), min);
}

//----------------------------------------------------------------------------
// Set the pre-integrated color table used to render the volume applying an 
// opacity correction.
//----------------------------------------------------------------------------
void DVRShader::SetPreIntegrationTable(const float atab[256][4], 
									   const int numRefinements)
{
	double factor;
	double ifunc[256][4];
	double r = 0;
	double g = 0;
	double b = 0;
	double a = 0;


	ifunc[0][0] = 0.0;
	ifunc[0][1] = 0.0;
	ifunc[0][2] = 0.0;
	ifunc[0][3] = 0.0;

	float opac[256];

	double delta = 2.0/_samplingRate * (double)(1<<numRefinements);

	opac[0] = MIN(1.0, 1.0 - pow((1.0 - atab[0][3]), delta));

	// 
	// Compute integral functions & opacity correction
	//

	for (int i=1; i<256; i++)
	{

		opac[i] = MIN(1.0, 1.0 - pow((1.0 - atab[i][3]), delta));

		a = 255.0*(opac[i-1]+opac[i])/2.0;

		// Opacity-weighted
		//ifunc[i][0] = ifunc[i-1][0] + (atab[i-1][0]+atab[i][0])/2.0*a;
		//ifunc[i][1] = ifunc[i-1][1] + (atab[i-1][1]+atab[i][1])/2.0*a;
		//ifunc[i][2] = ifunc[i-1][2] + (atab[i-1][2]+atab[i][2])/2.0*a;

		// No weighting
		ifunc[i][0] = ifunc[i-1][0] + (atab[i-1][0]+atab[i][0])/2.0*255;
		ifunc[i][1] = ifunc[i-1][1] + (atab[i-1][1]+atab[i][1])/2.0*255;
		ifunc[i][2] = ifunc[i-1][2] + (atab[i-1][2]+atab[i][2])/2.0*255;

		ifunc[i][3] = ifunc[i-1][3] + a;
	}    

	//
	// Compute lookup table
	//
	for (int sb=0; sb<256; sb++)
	{
		for (int sf=0; sf<256; sf++)
		{
			int smin = MIN(sb, sf);
			int smax = MAX(sb, sf);

			if (smin != smax)
			{
				factor = 1.0 / (double)(smax - smin);

				r = factor * (ifunc[smax][0] - ifunc[smin][0]);
				g = factor * (ifunc[smax][1] - ifunc[smin][1]);
				b = factor * (ifunc[smax][2] - ifunc[smin][2]);
				a = 256.0 * 
					(1.0 - expf(-(ifunc[smax][3] - ifunc[smin][3]) * factor / 255.0));
			}
			else
			{
				// Opacity-weighted
				//r = 255.0 * atab[smin][0] * atab[smin][3];
				//g = 255.0 * atab[smin][1] * atab[smin][3];
				//b = 255.0 * atab[smin][2] * atab[smin][3];

				// No weighting
				r = 255.0 * atab[smin][0];
				g = 255.0 * atab[smin][1];
				b = 255.0 * atab[smin][2];
				a = 256 * (1.0 - expf(-opac[smin]));

			}

			int index = (sf + sb*256) * 4;

			_colormap[index + 0] = clamp(r/255.0, 0.0, 1.0);
			_colormap[index + 1] = clamp(g/255.0, 0.0, 1.0);
			_colormap[index + 2] = clamp(b/255.0, 0.0, 1.0);
			_colormap[index + 3] = clamp(a/255.0, 0.0, 1.0);
		}
	}

	glBindTexture(GL_TEXTURE_2D, _cmapid[1]);

	glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 256, 256, GL_RGBA,
		GL_FLOAT, _colormap);

	glFlush();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::SetView(const float *pos, const float *dir) 
{
	for (int i=0; i<4; i++) 
	{
		_vdir[i] = dir[i];
		_vpos[i] = pos[i];
	}
	initShaderVariables();

}


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::SetPreintegrationOnOff(bool on) 
{
	_preintegration = on;

	_shader = shader(); 

	initShaderVariables();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::SetLightingOnOff(bool on) 
{
	_lighting = on;

	_shader = shader(); 

	initShaderVariables();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::SetLightingCoeff(float kd, float ka, float ks, float expS)
{
	_kd = kd;
	_ka = ka;
	_ks = ks;
	_expS = expS;

	initShaderVariables();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::SetLightingLocation(const float *pos)
{
	_pos[0] = pos[0];
	_pos[1] = pos[1];
	_pos[2] = pos[2];

	initShaderVariables();
}


//----------------------------------------------------------------------------
// Initalize the textures (i.e., 3d volume texture and the 1D colormap texture)
//----------------------------------------------------------------------------
int DVRShader::initTextures()
{

	//
	// Setup the colormap texture
	//
	glGenTextures(2, _cmapid);

	_colormap = new float[256*256*4];
	for (int i=0; i<256; i++) { 
		_colormap[i*4+0] = (float) i / 255.0;
		_colormap[i*4+1] = (float) i / 255.0;
		_colormap[i*4+2] = (float) i / 255.0;
		_colormap[i*4+3] = 1.0;
	}

	//
	// Standard colormap
	//
	glBindTexture(GL_TEXTURE_1D, _cmapid[0]);

	glTexImage1D(GL_TEXTURE_1D, 0, GL_RGBA, 256, 0, GL_RGBA,
		GL_FLOAT, _colormap);

	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);

	//
	// Pre-Integrated colormap
	//
	glBindTexture(GL_TEXTURE_2D, _cmapid[1]);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA,
		GL_FLOAT, _colormap);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glBindTexture(GL_TEXTURE_1D, 0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glFlush();

	return(0);
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::initShaderVariables()
{
	if (_shader->enable() < 0) return;

	if (_preintegration)
	{
		if (GLEW_VERSION_2_0)
		{
			glUniform1f(_shader->uniformLocation("delta"), _delta);
			glUniform4f(
				_shader->uniformLocation("vdir"), 
				_vdir[0], _vdir[1], _vdir[2], _vdir[3]
			);
			glUniform4f(
				_shader->uniformLocation("vpos"), 
				_vpos[0], _vpos[1], _vpos[2], _vpos[3]
			);

		}
		else
		{
			glUniform1fARB(_shader->uniformLocation("delta"), _delta);
			glUniform4fARB(
				_shader->uniformLocation("vdir"), 
				_vdir[0], _vdir[1], _vdir[2], _vdir[3]
			);
			glUniform4fARB(
				_shader->uniformLocation("vpos"), 
				_vpos[0], _vpos[1], _vpos[2], _vpos[3]
			);
		}
	}

	if (_lighting)
	{
		if (GLEW_VERSION_2_0)
		{
			glUniform3f(_shader->uniformLocation("dimensions"), _nx, _ny, _nz);
			glUniform1f(_shader->uniformLocation("kd"), _kd);
			glUniform1f(_shader->uniformLocation("ka"), _ka);
			glUniform1f(_shader->uniformLocation("ks"), _ks);
			glUniform1f(_shader->uniformLocation("expS"), _expS);
			glUniform3f(
				_shader->uniformLocation("lightDirection"), _pos[0], _pos[1], _pos[2]
			);
		}
		else
		{
			glUniform3fARB(_shader->uniformLocation("dimensions"), _nx, _ny, _nz);
			glUniform1fARB(_shader->uniformLocation("kd"), _kd);
			glUniform1fARB(_shader->uniformLocation("ka"), _ka);
			glUniform1fARB(_shader->uniformLocation("ks"), _ks);
			glUniform1fARB(_shader->uniformLocation("expS"), _expS);
			glUniform3fARB(
				_shader->uniformLocation("lightDirection"), _pos[0], _pos[1], _pos[2]
			);
		}
	} 

	_shader->disable();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
bool DVRShader::supported()
{
	return (CGLShaderProgram::supported() && GLEW_ARB_multitexture);
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
CGLShaderProgram* DVRShader::shader()
{
	if (_preintegration && _lighting)
	{
		return _shaders[PRE_INTEGRATED_LIGHT];
	}

	if (_preintegration && !_lighting)
	{
		return _shaders[PRE_INTEGRATED];
	}

	if (!_preintegration && _lighting)
	{
		return _shaders[LIGHT];
	}

	return _shaders[DEFAULT];
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRShader::calculateSampling()
{
	DVRTexture3d::calculateSampling();

	if (_preintegration)
	{
		if (_shader->enable() < 0) return;

		if (GLEW_VERSION_2_0)
		{
			glUniform1f(_shader->uniformLocation("delta"), _delta);
		}
		else
		{
			glUniform1fARB(_shader->uniformLocation("delta"), _delta);
		}

		_shader->disable();
	}
}

//----------------------------------------------------------------------------
// Draw the proxy geometry for the brick. Overriden to setup the texture
// matrix that the shader can use to convert object coordinates to 
// texture coordinates. 
//----------------------------------------------------------------------------
void DVRShader::drawViewAlignedSlices(const TextureBrick *brick,
									  const matrix4f &modelview,
									  const matrix4f &modelviewInverse)
{
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();

	if (_preintegration)
	{
		vec3f vmax = brick->volumeMax();
		vec3f vmin = brick->volumeMin();
		vec3f tmax = brick->textureMax();
		vec3f tmin = brick->textureMin();

		vec3f scale((tmax.x - tmin.x) / (vmax.x - vmin.x),
			(tmax.y - tmin.y) / (vmax.y - vmin.y),
			(tmax.z - tmin.z) / (vmax.z - vmin.z));

		vec3f trans((tmin.x / scale.x) - vmin.x,
			(tmin.y / scale.y) - vmin.y,
			(tmin.z / scale.z) - vmin.z);

		glScaled(scale.x, scale.y, scale.z);
		glTranslated(trans.x, trans.y, trans.z);
	}

	glMatrixMode(GL_MODELVIEW);

	DVRTexture3d::drawViewAlignedSlices(brick, modelview, modelviewInverse);
}


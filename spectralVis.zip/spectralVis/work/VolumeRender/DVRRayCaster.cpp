//--DVRRayCaster.cpp -----------------------------------------------------------
//
// $Id: DVRRayCaster.cpp,v 1.15 2008/05/27 18:40:07 clynejp Exp $
//
//
//----------------------------------------------------------------------------
#include "stdafx.h"
#include "glew.h"
#include <GL/gl.h>
#include <GL/glu.h>

#include "GLRender.h"
#include "DVRRayCaster.h"
#include "TextureBrick.h"
#include "GLShaderProgram.h"
#include "BBox.h"

//#include "shaders.h"

using namespace VolumeRender;

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------
DVRRayCaster::DVRRayCaster(
	GLint internalFormat, GLenum format, GLenum type
) : DVRShader(internalFormat, format, type)
{
	_lighting = false;
	_framebufferid = 0;
	_backface_texcrd_texid = 0;
	_backface_depth_texid = 0;
	_nearClip = 1.0;
	_farClip = 2.0;

	_nisos = 0;

	if (GLEW_VERSION_2_0) {
		_texcrd_texunit = GL_TEXTURE1;
		_depth_texunit = GL_TEXTURE2;
		_colormap_texunit = GL_TEXTURE3;
	}
	else {
		_texcrd_texunit = GL_TEXTURE1_ARB;
		_depth_texunit = GL_TEXTURE2_ARB;
		_colormap_texunit = GL_TEXTURE3_ARB;
	}
	_texcrd_sampler = 1;
	_depth_sampler = 2;
	_colormap_sampler = 3;
}

//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------
DVRRayCaster::~DVRRayCaster() 
{
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT,0);
	if (_framebufferid) glDeleteFramebuffersEXT(1, &_framebufferid);

	if (_backface_texcrd_texid) glDeleteTextures(1, &_backface_texcrd_texid);
	if (_backface_depth_texid) glDeleteTextures(1, &_backface_depth_texid);
	printOpenGLError();
}

bool DVRRayCaster::createShader(ShaderType type,
                             const char *vertexCommandLine,
                             const char *vertexSource,
                             const char *fragCommandLine,
                             const char *fragmentSource)
{
	_shaders[type] = new CGLShaderProgram();
	_shaders[type]->create();

	//
	// Vertex shader
	//
	if (vertexSource) {
		_shaders[type]->loadVertexSource(vertexSource);
	}
	else if(vertexCommandLine){
		_shaders[type]->loadVertexShader(vertexCommandLine);
	}

	//printOpenGLError();
	//
	// Fragment shader
	//
	if (fragmentSource) {
		_shaders[type]->loadFragmentSource(fragmentSource);
	}
	else if (fragCommandLine)
	{
		_shaders[type]->loadFragmentShader(fragCommandLine);
	}
	//printOpenGLError();

	if (!_shaders[type]->compile()) {
		printOpenGLError();
		return false;
	}

	//
	// Set up initial uniform values
	//
	if (type != BACKFACE) {
		if (_shaders[type]->enable() < 0) return(false);;

		if (GLEW_VERSION_2_0) {
			glUniform1i(_shaders[type]->uniformLocation("volumeTexture"), 0);
			glUniform1i(
				_shaders[type]->uniformLocation("texcrd_buffer"), 
				_texcrd_sampler
			);
			glUniform1i(
				_shaders[type]->uniformLocation("depth_buffer"), _depth_sampler
			);
         if(type == DVRRAYCASTING || type == DVRRAYCASTING_LIGHT)
			glUniform1i(
				_shaders[type]->uniformLocation("colormap"), _colormap_sampler
				);
		}
		else {
			glUniform1iARB(_shaders[type]->uniformLocation("volumeTexture"), 0);
			glUniform1iARB(
				_shaders[type]->uniformLocation("texcrd_buffer"), 
				_texcrd_sampler
			);
			glUniform1iARB(
				_shaders[type]->uniformLocation("depth_buffer"), _depth_sampler
			);
			if(type == DVRRAYCASTING || type == DVRRAYCASTING_LIGHT)
			glUniform1iARB(
				_shaders[type]->uniformLocation("colormap"), _colormap_sampler
				);
		}

		_shaders[type]->disable();
	}

	printOpenGLError();
	return true;
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRRayCaster::GraphicsInit() 
{
	glewInit();

	if (initTextures() < 0) return(-1);

	//
	// Create, Load & Compile the shader programs
	//

	if (!createShader(
		DEFAULT, 
		"vertex_shader_iso.h", NULL,
		"fragment_shader_iso.h", NULL)) {

		return -1;
	}
	if (!createShader(
		LIGHT, 
		"vertex_shader_iso_lighting.h", NULL,
		"fragment_shader_iso_lighting.h", NULL)) {

		return -1;
	}

	if (!createShader(
		DVRRAYCASTING,
		"vertex_shader_dvr_raycasting.h", NULL,
		"fragment_shader_dvr_raycasting.h", NULL))
	{
		return -1;
	}
	
	if (!createShader(
		DVRRAYCASTING_LIGHT,
		"vertex_shader_dvr_raycasting_lighting.h", NULL,
		"fragment_shader_dvr_raycasting_lighting.h", NULL))
	{
		return -1;
	}
	//
	// Set the current shader
	//

	m_bDVRRayCasting = true;
	//_shader = _shaders[DEFAULT];
	_shader = _shaders[DVRRAYCASTING];

	return 0;
}

void DVRRayCaster::SetLightingOnOff(bool on) 
{
	_lighting = on;
	_shader = shader();
}

void DVRRayCaster::SetDVRRayCastingOnOff(int on)
{
	m_bDVRRayCasting = on;
	_shader = shader();
	
}
//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
int DVRRayCaster::Render()
{
	if (_shader) if (_shader->enable() < 0) return(0);

	DVRTexture3d::calculateSampling();
	float delta = _delta * 2;

	if (GLEW_VERSION_2_0) {
		glUniform1f(_shader->uniformLocation("delta"), delta);
	} else {
		glUniform1fARB(_shader->uniformLocation("delta"), delta);
	}
	if (_shader) _shader->disable();

	return(DVRShader::Render());

	return 0;
}


void DVRRayCaster::drawVolumeFaces(
	const BBox &box, const BBox &tbox
) {

	// Indecies, in proper winding order, of vertices making up planes 
	// of BBox.
	//
	//       6*--------*7
	//       /|       /|
	//      / |      / |
	//     /  |     /  |
	//    /  4*----/---*5
	//  2*--------*3  /
	//   |  /     |  /
	//   | /      | /
	//   |/       |/
	//  0*--------*1
	//
	static const int planes[6][4] = {
		{4,5,7,6},	// front
		{0,2,3,1},	// back
		{5,1,3,7},	// right
		{4,6,2,0},	// left
		{6,7,3,2},	// top
		{4,0,1,5}	// bottom
	};


//cerr << "DrawVolumeFaces()\n";
	for (int i=0; i<6; i++) {
		glBegin(GL_QUADS);
		//cerr << "glBegin(GL_QUADS)\n";

		for (int j=0; j<4; j++) {

			// Color is set to texture coordinates. Thus the frame buffer 
			// will contain the texture coordinates of the pixels on each
			// face. Think we only need color for rendering of back
			// facing faces.
			//
			glColor3f(
				tbox[planes[i][j]].x, 
				tbox[planes[i][j]].y, 
				tbox[planes[i][j]].z
			);
			//cerr << "glColor3f : " 
			//	<< tbox[planes[i][j]].x << " "
			//	<< tbox[planes[i][j]].y << " " 
			//	<< tbox[planes[i][j]].z << endl;

			// Texture coordinates needed for front facing planes. 
			glTexCoord3f(
				tbox[planes[i][j]].x, 
				tbox[planes[i][j]].y, 
				tbox[planes[i][j]].z
			);
			//cerr << "glTexCoord3f : " 
			//	<< tbox[planes[i][j]].x << " "
			//	<< tbox[planes[i][j]].y << " " 
			//	<< tbox[planes[i][j]].z << endl;

			glVertex3f(
				box[planes[i][j]].x, 
				box[planes[i][j]].y, 
				box[planes[i][j]].z
			);
			//cerr << "glVertex3f : "
			//	<< box[planes[i][j]].x << " "
			//	<< box[planes[i][j]].y << " " 
			//	<< box[planes[i][j]].z << endl;
		}
		//cerr << endl;
		glEnd();
	}
}

// render the backfacing polygons
void DVRRayCaster::render_backface(
	const BBox &box, const BBox &tbox
) {

//    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);
	//glFrontFace(GL_CCW);

    if (GLEW_VERSION_2_0) {
      glActiveTexture(GL_TEXTURE1);
    }
    else {
      glActiveTextureARB(GL_TEXTURE1_ARB);
    }
	glDisable(GL_TEXTURE_1D);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_3D);

    if (GLEW_VERSION_2_0) {
      glActiveTexture(GL_TEXTURE0);
    }
    else {
      glActiveTextureARB(GL_TEXTURE0_ARB);
    }
	glDisable(GL_TEXTURE_1D);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_3D);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glDisable(GL_BLEND);

	drawVolumeFaces(box, tbox);

    glDisable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	printOpenGLError();

}

// render the front-facing polygons
//
void DVRRayCaster::raycasting_pass(
	const TextureBrick *brick, const BBox &box, const BBox &tbox
) {


	if (GLEW_VERSION_2_0) {


		glActiveTexture(_texcrd_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);

		glActiveTexture(_depth_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);

		if(m_bDVRRayCasting)
		{
			glActiveTexture(_colormap_texunit);
			glEnable(GL_TEXTURE_1D);
			glBindTexture(GL_TEXTURE_1D, _cmapid[0]);
		}


		glActiveTexture(GL_TEXTURE0);
		glEnable(GL_TEXTURE_3D);
		glBindTexture(GL_TEXTURE_3D, brick->handle());

	} else {

		glActiveTextureARB(_texcrd_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);

		glActiveTextureARB(_depth_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);

		if(m_bDVRRayCasting)
		{
			glActiveTextureARB(_colormap_texunit);
			glEnable(GL_TEXTURE_1D);
			glBindTexture(GL_TEXTURE_1D, _cmapid[0]);
		}

		glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_3D);
		glBindTexture(GL_TEXTURE_3D, brick->handle());
	}

	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	if (_shader->enable() == 0) {
		drawVolumeFaces(box, tbox);
		_shader->disable();
	}

	glDisable(GL_CULL_FACE);

	if (GLEW_VERSION_2_0) {
		glActiveTexture(_depth_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

		glActiveTexture(_texcrd_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

		if(m_bDVRRayCasting)
		{
			glActiveTexture(_colormap_texunit);			
			glBindTexture(GL_TEXTURE_2D, 0);
			glDisable(GL_TEXTURE_1D);
		}

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_3D, 0);
	} else {
		glActiveTextureARB(_depth_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

		glActiveTextureARB(_texcrd_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

		if(m_bDVRRayCasting)
		{
			glActiveTextureARB(_colormap_texunit);			
			glBindTexture(GL_TEXTURE_2D, 0);
			glDisable(GL_TEXTURE_1D);
		}

		glActiveTextureARB(GL_TEXTURE0_ARB);
		glBindTexture(GL_TEXTURE_3D, 0);
	}
	glDisable(GL_TEXTURE_3D);
	printOpenGLError();
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
void DVRRayCaster::renderBrick(
	const TextureBrick *brick,
	const matrix4f &modelview,
	const matrix4f &modelviewInverse
) {
	BBox volumeBox  = brick->volumeBox();
	BBox textureBox = brick->textureBox();

	GLint viewport[4];
	glGetIntegerv(GL_VIEWPORT, viewport);
	Resize(viewport[2], viewport[3]);
	// Write depth info.
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);

	// Parent class enables default shader
	_shader->disable();

	// enable rendering to FBO
	glBindFramebufferEXT (GL_FRAMEBUFFER_EXT, _framebufferid);
	//glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

	// No depth comparisons
	glDepthFunc(GL_ALWAYS);

    render_backface(volumeBox, textureBox);
	 
	// disable rendering to FBO
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

	// Restore normal depth comparison for ray casting pass.
	glDepthFunc(GL_LEQUAL);
	//glDisable(GL_BLEND);

	raycasting_pass(brick, volumeBox, textureBox);

	printOpenGLError();

	CGLRender::Set2DMode();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);

	glBegin(GL_QUADS);

	glTexCoord2f(0, 0); glVertex2f(280, 10);
	glTexCoord2f(1, 0); glVertex2f(380, 10);
	glTexCoord2f(1, 1); glVertex2f(380, 110);
	glTexCoord2f(0, 1); glVertex2f(280, 110);

	glEnd();

	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);

	glBegin(GL_QUADS);

	glTexCoord2f(0, 0); glVertex2f(280, 120);
	glTexCoord2f(1, 0); glVertex2f(380, 120);
	glTexCoord2f(1, 1); glVertex2f(380, 220);
	glTexCoord2f(0, 1); glVertex2f(280, 220);

	glEnd();

	glDisable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_1D);
	glBindTexture(GL_TEXTURE_1D, _cmapid[0]);

	//glDisable(GL_BLEND);
	glBegin(GL_QUADS);

	glTexCoord1f(0); glVertex2f(480, 10);
	glTexCoord1f(1); glVertex2f(680, 10);
	glTexCoord1f(1); glVertex2f(680, 50);
	glTexCoord1f(0); glVertex2f(480, 50);
	glEnd();
	glDisable(GL_TEXTURE_1D);

	glBegin(GL_LINE_LOOP);
	glColor3f(0.3, 0.3, 0.3);

	glVertex2f(480 - 2, 10 - 2);
	glVertex2f(680 + 2, 10 - 2);
	glVertex2f(680 + 2, 50 + 2);
	glVertex2f(480 - 2, 50 + 2);
	glEnd();

	CGLRender::Restore();

}


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------

void DVRRayCaster::SetIsoValues(
	const float *values, const float *colors, int n
) {

	if (n > GetMaxIsoValues()) n = GetMaxIsoValues();

	_nisos = n;
	for (int i=0; i<n; i++) {
		_values[i] = values[i];
		_colors[i*4+0] = colors[i*4+0];
		_colors[i*4+1] = colors[i*4+1];
		_colors[i*4+2] = colors[i*4+2];
		_colors[i*4+3] = colors[i*4+3];
	}

	initShaderVariables();

}

void DVRRayCaster::SetNearFar(GLfloat nearplane, GLfloat farplane) {

	_nearClip = nearplane;
	_farClip = farplane;
	initShaderVariables();
}

//----------------------------------------------------------------------------
// Initalize the textures (i.e., 3d volume texture and the 1D colormap texture)
//----------------------------------------------------------------------------
int DVRRayCaster::initTextures()
{
	int i;
	// List of acceptable frame buffer object internal types 
	//
	GLint colorInternalFormats[] = {
		GL_RGBA16F_ARB, GL_RGBA16, GL_RGBA16, GL_RGBA8, GL_RGBA
	};
	GLenum colorInternalTypes[] = {
		GL_FLOAT, GL_INT, GL_INT, GL_INT, GL_INT
	};
	int num_color_fmts = 
		sizeof(colorInternalFormats)/sizeof(colorInternalFormats[0]);

	GLint depthInternalFormats[] = {
		GL_DEPTH_COMPONENT32, GL_DEPTH_COMPONENT24, GL_DEPTH_COMPONENT, 
		GL_DEPTH_COMPONENT32, GL_DEPTH_COMPONENT24, GL_DEPTH_COMPONENT
	};
	GLenum depthInternalTypes[] = {
		GL_FLOAT, GL_FLOAT, GL_FLOAT,
		GL_INT, GL_INT, GL_INT,
	};
	int num_depth_fmts = 
		sizeof(depthInternalFormats)/sizeof(depthInternalFormats[0]);

	DVRShader::initTextures();

	GLint viewport[4];
	glGetIntegerv(GL_VIEWPORT, viewport);

	// Create the to FBO - one for the backside of the volumecube
	//
	glGenFramebuffersEXT(1, &_framebufferid);
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT,_framebufferid);

	glGenTextures(1, &_backface_texcrd_texid);
	glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

	// Try to find a supported format
	//
	GLenum status;
	for (i=0; i<num_color_fmts; i++) {
		glTexImage2D(
			GL_TEXTURE_2D, 0,colorInternalFormats[i], 
			viewport[2], viewport[3], 0, GL_RGBA, colorInternalTypes[i], NULL
		);
		glFramebufferTexture2DEXT(
			GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, 
			_backface_texcrd_texid, 0
		);
		status = (GLenum) glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
		if (status == GL_FRAMEBUFFER_COMPLETE_EXT) {
			_colorInternalFormat = colorInternalFormats[i];
			_colorInternalType = colorInternalTypes[i];
			break;
		}
	}
	if (status != GL_FRAMEBUFFER_COMPLETE_EXT) {
		DebugMessage(
			"Failed to create OpenGL color framebuffer_object : %d", status
		);
		return(-1);
	}

	glGenTextures(1, &_backface_depth_texid);
	glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameterf( GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_LUMINANCE);
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_NONE);
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_NEVER);

	for (i=0; i<num_depth_fmts; i++) {
		glTexImage2D(
			GL_TEXTURE_2D, 0,depthInternalFormats[i], viewport[2], viewport[3],
			0, GL_DEPTH_COMPONENT, depthInternalTypes[i], NULL
		);

		glFramebufferTexture2DEXT(
			GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, GL_TEXTURE_2D, 
			_backface_depth_texid, 0
		);

		status = (GLenum) glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
		if (status == GL_FRAMEBUFFER_COMPLETE_EXT) {
			_depthInternalFormat = depthInternalFormats[i];
			_depthInternalType = depthInternalTypes[i];
			break;
		}
	}
	if (status != GL_FRAMEBUFFER_COMPLETE_EXT) {
		DebugMessage(
			"Failed to create OpenGL depth framebuffer_object : %d", status
		);
		return(-1);
	}

	// Bind the default frame buffer
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	glBindTexture(GL_TEXTURE_2D, 0);

	printOpenGLError();
	return(0);
}

void DVRRayCaster::initShaderVariables() {

	assert(_shader);

	if (_shader->enable() < 0) return;

	if(m_bDVRRayCasting)
	{
		if (GLEW_VERSION_2_0) {
			
			glUniform1f(_shader->uniformLocation("zN"), _nearClip);
			glUniform1f(_shader->uniformLocation("zF"), _farClip);
		} else {
			
			glUniform1fARB(_shader->uniformLocation("zN"), _nearClip);
			glUniform1fARB(_shader->uniformLocation("zF"), _farClip);
		}
	}
	else
	{

		if (GLEW_VERSION_2_0) {
			glUniform1fv(_shader->uniformLocation("isovalues"), _nisos, _values);
			glUniform4fv(_shader->uniformLocation("isocolors"), _nisos, _colors);
			glUniform1i(_shader->uniformLocation("numiso"), _nisos);

			/*glUniform4f(
				_shader->uniformLocation("isocolors"), 
				_colors[0], _colors[1], _colors[2], _colors[3]
			);
			glUniform1f(_shader->uniformLocation("isovalues"), _values[0]);*/

			glUniform1f(_shader->uniformLocation("zN"), _nearClip);
			glUniform1f(_shader->uniformLocation("zF"), _farClip);
		} else {
			glUniform1fvARB(_shader->uniformLocation("isovalues"), _nisos, _values);
			glUniform4fvARB(_shader->uniformLocation("isocolors"), _nisos, _colors);
			glUniform1iARB(_shader->uniformLocation("numiso"), _nisos);

			/*glUniform4fARB(
				_shader->uniformLocation("isocolors"), 
				_colors[0], _colors[1], _colors[2], _colors[3]
			);
			glUniform1fARB(_shader->uniformLocation("isovalues"), _values[0]);*/

			glUniform1fARB(_shader->uniformLocation("zN"), _nearClip);
			glUniform1fARB(_shader->uniformLocation("zF"), _farClip);
		}
	}

	if (_lighting) {
		if (GLEW_VERSION_2_0) {   
			glUniform3f(_shader->uniformLocation("dimensions"), _nx, _ny, _nz);
			glUniform1f(_shader->uniformLocation("kd"), _kd);
			glUniform1f(_shader->uniformLocation("ka"), _ka);
			glUniform1f(_shader->uniformLocation("ks"), _ks);
			glUniform1f(_shader->uniformLocation("expS"), _expS);
			glUniform3f(
				_shader->uniformLocation("lightDirection"), 
				_pos[0], _pos[1], _pos[2]
			);
		}       
		else {   
			glUniform3fARB(_shader->uniformLocation("dimensions"), _nx, _ny, _nz);
			glUniform1fARB(_shader->uniformLocation("kd"), _kd);
			glUniform1fARB(_shader->uniformLocation("ka"), _ka);
			glUniform1fARB(_shader->uniformLocation("ks"), _ks);
			glUniform1fARB(_shader->uniformLocation("expS"), _expS);
			glUniform3fARB(
				_shader->uniformLocation("lightDirection"), 
				_pos[0], _pos[1], _pos[2]
			);
		}       
	}
	
	_shader->disable();
}

void DVRRayCaster::Resize(int width, int height) {

	if (GLEW_VERSION_2_0) {

		glActiveTexture(_texcrd_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);

		glActiveTexture(_depth_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);

	} else {

		glActiveTextureARB(_texcrd_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);

		glActiveTextureARB(_depth_texunit);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);

	}

	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT,_framebufferid);

	glBindTexture(GL_TEXTURE_2D, _backface_texcrd_texid);
	glTexImage2D(
		GL_TEXTURE_2D, 0,_colorInternalFormat, width, height, 0, 
		GL_RGBA, _colorInternalType, NULL
	);

	glBindTexture(GL_TEXTURE_2D, _backface_depth_texid);
	glTexImage2D(
		GL_TEXTURE_2D, 0,_depthInternalFormat, width, height, 0, 
		GL_DEPTH_COMPONENT, _depthInternalType, NULL
	);

	// Bind the default frame buffer
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

	if (GLEW_VERSION_2_0) {
		glActiveTexture(_depth_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

		glActiveTexture(_texcrd_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

	} else {
		glActiveTextureARB(_depth_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

		glActiveTextureARB(_texcrd_texunit);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);

	}
}


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
bool DVRRayCaster::supported()
{
	GLint	ntexunits;
	glGetIntegerv(GL_MAX_TEXTURE_UNITS, &ntexunits);
	return (
		DVRShader::supported() && 
		GLEW_EXT_framebuffer_object && 
		GLEW_ARB_vertex_buffer_object &&
		ntexunits >= 3
	);
}

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
CGLShaderProgram* DVRRayCaster::shader()
{
	if (_lighting && m_bDVRRayCasting) 
	{
		return _shaders[DVRRAYCASTING_LIGHT];
	}
	else if (!_lighting && m_bDVRRayCasting) 
	{
		return _shaders[DVRRAYCASTING];
	}
	else if(_lighting && ! m_bDVRRayCasting)
	{
		return _shaders[LIGHT];
	}
	else
	{
		return _shader = _shaders[DEFAULT];
	}	
}


#pragma once

#include "DVRTexture3d.h"


#include <vector>
#include <map>
typedef struct DragBox{
	GLuint nID;
	bool bSelect;
	double dMove;
	DragBox(){
		nID = -1;
		dMove = 0;
		bSelect = false;
	};
}DragBox;
#define LEGHT_TO_DRAGBOX 0.1
namespace VolumeRender
{

	class BBox;
	class CGLShaderProgram;


	class DVRShader : public DVRTexture3d
	{

	public:


		DVRShader(GLint internalFormat, GLenum format, GLenum type);
		virtual ~DVRShader();

		virtual int GraphicsInit();

		virtual int SetRegion(void *data, 
			int nx, int ny, int nz, 
			const int data_roi[6],
			const float extents[6],
			const int data_box[6],
			int level,
			double volumescale[3]);

		virtual void loadTexture(TextureBrick *brick);

		virtual int Render();

		virtual int HasPreintegration() const { return true; };
		virtual int HasLighting() const { return true; };

		virtual void SetCLUT(const float ctab[256][4]);
		virtual void SetOLUT(const float ftab[256][4], const int numRefinenements);

		virtual void SetView(const float *pos, const float *dir);

		virtual void SetPreintegrationOnOff(bool on);
		virtual bool GetPreintegrationOnOff() { 
			return _preintegration;}
		virtual void SetPreIntegrationTable(const float tab[256][4], const int nR);

		virtual void SetLightingOnOff(bool on);
		virtual bool GetLightingOnOff() {return _lighting;}
		virtual void SetLightingCoeff(float kd, float ka, float ks, float expS);
		virtual void SetLightingLocation(const float *pos);

		static bool supported();

	protected:

		enum ShaderType
		{
			DEFAULT = 0,
			LIGHT,
			PRE_INTEGRATED,
			PRE_INTEGRATED_LIGHT
		};

		int initTextures();
		virtual void initShaderVariables();

		virtual bool createShader(ShaderType,
			const char *vertexCommandLine,
			const char *vertexSource,
			const char *fragCommandLine,
			const char *fragmentSource);

		CGLShaderProgram* shader();

		virtual void calculateSampling();

		virtual void drawViewAlignedSlices(const TextureBrick *brick,
			const matrix4f &modelview,
			const matrix4f &modelviewInverse);

	protected:

		float          *_colormap;
		CGLShaderProgram  *_shader;
		std::map <int, CGLShaderProgram *> _shaders;

		bool            _lighting;
		bool            _preintegration;

		GLuint _cmapid[2];

		int    _nx;
		int    _ny;
		int    _nz;

	public:
		float _kd;
		float _ka;
		float _ks;
		float _expS;
		float _pos[3];
		float _vdir[4];
		float _vpos[4];
		
		//��ק���ƿ�
		bool  m_bDrawDragBox;
		GLuint m_litteBoxList;
		DragBox dragbox[6];
		int SetSelect(int nID);
		bool m_bInitLize;
		vec3f _vorimin;
		vec3f _vorimax;
		
	};

}

#include "StdAfx.h"
#include "TextureBrick.h"

#ifndef MAX
#define MAX(a,b)        ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b)        ((a) < (b) ? (a) : (b))
#endif

using namespace VolumeRender;

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------
TextureBrick::TextureBrick(GLint internalFormat, GLenum format, GLenum type) :
  _nx(0),
  _ny(0),
  _nz(0),
  _xoffset(0),
  _yoffset(0),
  _zoffset(0),
  _center(0,0,0),
  _dmin(0,0,0),
  _dmax(0,0,0),
  _vmin(0,0,0),
  _vmax(0,0,0),
  _tmin(0,0,0),
  _tmax(0,0,0),
  _texid(0),
  _internalFormat(internalFormat),
  _format(format),
  _type(type),
  _data(NULL),
  _haveOwnership(false),
  _dnx(0),
  _dny(0),
  _dnz(0)
{
	// Find size of texture elements
	//
	_size = 0;
	switch (format) {
	case GL_COLOR_INDEX:
	case GL_RED:
	case GL_GREEN:
	case GL_BLUE:
	case GL_ALPHA:
	case GL_LUMINANCE:
		_size = 1;
		break;
	case GL_LUMINANCE_ALPHA:
		_size = 2;
		break;
	case GL_RGB:
	case GL_BGR:
		_size = 3;
		break;
	case GL_RGBA:
	case GL_BGRA:
		_size = 4;
		break;
	}
	assert (_size != 0);

	switch (type) {
	case GL_UNSIGNED_BYTE:
	case GL_BYTE:
		break;
	case GL_UNSIGNED_SHORT:
	case GL_SHORT:
		_size *= 2;
		break;
	case GL_UNSIGNED_INT:
	case GL_INT:
	case GL_FLOAT:
		_size *= 4;
		break;
	default:
		assert(type == GL_UNSIGNED_BYTE);
		break;
	}
	
  //
  // Setup the 3d texture
  //
  glGenTextures(1, &_texid);
  glBindTexture(GL_TEXTURE_3D, _texid);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);  

  // Set texture border behavior
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
  
  // Set texture interpolation method
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  printOpenGLError();
}

//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------
TextureBrick::~TextureBrick()
{
	if(glIsTexture(_texid))
		glDeleteTextures(1, &_texid);

  if (_haveOwnership)
  {
    delete [] _data;
  }
  _data = NULL;
}

//----------------------------------------------------------------------------
// Set the minimum extent of the brick's data block
//----------------------------------------------------------------------------
void TextureBrick::dataMin(float x, float y, float z) 
{ 
  _dmin.x = x; 
  _dmin.y = y; 
  _dmin.z = z; 
}

//----------------------------------------------------------------------------
// Set the maximum extent of the brick's data block
//----------------------------------------------------------------------------
void TextureBrick::dataMax(float x, float y, float z) 
{ 
  _dmax.x = x; 
  _dmax.y = y; 
  _dmax.z = z; 
}

//----------------------------------------------------------------------------
// Set the extents of the brick's data block from the voxel coordinates.
//----------------------------------------------------------------------------
void TextureBrick::setDataBlock(int level, const int box[6], const int block[6], double volumescale[3])
{
  size_t min[3] = {block[0]+box[0], block[1]+box[1], block[2]+box[2]};
  size_t max[3] = {block[3]+box[0], block[4]+box[1], block[5]+box[2]};

  double vtemp[3] = {volumescale[0] / 2.0, volumescale[1] / 2.0, volumescale[2] / 2.0};

  const float extents[6] = {
	  -vtemp[0] + volumescale[0] * (min[0] - 1.0) / (box[3] - 2.0), 
	  -vtemp[1] + volumescale[1] * (min[1] - 1.0) / (box[4] - 2.0),
	  0 + volumescale[2] * (min[2] - 1.0) / (box[5] - 2.0),
	  -vtemp[0] + volumescale[0] * (max[0] - 1.0) / (box[3] - 2.0), 
	  -vtemp[1] + volumescale[1] * (max[1] - 1.0) / (box[4] - 2.0),
	  0 + volumescale[2] * (max[2] - 1.0) / (box[5] - 2.0)};//���ƿ��С

  _dmin.x = extents[0]; 
  _dmin.y = extents[1]; 
  _dmin.z = extents[2]; 
  _dmax.x = extents[3]; 
  _dmax.y = extents[4]; 
  _dmax.z = extents[5]; 

  _center.x = _dmin.x + (_dmax.x - _dmin.x) / 2.0;
  _center.y = _dmin.y + (_dmax.y - _dmin.y) / 2.0;
  _center.z = _dmin.z + (_dmax.z - _dmin.z) / 2.0;
}

//----------------------------------------------------------------------------
// Set the extents of the brick's roi from the voxel coordinates.
//----------------------------------------------------------------------------
void TextureBrick::setROI(int level, const int box[6], const int roi[6], double volumescale[3])
{
  size_t min[3] = {roi[0]+box[0], roi[1]+box[1], roi[2]+box[2]};
  size_t max[3] = {roi[3]+box[0], roi[4]+box[1], roi[5]+box[2]};

  double vtemp[3] = {volumescale[0] / 2.0, volumescale[1] / 2.0, volumescale[2] / 2.0};

  const float extents[6] = {
	  -vtemp[0] + volumescale[0] * (min[0] - 1.0) / (box[3] - 3.0), 
	  -vtemp[1] + volumescale[1] * (min[1] - 1.0) / (box[4] - 3.0),
	  0 + volumescale[2] * (min[2] - 1.0) / (box[5] - 3.0),
	  -vtemp[0] + volumescale[0] * (max[0] - 1.0) / (box[3] - 3.0), 
	  -vtemp[1] + volumescale[1] * (max[1] - 1.0) / (box[4] - 3.0),
	  0 + volumescale[2] * (max[2] - 1.0) / (box[5] - 3.0)};//���ƿ��С

  _vmin.x = extents[0]; 
  _vmin.y = extents[1]; 
  _vmin.z = extents[2]; 
  _vmax.x = extents[3]; 
  _vmax.y = extents[4]; 
  _vmax.z = extents[5]; 
}


//----------------------------------------------------------------------------
// Set the minimum extent of the brick's roi
//----------------------------------------------------------------------------
void TextureBrick::volumeMin(float x, float y, float z) 
{ 
  _vmin.x = x; 
  _vmin.y = y; 
  _vmin.z = z; 
}

//----------------------------------------------------------------------------
// Set the maximum extent of the brick's roi
//----------------------------------------------------------------------------
void TextureBrick::volumeMax(float x, float y, float z) 
{ 
  _vmax.x = x; 
  _vmax.y = y; 
  _vmax.z = z; 
}

//----------------------------------------------------------------------------
// Set the brick's minimum texture coordinate
//----------------------------------------------------------------------------
void TextureBrick::textureMin(float x, float y, float z) 
{ 
  _tmin.x = x; 
  _tmin.y = y; 
  _tmin.z = z; 
}

//----------------------------------------------------------------------------
// Set the brick's maximum texture coordinate
//----------------------------------------------------------------------------
void TextureBrick::textureMax(float x, float y, float z) 
{ 
  _tmax.x = x; 
  _tmax.y = y; 
  _tmax.z = z; 
}

//----------------------------------------------------------------------------
// Invalidate the brick. An invalid brick will be ignored by the renderer.
//----------------------------------------------------------------------------
void TextureBrick::invalidate()
{
  _nx = 0;
  _ny = 0;
  _nz = 0;
  _dmin = vec3f(0,0,0);
  _dmax = vec3f(0,0,0);
  _vmin = vec3f(0,0,0);
  _vmax = vec3f(0,0,0);
  _tmin = vec3f(0,0,0);
  _tmax = vec3f(0,0,0);
  _data = NULL;
}

//----------------------------------------------------------------------------
// Determine if this brick is valid.
//----------------------------------------------------------------------------
bool TextureBrick::valid() const
{
  return (_tmax.x > _tmin.x && _tmax.y > _tmin.y && _tmax.z > _tmin.z);
}


//----------------------------------------------------------------------------
// Load data into the texture object
//----------------------------------------------------------------------------
void TextureBrick::load()
{

  glBindTexture(GL_TEXTURE_3D, _texid);

// 
// If we "own" the data, it's stored in texture bricks that are
// guaranteed to be powers-of-two (dimensioned by _nx,_ny,_nz). 
// Similary true, if we don't own the data but the data dimensions match
// the "next power of two dimensions" (_nx,_ny, _nz).  N.B. In the
// former case, the bricks need only be partially filled with valid data.
//
// else, the data volume pointed to by _data are now a power-of-two
// and will need to be download as a subimage.
//
  bool gl_tex_sub_image_broken = false;

  if (gl_tex_sub_image_broken) {
      glTexImage3D(GL_TEXTURE_3D, 0, _internalFormat,
                 _nx, _ny, _nz, 0, _format, _type, _data);
  } 
  else { 
    if (_haveOwnership || (_dnx==_nx && _dny==_ny) && (_dnz==_nz)) {
      glTexImage3D(GL_TEXTURE_3D, 0, _internalFormat,
                 _nx, _ny, _nz, 0, _format, _type, _data);

    }
    else
    {
      glTexImage3D(GL_TEXTURE_3D, 0, _internalFormat,
                 _nx, _ny, _nz, 0, _format, _type, NULL);

      glTexSubImage3D(GL_TEXTURE_3D, 0, 0, 0, 0,
                    _dnx, _dny, _dnz, _format, _type, _data);
    }
  }
}

//----------------------------------------------------------------------------
// Reload data into the texture object.
//----------------------------------------------------------------------------
void TextureBrick::reload()
{
	if(!_data) return;
  glBindTexture(GL_TEXTURE_3D, _texid);

  bool gl_tex_sub_image_broken = false;

  if (gl_tex_sub_image_broken) {
      glTexImage3D(GL_TEXTURE_3D, 0, _internalFormat,
                 _nx, _ny, _nz, 0, _format, _type, _data);
  } 
  else {
	if (_haveOwnership || (_dnx==_nx && _dny==_ny) && (_dnz==_nz)) {
      glTexSubImage3D(GL_TEXTURE_3D, 0, 0, 0, 0, _nx, _ny, _nz, 
                    _format, _type, _data);
    }
    else
    {
      glTexSubImage3D(GL_TEXTURE_3D, 0, 0, 0, 0, _dnx, _dny, _dnz, 
                    _format, _type, _data);
    }
  }
}


//----------------------------------------------------------------------------
// Fill the texture brick. This method is used to deep copy a subset of the 
// data into the brick. (Used when bricking a volume).
//----------------------------------------------------------------------------
void TextureBrick::fill(GLubyte *data, 
                        int bx, int by, int bz,
                        int nx, int ny, int nz, 
                        int xoffset, int yoffset, int zoffset)
{ 

  _nx = bx;
  _ny = by;
  _nz = bz;

  _dnx = nx;
  _dny = ny;
  _dnz = nz;

  _xoffset = xoffset;
  _yoffset = yoffset;
  _zoffset = zoffset;

  if (_haveOwnership)
  {
    delete [] _data;
  }

  _haveOwnership = true;
  _data = new GLubyte[_nx*_ny*_nz*_size];
  assert(_data != NULL);

  //
  // Copy over the data
  //
  for (int z=0; z<bz && z+zoffset<=_dnz; z++)
  {
    for (int y=0; y<by && y+yoffset<=_dny; y++)
    {
      int di = (xoffset*_size +
                MIN(y+yoffset, _dny-1)*_dnx*_size + 
                MIN(z+zoffset, _dnz-1)*_dnx*_dny*_size);

      int ti = y*_nx*_size + z*_nx*_ny*_size;

      memcpy(&_data[ti], &data[di], MIN(bx, _dnx-_xoffset)*_size);
    }
  }
}

//----------------------------------------------------------------------------
// Points the brick to a contigous block of memory. Used when a volume will
// fit wholly into graphics memory, and bricking is not needed (i.e., there
// is only one brick, this one). 
//----------------------------------------------------------------------------
void TextureBrick::fill(GLubyte *data, int nx, int ny, int nz)
{ 
  _dnx = nx;
  _dny = ny;
  _dnz = nz;

  bool gl_tex_sub_image_broken = false;

  if (gl_tex_sub_image_broken) {
      _nx = nx;
      _ny = ny;
      _nz = nz;
	}
  else  {
    _nx = nextPowerOf2(nx);
    _ny = nextPowerOf2(ny);
    _nz = nextPowerOf2(nz);
  }

  _xoffset = 0;
  _yoffset = 0;
  _zoffset = 0;

  if (_haveOwnership)
  {
    delete [] _data;
  }

  _haveOwnership = false;
  _data = data;
}

//----------------------------------------------------------------------------
// Update the brick's data.
//----------------------------------------------------------------------------
void TextureBrick::refill(GLubyte *data)
{ 
  if (_haveOwnership)
  {
    //
    // Copy over the data
    //
    for (int z=0; z<_nz && z+_zoffset<=_dnz; z++)
    {
      for (int y=0; y<_ny && y+_yoffset<=_dny; y++)
      {
        int di = (_xoffset*_size +
                  MIN(y+_yoffset, _dny-1)*_dnx*_size + 
                  MIN(z+_zoffset, _dnz-1)*_dnx*_dny*_size);
        
        int ti = y*_nx*_size + z*_nx*_ny*_size;
        
        memcpy(&_data[ti], &data[di], MIN(_nx, _dnx-_xoffset)*_size);
      }
    }
  }
  else
  {
    _data = data;
  }

  reload();
}

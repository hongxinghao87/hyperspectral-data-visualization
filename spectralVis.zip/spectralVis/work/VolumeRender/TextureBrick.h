#pragma once

#include "glew.h"
#include <GL/gl.h>
#include <GL/glu.h>
#include <iostream>

#include "BBox.h"

namespace VolumeRender
{

class TextureBrick
{
 public:
   
  TextureBrick(GLint internalFormat, GLenum format, GLenum type);
  virtual ~TextureBrick();

  void bind() const     { glBindTexture(GL_TEXTURE_3D, _texid); }
  GLuint handle() const { return _texid; }

  void size(int nx, int ny, int nz) { _nx=nx; _ny=ny; _nz=nz; }

  int nx() const { return _nx; }
  int ny() const { return _ny; }
  int nz() const { return _nz; }

  void* data() { return _data; }

  void load();
  void reload();

  void fill(GLubyte *data, 
            int bx, int by, int bz,
            int nx, int ny, int nz,
            int xoffset=0, int yoffset=0, int zoffset=0);

  void fill(GLubyte *data, int nx, int ny, int nz);

  void refill(GLubyte *data);


  //
  // Accessors for the brick's data block extents
  //
  BBox dataBox() const    { return BBox(_dmin, _dmax); }

  vec3f dataMin() const { return _dmin; }
  vec3f dataMax() const { return _dmax; }

  void dataMin(float x, float y, float z);
  void dataMax(float x, float y, float z);

  void setDataBlock(int level, const int box[6], const int block[6], double vscale[3]);

  //
  // Accessors for the brick's region of interest extents
  //
  BBox volumeBox() const  { return BBox(_vmin, _vmax); }

  vec3f volumeMin() const { return _vmin; }
  vec3f volumeMax() const { return _vmax; }

  void volumeMin(float x, float y, float z);
  void volumeMax(float x, float y, float z);

  void setROI(int level, const int box[6], const int roi[6], double vscale[3]);

  //
  // Accessor for the brick's texture coordinates
  //
  BBox textureBox() const { return BBox(_tmin, _tmax); }

  vec3f textureMin() const { return _tmin; }
  vec3f textureMax() const { return _tmax; }

  void textureMin(float x, float y, float z); 
  void textureMax(float x, float y, float z); 

  //
  // Brick's center. Used for sorting. 
  //
  vec3f center() const { return _center; }
  void    center(const vec3f &center) { _center = center; }

  void invalidate();
  bool valid() const;

  //
  // Friend functions
  //
  friend std::ostream &operator<<(std::ostream &o, const TextureBrick &b)
  {
    o << "Brick " << b.handle() << std::endl
      << " " << b.nx() << "x" << b.ny() << "x" << b.nz() << std::endl
      << " data extents " << b.dataMin() 
      << "              " << b.dataMax()
      << " roi extents  " << b.volumeMin()
      << "              " << b.volumeMax()
      << " tex extents  " << b.textureMin()
      << "              " << b.textureMax()
      << " center       " << b.center() << std::endl;
    
    return o;
  }

 protected:

  // Brick size (power-of-2)
  int _nx;
  int _ny;
  int _nz;

  // Brick's voxel offset into data
  int _xoffset;
  int _yoffset;
  int _zoffset;

  // Brick center
  vec3f _center;

  // data extents
  vec3f _dmin;
  vec3f _dmax;

  // visible volume extents
  vec3f _vmin;
  vec3f _vmax;

  // Texture extents
  vec3f _tmin;
  vec3f _tmax;

  // GL texture handle
  GLuint _texid;

  // Texture internal data format
  GLenum _internalFormat;

  // Texture data format
  GLenum _format;

  // Texture data type
  GLenum _type;

  // size of texel in bytes;
  int _size;

  // Data
  GLubyte *_data;
  bool     _haveOwnership;

  // Data size (maybe non-power-2 < brick size)
  int _dnx;
  int _dny;
  int _dnz;

};

}

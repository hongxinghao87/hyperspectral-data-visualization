// ElecEquipments.cpp: implementation of the CElecEquipments class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "ElecEquipments.h"
#include "MainFrm.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CElecEquipments::CElecEquipments()
{
	m_bPickPoint = false;
	m_pGeoLayer = NULL;
	m_vecPickPoint = vec3d(0,0,0);
	//for (int i = 0;i<MAX_ET_NUM;i++)
	//{
	//	m_pFltModels[i] = NULL;
	//}
	bstart = false;
	bend   = false;
	m_pData = NULL;
	m_bFirstRender = true;
	m_ChosingEle = NULL;
}

CElecEquipments::~CElecEquipments()
{
	int i;
	//for (i = 0;i<MAX_ET_NUM;i++)
	//{
	//	if (m_pFltModels[i] != NULL)
	//	{
	//		m_pFltModels[i]->ReleaseModel();
	//	}
	//}

}
void CElecEquipments::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if(!m_ChosingEle)
		return;
	switch(nChar)
	{
	case VK_UP:
		m_ChosingEle->Pos.z -= 1;
		break;
	case VK_DOWN:
		m_ChosingEle->Pos.z += 1;
		break;
	case VK_LEFT:
		m_ChosingEle->Pos.x -= 1;
		break;
	case VK_RIGHT:
		m_ChosingEle->Pos.x += 1;
		break;
	default:
		break;
	}
}
void CElecEquipments::ReadEleData(CString strPath)
{
	CStdioFile InitFile;
	int nFrames = 1;
	int FrameIndex = 0;
	int i,j,k;
	CString strInfo;
	CStringArray sDataArray;
	if(InitFile.Open(strPath,CFile::modeRead))
	{

		InitFile.ReadString(strInfo);
		InitFile.ReadString(strInfo);

		InitFile.ReadString(strInfo);
		sDataArray.RemoveAll();
		Separate(strInfo,sDataArray,":");
		strInfo = sDataArray.GetAt(1);
		sDataArray.RemoveAll();
		Separate(strInfo,sDataArray," ");
		m_nX = atoi(sDataArray.GetAt(0));
		m_nY = atoi(sDataArray.GetAt(1));
		m_nZ = atoi(sDataArray.GetAt(2));

		InitFile.ReadString(strInfo);
		InitFile.ReadString(strInfo);


		double dtemp;
		for (k=0;k<m_nZ;k++)
		{
			for (i=0;i<m_nY;i++)
			{
				InitFile.ReadString(strInfo);
				sDataArray.RemoveAll();
				Separate(strInfo,sDataArray," ");
				for (j=0;j<m_nX;j++)
				{
					m_pData[k*m_nX*m_nY + i*m_nX + j] = atof(sDataArray.GetAt(j));
				}

			}
		}
	}
}
bool CElecEquipments::Separate(const CString tParam, CStringArray& sAParam, CString strToken)
{
	//�������ֿ�,��tParam����strToken�ָ�
	
	int tStart = 0;
	int tEnd = 0; 
	if (tParam.IsEmpty()) 
	{
		return(false);
	}
	int i = 0;           //���ֲ����ĸ���
	int j = 0;           //����λ��
	int flag = false;    //����Ƿ����
	sAParam.RemoveAll();
	while (!flag) 
	{
		tEnd = tParam.Find((LPCTSTR)strToken, tStart);
		if (tEnd < 0) 
		{
			//�������Ĳ���
			tEnd = tParam.GetLength();
			flag = true;
		}
		sAParam.Add(_T(""));   //����һ���յ��ַ���
		if(tStart == tEnd)
		{
			tStart = tEnd + 1;  //������ǰ�ķָ��
			continue;
		}
		for(j = tStart; j < tEnd; j++)
		{
			sAParam[i] += tParam[j];  //�ҵ���i������
		}
		CString temp = sAParam[i];
		
		//����һ������
		tStart = tEnd + 1;  //������ǰ�ķָ��
		
		i++;
	}
	return(true);
}

void CElecEquipments::CalculateEleArea()
{
	vec3d curVec;
	int i,j,k,m;
	double dXStep,dYStep,dZStep;
	dXStep = (m_vecRTPos[0] - m_vecLBPos[0])/(m_nX-1);
	dYStep = (m_vecRTPos[1] - m_vecLBPos[1])/(m_nY-1);
	dZStep = (m_vecRTPos[2] - m_vecLBPos[2])/(m_nZ-1);
	int nFrames = 1;
	FILE *fp = fopen("hyperdata.hyp", "w+");
	
	if(fp)
	{
		fprintf(fp,"Version:EleData V1.0\n");
		fprintf(fp,"Range:%f %f %f %f %f %f\n"
			,m_pGeoLayer->dEast
			,m_pGeoLayer->dWest
			,m_pGeoLayer->dSouth
			,m_pGeoLayer->dNorth
			,m_pGeoLayer->m_dMinElv
			,m_pGeoLayer->m_dMinElv + (m_pGeoLayer->m_dMaxElv - m_pGeoLayer->m_dMinElv)*2000);
		fprintf(fp,"hits:%d %d %d\n",m_nX,m_nY,m_nZ);
		fprintf(fp,"Frames:%d\n",nFrames);
		fprintf(fp,"FrameIndex:%d\n",0);
	}
	double dMinValue = 10000000;
	double dMaxValue = -10000000;
	for (k=0;k<m_nZ;k++)
	{
		for (i=0;i<m_nY;i++)
		{
			for (j=0;j<m_nX;j++)
			{
				curVec[0] = m_vecLBPos[0] + dXStep*j;
				curVec[1] = m_vecLBPos[1] + dYStep*i;
				curVec[2] = m_vecLBPos[2] + dZStep*k;
				
				double dPower = 0;
				for (m=0;m<m_arrElectricETS.GetSize();m++)
				{

					double dis = (curVec-m_arrElectricETS[m]->Pos).length();
					int nNum = dis;
					double *Elev = new double[nNum + 2];
					vec3d vecstep = (m_arrElectricETS[m]->Pos - curVec)/(nNum-1);
					for (int t = 0;t<nNum;t++)
					{
						vec3d tempvec;
						tempvec = curVec + t*vecstep;
						if (m_pGeoLayer->GetElv(tempvec.x,tempvec.z,tempvec.y))
						{
							Elev[t+2] = tempvec.y;
						}
						if (t==0)
						{
							Elev[t+2] = curVec[1]/m_dH_Scale;
						}
					}
					vecstep.y = 0;
					double dDis = vecstep.length()/m_pGeoLayer->scale;//EARTH_RADIUS*
					Elev[0] = nNum - 1;
					Elev[1] = dDis;
					double dbloss;
					int nModel;
					double deltaH;
					int nErr; 
					m_ppModel.point_to_pointMDH(Elev,1, 1,15, 0.005,320,m_arrElectricETS[m]->dFrequencyTop,2,0,0.3,0.5,0.8,dbloss,nModel,deltaH,nErr);
					delete []Elev;		
					
					vec3d curReal;
					curReal[0] = curVec[0]/m_dScale;
					curReal[1] = curVec[1]/m_dH_Scale;
					curReal[2] = curVec[2]/m_dScale;
					vec3d elePos = m_arrElectricETS[m]->Pos;
					elePos[0] /= m_dScale;
					elePos[1] /= m_dH_Scale;
					elePos[2] /= m_dScale;

					double dr = (elePos - curReal).length();
					double dCurPower;
					dCurPower = m_arrElectricETS[m]->dPower/(4*PI*dr*dr);
					double dPlus = m_arrElectricETS[m]->dAntennaPlus - dbloss;
					dCurPower = dCurPower*(pow(10,(dPlus/10)));
					dPower += dCurPower;
				}
				m_pData[k*m_nX*m_nY + i*m_nX + j] = 10*log(dPower/1.0);
				fprintf(fp,"%f ",m_pData[k*m_nX*m_nY + i*m_nX + j]);
				if (m_pData[k*m_nX*m_nY + i*m_nX + j] > dMaxValue)
				{
					dMaxValue = m_pData[k*m_nX*m_nY + i*m_nX + j];
				}
				if (m_pData[k*m_nX*m_nY + i*m_nX + j] < dMinValue)
				{
					dMinValue = m_pData[k*m_nX*m_nY + i*m_nX + j];
				}
			}
			fprintf(fp,"\n");
		}
	}
	if(fp)
		fclose(fp);

	//-test-����equizer-������------------------
	BYTE *data = new BYTE[4*m_nZ*m_nY*m_nX];
	for (k=0;k<m_nZ;k++)
	{
		for (i=0;i<m_nY;i++)
		{
			for (j=0;j<m_nX;j++)
			{
				int curIndex = k*m_nX*m_nY + i*m_nX + j;
				data[curIndex*4] = (BYTE)255*(m_pData[k*m_nX*m_nY + i*m_nX + j]-dMinValue)/(dMaxValue - dMinValue);
				data[curIndex*4+1] = 255;
				data[curIndex*4+2] = 255;
				data[curIndex*4+3] = 255;
			}
		}
	}
	fp = fopen("Sanfrancisco.raw", "w+");
	
	if(fp)
	{
		fwrite(data,sizeof(BYTE),m_nZ*m_nY*m_nX,fp);
		fclose(fp);
	}
	delete data;
}
void CElecEquipments::SetVolumeBox(vec3d vecLBPos,vec3d vecRTPos,double dScale,double dH_Scale,int nx,int ny,int nz)
{
	m_vecLBPos = vecLBPos;
	m_vecRTPos = vecRTPos;
	m_dScale = dScale;
	m_dH_Scale = dH_Scale;
	m_nX = nx;
	m_nY = ny;
	m_nZ = nz;
	m_pData = new double[m_nX*m_nY*m_nZ];
}
double* CElecEquipments::GetVolumeData()
{
	return m_pData;
}
void CElecEquipments::InitLize()
{
	CString str;
	GetModuleFileName(NULL,str.GetBuffer(1024),1024);
	str.ReleaseBuffer();
	int nPos = str.ReverseFind('\\');
	str.Delete(nPos+1,str.GetLength()-nPos-1);
	//m_pFltModels[ET_Radar] = CreatOneFLtMode(str + "data\\Models\\��ͨ�״�\\��ͨ�״�.flt");
	//m_pFltModels[ET_Mobile_Base] = CreatOneFLtMode(str + "data\\Models\\ͨ�Ż�վ\\��վ.flt");
	

	ElectricET *pNewET = new ElectricET;
	vec3d pos = vec3d(23,2.2,-2.95);
	m_pGeoLayer->GetElv(pos.x,pos.z,pos.y);
	pos.y = pos.y*m_pGeoLayer->h_scale;
	pNewET->Pos = pos;
	pNewET->dPower = 500;
	pNewET->dFrequencyBottom = 50;
	pNewET->dFrequencyTop = 200;
	pNewET->dAntennaPlus = 20;
	pNewET->nType = ET_Radar;
	pNewET->strName = "��Ƶ�豸1";
	pNewET->nID = 0;
	m_arrElectricETS.Add(pNewET);
	CMainFrame* pMainFrame = (CMainFrame*) AfxGetMainWnd ();

	
	pNewET = new ElectricET;
	pos = vec3d(-22.92,0,23.84);
	m_pGeoLayer->GetElv(pos.x,pos.z,pos.y);
	pos.y = pos.y*m_pGeoLayer->h_scale;
	pNewET->Pos = pos;
	pNewET->dPower = 500;
	pNewET->dFrequencyBottom = 50;
	pNewET->dFrequencyTop = 200;
	pNewET->dAntennaPlus = 20;
	pNewET->nType = ET_Radar;
	pNewET->strName = "��Ƶ�豸2";
	pNewET->nID = 0;
	m_arrElectricETS.Add(pNewET);
}

void CElecEquipments::DrawPickPoint()
{
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glPointSize(2);
	glScalef(1,m_pGeoLayer->m_dHighScale,1);
	glColor3f(1,0,0);
	glBegin(GL_POINTS);
	glVertex3f(m_vecPickPoint.x,m_vecPickPoint.y - m_pGeoLayer->m_dMinElv*m_pGeoLayer->h_scale,m_vecPickPoint.z);
	glEnd();
	if (bstart&&bend)
	{
		glBegin(GL_LINES);
		glVertex3f(vecstart.x,vecstart.y - m_pGeoLayer->m_dMinElv*m_pGeoLayer->h_scale,vecstart.z);
		glVertex3f(vecend.x,vecend.y - m_pGeoLayer->m_dMinElv*m_pGeoLayer->h_scale,vecend.z);
		glEnd();
	}
	glPopAttrib();
	glPopMatrix();

}
void CElecEquipments::Render()
{
	if (m_bPickPoint)
	{
		DrawPickPoint();
	}
	//DrawModels();
	if (m_bFirstRender)
	{
		CMainFrame* pMainFrame = (CMainFrame*) AfxGetMainWnd ();
		if (pMainFrame)
		{
			for (int i = 0;i<m_arrElectricETS.GetSize();i++)
			{
				pMainFrame->GetWorkspaceBar()->GetTreeList()->InsertItem(m_arrElectricETS[i]->strName,1,1,pMainFrame->GetWorkspaceBar()->m_hRoot);
			}
			
		}
		pMainFrame->GetWorkspaceBar()->GetTreeList()->Expand(pMainFrame->GetWorkspaceBar()->m_hRoot,TVE_TOGGLE);
		m_bFirstRender = false;
	}
}
//void CElecEquipments::DrawModels()
//{
//	glPushMatrix();
//	glPushAttrib(GL_ALL_ATTRIB_BITS);
//	for (int i = 0;i<m_arrElectricETS.GetSize();i++)
//	{
//		if (m_pFltModels[m_arrElectricETS[i]->nType])
//		{
//			glPushMatrix();
//			glScalef(1,m_pGeoLayer->m_dHighScale,1);
//			glTranslated(m_arrElectricETS[i]->Pos.x,m_arrElectricETS[i]->Pos.y - m_pGeoLayer->m_dMinElv*m_pGeoLayer->h_scale,m_arrElectricETS[i]->Pos.z);
//// 			glBegin(GL_LINES);
//// 			glVertex3f(0,0,0);
//// 			glVertex3f(0,20,0);
//// 			glEnd();
//			glScalef(m_arrElectricETS[i]->dScaleSize,m_arrElectricETS[i]->dScaleSize,m_arrElectricETS[i]->dScaleSize);
//			glRotated(-90,1,0,0);
//			double dAzim = (m_arrElectricETS[i]->dMaxAzim + m_arrElectricETS[i]->dMinAzim)/2;
//			glRotated(-dAzim,0,0,1);
//			glScalef(10,10,10);
//			m_pFltModels[m_arrElectricETS[i]->nType]->RenderModel();
//			glPopMatrix();
//		}
//		
//	}
//	glPopAttrib();
//	glPopMatrix();
//
//}
void CElecEquipments::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_bPickPoint&&m_pGeoLayer)
	{
		m_pGeoLayer->PickPoint(point,m_vecPickPoint);
// 		CString strInfo;
// 		strInfo.Format("x:%f,y:%f,z:%f,cos:%f",m_vecPickPoint[0],m_vecPickPoint[1],m_vecPickPoint[2],cos(37.7*PI/180));
// 		AfxMessageBox(strInfo);
		if (!bstart)
		{
			vecstart = m_vecPickPoint;
			bstart = true;
		}else if (!bend)
		{
			vecend = m_vecPickPoint;
			bend = true;
			CalculateElec(vecstart,1);
		}else
		{

		}
	}
}
void CElecEquipments::OnRButtonDown(UINT nFlags, CPoint point)
{
	if (bstart&&bend&&m_bPickPoint)
	{
		bstart = false;
		bend = false;
	}
}
void CElecEquipments::SetGeoLayer(CGeoLayer *pGeoLayer)
{
	m_pGeoLayer = pGeoLayer;
}
//CFltRender *CElecEquipments::CreatOneFLtMode(CString strFilePath)
//{
//	CFltRender *pNewModel = new CFltRender();
//	pNewModel->LoadModel(strFilePath.GetBuffer(strFilePath.GetLength()),0);
//	return pNewModel;
//}
double CElecEquipments::CalculateElec(vec3d pos,double dFrequency)
{
	double dis = (vecend-vecstart).length();
	int nNum = dis*10;
	double *Elev = new double[nNum + 2];
	vec3d vecstep = (vecend-vecstart)/(nNum-1);
	for (int i = 0;i<nNum;i++)
	{
		vec3d tempvec;
		tempvec = vecstart + i*vecstep;
		if (m_pGeoLayer->GetElv(tempvec.x,tempvec.z,tempvec.y))
		{
			Elev[i+2] = tempvec.y;
		}
	}
	vecstep.y = 0;
	double dDis = vecstep.length()/m_pGeoLayer->scale;//EARTH_RADIUS*
	Elev[0] = nNum - 1;
	Elev[1] = dDis;
	double dbloss;
	int nModel;
	double deltaH;
	int nErr; 
	m_ppModel.point_to_pointMDH(Elev,1, 1,15, 0.005,320,50,2,0,0.3,0.5,0.8,dbloss,nModel,deltaH,nErr);
	delete []Elev;
	CString strInfo;
	strInfo.Format("��ֵ����:%d;˥��:%.2f;deltaH:%.2f;nModel:%d:nErr:%d",nNum,dbloss,deltaH,nModel,nErr);
	AfxMessageBox(strInfo);
	return 0;
}
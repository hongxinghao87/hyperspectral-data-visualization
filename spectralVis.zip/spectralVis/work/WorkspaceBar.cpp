// WorkspaceBar.cpp : implementation of the CWorkspaceBar class
//

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "WorkspaceBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int nBorderSize = 1;

/////////////////////////////////////////////////////////////////////////////
// CWorkspaceBar

BEGIN_MESSAGE_MAP(CWorkspaceBar, CBCGPDockingControlBar)
	//{{AFX_MSG_MAP(CWorkspaceBar)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
static UINT treeIcons[] =
{
	IDI_UNCHECK			,
	IDI_CHECK		,
};

/////////////////////////////////////////////////////////////////////////////
// CWorkspaceBar construction/destruction

CWorkspaceBar::CWorkspaceBar()
{
	// TODO: add one-time construction code here

}

CWorkspaceBar::~CWorkspaceBar()
{
}

/////////////////////////////////////////////////////////////////////////////
// CWorkspaceBar message handlers

int CWorkspaceBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CBCGPDockingControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CRect rectDummy;
	rectDummy.SetRectEmpty ();

	// Create tree windows.
	// TODO: create your own tab windows here:
	const DWORD dwViewStyle =	WS_CHILD | WS_VISIBLE | TVS_HASLINES | 
								TVS_LINESATROOT | TVS_HASBUTTONS;
	
	if (!m_wndTree.Create (dwViewStyle, rectDummy, this, 1))
	{
		TRACE0("Failed to create workspace view\n");
		return -1;      // fail to create
	}
	m_imgList.Create(16, 16, ILC_MASK|ILC_COLOR32, 1, 1);

	for (int i  = 0; i < 2; i++)
	{
		HICON hIcon = AfxGetApp()->LoadIcon(treeIcons[i]);
		ASSERT(hIcon);
		m_imgList.Add (hIcon);
	}
 	m_wndTree.SetImageList(&m_imgList,TVSIL_NORMAL);

	// Setup trees content:
	m_hRoot = m_wndTree.InsertItem (_T("��Ƶ�豸"),1,1);
	return 0;
}

void CWorkspaceBar::OnSize(UINT nType, int cx, int cy) 
{
	CBCGPDockingControlBar::OnSize(nType, cx, cy);

	// Tab control should cover a whole client area:
	m_wndTree.SetWindowPos (NULL, nBorderSize, nBorderSize, 
		cx - 2 * nBorderSize, cy - 2 * nBorderSize,
		SWP_NOACTIVATE | SWP_NOZORDER);
}

void CWorkspaceBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rectTree;
	m_wndTree.GetWindowRect (rectTree);
	ScreenToClient (rectTree);

	rectTree.InflateRect (nBorderSize, nBorderSize);
	dc.Draw3dRect (rectTree,	::GetSysColor (COLOR_3DSHADOW), 
								::GetSysColor (COLOR_3DSHADOW));
}

BOOL CWorkspaceBar::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->hwnd == ((CWnd*)&m_wndTree)->m_hWnd)
	{
		if(pMsg->message==WM_LBUTTONDOWN)
		{
			CPoint point;
			UINT pflags;	
			point=pMsg->pt;
			CString temp;
			m_wndTree.ScreenToClient(&point);
			HTREEITEM hitItem = m_wndTree.HitTest(point,&pflags);
			int nImage,nSelectedImage;
			
			
			if (hitItem)
			{
				CString str = m_wndTree.GetItemText(hitItem);
				if ( pflags & (TVHT_ONITEMICON))
				{
					m_wndTree.GetItemImage(hitItem, nImage, nSelectedImage);
					if(nImage==0)
					{
						m_wndTree.SetItemImage(hitItem,1,1);
						CString strParName = "";
						HTREEITEM hParItem = m_wndTree.GetParentItem(hitItem);
						if (hParItem)
						{
							strParName = m_wndTree.GetItemText(hParItem);
							m_wndTree.SetItemImage(hParItem,1,1);
						}
					}else
					{
						m_wndTree.SetItemImage(hitItem,0,0);
						HTREEITEM hChildItem = m_wndTree.GetChildItem(hitItem);
						while (hChildItem)
						{
							m_wndTree.SetItemImage(hChildItem,0,0);
							hChildItem = m_wndTree.GetNextItem(hChildItem,TVGN_NEXT);
						}
					}
				}else
				{
					for (int i = 0;i<theApp.pView->m_pET->m_arrElectricETS.GetSize();i++)
					{
						if (str == theApp.pView->m_pET->m_arrElectricETS[i]->strName)
						{
							theApp.pView->m_pET->m_ChosingEle = theApp.pView->m_pET->m_arrElectricETS[i];
						}
					}
				}
			}
		}
	}
	return CBCGPDockingControlBar::PreTranslateMessage(pMsg);
}
CTreeCtrl *CWorkspaceBar::GetTreeList()
{
	return &m_wndTree;
}
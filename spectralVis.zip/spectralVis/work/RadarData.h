// RadarData.h: interface for the CRadarData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RADARDATA_H__78480A61_329C_459B_A71A_92BC67A59CE5__INCLUDED_)
#define AFX_RADARDATA_H__78480A61_329C_459B_A71A_92BC67A59CE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRadarData  
{
public:
	CRadarData();
	virtual ~CRadarData();
	bool Separate(const CString tParam, CStringArray& sAParam, CString strToken);
	void LoadRadarData(CString strpath);
	void Init(int nX,int nY,int nZ);
	double LossToProba(double dLoss);
	void DrawRadarFace();
	void GetColor(double dProb,double &r,double &g,double &b);
	void CalculateVolumeData();
	double *GetVolumeData();
	void LoadVolumData(CString strpath);
	double *m_pVolumData;
public:
	double dMinHigh,dMaxHigh,dMinRange,dMaxRange;
	double dRadarX,dRadarZ;
	double dRadarHigh,dRadarRange;
	double dRadarX1,dRadarZ1;
	double dRadarHigh1,dRadarRange1;
	double dRadarX2,dRadarZ2;
	double dRadarHigh2,dRadarRange2;
	int nXNum,nYNum;
	double dProba[100];
	double **m_dRadarData;
	int m_nX,m_nY,m_nZ;
	double *m_pData;
};

#endif // !defined(AFX_RADARDATA_H__78480A61_329C_459B_A71A_92BC67A59CE5__INCLUDED_)

#if !defined(AFX_DLGDOCKBAR_H__F19609DA_241D_4F29_80F7_089B5A380DEC__INCLUDED_)
#define AFX_DLGDOCKBAR_H__F19609DA_241D_4F29_80F7_089B5A380DEC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgDockBar.h : header file
//
#include "VolumeRender.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgDockBar dialog
#define COLORBAR_TO_BOTTOM 40
#define COLORBAR_HIGH 10
#define COLORBAR_TO_LEFT 5
#define COLORBAR_TO_RIGHT 5
#define HIST_TO_TOP 10
#define HIST_TO_BOTTOM 5
#define STAFF_TO_COLORBAR 10
class CHisAlpha
{
public:
	bool m_bAlphaSel;
	float m_fMidPos;
	float m_fAlpha;
	float m_fWidth;
	CHisAlpha()
	{
		m_bAlphaSel = false;
		m_fMidPos   = 0.1;
		m_fAlpha    = 0.5;
		m_fWidth    = 0.02;
	}
};
class CDlgDockBar : public CBCGPDialogBar
{
public:
	CVolumeRender *m_pVolumeRender;
	CWnd *m_pControlWnd;
	CRect m_ControlRect;
	int   m_nselIndex;
	int   m_nselAlpha;
	int   m_nSelHisAlpha;
	CPalette	m_palSys;
	CArray<CAlphaPoint,CAlphaPoint> m_arrLineAlphaPoints;
	CArray<CHisAlpha,CHisAlpha> m_arrHistAlphaPoints;
	bool  m_bHistAlpha;
	bool  m_bInitlize;
public:
	void SetVolumeRenderLay(CVolumeRender *pVolumeRender);
// Construction
public:
	CDlgDockBar(CWnd* pParent = NULL);   // standard constructor
	void DrawControlArea(CDC *pDC);
	bool SelectColorPoint(double dx);
	bool SelectAlphaPoint(double dx,double dy);
	bool InsertColorPoint(double dx);
	bool InsertAlphaPoint(double dx,double dy);
	bool InsertAlphaHist(double dx,double dy);
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	void Initlize();
	bool SelectHistAlphaPoint(CPoint pt,CHisAlpha HisAlphaPt);
	void ResetHistAlpha();
// Dialog Data
	//{{AFX_DATA(CDlgDockBar)
	enum { IDD = IDD_DLG_DVRCONTROL };
	CComboBox	m_AlphaComb;
	CBCGPColorPickerCtrl m_wndColorSlide;
	CBCGPColorPickerCtrl m_wndColorPalette;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgDockBar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgDockBar)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnColorPick();
	afx_msg void OnColorSlide();
	afx_msg void OnSelchangeAlphaCombo();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	// ѡ�������ȷ����ť���Ʊ���
	afx_msg void OnBnClickedCheck1();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGDOCKBAR_H__F19609DA_241D_4F29_80F7_089B5A380DEC__INCLUDED_)

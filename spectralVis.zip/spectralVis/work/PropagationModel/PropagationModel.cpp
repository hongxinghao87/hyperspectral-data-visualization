#include "StdAfx.h"
#include "PropagationModel.h"
#include <math.h>
CPropagationModel test;
CPropagationModel::CPropagationModel(void)
{
/*	float d = Okumura_Hata(70, 1.5, 7.78, 851, 1);
	float dd1 = Okumura_Hata_Distance(70, 1.5, d, 851, 1);
	float d1 = Okumura_Hata(70, 1.5, 18.07, 851, 1);
	float dd2 = Okumura_Hata_Distance(70, 1.5, d1, 851, 1);
	float d2 = d - d1;

	float d3 = Min_Co_channel_Distance(70, 1.5, 150, 12, 150);

	float d4 = Min_Co_channel_Distance(70, 1.5, 150, 12, 149);

	float dd = 96.1 +32.9 * log10(5.7);*/
}

CPropagationModel::~CPropagationModel(void)
{
}

float CPropagationModel::FreeSpaceLoss(float fDis, float fFrequency)
{
	return (32.45 + 20 * log10(fDis * fFrequency));
}

float CPropagationModel::IMT2000_Indoor(float fDis, int nFloor)
{
	return (37 + 30 * log10(fDis) + 18.3 * pow(nFloor, (nFloor + 2.0) / (nFloor + 1.0) - 0.46));
}

float CPropagationModel::IMT2000_OutdoorToIndoor(float fDis, float fFrequency)
{
	return (40 * log10(fDis) + 30 * log10(fFrequency) + 49);
}

float CPropagationModel::IMT2000_Vehicular(float fDeltaHb, float fDis, float fFrequency)
{
	return (40 * (1 - 0.04 * fDeltaHb) * log10(fDis) - 18 * log10(fDeltaHb) + 21 * log10(fFrequency) + 80);
}

float CPropagationModel::Min_Co_channel_Distance(float fHb, float fHm, float fLoss, 
							  float fRadioD2U, float fFrequency, int nType)
{
	float d1 = 0, d2 = 0;
	if(fFrequency >= 150 && fFrequency <= 1500)
	{
		d1 = Okumura_Hata_Distance(fHb, fHm, fLoss, fFrequency, nType);
		d2 = Okumura_Hata_Distance(fHb, fHm, fLoss + fRadioD2U, fFrequency, nType);
	}
	else if(fFrequency >= 1500 && fFrequency <= 2000)
	{
		d1 = COST231_Hata_Distance(fHb, fHm, fLoss, fFrequency, nType);
		d2 = COST231_Hata_Distance(fHb, fHm, fLoss + fRadioD2U, fFrequency, nType);
	}

	else
	{
		d1 = Egli_Distance(fHb, fHm, fLoss, fFrequency);
		d2 = Egli_Distance(fHb, fHm, fLoss + fRadioD2U, fFrequency);
	}
	
	return d1 + d2;

}

float CPropagationModel::Okumura_Hata(float fHb, float fHm, float fDis, float fFrequency, int nType)
{
	//�ƶ����߸߶ȵ�У��
	float ahm = 0;
	/*1�������
	  2����С����
	  3������
	  4��ũ��
	  5�����ٹ�·*/
	if(nType == 1)
	{
		//����� 
		if(fFrequency <= 200)
			ahm = 8.29 * pow(log10(1.54 * fHm), 2) - 1.1;
		else if(fFrequency >= 400)
			ahm = 3.2 * pow(log10(11.75 * fHm), 2) - 4.97;
		else
			ahm = 3.2 * pow(log10(11.75 * fHm), 2) - 4.97;//��ȷ��������

	}
	else if(nType == 2)
	{
		//��С����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);

	}
	else if(nType == 3)
	{
		//����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= (- 2 * pow(log10(fFrequency / 28), 2) - 5.4);

	}
	else if(nType == 4)
	{
		//ũ��
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94);
	}
	else if(nType == 5)
	{
		//���ٹ�·
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94 + 3);
	}


	float L = 69.55 + 26.16 * log10(fFrequency) - 13.82 * log10(fHb) - ahm + (44.9 - 6.55 * log10(fHb))  * log10(fDis);

	return L;
}

float CPropagationModel::Okumura_Hata_Distance(float fHb, float fHm, float fLoss, float fFrequency, int nType)
{
	//�ƶ����߸߶ȵ�У��
	float ahm = 0;
	/*1�������
	2����С����
	3������
	4��ũ��
	5�����ٹ�·*/
	if(nType == 1)
	{
		//����� 
		if(fFrequency <= 200)
			ahm = 8.29 * pow(log10(1.54 * fHm), 2) - 1.1;
		else if(fFrequency >= 400)
			ahm = 3.2 * pow(log10(11.75 * fHm), 2) - 4.97;
		else
			ahm = 3.2 * pow(log10(11.75 * fHm), 2) - 4.97;//��ȷ��������

	}
	else if(nType == 2)
	{
		//��С����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);

	}
	else if(nType == 3)
	{
		//����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= (- 2 * pow(log10(fFrequency / 28), 2) - 5.4);

	}
	else if(nType == 4)
	{
		//ũ��
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94);
	}
	else if(nType == 5)
	{
		//���ٹ�·
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94 + 3);
	}


	float L = 69.55 + 26.16 * log10(fFrequency) - 13.82 * log10(fHb) - ahm;

	float fDis = pow(10, (fLoss - L) / (44.9 - 6.55 * log10(fHb)));

	return fDis;
}

float CPropagationModel::COST231_Hata(float fHb, float fHm, float fDis, float fFrequency, int nType)
{
	//�ƶ����߸߶ȵ�У��
	float ahm = 0;
	/*1�������
	2����С����
	3������
	4��ũ��
	5�����ٹ�·*/
	if(nType == 1)
	{
		//����� 
		ahm = 3.2 * pow(log10(11.75 * fHm), 2) - 4.97 - 3;

	}
	else if(nType == 2)
	{
		//��С����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);

	}
	else if(nType == 3)
	{
		//����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= (- 2 * pow(log10(fFrequency / 28), 2) - 5.4);

	}
	else if(nType == 4)
	{
		//ũ��
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94);
	}
	else if(nType == 5)
	{
		//���ٹ�·
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94 + 3);
	}


	float L = 69.3 + 33.9 * log10(fFrequency) - 13.82 * log10(fHb) - ahm + (44.9 - 6.55 * log10(fHb))  * log10(fDis);

	return L;
}

float CPropagationModel::COST231_Hata_Distance(float fHb, float fHm, float fLoss, float fFrequency, int nType)
{
	//�ƶ����߸߶ȵ�У��
	float ahm = 0;
	/*1�������
	2����С����
	3������
	4��ũ��
	5�����ٹ�·*/
	if(nType == 1)
	{
		//����� 
		ahm = 3.2 * pow(log10(11.75 * fHm), 2) - 4.97 - 3;
	}
	else if(nType == 2)
	{
		//��С����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
	}
	else if(nType == 3)
	{
		//����
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= (- 2 * pow(log10(fFrequency / 28), 2) - 5.4);

	}
	else if(nType == 4)
	{
		//ũ��
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94);
	}
	else if(nType == 5)
	{
		//���ٹ�·
		ahm = (1.11 * log10(fFrequency) - 0.7) * fHm - (1.56 * log10(fFrequency) - 0.8);
		ahm -= ( - 4.78 * pow(log10(fFrequency), 2) + 18.33 * log10(fFrequency) - 40.94 + 3);
	}

	float L = 69.3 + 33.9 * log10(fFrequency) - 13.82 * log10(fHb) - ahm ;

	float fDis = pow(10, (fLoss - L) / (44.9 - 6.55 * log10(fHb)));
	return fDis;
}

float CPropagationModel::COST231_Walfish_Ikegami_Vis(float fDis, float fFrequency)
{
	return (42.64 + 26 * log10(fDis) + 20 * log10(fFrequency));
}

float CPropagationModel::COST231_Walfish_Ikegami_NoVis(float fHb, float fHm, float fHB, float fW, 
													   float fA, float fB,
													   float fDis, 
													   float fFrequency, 
													   int nType)
{
	float L, L0, Lrts, Lmsd, Lori;

	L0 = 32.4 + 20 * log10(fDis * fFrequency);
	if(fA >= 0 && fA <= 35)
		Lori = -10 + 0.354 * fA;
	else if(fA > 35 && fA <= 55)
		Lori = 2.5 + 0.075 * (fA - 35);
	else if(fA > 55 && fA <= 90)
		Lori = 4.0 - 0.114 * (fA - 55);
	Lrts = -16.9 - 10 * log10(fW) + 10 * log10(fFrequency) + 20 * log10(fHB - fHm) + Lori;

	float Lbsh, Ka, Kd, Kf;
	float fDeltaHb = fHb - fHB;
	if(fDeltaHb > 0)
	{
		Lbsh = -18 * log10(1 + fDeltaHb);
		Ka = 54;
		Kd = 18;
	}
	else 
	{
		Lbsh = 0;
		Kd = 18 - 15 * fDeltaHb / fHB ;
		if(fDis>=0.5) Ka = 54 - 0.8 * fDeltaHb;
		else Ka = 54 - 1.6 * fDis * fDeltaHb;
	}
	
	if(nType == 1) //�еȳ��кͽ���
		Kf = -4 + 0.7 * (fFrequency / 925 - 1);
	else if(nType == 2)//�����
		Kf = -4 + 1.5 * (fFrequency / 925 - 1);
	
	Lmsd = Lbsh + Ka + Kd * log10(fDis) + Kf * log10(fFrequency) - 9 * log10(fB);

	if(Lrts + Lmsd > 0)
		L = L0 + Lrts + Lmsd;
	else
		L = L0;

	return L;
}

float CPropagationModel::General(float Pt, float d, float Hb, float Hm)
{
	float K1 = -25.7, K2 = -44.97, K3 = -5.83, K4 = 0.4, K5 = 6.55, K6 = 0, K7 = 0;
	//K1 = -32.4, K2 = -38.1, K3 = -5.83, K4 = 0.63, K5 = 6.55, K6 = 0, K7 = 0; //�˿ڽ��ܡ����ݽ���
	float Pr = Pt + K1 + K2 * log10(d) + K3 * log10(Hb) + K4 + K5 * log10(Hb) * log10(d) + K6 * Hm + K7;

	return Pr;
}

float CPropagationModel::Egli(float fHb, float fHm, float fDis, float fFrequency, float fKf)
{
	return(88 + 40 * log10(fDis) + 20 * log10(fFrequency) - 20 * log10(fHb * fHm) - fKf);
}

float CPropagationModel::Egli_Distance(float fHb, float fHm, float fLoss, float fFrequency, float fKf)
{
	return pow(10, (fLoss - (88 + 20 * log10(fFrequency) - 20 * log10(fHb * fHm) - fKf)) / 40.0);
}
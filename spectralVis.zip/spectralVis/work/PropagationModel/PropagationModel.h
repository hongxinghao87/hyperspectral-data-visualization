#pragma once

//surface refractivity (Ns N-Units)
#define Equatorial 360 //Congo
#define Continental_Subtropical 320 //Sudan
#define Maritime_Subtropical 370 //West Coast of Africa
#define Desert 280 //Sahara
#define Continental_Temperate 301 //Use for Avg. Atmospheric Condition
#define Maritime_Temperate_OverLand 320 //UK and Continental West Coast
#define Maritime_Temperate_OverSea 350 

//Dielectric Constant of Ground
#define Average_Ground 15
#define Poor_Ground 4
#define Good_Ground 25
#define Fresh_Water 81
#define Sea_Water 81

//Conductivity 0f Ground
#define Average_Ground_Conductivity 0.005
#define Poor_Ground_Conductivity 0.001
#define Good_Ground_Conductivity 0.02
#define Fresh_Water_Conductivity 0.01
#define Sea_Water_Conductivity 5

//Radio Climate
#define Equatorial_Climate 1 
#define Continental_Subtropical_Climate 2  
#define Maritime_Tropical_Climate 3 
#define Desert_Climate 4  
#define Continental_Temperate_Climate 5
#define Maritime_Temperate_OverLand_Climate 6 
#define Maritime_Temperate_OverSea_Climate 7 

//Delta H (m)
#define Flat_Water 0
#define Plains 30
#define Hills 90
#define Mountains 200
#define Rugged_Mountains 500

//polarization
#define Horizontal  0 
#define Vertical 1

//Site Criteria
#define random 0 
#define careful 1 
#define very_careful 2 

#define earth_perimeter (2 * PI * RADIUS)

class CPropagationModel
{
public:
	CPropagationModel(void);
	~CPropagationModel(void);
	
public:

	static float Min_Co_channel_Distance(float fHb, float fHm, float fLoss, 
		float fRadioD2U, float fFrequency, int nType = 4);

public:

	//fDis �շ�����(km), fFrequencyƵ��(MHz)
	static float FreeSpaceLoss(float fDis, float fFrequency);

	//fDis �շ����루m��, nFloor ����·���е�¥����
	static float IMT2000_Indoor(float fDis, int nFloor);
	//fDis �շ����루m��, fFrequencyƵ�ʣ�MHz��
	static float IMT2000_OutdoorToIndoor(float fDis, float fFrequency);
	//fDeltaHb��վ���߾����ݶ��ĸ߶ȣ�m��, fDis �շ����루km��, fFrequencyƵ�ʣ�MHz��
	static float IMT2000_Vehicular(float fDeltaHb, float fDis, float fFrequency);

	//fHb��fHm��վ���ƶ�̨������Ч�߶ȣ�m��, fDis �շ����루km��, fFrequencyƵ�ʣ�MHz��
	//Ƶ�ʷ�Χ150~1500MHz, ��վ����30~200m, �ƶ�����1~10m, ���� 1km <=fDis<=20km
	static float Okumura_Hata(float fHb, float fHm, float fDis, float fFrequency, int nType);
	static float Okumura_Hata_Distance(float fHb, float fHm, float fLoss, float fFrequency, int nType);

	//fHb��fHm��վ���ƶ�̨������Ч�߶ȣ�m��, fDis �շ����루km��, fFrequencyƵ�ʣ�MHz��
	//Ƶ�ʷ�Χ1500~2000MHz, ��վ����30~200m, �ƶ�����1~10m, ���� 1km <=fDis<=35km
	static float COST231_Hata(float fHb, float fHm, float fDis, float fFrequency, int nType);
	static float COST231_Hata_Distance(float fHb, float fHm, float fLoss, float fFrequency, int nType);

	//800MHz <=f<=2000MHz, 0.02km<=d<=5km, 4m<=hr<=50m
	//fHB �������ݶ��߶ȣ�fW�ֵ�����, fA ����ڽֵ��������,fB ��������
	static float COST231_Walfish_Ikegami_Vis(float fDis, float fFrequency);//���ϰ��Ӿ�
	static float COST231_Walfish_Ikegami_NoVis(float fHb, float fHm, float fHB, float fW, 
										float fA, float fB,
										float fDis, float fFrequency, int nType);//���Ӿ�

	// d:km, f:MHz, Hb:m, Hm:m, Kf:dB
	//ref: Ұս���ߵ�Ƶ�ʹ�����ͬƵ���ŵļ��������Ԥ��
	static float Egli(float fHb, float fHm, float fDis, float fFrequency, float fKf = 0);
	static float Egli_Distance(float fHb, float fHm, float fLoss, float fFrequency, float fKf = 0);

	//Pr = pt + K1 + K2 * log10(d) + K3 * log10(Hb) + K4 + K5 * log10(Hb) * log10(d) + K6 * Hm + K7;
	//Pr ���ܹ���dBm,Pt���书��dBm��
	//K1 ��������dB,Ƶ�ʵı仯
	//K2 �˻����ӣ�������й�
	//K3 ���վ������Ч�߶��й�
	//K4 ��������
	//K5 Okumura����
	//K6 �ƶ�̨��Ч�߶��������ӣ���Hm = 1.5m��Ϊ0
	//K7 ���ε�ò���棨dB��
	static float General(float Pt, float d, float Hb, float Hm);


	// IRREGULAR TERRAIN MODEL (ITM)
	//ITM estimates radio propagation losses over irregular terrain
	//for VHF, UHF and SHF frequencies as a function of distance and the variability
	//of signal in time and space.  
	//The model is based on electromagnetic theory and 
	//signal loss variability expressions derived from extensive sets of measurements.  
	//The ITM algorithm works in two modes: 1) area prediction mode, and 2) point-to-point mode.  
	//The input parameters include frequency, distance, antenna heights, polarization, 
	//surface refractivity, electrical ground constants, climate, reliability and confidence levels, 
	//percent time and location, and siting criteria.   
	//For the area prediction mode, terrain irregularity parameter is needed and 
	//the output is either a table of transmission losses in dB vs. distance 
	//for several confidence levels or graphs of dB loss vs. distance 
	//for specified confidence levels.  
	//For the point-to-point mode, the model requires terrain data and 
	//the path coordinates are specified.  
	//The output is a list of estimated transmission losses 
	//for specifies values of reliability and confidence levels.  
	//The output screen also contains a snapshot of the terrain profile.

	//Valid ranges of input parameters:

	//Frequency        20 MHz to 20 GHz.

	//	Distance          1 km to 2000 km.

	//	Antenna heights  0.5 m to 3000 m.

	static double ITMAreadBLoss(long ModVar, double deltaH, double tht_m, double rht_m,
		double dist_km, int TSiteCriteria, int RSiteCriteria, 
		double eps_dielect, double sgm_conductivity, double eno_ns_surfref,
		double frq_mhz, int radio_climate, int pol, double pctTime, double pctLoc,
		double pctConf);
	// pol: 0-Horizontal, 1-Vertical
	// TSiteCriteria, RSiteCriteria:
	//		   0 - random, 1 - careful, 2 - very careful
	// radio_climate: 1-Equatorial, 2-Continental Subtropical, 3-Maritime Tropical,
	//                4-Desert, 5-Continental Temperate, 6-Maritime Temperate, Over Land,
	//                7-Maritime Temperate, Over Sea
	// ModVar: 0 - Single: pctConf is "Time/Situation/Location", pctTime, pctLoc not used
	//         1 - Individual: pctTime is "Situation/Location", pctConf is "Confidence", pctLoc not used
	//         2 - Mobile: pctTime is "Time/Locations (Reliability)", pctConf is "Confidence", pctLoc not used
	//         3 - Broadcast: pctTime is "Time", pctLoc is "Location", pctConf is "Confidence"
	// pctTime, pctLoc, pctConf: .01 to .99
	// errnum: 0- No Error.
	//         1- Warning: Some parameters are nearly out of range.
	//                     Results should be used with caution.
	//         2- Note: Default parameters have been substituted for impossible ones.
	//         3- Warning: A combination of parameters is out of range.
	//                     Results are probably invalid.
	//         Other-  Warning: Some parameters are out of range.
	//                          Results are probably invalid.
	// NOTE: strmode is not used at this time.
	static void area(long ModVar, double deltaH, double tht_m, double rht_m,
		double dist_km, int TSiteCriteria, int RSiteCriteria, 
		double eps_dielect, double sgm_conductivity, double eno_ns_surfref,
		double frq_mhz, int radio_climate, int pol, double pctTime, double pctLoc,
		double pctConf, double &dbloss, char *strmode, int &errnum);

	// pol: 0-Horizontal, 1-Vertical
	// radio_climate: 1-Equatorial, 2-Continental Subtropical, 3-Maritime Tropical,
	//                4-Desert, 5-Continental Temperate, 6-Maritime Temperate, Over Land,
	//                7-Maritime Temperate, Over Sea
	// conf, rel: .01 to .99
	// elev[]: [num points - 1], [delta dist(meters)], [height(meters) point 1], ..., [height(meters) point n]
	// errnum: 0- No Error.
	//         1- Warning: Some parameters are nearly out of range.
	//                     Results should be used with caution.
	//         2- Note: Default parameters have been substituted for impossible ones.
	//         3- Warning: A combination of parameters is out of range.
	//                     Results are probably invalid.
	//         Other-  Warning: Some parameters are out of range.
	//                          Results are probably invalid.
	static void point_to_pointDH (double elev[], double tht_m, double rht_m,
		double eps_dielect, double sgm_conductivity, double eno_ns_surfref,
		double frq_mhz, int radio_climate, int pol, double conf, double rel,
		/*���*/double &dbloss, double &deltaH, int &errnum);

	// pol: 0-Horizontal, 1-Vertical
	// radio_climate: 1-Equatorial, 2-Continental Subtropical, 3-Maritime Tropical,
	//                4-Desert, 5-Continental Temperate, 6-Maritime Temperate, Over Land,
	//                7-Maritime Temperate, Over Sea
	// timepct, locpct, confpct: .01 to .99
	// elev[]: [num points - 1], [delta dist(meters)], [height(meters) point 1], ..., [height(meters) point n]
	// propmode:  Value   Mode
	//             -1     mode is undefined
	//              0     Line of Sight
	//              5     Single Horizon, Diffraction
	//              6     Single Horizon, Troposcatter
	//              9     Double Horizon, Diffraction
	//             10     Double Horizon, Troposcatter
	// errnum: 0- No Error.
	//         1- Warning: Some parameters are nearly out of range.
	//                     Results should be used with caution.
	//         2- Note: Default parameters have been substituted for impossible ones.
	//         3- Warning: A combination of parameters is out of range.
	//                     Results are probably invalid.
	//         Other-  Warning: Some parameters are out of range.
	//                          Results are probably invalid.
	static void point_to_pointMDH (double elev[], double tht_m, double rht_m,
		double eps_dielect, double sgm_conductivity, double eno_ns_surfref,
		double frq_mhz, int radio_climate, int pol, double timepct, double locpct, double confpct, 
		double &dbloss, int &propmode, double &deltaH, int &errnum);

	// pol: 0-Horizontal, 1-Vertical
	// radio_climate: 1-Equatorial, 2-Continental Subtropical, 3-Maritime Tropical,
	//                4-Desert, 5-Continental Temperate, 6-Maritime Temperate, Over Land,
	//                7-Maritime Temperate, Over Sea
	// conf, rel: .01 to .99
	// elev[]: [num points - 1], [delta dist(meters)], [height(meters) point 1], ..., [height(meters) point n]
	// errnum: 0- No Error.
	//         1- Warning: Some parameters are nearly out of range.
	//                     Results should be used with caution.
	//         2- Note: Default parameters have been substituted for impossible ones.
	//         3- Warning: A combination of parameters is out of range.
	//                     Results are probably invalid.
	//         Other-  Warning: Some parameters are out of range.
	//                          Results are probably invalid.
	static void point_to_point(double elev[], double tht_m, double rht_m,
		double eps_dielect, double sgm_conductivity, double eno_ns_surfref,
		double frq_mhz, int radio_climate, int pol, double conf, double rel,
		double &dbloss, char *strmode, int &errnum);

};

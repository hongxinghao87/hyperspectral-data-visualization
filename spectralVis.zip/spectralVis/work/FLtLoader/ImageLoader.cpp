// ImageLoader.cpp: implementation of the CImageLoader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "fltviewer.h"
#include "ImageLoader.h"

#include <math.h>


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImageLoader::CImageLoader()
{
	m_pImage = NULL;
	m_bRGBIndexed = true;
	InitBmpInfo();
}

CImageLoader::~CImageLoader()
{
	if(m_pImage)
		delete m_pImage;

}

void* CImageLoader::LoadImage(CString sFileName)
{
	if(m_pImage)
		delete m_pImage;
	m_pImage = NULL;
	InitBmpInfo();

	int pos = sFileName.ReverseFind('.');
	CString sExt="sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss";
	sExt = sFileName.Right(sFileName.GetLength()-pos-1);
	sExt.MakeLower();
	if((sExt=="rgb")||(sExt=="rgba")||(sExt=="int")||(sExt=="inta"))	LoadImageSGI(sFileName);
//	else if((sExt=="bmp"))												LoadImageBMP(sFileName);
//	else if((sExt=="tga"))												LoadImageTGA(sFileName);
	else if((sExt=="bmp")||(sExt=="png")||(sExt=="tga")||(sExt=="jpg")||(sExt=="jpeg")||
		(sExt=="tif")||(sExt=="tiff")||(sExt=="pcx")||(sExt=="jp2")||(sExt=="jpc"))
		LoadxImage(sFileName);
	else					AfxMessageBox(sFileName+":\r\n  ��֧������ͼ���ʽ��");
	if(m_pImage)
		RegulateImage();	
	return m_pImage;
}

void CImageLoader::RegulateImage()
{
	int i;
	long nShiftWidth	= m_BmpInfoHead.biWidth;
	long nShiftHeight	= m_BmpInfoHead.biHeight;
	//-------------------��������С��Ϊ2����
	long shifted_x = nShiftWidth;
	for (i = 0; ((i < 16) && (shifted_x != 0)); i++)
		shifted_x = shifted_x >> 1;
	if (i == 0)		nShiftWidth = 0;
	else			nShiftWidth = (long)(pow((double)2,(double)(i-1)));
	//-------------------
	//-------------------��������С��Ϊ2����
	shifted_x = nShiftHeight;
	for (i = 0; ((i < 16) && (shifted_x != 0)); i++)
		shifted_x = shifted_x >> 1;
	if (i == 0)		nShiftHeight = 0;
	else			nShiftHeight = (long)(pow((double)2,(double)(i-1)));
	//-------------------
	bool bNotNeed = false;
	bNotNeed = (m_BmpInfoHead.biWidth == nShiftWidth)&&(m_BmpInfoHead.biHeight== nShiftHeight);
	if(bNotNeed)
		return ;
	
	BITMAPINFOHEADER	BmpInfoHead;					
	BITMAPINFO			BmpInfo;						
	BmpInfoHead = m_BmpInfoHead;
	BmpInfo.bmiHeader = BmpInfoHead;
	unsigned int nSize = nShiftWidth*nShiftHeight*m_BmpInfoHead.biBitCount/8;
	
	m_BmpInfoHead.biWidth			= nShiftWidth; 
	m_BmpInfoHead.biHeight			= nShiftHeight; 
//	m_BmpInfoHead.biBitCount		= 24; 
	m_BmpInfoHead.biSizeImage		= nSize; 
	
	BYTE* pImage = m_pImage;
	BYTE* pImage2;
	
	HDC		hMemDC;
	hMemDC = CreateCompatibleDC(NULL);
	HBITMAP	hbmNew;
	hbmNew=CreateDIBSection(hMemDC, (BITMAPINFO*)&m_BmpInfoHead,
		DIB_RGB_COLORS,  (void**)&pImage2, NULL, 0);
	
	SelectObject(hMemDC,hbmNew);				//�趨Ϊ��ǰ		
	SetStretchBltMode(hMemDC, COLORONCOLOR);
	SetMapMode(hMemDC, MM_TEXT);
	//��Դͼ���л��ͼ������
	int kk = StretchDIBits (hMemDC,	0, 0, nShiftWidth, nShiftHeight,//Ŀ��
		0, 0, BmpInfoHead.biWidth, BmpInfoHead.biHeight,	pImage,	//Դ
		(BITMAPINFO*)&BmpInfo, DIB_RGB_COLORS, SRCCOPY);		
	GdiFlush();	
	
	m_pImage = new BYTE[nSize];
	memcpy(m_pImage,pImage2,nSize*sizeof(BYTE));
	
	delete pImage;
	DeleteObject(hbmNew);
	DeleteDC(hMemDC);	//������������ˣ�delete pImage2;
	
}

bool CImageLoader::LoadImageBMP(CString sFileName)
{
	struct BMPFileHeader
	{
		int			  size;
		unsigned short	reserved1;
		unsigned short	reserved2;
		int			  offset_bits;
	};
	struct BMPInfoHeader
	{
		int			  width;
		int			  height;
		short			planes;
		short			bit_count;
		int			  compression;
		int			  image_size;
		int			  x_pixels_per_meter;
		int			  y_pixels_per_meter;
		int			  colors_used;
		int			  colors_important;
	};
	struct BMPInfoHeaderOld
	{
		short			width;
		short			height;
		short			planes;
		short			bit_count;
	};
	//��ȡBMP�ļ�ͷ
	BMPFileHeader header;
	BMPInfoHeader info;
	int info_size;

	CFile f;
	char file_type[2];
	if(!f.Open(sFileName,CFile::modeRead,NULL))
	{
	  f.Close();
	  return false;
	}
	f.Read(&file_type, 2);
	if (file_type[0] != 'B' || (file_type[1] != 'A' && file_type[1] != 'M'))
	{
		//"loadImageBMP(): invalid type("
		f.Close();
		return false;
	}
	f.Read(&header, sizeof(BMPFileHeader));
	f.Read(&info_size,sizeof(int));
	if (info_size == 12)
	{
		BMPInfoHeaderOld old_info;
		f.Read(&old_info, sizeof(BMPInfoHeaderOld));
		
		
		info.width = old_info.width;
		info.height = old_info.height;
		info.planes = old_info.planes;
		info.bit_count = old_info.bit_count;
		
		info.compression = 0;
		info.image_size = ((info.bit_count * info.width + 31) / 32)
			* 4 * info.height;
		info.x_pixels_per_meter = 0;
		info.y_pixels_per_meter = 0;
		info.colors_used = 0;
		info.colors_important = 0;
	}
	else if (info_size >= 40)
		f.Read(&info, sizeof(BMPInfoHeader));
	
	else
		//"loadImageBMP(): invalid info header size in file "
		return false;
	//��ȡͼ������
	bool bWidth,bHeight,bPlanes,bBit,bCompress,bColor;
	bWidth = (info.width <= 0);								// "loadImageBMP(): invalid width in file "
	bHeight = (info.height <= 0);							// "loadImageBMP(): invalid height in file "
	bPlanes = (info.planes != 1);							// "loadImageBMP(): invalid # of planes in file "
	bBit = (info.bit_count != 1 && info.bit_count != 4 &&
		info.bit_count != 8 && info.bit_count != 24);		// "loadImageBMP(): invalid bit count in file "
	bCompress = (info.compression < 0 || info.compression > 2 ||
		(info.compression == 1 && info.bit_count != 8) ||
		(info.compression == 2 && info.bit_count != 4));		//"loadImageBMP(): invalid compression in file "
	bColor = (info.bit_count == 1 && info.colors_used != 0 && info.colors_used != 2);
															//"loadImageBMP(): invalid # of colors used in file "
	if (bWidth||bHeight||bPlanes||bBit||bCompress||bColor)
	{
	  f.Close();
	  return false;
	}

	if (info_size > 40)
		f.Seek(info_size-40,CFile::current);

	unsigned int num_bytes = info.width * info.height * 3;
	BYTE* image = new BYTE[num_bytes];

	char *color_map = NULL;
	if (info.bit_count != 24)
	{
	  if (!info.colors_used)
		 info.colors_used = 1 << info.bit_count;
	  color_map = new char[info.colors_used * 3];
	  for (int i=0; i<3*info.colors_used; i+=3)
	  {
		 f.Read(&color_map[i+2], 1);
		 f.Read(&color_map[i+1], 1);
		 f.Read(&color_map[i], 1);
		 if (info_size != 12)
			f.Seek(1,CFile::current);
	  }
	}

	f.Seek(header.offset_bits, CFile::begin);
	if (info.bit_count == 1)
	{
	  long pad = ((info.width + 31) / 32)*4 - ((info.width + 7)/8);
	  char *iptr = (char*)image;
	  for (int y=0; y<info.height; ++y)
	  {
		 for (int x=0; x<info.width;)
		 {
			char buf;
			f.Read(&buf, 1);
			for (int i=0; i<8 && x<info.width; ++x, ++i)
			{
				if (buf & 0x80)
				{
				  *iptr = color_map[3]; ++iptr;
				  *iptr = color_map[4]; ++iptr;
				  *iptr = color_map[5]; ++iptr;
				}
				else
				{
				  *iptr = color_map[0]; ++iptr;
				  *iptr = color_map[1]; ++iptr;
				  *iptr = color_map[2]; ++iptr;
				}
				buf <<= 1;
			}
		 }
		 f.Seek(pad,CFile::current);
	  }
	}
	else if (info.bit_count == 4)
	{
	  if (info.compression)
	  {
		 int x = 0, y = 0;
		 char *iptr = (char*)image;
		 while (y < info.height)
		 {
			BYTE buf;
			f.Read(&buf, 1);
			if (buf == 0)
			{
				f.Read(&buf, 1);
				if (buf == 0)
				{
				  x = 0; ++y;
				  iptr = (char*)image + y*info.width*3 + x*3;
				}
				else if (buf == 1)
				{
				  break;
				}
				else if (buf == 2)
				{
				  f.Read(&buf, 1);
				  x += buf;
				  f.Read(&buf, 1);
				  y += buf;
				  iptr = (char*)image + y*info.width*3 + x*3;
				}
				else
				{
				  BYTE num = buf;
				  for (BYTE i = 0; i < num; ++i)
				  {
					 f.Read(&buf, 1);
					 int indx = 3*((buf >> 4) & 0x0f);
					 *iptr = color_map[indx]; ++iptr;
					 *iptr = color_map[indx+1]; ++iptr;
					 *iptr = color_map[indx+2]; ++iptr;
					 ++x;
					 if (++i < num)
					 {
						indx = 3 * (buf & 0x0f);
						*iptr = color_map[indx]; ++iptr;
						*iptr = color_map[indx+1]; ++iptr;
						*iptr = color_map[indx+2]; ++iptr;
						++x;
					 }
				  }
				  if (num & 0x03 == 0x01 || num & 0x03 == 0x02)
					 f.Seek(1,CFile::current);
				}
			}
			else
			{
				BYTE num = buf;
				f.Read(&buf, 1);
				int indx1 = 3*((buf >> 4) & 0x0f);
				int indx2 = 3 * (buf & 0x0f);
				for (BYTE i = 0; i < num; ++i)
				{
				  *iptr = color_map[indx1]; ++iptr;
				  *iptr = color_map[indx1+1]; ++iptr;
				  *iptr = color_map[indx1+2]; ++iptr;
				  if (++i < num)
				  {
					 *iptr = color_map[indx2]; ++iptr;
					 *iptr = color_map[indx2+1]; ++iptr;
					 *iptr = color_map[indx2+2]; ++iptr;
				  }
				}
				x += num;
			}
		 }
	  }
	  else
	  {
		 long pad = ((4*info.width + 31) / 32)*4 - ((4*info.width + 7)/8);
		 char *iptr = (char*)image;
		 for (int y=0; y<info.height; ++y)
		 {
			for (int x=0; x<info.width; ++x)
			{
				BYTE buf;
				f.Read(&buf, 1);
				int indx = 3*((buf >> 4) & 0x0f);
				*iptr = color_map[indx]; ++iptr;
				*iptr = color_map[indx+1]; ++iptr;
				*iptr = color_map[indx+2]; ++iptr;
				if (++x < info.width)
				{
				  indx = 3 * (buf & 0x0f);
				  *iptr = color_map[indx]; ++iptr;
				  *iptr = color_map[indx+1]; ++iptr;
				  *iptr = color_map[indx+2]; ++iptr;
				}
			}
			f.Seek(pad,CFile::current);
		 }
	  }
	}
	else if (info.bit_count == 8)
	{
	  if (info.compression)
	  {
		 int x = 0, y = 0;
		 char *iptr = (char*)image;
		 while (y < info.height)
		 {
			BYTE buf;
			f.Read(&buf, 1);
			if (buf == 0)
			{
				f.Read(&buf, 1);
				if (buf == 0)
				{
				  x = 0; ++y;
				  iptr = (char*)image + y*info.width*3 + x*3;
				}
				else if (buf == 1)
				{
				  break;
				}
				else if (buf == 2)
				{
				  f.Read(&buf, 1);
				  x += buf;
				  f.Read(&buf, 1);
				  y += buf;
				  iptr = (char*)image + y*info.width*3 + x*3;
				}
				else
				{
				  BYTE num = buf;
				  for (BYTE i = 0; i < num; ++i)
				  {
					 f.Read(&buf, 1);
					 int indx = 3*buf;
					 *iptr = color_map[indx]; ++iptr;
					 *iptr = color_map[indx+1]; ++iptr;
					 *iptr = color_map[indx+2]; ++iptr;
					 ++x;
				  }
				  if (num & 0x01)
					 f.Seek(1,CFile::current);
				}
			}
			else
			{
				BYTE num = buf;
				f.Read(&buf, 1);
				int indx = 3*buf;
				for (BYTE i = 0; i < num; ++i)
				{
				  *iptr = color_map[indx]; ++iptr;
				  *iptr = color_map[indx+1]; ++iptr;
				  *iptr = color_map[indx+2]; ++iptr;
				}
				x += num;
			}
		 }
	  }
	  else
	  {
		 long pad = ((info.width + 3) / 4)*4 - info.width;
		 char *iptr = (char*)image;
		 for (int y=0; y<info.height; ++y)
		 {
			for (int x=0; x<info.width; ++x)
			{
				BYTE buf;
				f.Read(&buf, 1);
				int indx = 3*buf;
				*iptr = color_map[indx]; ++iptr;
				*iptr = color_map[indx+1]; ++iptr;
				*iptr = color_map[indx+2]; ++iptr;
			}
			f.Seek(pad,CFile::current);
		 }
	  }
	}
	else
	{
	  long pad = ((3*info.width + 3) / 4)*4 - info.width*3;
	  char *iptr = (char*)image;
	  for (int y=0; y<info.height; ++y)
	  {
		 f.Read(iptr, 3*info.width);
		 for (int x=0; x<info.width; ++x)
		 {
			BYTE tmp = *iptr;
			*iptr = *(iptr+2);
			*(iptr+2) = tmp;
			iptr += 3;
		 }
		 f.Seek(pad,CFile::current);
	  }
	}

	if (color_map)
	  delete color_map;

	f.Close();
	m_pImage = new BYTE[num_bytes];
	memcpy(m_pImage,image,num_bytes);
	m_bRGBIndexed = true;

	m_BmpInfoHead.biSizeImage = num_bytes;
	m_BmpInfoHead.biWidth	= info.width;
	m_BmpInfoHead.biHeight	=info.height;
	m_BmpInfoHead.biBitCount= info.bit_count*8;
	delete image;
	return true;
}

bool CImageLoader::LoadImageSGI(CString sFileName)
{
	struct SGIImageHeader {
		short			magic;
		BYTE	storage;
		BYTE	bytes_per_channel;
		unsigned short	dimension;
		unsigned short	xsize, ysize, zsize;
		unsigned int	min, max;
		unsigned int	waste_bytes1;
		char			name[80];
		unsigned int	colormap;
		char			waste_bytes2[404];
	};
	
	CString filepath;
	CFile f;
	if (!(f.Open(sFileName, CFile::modeRead,NULL)))
	{//"loadImageSGI(): Error opening file "
		return false;
	}
	
	SGIImageHeader header;
	f.Read(&header, sizeof(SGIImageHeader));

//#if defined(SGL_LITTLE_ENDIAN)
	sglEndianSwap(&header.magic);
	sglEndianSwap(&header.dimension);
	sglEndianSwap(&header.xsize);
	sglEndianSwap(&header.ysize);
	sglEndianSwap(&header.zsize);
	sglEndianSwap(&header.min);
	sglEndianSwap(&header.max);
	sglEndianSwap(&header.colormap);
//#endif
	
	if (header.magic != 474)
	{//"loadImageSGI(): invalid magic number in file "
		f.Close();
		return false;
	}
	if (header.bytes_per_channel != 1 &&
		header.bytes_per_channel != 2)
	{// "loadImageSGI(): invalid bytes_per_channel in file "
		f.Close();
		return false;
	}
	if (header.dimension == 1 && (header.ysize != 1 || header.zsize != 1))
	{//"loadImageSGI(): invalid dimension (1) for a "
		if (header.zsize == 1)
			header.dimension = 2;
		else
			header.dimension = 3;
	}
	if (header.dimension == 2 && header.zsize != 1)
	{//"loadImageSGI(): invalid dimension (2) for a "
		header.dimension = 3;
	}
	if (header.storage != 0x01 && header.storage != 0)
	{//"loadImageSGI(): invalid storage format in file "
		f.Close();
		return false;
	}
	
	unsigned short zsize = header.zsize;
	if (zsize > 4)
		zsize = 4;
	//  switch (zsize)
	{
		//case 1:format = sglTexture::eLUMINANCE;
		//case 2:format = sglTexture::eLUMINANCE_ALPHA;
		//case 3:format = sglTexture::eRGB;
		//case 4:format = sglTexture::eRGBA;
		//default:		 sglPrintWarning() << "loadImageSGI(): invalid zsize in file " << filepath << endl;
		//fclose(file);
		//return NULL;
	}
	switch (header.colormap)
	{
		case 0:
			// normal
			break;
			
			//case 1:"loadImageSGI(): obsolete dithered format not supported "
			// case 2:"loadImageSGI(): obsolete color-indexed format not supported "
			//case 3: "loadImageSGI(): colormap format not supported "
		default:	//"loadImageSGI(): unknown color format in file "
			f.Close();
			return false;
	}
	
	unsigned int num_pixels = header.xsize * header.ysize * zsize;
	unsigned int num_bytes  = num_pixels*header.bytes_per_channel;
	BYTE* image = new BYTE[num_bytes];
	
	//	if (header.bytes_per_channel == 1)
	//type = sglTexture::eUNSIGNED_BYTE;
	//	else
	//type = sglTexture::eUNSIGNED_SHORT;
	
	if (header.storage == 0x01)//readRLESGIImage(header, file, zsize, (char*)image);
	{
		unsigned int tablen = header.ysize * header.zsize * sizeof(int);
		int *row_start = new int[tablen];
		int *row_length = new int[tablen];
		int nn = f.GetLength();
		f.Read(row_start, tablen);
		f.Read(row_length,tablen);
		
		char* tmp = new char[header.xsize * header.bytes_per_channel * 2];
		int row = 0;
		for (unsigned short z = 0; z < zsize; ++z)
		{
			for (unsigned short y = 0; y < header.ysize; ++y)
			{
//#if defined(SGL_LITTLE_ENDIAN)
		 sglEndianSwap(&row_start[row]);
		 sglEndianSwap(&row_length[row]);
//#endif
				f.Seek(row_start[row], CFile::begin);
				f.Read(tmp,row_length[row]);
				
				char *iPtr = tmp;
				char *oPtr = (char*)image + y*header.xsize*zsize + z;
				char count;
				do
				{
					char pixel = *iPtr++;
					count = pixel & 0x7F;
					if (count)
					{
						if (pixel & 0x80)
							while (count--)
							{
								*oPtr = *iPtr++;
								oPtr += zsize;
							}
						else
						{
							pixel = *iPtr++;
							while (count--)
							{
								*oPtr = pixel;
								oPtr += zsize;
							}
						}
					}
				} while (count);
				++row;
			}
		}
		delete row_start;
		delete row_length;
		delete tmp;
	}
		
	else//readSGIImage(header, file, zsize, (char*)image);
	{
		int row_size = header.xsize * header.bytes_per_channel;
		char* tmp = new char[row_size];
	//f.SeekToBegin();
		for (unsigned short z = 0; z < zsize; ++z)
		{
		  for (unsigned short y = 0; y < header.ysize; ++y)
		  {
			 f.Read(tmp,row_size);
			 char *iPtr = tmp;
			 char *oPtr = (char*)image + y*header.xsize*zsize + z;
			 for (int i = 0; i < header.xsize; ++i)
			 {
				*oPtr = *iPtr++;
				oPtr += zsize;
			 }
		  }
		}
		delete tmp;
	}
	if (header.bytes_per_channel != 1)
	{
		//	#if defined(SGL_LITTLE_ENDIAN)
		short *tmp = (short*)image;
		for (unsigned int i = 0; i < num_pixels; ++i)
			 sglEndianSwap(tmp++);
		//	#endif
	}
	f.Close();
	
	m_pImage = new BYTE[num_bytes];
	memcpy(m_pImage,image,num_bytes);
	m_bRGBIndexed = true;

	m_BmpInfoHead.biSizeImage	= num_bytes;
	m_BmpInfoHead.biWidth		= header.xsize;
	m_BmpInfoHead.biHeight		= header.ysize;
	m_BmpInfoHead.biBitCount	= zsize*8;
	delete image;
	return true;
}

bool CImageLoader::LoadImageTGA(CString sFileName)
{
	struct sglTGAFileHeader
	{
		BYTE	fileType;
		BYTE	colorMapType;
		BYTE	 imageType;
		BYTE	 colorMapSpec[4];
		unsigned short  origX, origY;
		unsigned short  width, height;
		BYTE	bpp;
		BYTE	info;
	};
	CFile f;
	
	if (!(f.Open(sFileName, CFile::modeRead)))
	{//"loadImageTGA(): Error opening file "
		return false;
	}
	
	sglTGAFileHeader header;
	
	if (!f.Read(&header,sizeof(sglTGAFileHeader))||(header.width <= 0)
		||(header.height <= 0)||(header.imageType != 2)
		||(header.colorMapType != 0)||(header.bpp != 24 && header.bpp != 32))
	{
			f.Close();
			return false;
	}
	//"loadImageTGA(): invalid width in file "
	//"loadImageTGA(): invalid height in file "
	//"loadImageTGA(): compressed images not supported "
	//"loadImageTGA(): color mapped images not supported "
	//"loadImageTGA(): 24 & 32 bit depths supported "
//#if defined(SGL_BIG_ENDIAN)
	sglEndianSwap(&header.origX);
	sglEndianSwap(&header.origY);
	sglEndianSwap(&header.width);
	sglEndianSwap(&header.height);
//#endif
	
	unsigned int num_bytes;
	if( header.bpp == 32 )
		num_bytes = header.width * header.height * 4;
	else
		num_bytes = header.width * header.height * 3;
	
	BYTE *image = new BYTE[num_bytes];
	
	if( image )
	{
		if(f.Read( image,num_bytes) != 1 )
		{
			delete image;
			return 0;
		}
		
		// swap image to RGB(a) instead of BGR(a)
		if( header.bpp == 24 )
		{
			for( int i=0; i < (header.width * header.height) ; i++ )
			{
				char tmp;
				tmp = image[i*3+0];
				image[i*3+0] = image[i*3+2];
				image[i*3+2] = tmp;
			}
		}
		else
		{
			for( int i=0; i < (header.width * header.height); i++ )
			{
				char tmp;
				tmp = image[i*4+0];
				image[i*4+0] = image[i*4+2];
				image[i*4+2] = tmp;
			}
		}
	}
	f.Close();
	
	m_pImage = new BYTE[num_bytes];
	memcpy(m_pImage,image,num_bytes);
	m_bRGBIndexed = true;

	m_BmpInfoHead.biSizeImage	= num_bytes;
	m_BmpInfoHead.biWidth	= header.width;
	m_BmpInfoHead.biHeight	= header.height;
	m_BmpInfoHead.biBitCount= ( header.bpp == 32 )?(4*8):(3*8);
	delete image;
	return true;
}

BITMAPINFOHEADER CImageLoader::GetImageInfo()
{
	return m_BmpInfoHead;
}

void CImageLoader::InitBmpInfo()
{
	m_BmpInfoHead.biSizeImage		= 0; 
	m_BmpInfoHead.biWidth			= 0; 
	m_BmpInfoHead.biHeight			= 0; 
	m_BmpInfoHead.biBitCount		= 0; 

	m_BmpInfoHead.biSize			= sizeof(BITMAPINFOHEADER); 
	m_BmpInfoHead.biPlanes			= 1; 
	m_BmpInfoHead.biCompression		= BI_RGB; 
	m_BmpInfoHead.biXPelsPerMeter	= 0; 
	m_BmpInfoHead.biYPelsPerMeter	= 0; 
	m_BmpInfoHead.biClrUsed			= 0; 
	m_BmpInfoHead.biClrImportant	= 0; 

}


bool CImageLoader::LoadxImage(CString sFileName)
{
	int pos = sFileName.ReverseFind('.');
	CString sExt = sFileName.Right(sFileName.GetLength()-pos-1);
	int type = FindType(sExt);
	CxImage img(sFileName, type);

	if (!img.IsValid())
	{
		AfxMessageBox(sFileName+"��ȡ����"+img.GetLastError());
		return false;
	}
	m_bRGBIndexed = false;

	LPBITMAPINFO lpi = (LPBITMAPINFO)img.GetDIB();
	LPBITMAPINFOHEADER lp = (LPBITMAPINFOHEADER)img.GetDIB();
	m_BmpInfoHead = *lp;
	m_pImage = NULL;
	m_pImage = new BYTE[m_BmpInfoHead.biSizeImage];
	memcpy(m_pImage,img.GetBits(),m_BmpInfoHead.biSizeImage);
// 	if(img != NULL)
// 	{
// 		delete img;
// 		img = NULL;
// 	}
	return true;
}

int CImageLoader::FindType(CString sFileExt)
{
		int type = 0;
		if (sFileExt == "bmp")						type = CXIMAGE_FORMAT_BMP;
	#if CXIMAGE_SUPPORT_JPG
		else if (sFileExt=="jpg"||sFileExt=="jpeg")	type = CXIMAGE_FORMAT_JPG;
	#endif
	#if CXIMAGE_SUPPORT_GIF
		else if (sFileExt == "gif")					type = CXIMAGE_FORMAT_GIF;
	#endif
	#if CXIMAGE_SUPPORT_PNG
		else if (sFileExt == "png")					type = CXIMAGE_FORMAT_PNG;
	#endif
	#if CXIMAGE_SUPPORT_MNG
		else if (sFileExt=="mng"||sFileExt=="jng")	type = CXIMAGE_FORMAT_MNG;
	#endif
	#if CXIMAGE_SUPPORT_ICO
		else if (sFileExt == "ico")					type = CXIMAGE_FORMAT_ICO;
	#endif
	#if CXIMAGE_SUPPORT_TIF
		else if (sFileExt=="tiff"||sFileExt=="tif")	type = CXIMAGE_FORMAT_TIF;
	#endif
	#if CXIMAGE_SUPPORT_TGA
		else if (sFileExt=="tga")					type = CXIMAGE_FORMAT_TGA;
	#endif
	#if CXIMAGE_SUPPORT_PCX
		else if (sFileExt=="pcx")					type = CXIMAGE_FORMAT_PCX;
	#endif
	#if CXIMAGE_SUPPORT_WBMP
		else if (sFileExt=="wbmp")					type = CXIMAGE_FORMAT_WBMP;
	#endif
	#if CXIMAGE_SUPPORT_WMF
		else if (sFileExt=="wmf"||sFileExt=="emf")	type = CXIMAGE_FORMAT_WMF;
	#endif
	#if CXIMAGE_SUPPORT_J2K
		else if (sFileExt=="j2k"||sFileExt=="jp2")	type = CXIMAGE_FORMAT_J2K;
	#endif
	#if CXIMAGE_SUPPORT_JBG
		else if (sFileExt=="jbg")					type = CXIMAGE_FORMAT_JBG;
	#endif
	#if CXIMAGE_SUPPORT_JP2
		else if (sFileExt=="jp2"||sFileExt=="j2k")	type = CXIMAGE_FORMAT_JP2;
	#endif
	#if CXIMAGE_SUPPORT_JPC
		else if (sFileExt=="jpc"||sFileExt=="j2c")	type = CXIMAGE_FORMAT_JPC;
	#endif
	#if CXIMAGE_SUPPORT_PGX
		else if (sFileExt=="pgx")					type = CXIMAGE_FORMAT_PGX;
	#endif
	#if CXIMAGE_SUPPORT_RAS
		else if (sFileExt=="ras")					type = CXIMAGE_FORMAT_RAS;
	#endif
	#if CXIMAGE_SUPPORT_PNM
		else if (sFileExt=="pnm"||sFileExt=="pgm"||sFileExt=="ppm") type = CXIMAGE_FORMAT_PNM;
	#endif
		else										type = CXIMAGE_FORMAT_UNKNOWN;

		return type;

}


bool CImageLoader::IsRGBIndexed()
{
	return m_bRGBIndexed;
}

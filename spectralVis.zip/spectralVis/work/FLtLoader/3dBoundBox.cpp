// 3dBoundBox.cpp: implementation of the C3dBoundBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "3dBoundBox.h"
#include "glut.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3dBoundBox::C3dBoundBox()
{
	m_Max.SetData(-MAX_NUM, -MAX_NUM, -MAX_NUM);
	m_Min.SetData( MAX_NUM,  MAX_NUM,  MAX_NUM);
}

C3dBoundBox::~C3dBoundBox()
{

}

///���������Сֵ
void C3dBoundBox::SetMinMax(float dx, float dy, float dz)
{
	if (dx < m_Min.x)  m_Min.x = dx;
	if (dx > m_Max.x)  m_Max.x = dx;
	
	if (dy < m_Min.y)  m_Min.y = dy;
	if (dy > m_Max.y)  m_Max.y = dy;

	if (dz < m_Min.z)  m_Min.z = dz;
	if (dz > m_Max.z)  m_Max.z = dz;
}

void C3dBoundBox::SetMinMax(C3dBoundBox *pBox)
{
	if (pBox->m_Min.x < m_Min.x)
		m_Min.x = pBox->m_Min.x;
	if (pBox->m_Max.x > m_Max.x)
		m_Max.x = pBox->m_Max.x;

	if (pBox->m_Min.y < m_Min.y)
		m_Min.y = pBox->m_Min.y;
	if (pBox->m_Max.y > m_Max.y)
		m_Max.y = pBox->m_Max.y;

	if (pBox->m_Min.z < m_Min.z)
		m_Min.z = pBox->m_Min.z;
	if (pBox->m_Max.z > m_Max.z)
		m_Max.z = pBox->m_Max.z;
}

void C3dBoundBox::Display(float LineWidth, float cr, float cg, float cb)
{
	///���浱ǰ��״̬
	BOOL  bLighting = glIsEnabled(GL_LIGHTING);
	BOOL  bTexture  = glIsEnabled(GL_TEXTURE_2D);
	
	///��ֹ�ƹ��Լ�����ӳ��
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	
	glColor4f(cr, cg, cb,0.3);
// 	glLineWidth(LineWidth);
	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glBlendFunc(GL_SRC_ALPHA ,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glBegin(GL_QUADS);
	  glVertex3d(m_Max.x, m_Max.y, m_Max.z);  ///p1
	  glVertex3d(m_Max.x, m_Min.y, m_Max.z);  ///p2
	  glVertex3d(m_Min.x, m_Min.y, m_Max.z);  ///p3
	  glVertex3d(m_Min.x, m_Max.y, m_Max.z);  ///p4

	  glVertex3d(m_Max.x, m_Max.y, m_Max.z);  ///p1
	  glVertex3d(m_Max.x, m_Max.y, m_Min.z);  ///p7
	  glVertex3d(m_Max.x, m_Min.y, m_Min.z);  ///p6
	  glVertex3d(m_Max.x, m_Min.y, m_Max.z);  ///p5

	  glVertex3d(m_Max.x, m_Max.y, m_Min.z);  ///p8
	  glVertex3d(m_Min.x, m_Max.y, m_Min.z);  ///p7
	  glVertex3d(m_Min.x, m_Min.y, m_Min.z);  ///p6
	  glVertex3d(m_Max.x, m_Min.y, m_Min.z);  ///p2

	  glVertex3d(m_Min.x, m_Max.y, m_Min.z);  ///p3
	  glVertex3d(m_Min.x, m_Max.y, m_Max.z);  ///p5
	  glVertex3d(m_Min.x, m_Min.y, m_Max.z);  ///p8
	  glVertex3d(m_Min.x, m_Min.y, m_Min.z);  ///p4
   
	  glVertex3d(m_Min.x, m_Max.y, m_Max.z);  ///p3
	  glVertex3d(m_Min.x, m_Max.y, m_Min.z);  ///p5
	  glVertex3d(m_Max.x, m_Max.y, m_Min.z);  ///p8
	  glVertex3d(m_Max.x, m_Max.y, m_Max.z);  ///p4

      glVertex3d(m_Min.x, m_Min.y, m_Max.z);  ///p3
	  glVertex3d(m_Max.x, m_Min.y, m_Max.z);  ///p4
	  glVertex3d(m_Max.x, m_Min.y, m_Min.z);  ///p8
	  glVertex3d(m_Min.x, m_Min.y, m_Min.z);  ///p5
	  
	glEnd();

	glColor4f(0,1,0,0.5);


	glBegin(GL_LINES);
	  glVertex3d(m_Max.x, m_Max.y, m_Max.z);  ///p1
	  glVertex3d(m_Max.x, m_Min.y, m_Max.z);  ///p2

	  glVertex3d(m_Max.x, m_Min.y, m_Max.z);  ///p2
	  glVertex3d(m_Min.x, m_Min.y, m_Max.z);  ///p3

	  glVertex3d(m_Min.x, m_Min.y, m_Max.z);  ///p3
	  glVertex3d(m_Min.x, m_Max.y, m_Max.z);  ///p4

	  glVertex3d(m_Min.x, m_Max.y, m_Max.z);  ///p4
	  glVertex3d(m_Max.x, m_Max.y, m_Max.z);  ///p1

	  /////////////////////////////////////////////

	  glVertex3d(m_Max.x, m_Max.y, m_Min.z);  ///p1
	  glVertex3d(m_Max.x, m_Min.y, m_Min.z);  ///p2

	  glVertex3d(m_Max.x, m_Min.y, m_Min.z);  ///p2
	  glVertex3d(m_Min.x, m_Min.y, m_Min.z);  ///p3

	  glVertex3d(m_Min.x, m_Min.y, m_Min.z);  ///p3
	  glVertex3d(m_Min.x, m_Max.y, m_Min.z);  ///p4

	  glVertex3d(m_Min.x, m_Max.y, m_Min.z);  ///p4
	  glVertex3d(m_Max.x, m_Max.y, m_Min.z);  ///p1

	  //////////////////////////////////////////////

	  glVertex3d(m_Max.x, m_Max.y, m_Max.z);  ///p1
	  glVertex3d(m_Max.x, m_Max.y, m_Min.z);  ///p1

	  glVertex3d(m_Max.x, m_Min.y, m_Max.z);  ///p2
	  glVertex3d(m_Max.x, m_Min.y, m_Min.z);  ///p2

	  glVertex3d(m_Min.x, m_Min.y, m_Max.z);  ///p3
	  glVertex3d(m_Min.x, m_Min.y, m_Min.z);  ///p3
	  
	  glVertex3d(m_Min.x, m_Max.y, m_Max.z);  ///p4
	  glVertex3d(m_Min.x, m_Max.y, m_Min.z);  ///p4



	glEnd();


	glDisable(GL_BLEND);
	///�ָ�ԭ����״̬
	if(bLighting) glEnable(GL_LIGHTING);
	if(bTexture)  glEnable(GL_TEXTURE_2D);
}

GLfloat C3dBoundBox::GetWidth()
{
	return (m_Max.x - m_Min.x);
}

GLfloat C3dBoundBox::GetHeight()
{
	return (m_Max.z - m_Min.z);
}

GLfloat C3dBoundBox::GetLength()
{
	return (m_Max.y - m_Min.y);
}

BOOL C3dBoundBox::IsPointInside(double x, double y, double z)
{
	if (x>m_Max.x)
		return  FALSE;
	if (y>m_Max.y)
		return FALSE;
	if (z>m_Max.z)
		return FALSE;

	if (x<m_Min.x)
		return FALSE;
	if (y<m_Min.y)
		return FALSE;
	if (z<m_Min.z)
		return FALSE;

	return TRUE;
}

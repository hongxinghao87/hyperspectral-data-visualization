// ImageLoader.h: interface for the CImageLoader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMAGELOADER_H__94923238_F42F_492D_97DE_29CECF72D71A__INCLUDED_)
#define AFX_IMAGELOADER_H__94923238_F42F_492D_97DE_29CECF72D71A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "cximage/ximage.h"

class CImageLoader  
{
public:
	bool IsRGBIndexed();
	CImageLoader();
	virtual ~CImageLoader();

	BITMAPINFOHEADER GetImageInfo();		//���ͼ���ʽ��Ϣm_BmpInfoHead
	void* LoadImage(CString sFileName);		//���ͼ������ָ��m_pImage

protected:
	bool m_bRGBIndexed;
	int FindType(CString sFileExt);
	bool LoadxImage(CString sFileName);
	void RegulateImage();					//��ʽ��ͼ�񣺳���Ϊ2����
	void InitBmpInfo();						//��ʼ��ͼ���ʽ��Ϣm_BmpInfoHead

	bool LoadImageBMP(CString sFileName);	//�������BMP
	bool LoadImageSGI(CString sFileName);	//����INT,INTA, RGB,RGBA
	bool LoadImageTGA(CString sFileName);	//����TGA

	//����
	BITMAPINFOHEADER m_BmpInfoHead;
	BYTE* m_pImage;



	void sglEndianSwap(unsigned int *x)
	{
	   *x = (( *x >> 24 ) & 0x000000FF ) |
			(( *x >>  8 ) & 0x0000FF00 ) |
			(( *x <<  8 ) & 0x00FF0000 ) |
			(( *x << 24 ) & 0xFF000000 ) ;
	}

	void sglEndianSwap(int *x)
	{
	   *x = (( *x >> 24 ) & 0x000000FF ) |
			(( *x >>  8 ) & 0x0000FF00 ) |
			(( *x <<  8 ) & 0x00FF0000 ) |
			(( *x << 24 ) & 0xFF000000 ) ;
	}

	void sglEndianSwap(unsigned short *x)
	{
	   *x = (( *x >>  8 ) & 0x00FF ) |
			(( *x <<  8 ) & 0xFF00 ) ;
	}

	void sglEndianSwap(short *x)
	{
	   *x = (( *x >>  8 ) & 0x00FF ) |
			(( *x <<  8 ) & 0xFF00 ) ;
	}

};

#endif // !defined(AFX_IMAGELOADER_H__94923238_F42F_492D_97DE_29CECF72D71A__INCLUDED_)

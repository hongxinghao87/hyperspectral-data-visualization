// 3dBoundBox.h: interface for the C3dBoundBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DBOUNDBOX_H__8EBD4C1E_2417_4EEE_B0F2_71DE36A2B245__INCLUDED_)
#define AFX_3DBOUNDBOX_H__8EBD4C1E_2417_4EEE_B0F2_71DE36A2B245__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define       MAX_NUM               99
#include    "Vectorf.h"


///��ά�����Ӧ�İ�Χ����
class C3dBoundBox  
{
public:
	float GetLength();
	float GetHeight();
	float GetWidth();
	void Display(float LineWidth, float cr, float cg, float cb);
	void SetMinMax(C3dBoundBox *pBox);
	void SetMinMax(float dx, float dy, float dz);
	C3dBoundBox();
	virtual ~C3dBoundBox();

public:
	BOOL IsPointInside(double x, double y, double z);
	CVectorf   m_Min;
	CVectorf   m_Max;
};

#endif // !defined(AFX_3DBOUNDBOX_H__8EBD4C1E_2417_4EEE_B0F2_71DE36A2B245__INCLUDED_)

// Vectorf.h: interface for the CVectorf class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VECTORF_H__AB56CA1A_BD7A_4084_A343_2B2E26AE15FF__INCLUDED_)
#define AFX_VECTORF_H__AB56CA1A_BD7A_4084_A343_2B2E26AE15FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVectorf  
{
public:
public:
	float x;   // x,y,z coordinates
	float y;
	float z;    
	
public:
	void Normalize();
	float Length();
	float DotProduct(CVectorf &vec);
	CVectorf CrossProduct(CVectorf &vec);
	const CVectorf operator /(const float &s) const;		
	const CVectorf operator *(const float &s) const;	
	const CVectorf& operator /=(const float &s);			
	const CVectorf& operator *=(const float &s);		
	const CVectorf& operator -=(const CVectorf &vec);
	const CVectorf operator-() const;
	const CVectorf operator-(const CVectorf &vec) const;
	const CVectorf& operator +=(const CVectorf &vec);
	const CVectorf operator+() const;
	const CVectorf operator+(const CVectorf &vec) const;
	const BOOL operator !=(const CVectorf &vec) const;
	const BOOL operator ==(const CVectorf &vec) const;
	const CVectorf& operator =(const CVectorf &vec);
	void SetData(float a, float b, float c);
	CVectorf(const CVectorf &vec);
	CVectorf(float a=0, float b=0, float c=0);
	virtual ~CVectorf();

};

#endif // !defined(AFX_VECTORF_H__AB56CA1A_BD7A_4084_A343_2B2E26AE15FF__INCLUDED_)

// Vectorf.cpp: implementation of the CVectorf class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "../GlobalView.h"
#include "Vectorf.h"
#include "math.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVectorf::CVectorf(float a, float b, float c)
{
	x = a; y = b; z = c; 
}

CVectorf::~CVectorf()
{

}

CVectorf::CVectorf(const CVectorf &vec)
{
	x = vec.x;
	y = vec.y;
	z = vec.z;
}

void CVectorf::SetData(float a, float b, float c)
{
	x = a;  y = b; z = c;
}

const CVectorf& CVectorf::operator =(const CVectorf &vec)
{
	x = vec.x;
	y = vec.y;
	z = vec.z;

	return *this;
}

const BOOL CVectorf::operator ==(const CVectorf &vec) const
{
	return ((x == vec.x) && (y == vec.y) && (z == vec.z));
}

const BOOL CVectorf::operator !=(const CVectorf &vec) const
{
	return !(*this == vec);
}

const CVectorf CVectorf::operator +(const CVectorf &vec) const
{
	return CVectorf(x + vec.x, y + vec.y, z + vec.z);
}

const CVectorf CVectorf::operator +() const
{
	return CVectorf(*this);
}

const CVectorf& CVectorf::operator +=(const CVectorf &vec)
{
	x += vec.x;
	y += vec.y;
	z += vec.z;

	return *this;
}

const CVectorf CVectorf::operator -(const CVectorf &vec) const
{
	return CVectorf(x - vec.x, y - vec.y, z - vec.z);
}

const CVectorf CVectorf::operator -() const
{
	return CVectorf(-x, -y, -z);
}

const CVectorf& CVectorf::operator -=(const CVectorf &vec)
{
	x -= vec.x;
	y -= vec.y;
	z -= vec.z;
	
	return *this;
}

const CVectorf& CVectorf::operator *=(const float &s)
{
	x *= s;
	y *= s;
	z *= s;
	
	return *this;
}

const CVectorf& CVectorf::operator /=(const float &s)
{
	const float recip = 1/s; // for speed, one divecision

	x *= recip;
	y *= recip;
	z *= recip;
	
	return *this;
}

const CVectorf CVectorf::operator *(const float &s) const
{
	return CVectorf(x*s, y*s, z*s);
}

const CVectorf CVectorf::operator /(const float &s) const
{
	float scal = 1/s;

	return CVectorf(x*scal, y*scal, z*scal);
}

CVectorf CVectorf::CrossProduct(CVectorf &vec)
{
	return CVectorf(y*vec.z - z*vec.y, z*vec.x - x*vec.z, x*vec.y - y*vec.x);
}

float CVectorf::DotProduct(CVectorf &vec)
{
	return x*vec.x + y*vec.x + z*vec.z;
}

float CVectorf::Length()
{
	return sqrtf((x*x + y*y + z*z));
}

void CVectorf::Normalize()
{
	(*this) /= Length();
}


// GeoLayer.cpp: implementation of the CGeoLayer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "GeoLayer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGeoLayer::CGeoLayer()
{
	scale=1;
	h_scale=1;//100*scale*1.0/6378137
	data = NULL;
	m_dHighScale = 1;
	m_pCamera = NULL;
// 	m_nOTreeLevel = -1;
}

CGeoLayer::~CGeoLayer()
{
	if (data)
	{
		delete []data;
	}
	if (glIsTexture(m_nImageList))
	{
		glDeleteTextures(1,&m_nImageList);
	}
	if (glIsList(m_nGridList))
	{
		glDeleteLists(m_nGridList,4);
	}

//  	RealseOtree(&m_OTreeRoot);
}
void CGeoLayer::Init()
{
	CString str;
	GetModuleFileName(NULL,str.GetBuffer(1024),1024);
	str.ReleaseBuffer();
	int nPos = str.ReverseFind('\\');
	str.Delete(nPos+1,str.GetLength()-nPos-1);
	LoadImage(str+"data\\GeoData\\Sanfrancisco.bmp");
	Load(str+"data\\GeoData\\Sanfrancisco.txt");
	GenGridList();
}
void CGeoLayer::Render()
{
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
// 	DrawOtree();
	glEnable(GL_LIGHTING); 
	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

// 	glDisable(GL_TEXTURE_2D);
// 	glDisable(GL_LIGHTING);
// 	glColor3f(1,0,0);
// 	glBegin(GL_LINES);
// 	glVertex3f(BottomPt.x,BottomPt.y,BottomPt.z);
// 	glVertex3f(TopPt.x,TopPt.y,TopPt.z);
// 	glEnd();
// 
// 
// 	glPushMatrix();
// 	glScalef(1,m_dHighScale,1);
// 	glColor3f(1, 1, 1);
// 	glLineWidth(2.0f);
// 	glBegin(GL_LINE_LOOP);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMin[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMin[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMax[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMax[1], m_dRangeMin[2]);
// 	glEnd();
// 	
// 	glBegin(GL_LINE_LOOP);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMin[1], m_dRangeMax[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMin[1], m_dRangeMax[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMax[1], m_dRangeMax[2]);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMax[1], m_dRangeMax[2]);
// 	glEnd();
// 	
// 	glBegin(GL_LINES);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMin[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMin[1], m_dRangeMax[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMin[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMin[1], m_dRangeMax[2]);
// 	
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMax[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMin[0],	m_dRangeMax[1], m_dRangeMax[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMax[1], m_dRangeMin[2]);
// 	glVertex3f(m_dRangeMax[0],	m_dRangeMax[1], m_dRangeMax[2]);
// 	glEnd();
// 	glPopMatrix();
	//----����--------------------------------------------
// 	glDisable(GL_TEXTURE_2D);
// 	glDisable(GL_LIGHTING);
// 	double dx = m_dRangeMax[0]*0.36;
// 	double dz = m_dRangeMax[2]*0.59;
// 	double dH;
// 	GetElv(dx,dz,dH);
// 	glPushMatrix();
// 	glColor3f(1, 1, 1);
// 	glLineWidth(2);
// 	glTranslatef(dx,0,dz);
// 	glBegin(GL_LINES);
// 	glVertex3f(0,0,0);
// 	glVertex3f(0,10*m_dRangeMax[1],0);
// 	glEnd();
// 	glColor3f(1,0,0);
// 	glPointSize(10);
// 	glBegin(GL_POINTS);
// 	glVertex3f(0,dH*h_scale*m_dHighScale,0);
// 	glEnd();
// 	glPopMatrix();
	//----����--------------------------------------------


	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
 	glTranslatef(-m_dMoveX,-m_dMoveY,-m_dMoveZ);
	glScalef(1,m_dHighScale,1);
	glCallList(m_nGridList);
	glCallList(m_nGridList+1);
	glCallList(m_nGridList+2);
	glCallList(m_nGridList+3);
	glPopAttrib();
	glPopMatrix();
}
void CGeoLayer::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch(nChar)
	{
	case VK_INSERT:
		m_dHighScale *= 1.1;
		break;
	case VK_DELETE:
		m_dHighScale *= 0.9;
		break;
	default:
	    break;
	}
}
BOOL CGeoLayer::Load(const char *pszfilename)
{
	FILE *fp=NULL;
	char ValueType[100];
	fp=fopen(pszfilename,"r");
	fscanf(fp,"north: %f\n",&(dNorth));
	fscanf(fp,"south: %f\n",&(dSouth));
	fscanf(fp,"east: %f\n",&(dEast));
	fscanf(fp,"west: %f\n",&(dWest));
	fscanf(fp,"rows: %d\n",&(Row));
	fscanf(fp,"cols: %d\n",&(Col));
	fscanf(fp,"null: %f\n",&(dNull));
	fscanf(fp,"type: %s\n",&ValueType);
	fscanf(fp,"\n");

	data=new DEMData[Col*Row];
	float B1=dNorth,B2=dSouth,
		  L1=dWest,L2=dEast;
	DX = (dEast - dWest)/(Col-1);
	DY = (dNorth - dSouth)/(Row-1);

	scale=0.1/DX;
	//if (DX < 1.0)
	//{
	//	h_scale = scale*1.0/6378137;
	//}else
	//	h_scale = 0.1*scale;
	h_scale = scale;

	m_dMinElv = 10000;
	m_dMaxElv = -10000;
	int i=0,j=0;
	float zz;
	for (i=0;i < Row;i++)
	{
		for (j = 0; j< Col;j++)
		{
			data[i*Col+j].X=dWest + j*DX;
			data[i*Col+j].Y=dSouth + i*DY;
			fscanf(fp,"%f",&zz);
			if (zz == dNull)
			{
				zz = 0;
			}else
			{
				if (zz < m_dMinElv)
				{
					m_dMinElv = zz;
				}
				if (zz > m_dMaxElv)
				{
					m_dMaxElv = zz;
				}
			}
			data[i*Col+j].Z=zz;
		}
	}
	m_dMoveX = (dEast - dWest)*scale/2;
	m_dMoveZ = m_dMoveX;
	m_dMoveY = m_dMoveX;
	//m_dMoveZ = (dNorth - dSouth)*scale/2;
	//m_dMoveY = (m_dMaxElv - m_dMinElv)*h_scale;
	

	return TRUE;

}

void CGeoLayer::GenGridList()
{
	double dMinH = 10000;
	double dMaxH = -10000;
	double dx,dy,dz;
	GLint x,y;
	m_nGridList = glGenLists(4);
	glNewList(m_nGridList,GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture( GL_TEXTURE_2D,m_nImageList);
	for (x=0;x<Col/2;x=x+1)
	{
		for (y=0;y<Row/2;y=y+1)
		{	
			glBegin(GL_TRIANGLES);
			dx = data[y*Col+x].X - dWest;
			dy = data[y*Col+x].Y - dSouth;
			dz = data[y*Col+x].Z - m_dMinElv;
			if (dz < 0)
				dz = 0;
			glTexCoord2d( (float)x/Col,1- (float)y/Row );
			glVertex3f(dx*scale,	
				dz*h_scale,
				dy*scale);

			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			dz = data[(y+1)*Col+x].Z - m_dMinElv;
			if (dz < 0)
				dz = 0;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				dz*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			dz = data[y*Col+x+1].Z - m_dMinElv;
			if (dz < 0)
				dz = 0;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				dz*h_scale,
				dy*scale);


			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			dz = data[(y+1)*Col+x].Z - m_dMinElv;
			if (dz < 0)
				dz = 0;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				dz*h_scale,
				dy*scale);

			dx = data[(y+1)*Col+x+1].X - dWest;
			dy = data[(y+1)*Col+x+1].Y - dSouth;
			dz = data[(y+1)*Col+x+1].Z - m_dMinElv;
			if (dz < 0)
				dz = 0;
			glTexCoord2d( (float)(x+1)/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				dz*h_scale,
				dy*scale);

			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			dz = data[y*Col+x+1].Z - m_dMinElv;
			if (dz < 0)
				dz = 0;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				dz*h_scale,
				dy*scale);

			glEnd();

			if (data[y*Col+x].Z > dMaxH)
				dMaxH = data[y*Col+x].Z;
			if (data[y*Col+x].Z < dMinH)
				dMinH = data[y*Col+x].Z;
		}
	}
	glEndList();

	glNewList(m_nGridList+1,GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture( GL_TEXTURE_2D,m_nImageList);
	for (x=Col/2;x<Col-1;x=x+1)
	{
		for (y=0;y<Row/2;y=y+1)
		{	
			glBegin(GL_TRIANGLES);
			dx = data[y*Col+x].X - dWest;
			dy = data[y*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)y/Row );
			glVertex3f(dx*scale,	
				data[y*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				data[y*Col+x+1].Z*h_scale,
				dy*scale);
			
			
			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[(y+1)*Col+x+1].X - dWest;
			dy = data[(y+1)*Col+x+1].Y - dSouth;
			glTexCoord2d( (float)(x+1)/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x+1].Z*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				data[y*Col+x+1].Z*h_scale,
				dy*scale);
			
			glEnd();
			
			if (data[y*Col+x].Z > dMaxH)
				dMaxH = data[y*Col+x].Z;
			if (data[y*Col+x].Z < dMinH)
				dMinH = data[y*Col+x].Z;
		}
	}
	glEndList();

	glNewList(m_nGridList+2,GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture( GL_TEXTURE_2D,m_nImageList);
	for (x=Col/2;x<Col-1;x=x+1)
	{
		for (y=Row/2;y<Row-1;y=y+1)
		{	
			glBegin(GL_TRIANGLES);
			dx = data[y*Col+x].X - dWest;
			dy = data[y*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)y/Row );
			glVertex3f(dx*scale,	
				data[y*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				data[y*Col+x+1].Z*h_scale,
				dy*scale);
			
			
			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[(y+1)*Col+x+1].X - dWest;
			dy = data[(y+1)*Col+x+1].Y - dSouth;
			glTexCoord2d( (float)(x+1)/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x+1].Z*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				data[y*Col+x+1].Z*h_scale,
				dy*scale);
			
			glEnd();
			
			if (data[y*Col+x].Z > dMaxH)
				dMaxH = data[y*Col+x].Z;
			if (data[y*Col+x].Z < dMinH)
				dMinH = data[y*Col+x].Z;
		}
	}
	glEndList();

	glNewList(m_nGridList+3,GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture( GL_TEXTURE_2D,m_nImageList);
	for (x=0;x<Col/2;x=x+1)
	{
		for (y=Row/2;y<Row-1;y=y+1)
		{	
			glBegin(GL_TRIANGLES);
			dx = data[y*Col+x].X - dWest;
			dy = data[y*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)y/Row );
			glVertex3f(dx*scale,	
				data[y*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				data[y*Col+x+1].Z*h_scale,
				dy*scale);
			
			
			dx = data[(y+1)*Col+x].X - dWest;
			dy = data[(y+1)*Col+x].Y - dSouth;
			glTexCoord2d( (float)x/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x].Z*h_scale,
				dy*scale);
			
			dx = data[(y+1)*Col+x+1].X - dWest;
			dy = data[(y+1)*Col+x+1].Y - dSouth;
			glTexCoord2d( (float)(x+1)/Col,1- (float)(y+1)/Row );
			glVertex3f(dx*scale,	
				data[(y+1)*Col+x+1].Z*h_scale,
				dy*scale);
			
			dx = data[y*Col+x+1].X - dWest;
			dy = data[y*Col+x+1].Y - dSouth;
			glTexCoord2d((float)(x+1)/Col, 1-(float)y/Row );
			glVertex3f(dx*scale,
				data[y*Col+x+1].Z*h_scale,
				dy*scale);
			
			glEnd();
			
			if (data[y*Col+x].Z > dMaxH)
				dMaxH = data[y*Col+x].Z;
			if (data[y*Col+x].Z < dMinH)
				dMinH = data[y*Col+x].Z;
		}
	}
	glEndList();

	m_dRangeMin[0] = -m_dMoveX;
	m_dRangeMin[1] = dMinH*h_scale;
	m_dRangeMin[2] = -m_dMoveZ;

	m_dRangeMax[0] = m_dMoveX;
	m_dRangeMax[1] = dMaxH*h_scale;
	m_dRangeMax[2] = m_dMoveZ;

// 	CreatOtree(4);
}
void CGeoLayer::LoadImage(CString strPath)
{
	m_nImageList = glGenLists(1);
	// ��ָ����ͼ��
	CFile file;
	CFileException ex;
	if( !file.Open(strPath, CFile::modeRead,NULL ) ) return ;

	BITMAPFILEHEADER bmFileHeader;
	file.Read( (void*)&bmFileHeader, sizeof(bmFileHeader) );
	BITMAPINFO bitInfo;
	file.Read( (void*)&bitInfo, sizeof(bmFileHeader) );

	int nWidth,nHigh;
	nWidth = bitInfo.bmiHeader.biWidth;
	nHigh  = bitInfo.bmiHeader.biHeight;
	if(bmFileHeader.bfType != 0x4d42 ) return ;
	else
	{
		DWORD dibSize = file.GetLength() - sizeof(bmFileHeader);
		int kk = sizeof(BITMAPINFO);
		file.Seek(  - 4, CFile::current );//sizeof(BITMAPINFO)
		BYTE *pNorthImage = new BYTE[nWidth * nHigh * 3 ];
		file.Read( pNorthImage, nWidth * nHigh * 3 );

		// ������RGB��RGBAת��
		BYTE *tempImage = new BYTE[nWidth * nHigh * 4 ];
		int nPos1 = 0, nPos2 = 0;
		for(int i = 0; i < nHigh; i++)
		{
			for(int j = 0; j < nWidth; j++)
			{
				nPos1 = (i * nWidth + j) * 3;
				nPos2 = (i * nWidth + j) * 4;
				tempImage[nPos2] = pNorthImage[nPos1];
				tempImage[nPos2 + 1] = pNorthImage[nPos1 + 1];
				tempImage[nPos2 + 2] = pNorthImage[nPos1 + 2];
				tempImage[nPos2 + 3] = 255; 
			}
		}
		// ������
		glBindTexture(GL_TEXTURE_2D, m_nImageList);
		glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
		glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
		glTexImage2D( GL_TEXTURE_2D, 0, 4, nWidth, nHigh, 0, GL_BGRA_EXT,	
			GL_UNSIGNED_BYTE, tempImage );
		delete[] pNorthImage;
		delete[] tempImage;
	}

	// �ر��ļ�
	file.Close();	
}
bool CGeoLayer::GetElv(double dx,double dz,double &dH)
{
	dx = (dx + m_dMoveX)/scale;
	dz = (dz + m_dMoveZ)/scale;
	int nCol = dx/DX;
	int nRow = dz/DY;
	dx = dx - nCol*DX;
	dz = dz - nRow*DY;
	double dLTHigh,dRTHigh,dLBHigh,dRBHigh;
	if (nCol < Col-1&&nRow < Row -1)
	{
		dLTHigh = data[nRow*Col+nCol].Z;
		dRTHigh = data[nRow*Col+nCol + 1].Z;
		dLBHigh = data[(nRow+1)*(Col)+nCol].Z;
		dRBHigh = data[(nRow+1)*(Col)+nCol + 1].Z;
	}else if (nCol < Col-1)
	{
		dLTHigh = data[nRow*Col+nCol].Z;
		dRTHigh = data[nRow*Col+nCol + 1].Z;
		dLBHigh = data[(nRow)*(Col)+nCol].Z;
		dRBHigh = data[(nRow)*(Col)+nCol + 1].Z;
	}else if (nRow < Row -1)
	{
		dLTHigh = data[nRow*Col+nCol].Z;
		dRTHigh = data[nRow*Col+nCol].Z;
		dLBHigh = data[(nRow+1)*(Col)+nCol].Z;
		dRBHigh = data[(nRow+1)*(Col)+nCol].Z;
	}else
	{
		dLTHigh = data[nRow*Col+nCol].Z;
		dRTHigh = data[nRow*Col+nCol].Z;
		dLBHigh = data[(nRow)*(Col)+nCol].Z;
		dRBHigh = data[(nRow)*(Col)+nCol].Z;
	}
	if (dx*DY + dz*DX <= DX*DY)
	{
		double dxT = dLTHigh + (dRTHigh - dLTHigh)*dx/DX;
		double dxB = dLBHigh + (dRTHigh - dLBHigh)*dx/DX;
		double dzB = DY - DY*dx/DX;
		dH = dxT + (dxB - dxT)*dz/dzB;
		return true;
	}else
	{
		double dxB = dLBHigh + (dRBHigh - dLBHigh)*dx/DX;
		double dxT = dLBHigh + (dRTHigh - dLBHigh)*dx/DX;
		double dzT = DY - DY*dx/DX;
		dH = dxT + (dxB - dxT)*(dz- dzT)/(DY - dzT);
		return true;

	}
	return false;
}
bool CGeoLayer::PickPoint(CPoint scrPoint,vec3d &pt)
{
	if (m_pCamera)
	{
		vec3d point3D,point3D1;
		gluUnProject((GLdouble)scrPoint.x,(GLdouble)(m_pCamera->m_ncy - scrPoint.y),1.0,m_pCamera->modelviewInverse,m_pCamera->projmatrix,m_pCamera->viewportmatrix,&point3D.x,&point3D.y,&point3D.z);
		gluUnProject((GLdouble)scrPoint.x,(GLdouble)(m_pCamera->m_ncy - scrPoint.y),0.1,m_pCamera->modelviewInverse,m_pCamera->projmatrix,m_pCamera->viewportmatrix,&point3D1.x,&point3D1.y,&point3D1.z);		
		vec3d dir = point3D-point3D1;
		dir.Normalize();
		vec3d BottomPt,TopPt;

		double t = -point3D1.y/dir.y;
		BottomPt.x = point3D1.x + dir.x*t;
		BottomPt.y = 0;
		BottomPt.z = point3D1.z + dir.z*t;	
		
		t = (m_dRangeMax.y*m_dHighScale-point3D1.y)/dir.y;
		TopPt.x = point3D1.x + dir.x*t;
		TopPt.y = m_dRangeMax.y*m_dHighScale;
		TopPt.z = point3D1.z + dir.z*t;


		int nNum = 10;
		int i,k;
		vec3d vecStep = (BottomPt - TopPt)/(float)nNum;
		vec3d vecCur,vecPre;
		double dH ; 

		for (i = 0;i < nNum + 1;i++)
		{
			vecCur = TopPt + vecStep*((float)i);
			GetElv(vecCur.x,vecCur.z,dH);
			if (vecCur.y < dH*h_scale*m_dHighScale)
			{
				vecPre = TopPt + vecStep*((float)(i-1));
				vecStep = (vecCur - vecPre)/(float)nNum;
				for(i = 0;i<nNum + 1;i++)
				{
					vecCur = vecPre +  vecStep*((float)i);
					GetElv(vecCur.x,vecCur.z,dH);
					if (vecCur.y < dH*h_scale*m_dHighScale)
					{
						
						vecPre = vecPre + vecStep*((float)(i-1));
						vecStep = (vecCur - vecPre)/(float)nNum;
						for(i = 0;i<nNum + 1;i++)
						{
							vecCur = vecPre +  vecStep*((float)i);
							GetElv(vecCur.x,vecCur.z,dH);
							if (vecCur.y < dH*h_scale*m_dHighScale)
							{
								
								pt = vecPre +  vecStep*((float)(i-1));
								GetElv(pt.x,pt.z,pt.y);
								pt.y = pt.y*h_scale;
								return true;
							}
						}
					}
				}
			}
		}
	}
	return false;
}
void CGeoLayer::SetCamera(CCamera *pCamera)
{
	m_pCamera = pCamera;
}
void CGeoLayer::CreatOtree(int nLevel)
{
// 	m_OTreeRoot.m_dRangeMax = m_dRangeMin + 8*(m_dRangeMax-m_dRangeMin)/16.0;
// 	m_OTreeRoot.m_dRangeMin = m_dRangeMin + 10*(m_dRangeMax-m_dRangeMin)/16.0;
// 	m_nOTreeLevel = nLevel;
// 	m_OTreeRoot.m_dRangeMax[1] *= 8;
// 	CreatOneNode(&m_OTreeRoot,0);

}
void CGeoLayer::CreatOneNode(OTreeNode *par,int nLevel)
{
/*	if (nLevel<m_nOTreeLevel&&par)
	{
		par->childre0 = new OTreeNode;
		par->childre1 = new OTreeNode;
		par->childre2 = new OTreeNode;
		par->childre3 = new OTreeNode;
		par->childre4 = new OTreeNode;
		par->childre5 = new OTreeNode;
		par->childre6 = new OTreeNode;
		par->childre7 = new OTreeNode;
		
		par->childre0->m_dRangeMax[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre0->m_dRangeMax[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre0->m_dRangeMax[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		par->childre0->m_dRangeMin = par->m_dRangeMin;
		
		par->childre1->m_dRangeMax[0] = par->m_dRangeMax[0];
		par->childre1->m_dRangeMax[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre1->m_dRangeMax[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		par->childre1->m_dRangeMin[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre1->m_dRangeMin[1] = par->m_dRangeMin[1];
		par->childre1->m_dRangeMin[2] = par->m_dRangeMin[2];
		
		par->childre2->m_dRangeMax[0] = par->m_dRangeMax[0];
		par->childre2->m_dRangeMax[1] = par->m_dRangeMax[1];
		par->childre2->m_dRangeMax[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		par->childre2->m_dRangeMin[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre2->m_dRangeMin[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre2->m_dRangeMin[2] = par->m_dRangeMin[2];
		
		par->childre3->m_dRangeMax[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre3->m_dRangeMax[1] = par->m_dRangeMax[1];
		par->childre3->m_dRangeMax[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		par->childre3->m_dRangeMin[0] = par->m_dRangeMin[0];
		par->childre3->m_dRangeMin[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre3->m_dRangeMin[2] = par->m_dRangeMin[2];
//-------------------------------------------------------------------------------------
		par->childre4->m_dRangeMax[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre4->m_dRangeMax[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre4->m_dRangeMax[2] = par->m_dRangeMax[2];
		par->childre4->m_dRangeMin[0] = par->m_dRangeMin[0];
		par->childre4->m_dRangeMin[1] = par->m_dRangeMin[1];
		par->childre4->m_dRangeMin[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		
		par->childre5->m_dRangeMax[0] = par->m_dRangeMax[0];
		par->childre5->m_dRangeMax[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre5->m_dRangeMax[2] = par->m_dRangeMax[2];
		par->childre5->m_dRangeMin[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre5->m_dRangeMin[1] = par->m_dRangeMin[1];
		par->childre5->m_dRangeMin[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		
		par->childre6->m_dRangeMax[0] = par->m_dRangeMax[0];
		par->childre6->m_dRangeMax[1] = par->m_dRangeMax[1];
		par->childre6->m_dRangeMax[2] = par->m_dRangeMax[2];
		par->childre6->m_dRangeMin[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre6->m_dRangeMin[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre6->m_dRangeMin[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		
		par->childre7->m_dRangeMax[0] = par->m_dRangeMin[0] + (par->m_dRangeMax[0]-par->m_dRangeMin[0])/2.0;
		par->childre7->m_dRangeMax[1] = par->m_dRangeMax[1];
		par->childre7->m_dRangeMax[2] = par->m_dRangeMax[2];
		par->childre7->m_dRangeMin[0] = par->m_dRangeMin[0];
		par->childre7->m_dRangeMin[1] = par->m_dRangeMin[1] + (par->m_dRangeMax[1]-par->m_dRangeMin[1])/2.0;
		par->childre7->m_dRangeMin[2] = par->m_dRangeMin[2] + (par->m_dRangeMax[2]-par->m_dRangeMin[2])/2.0;
		CreatOneNode(par->childre0,nLevel+1);
		CreatOneNode(par->childre1,nLevel+1);
		CreatOneNode(par->childre2,nLevel+1);
		CreatOneNode(par->childre3,nLevel+1);
		CreatOneNode(par->childre4,nLevel+1);
		CreatOneNode(par->childre5,nLevel+1);
		CreatOneNode(par->childre6,nLevel+1);
		CreatOneNode(par->childre7,nLevel+1);
	}*/
}
void CGeoLayer::DrawOtree()
{
/*	int nCount = 0;
	DrawOneNode(&m_OTreeRoot,nCount);*/
}
void CGeoLayer::DrawOneNode(OTreeNode *par,int &nCount)
{
/*	if (par == NULL)
	{
		return;
	}
	if (par->childre0 == NULL)
	{
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		glPushMatrix();
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glScalef(1,m_dHighScale,1);
		if (nCount%5==0)
		{
			glColor4f(0, 1, 1,0.5);
		}else if (nCount%4==1)
		{
			glColor4f(1, 0, 0,0.5);
		}else if (nCount%4==2)
		{
			glColor4f( 0,1, 0,0.5);
		}else if (nCount%4==3)
		{
			glColor4f( 0, 0,1,0.5);
		}
		else
		{
			glColor4f( 1, 1,0,0.5);
		}
		glLineWidth(2.0f);
		glBegin(GL_LINE_LOOP);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glEnd();
		
		glBegin(GL_LINE_LOOP);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glEnd();
		
		glBegin(GL_LINES);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glEnd();

		glBegin(GL_QUADS);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glEnd();
		
		glBegin(GL_QUADS);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glEnd();

		glBegin(GL_QUADS);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMin[1], par->m_dRangeMin[2]);
		glEnd();

		glBegin(GL_QUADS);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glVertex3f(par->m_dRangeMin[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMax[2]);
		glVertex3f(par->m_dRangeMax[0],	par->m_dRangeMax[1], par->m_dRangeMin[2]);
		glEnd();
		glPopMatrix();
		glPopAttrib();
		nCount++;
		
		DrawOneNode(par->childre0,nCount);
		DrawOneNode(par->childre1,nCount);
		DrawOneNode(par->childre2,nCount);
		DrawOneNode(par->childre3,nCount);
		DrawOneNode(par->childre4,nCount);
		DrawOneNode(par->childre5,nCount);
		DrawOneNode(par->childre6,nCount);
		DrawOneNode(par->childre7,nCount);
	}else
	{
		DrawOneNode(par->childre0,nCount);
		DrawOneNode(par->childre1,nCount);
		DrawOneNode(par->childre2,nCount);
		DrawOneNode(par->childre3,nCount);
		DrawOneNode(par->childre4,nCount);
		DrawOneNode(par->childre5,nCount);
		DrawOneNode(par->childre6,nCount);
		DrawOneNode(par->childre7,nCount);
	}
*/
}
void CGeoLayer::RealseOtree(OTreeNode *par)
{
/*	if (par == NULL)
	{
		return;
	}
	if (par->childre0 == NULL)
	{
		delete []par;
		par = NULL;
		return;
	}else
	{
		RealseOtree(par->childre0);
		RealseOtree(par->childre1);
		RealseOtree(par->childre2);
		RealseOtree(par->childre4);
		RealseOtree(par->childre4);
		RealseOtree(par->childre5);
		RealseOtree(par->childre6);
		RealseOtree(par->childre1);
		par->childre0 = NULL;
		par->childre1 = NULL;
		par->childre2 = NULL;
		par->childre4 = NULL;
		par->childre4 = NULL;
		par->childre5 = NULL;
		par->childre6 = NULL;
		par->childre7 = NULL;
		return;
	}
	*/

}
// Camera.cpp: implementation of the CCamera class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "Camera.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCamera::CCamera()
{
	cameraPos.x = 0;
	cameraPos.y = 500;
	cameraPos.z = 500;

	lookatPos.x = 0;
	lookatPos.y = 0;
	lookatPos.z = 0;

	upDirect.x = 0;
	upDirect.y = 1;
	upDirect.z = 0;
	m_dDis = 5;
	m_dAzim = CalcuAzim(cameraPos,lookatPos);
	m_dTilt = CalcuTilt(cameraPos,lookatPos);
	m_dDis = (cameraPos - lookatPos).length()/3.0;
	CalcuCameraByDis();
	m_bAuto = false;
	m_bLBDown = false;
	m_bRBDown = false;
	m_ncx = 0;
	m_ncy = 0;
}

CCamera::~CCamera()
{

}
void CCamera::SetCamera()
{
	gluLookAt(cameraPos.x,cameraPos.y,cameraPos.z,
		lookatPos.x,lookatPos.y,lookatPos.z,
		upDirect.x,upDirect.y,upDirect.z);
	modelviewInverse.unit();

 	glGetDoublev(GL_MODELVIEW_MATRIX, modelviewInverse);
 	glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
	glGetIntegerv(GL_VIEWPORT,viewportmatrix);


	
// 	modelviewInverse.invert();


// 	vec3f point3D;
// 	vec3f ori;
// 	ori.x = 0;//
// 	ori.y = 0;//
// 	ori.z = -1;
// 	point3D.x = modelviewInverse.m[0][0]*ori.x + modelviewInverse.m[0][1]*ori.y + modelviewInverse.m[0][2]*ori.z + modelviewInverse.m[0][3];
// 	point3D.y = modelviewInverse.m[1][0]*ori.x + modelviewInverse.m[1][1]*ori.y + modelviewInverse.m[1][2]*ori.z + modelviewInverse.m[1][3];
// 	point3D.z = modelviewInverse.m[2][0]*ori.x + modelviewInverse.m[2][1]*ori.y + modelviewInverse.m[2][2]*ori.z + modelviewInverse.m[2][3];
}
void CCamera::SetCameraPos(vec3f pos)
{
	cameraPos = pos;
}
void CCamera::SetLookatPos(vec3f pos)
{
	lookatPos = pos;
}
void CCamera::SetUpDirect(vec3f  dir)
{
	upDirect = dir;
}	
void CCamera::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch(nChar)
	{
	case 'w':
	case 'W':
		Forwards();
		break;
	case 's':
	case 'S':
		Backwards();
	    break;
	case 'a':
	case 'A':
		Leftwards();
		break;
	case 'd':
	case 'D':
		Rightwards();
	    break;
	default:
	    break;
	}
}
void CCamera::OnMouseMove(UINT nFlags, CPoint point)
{
	if (nFlags&MK_LBUTTON)
	{
		if ((nFlags&MK_SHIFT))
		{
			int nMove = point.y -m_prePoint.y;
			float dMove = (float)nMove/m_ncx;
			m_dTilt = m_predTilt + dMove*90;
			if (m_dTilt >= 0)
			{
				m_dTilt = 0.001;
			}
			if (m_dTilt < -89)
			{
				m_dTilt = -89;
			}
			CalcuCameraByTilt();
		}else
		{
			vec3d point3D,point3D1,pointground,preground;
			gluUnProject((GLdouble)point.x,(GLdouble)(m_ncy - point.y),1.0,modelviewInverse,projmatrix,viewportmatrix,&point3D.x,&point3D.y,&point3D.z);
			gluUnProject((GLdouble)point.x,(GLdouble)(m_ncy - point.y),0.1,modelviewInverse,projmatrix,viewportmatrix,&point3D1.x,&point3D1.y,&point3D1.z);		
			vec3d dir = point3D-point3D1;
			dir.Normalize();
			double t = -point3D1.y/dir.y;
			pointground.x = point3D1.x + dir.x*t;
			pointground.y = 0;
			pointground.z = point3D1.z + dir.z*t;

			gluUnProject((GLdouble)m_prePoint.x,(GLdouble)(m_ncy - m_prePoint.y),1.0,modelviewInverse,projmatrix,viewportmatrix,&point3D.x,&point3D.y,&point3D.z);
			gluUnProject((GLdouble)m_prePoint.x,(GLdouble)(m_ncy - m_prePoint.y),0.1,modelviewInverse,projmatrix,viewportmatrix,&point3D1.x,&point3D1.y,&point3D1.z);		
			dir = point3D-point3D1;
			dir.Normalize();
			t = -point3D1.y/dir.y;
			preground.x = point3D1.x + dir.x*t;
			preground.y = 0;
			preground.z = point3D1.z + dir.z*t;

			//--------------------------------------------------------------------
			
			vec3d movevec = preground - pointground;
			vec3f movevecf;
			movevecf.x = movevec.x;
			movevecf.y = movevec.y;
			movevecf.z = movevec.z;

			cameraPos = precameraPos + movevecf;
			lookatPos = prelookatPos + movevecf;

			vec3f tempground;
			tempground.x = pointground.x;
			tempground.y = pointground.y;
			tempground.z = pointground.z;
			m_pointground = tempground;
			tempground.x = preground.x;
			tempground.y = preground.y;
			tempground.z = preground.z;
			m_preground = tempground;
		}
	}
	if (nFlags&MK_RBUTTON)
	{
		int nMove = point.x -m_prePoint.x;
		float dMove = (float)nMove/m_ncx;
		m_dAzim = m_predAzim + dMove*360;
		CalcuCameraByAzim();
	}

}
BOOL CCamera::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	if (zDelta < 0)
	{
		m_dDis *= 0.9;
	}else
		m_dDis *= 1.1;
	CalcuCameraByDis();
	return true;
}
void CCamera::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_bLBDown = true;
	m_prePoint = point;
	precameraPos = cameraPos;
	prelookatPos = lookatPos;
	m_predTilt = m_dTilt;
}
void CCamera::OnLButtonUp(UINT nFlags, CPoint point)
{
	m_bLBDown = false;
}
void CCamera::OnRButtonDown(UINT nFlags, CPoint point)
{
	m_prePoint = point;
	m_bRBDown = true;
	m_predAzim = m_dAzim;
}
void CCamera::OnRButtonUp(UINT nFlags, CPoint point)
{
	m_bRBDown = false;
}
double CCamera::CalcuAzim(vec3f camera,vec3f lookat)
{
	vec3f dir = lookat - camera;
	double dis = dir.length();
	double dAngle = 180*asin(-dir.x/dir.z)/PI;
	if (dir.z < 0)
	{
		dAngle += 180;
	}
	if (dAngle < 0)
	{
		dAngle += 360;
	}
	return dAngle;
}
double CCamera::CalcuTilt(vec3f camera,vec3f lookat)
{
	vec3f dir = lookat - camera;
	double dis = dir.length();
	double dAngle = 180*asin(dir.y/dis)/PI;
	return dAngle;
}
void CCamera::CalcuCameraByDis()
{
	vec3f dir = cameraPos - lookatPos;
	dir.Normalize();
	dir *= m_dDis;
	cameraPos = lookatPos + dir;
}
void CCamera::Forwards()
{
	vec3f dir = lookatPos - cameraPos;
	dir.y = 0;
	dir.Normalize();
	lookatPos += 0.01*m_dDis*dir;
	cameraPos += 0.01*m_dDis*dir;
}
void CCamera::Backwards()
{
	vec3f dir = cameraPos - lookatPos;
	dir.y = 0;
	dir.Normalize();
	lookatPos += 0.01*m_dDis*dir;
	cameraPos += 0.01*m_dDis*dir;

}
void CCamera::Leftwards()
{
	vec3f dir = lookatPos - cameraPos;
	vec2d dir2D,invdir2D;
	vec3f invdir3D;
	dir2D.x = dir.x;
	dir2D.y = dir.z;
	if (dir2D.x < 0)
	{
		invdir2D.x = dir2D.y;
		invdir2D.y = -dir2D.x;
	}else
	{
		invdir2D.x = -dir2D.y;
		invdir2D.y = dir2D.x;
	}
	invdir3D.x = invdir2D.x;
	invdir3D.y = 0;
	invdir3D.z = invdir2D.y;
	invdir3D.Normalize();
	lookatPos += 0.01*m_dDis*invdir3D;
	cameraPos += 0.01*m_dDis*invdir3D;
}
void CCamera::Rightwards()
{
	vec3f dir = lookatPos - cameraPos;
	vec2d dir2D,invdir2D;
	vec3f invdir3D;
	dir2D.x = dir.x;
	dir2D.y = dir.z;
	if (dir2D.x >= 0)
	{
		invdir2D.x = dir2D.y;
		invdir2D.y = -dir2D.x;
	}else
	{
		invdir2D.x = -dir2D.y;
		invdir2D.y = dir2D.x;
	}
	invdir3D.x = invdir2D.x;
	invdir3D.y = 0;
	invdir3D.z = invdir2D.y;
	invdir3D.Normalize();
	lookatPos += 0.01*m_dDis*invdir3D;
	cameraPos += 0.01*m_dDis*invdir3D;
}
void CCamera::OnSize(UINT nType, int cx, int cy) 
{
	m_ncx = cx;
	m_ncy = cy;
}
void CCamera::CalcuCameraByAzim()
{
	vec3f dir;
	dir.y = -sin(m_dTilt*PI/180);
	dir.x = cos(m_dTilt*PI/180)*sin(m_dAzim*PI/180);
	dir.z = -cos(m_dTilt*PI/180)*cos(m_dAzim*PI/180);
	cameraPos = lookatPos + dir*m_dDis;
}
void CCamera::CalcuCameraByTilt()
{
	vec3f dir;
	dir.y = -sin(m_dTilt*PI/180);
	dir.x = cos(m_dTilt*PI/180)*sin(m_dAzim*PI/180);
	dir.z = -cos(m_dTilt*PI/180)*cos(m_dAzim*PI/180);
	cameraPos = lookatPos + dir*m_dDis;
}
void CCamera::Render()
{
// 	glDisable(GL_TEXTURE_2D);
// 	glDisable(GL_LIGHTING);
// 	glPointSize(5);
// 	glBegin(GL_POINTS);
// 	glColor3f(1,0,0);
// 	glVertex3f(m_preground.x,m_preground.y,m_preground.z);
// 	glVertex3f(m_pointground.x,m_pointground.y,m_pointground.z);
// 	glEnd();
// 	glPushMatrix();
// 	glLoadIdentity();
// 	glBegin(GL_POINTS);
// 	glColor3f(0,1,0);
// 	glVertex3f(m_preScreen.x,m_preScreen.y,m_preScreen.z);
// 	glVertex3f(m_pointScreen.x,m_pointScreen.y,m_pointScreen.z);
// 	glEnd();
// 
// 	glPopMatrix();
}
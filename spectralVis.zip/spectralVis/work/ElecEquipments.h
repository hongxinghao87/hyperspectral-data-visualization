// ElecEquipments.h: interface for the CElecEquipments class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELECEQUIPMENTS_H__4407990A_DC78_4085_AFF2_9F508F1632DE__INCLUDED_)
#define AFX_ELECEQUIPMENTS_H__4407990A_DC78_4085_AFF2_9F508F1632DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "GeoLayer.h"
//#include "FLtLoader/FltRender.h"
#define MAX_ET_NUM 10
#define ET_Radar       0
#define ET_Antenna     1
#define ET_Mobile_Base 2
#include "PropagationModel\PropagationModel.h"
//��Ƶ�豸
typedef struct ElectricET{
	vec3d  Pos;//λ��
	int    nType;//�豸����
	double dPower;//����kw
	double dFrequencyTop,dFrequencyBottom;//Ƶ�ʷ�ΧkHZ
	double dAntennaPlus;//��������
	double dMaxAzim,dMinAzim;//��λ��Χ/��
	double dMaxTilt,dMinTilt;//������Χ/��
	double dScaleSize;
	CString strName;
	int     nID;
	ElectricET()
	{
		Pos = vec3d(0,0,0);
		dPower = 0;
		dFrequencyBottom = 0;
		dFrequencyTop = 0;
		dAntennaPlus = 0;
		dMaxAzim = 360;
		dMinAzim = 0;
		dMaxTilt = 90;
		dMinTilt = -90;
		nType = ET_Radar;
		dScaleSize = 0.001;
		strName = "�豸1";
		nID = -1;
	}
}ElectricET;
class CElecEquipments  
{
public:
//	CFltRender *m_pFltModels[MAX_ET_NUM];
	CArray<ElectricET *,ElectricET *> m_arrElectricETS;
	bool m_bPickPoint;
	vec3d m_vecPickPoint;
	CGeoLayer *m_pGeoLayer;
	CPropagationModel m_ppModel;
	ElectricET *m_ChosingEle;

	double *m_pData;
	int m_nX, m_nY, m_nZ;//�����ݴ�С
	vec3d m_vecLBPos,m_vecRTPos;
	double m_dScale,m_dH_Scale;
	void SetVolumeBox(vec3d vecLBPos,vec3d vecRTPos,double dScale,double dH_Scale,int nx,int ny,int nz);
	double* GetVolumeData();

	//---------����----------------------
	bool bstart,bend;
	vec3d vecstart,vecend;
	//-----------------------------------
	bool m_bFirstRender;
public:
	void InitLize();
	void Render();
	void DrawPickPoint();
	//void DrawModels();
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnRButtonDown(UINT nFlags, CPoint point); 
	void SetGeoLayer(CGeoLayer *pGeoLayer);
//	CFltRender *CreatOneFLtMode(CString strFilePath);
	double CalculateElec(vec3d pos,double dFrequency);
	double CalculatePosElec(vec3d pos);
	void CalculateEleArea();
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	void ReadEleData(CString strPath);
	bool Separate(const CString tParam, CStringArray& sAParam, CString strToken);
public:
	CElecEquipments();
	virtual ~CElecEquipments();

};

#endif // !defined(AFX_ELECEQUIPMENTS_H__4407990A_DC78_4085_AFF2_9F508F1632DE__INCLUDED_)

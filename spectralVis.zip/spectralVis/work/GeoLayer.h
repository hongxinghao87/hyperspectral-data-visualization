// GeoLayer.h: interface for the CGeoLayer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GEOLAYER_H__BDC3FEF8_E7DC_4BB2_B8BC_9A059AD73B3B__INCLUDED_)
#define AFX_GEOLAYER_H__BDC3FEF8_E7DC_4BB2_B8BC_9A059AD73B3B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Camera.h"
#define EARTH_RADIUS 6378137
struct DEMData {
		GLfloat X;
		GLfloat Y;
		GLfloat Z;
	};
typedef struct OTreeNode{
	vec3d  m_dRangeMin,m_dRangeMax;
	OTreeNode *childre0;
	OTreeNode *childre1;
	OTreeNode *childre2;
	OTreeNode *childre3;
	OTreeNode *childre4;
	OTreeNode *childre5;
	OTreeNode *childre6;
	OTreeNode *childre7;
	OTreeNode(){
		childre0 = NULL; childre1 = NULL;
		childre2 = NULL; childre3 = NULL;
		childre4 = NULL; childre5 = NULL;
		childre6 = NULL; childre7 = NULL;
	};
}OTreeNode;

class CGeoLayer  
{
public:
	float dNorth;
	float dSouth;
	float dEast;
	float dWest;
	int Row,Col;
	float dNull;
	double DX;
	double DY;
	DEMData *data;
	double scale;
	double h_scale;
	double  m_dHighScale;
	GLuint m_nGridList;	
	GLuint m_nImageList;
	double m_dMoveX,m_dMoveZ,m_dMoveY;
	vec3d  m_dRangeMin,m_dRangeMax;
	CCamera *m_pCamera;

	vec3d BottomPt,TopPt;

	double m_dMinElv;
	double m_dMaxElv;

// 	OTreeNode m_OTreeRoot;
// 	int m_nOTreeLevel;
public:
	BOOL Load(const char*pszfilename);
	void LoadImage(CString strPath);
	void Init();
	void Render();
	void GenGridList();
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	bool GetElv(double dx,double dz,double &dH);
	bool PickPoint(CPoint scrPoint,vec3d &pt);
	void SetCamera(CCamera *pCamera);

	//�����ָ���
	void CreatOtree(int nLevel);
	void CreatOneNode(OTreeNode *par,int nLevel);
	void DrawOtree();
	void DrawOneNode(OTreeNode *par,int &nCount);
	void RealseOtree(OTreeNode *par);


public:
	CGeoLayer();
	virtual ~CGeoLayer();
};

#endif // !defined(AFX_GEOLAYER_H__BDC3FEF8_E7DC_4BB2_B8BC_9A059AD73B3B__INCLUDED_)

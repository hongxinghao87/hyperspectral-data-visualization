// DlgDrawImage.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "DlgDrawImage.h"


// CDlgDrawImage �Ի���

IMPLEMENT_DYNAMIC(CDlgDrawImage, CDialog)

CDlgDrawImage::CDlgDrawImage(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDrawImage::IDD, pParent)
	, m_voldata(NULL)
	, m_drawdata(NULL)
	, m_xsize(0)
	, m_ysize(0)
	, m_zsize(0)
	, m_iSpectnum(1)
{

}

CDlgDrawImage::~CDlgDrawImage()
{
	if (NULL != m_voldata)
	{
		delete m_voldata;
	}
	if (NULL != m_drawdata)
	{
		delete m_drawdata;
	}
}

void CDlgDrawImage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_SPECTNUM, m_iSpectnum);
	DDX_Control(pDX, IDC_SLIDE_SPECTRALIDX, m_SlideSpectIndes);
}


BEGIN_MESSAGE_MAP(CDlgDrawImage, CDialog)
	ON_BN_CLICKED(IDC_BUT_DRAW, &CDlgDrawImage::OnBnClickedButDraw)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDE_SPECTRALIDX, &CDlgDrawImage::OnNMReleasedcaptureSlideSpectralidx)
END_MESSAGE_MAP()


// CDlgDrawImage ��Ϣ��������

void CDlgDrawImage::SetImageData(double * pdata, int ix, int iy, int iz)
{
	if (NULL == m_voldata)
	{
		m_voldata = new double[ix*iy*iz];
	}
	m_xsize = ix;
	m_ysize = iy;
	m_zsize = iz;
	for (int i = 0;i<ix*iy*iz;i++)
	{
		*(m_voldata+i) = *(pdata+i);

	}
	m_SlideSpectIndes.SetRange(1,m_zsize);
}

void CDlgDrawImage::OnBnClickedButDraw()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(true);
	if (m_iSpectnum<=0||m_iSpectnum>m_zsize)
	{
		AfxMessageBox("�������곬������������Χ",MB_OK);
		return;
	}
	if (NULL == m_drawdata)
	{
		m_drawdata = new double[m_xsize*m_ysize];
	}
	double maxdrawdata = MinFloatValue;
	double mindrawdata = MaxFloatValue;
	for (int i = 0;i<m_xsize;i++)
	{
		for (int j = 0;j<m_ysize;j++)
		{
			*(m_drawdata+(m_ysize-1-j)*m_xsize+m_xsize-1-i) = *(m_voldata+(m_iSpectnum-1)*m_xsize*m_ysize+i*m_ysize+j);
		}
	}
	for (int i = 0;i<m_xsize*m_ysize*m_zsize;i++)
	{
		if (*(m_voldata+i)>maxdrawdata)
		{
			maxdrawdata = *(m_voldata+i);
		}
		if (*(m_voldata+i)<mindrawdata)
		{
			mindrawdata = *(m_voldata+i);
		}
	}
	const int mytop=m_ysize<256?356-m_ysize:100;
	//const int mybottom=20;
	const int myleft=100;
	//const int myright=20;

	CImage img;
	img.Create(m_xsize, m_ysize, 32);
	for (int i = 0; i < m_xsize; i++)
	{
		for (int j = 0; j < m_ysize; j++)
		{
			int index;
			if (maxdrawdata==mindrawdata)
				index = 0;
			else
			    index =(*(m_drawdata+i*m_ysize+j)-mindrawdata)*255/(maxdrawdata-mindrawdata);
			img.SetPixel(i, j, RGB(m_IndexColor[index][0]*255, m_IndexColor[index][1]*255, m_IndexColor[index][2]*255));
			//img.SetPixel(i, j, RGB(255,0,0));
		}
	}
	img.Draw(GetDC()->m_hDC, CRect(myleft, mytop, myleft+m_xsize, mytop+m_ysize));

	//����ɫ��
	CImage imgbar;
	imgbar.Create(20, 256, 32);
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 256; j++)
		{
			imgbar.SetPixel(i, 255-j, RGB(m_IndexColor[j][0]*255, m_IndexColor[j][1]*255, m_IndexColor[j][2]*255));
		}
	}
	imgbar.Draw(GetDC()->m_hDC, CRect(myleft+m_xsize+20, mytop+m_ysize-256,myleft+m_xsize+40, mytop+m_ysize));

	CClientDC dc(this);
	CString strStaff;
	for (int i = 0;i<6;i++)
	{
		strStaff.Format("%.3f",mindrawdata+i*(maxdrawdata-mindrawdata)/5);
		dc.MoveTo(myleft+m_xsize+40,int(mytop+m_ysize-(1+i*256/5)));
		dc.LineTo(myleft+m_xsize+45,int(mytop+m_ysize-(1+i*256/5)));
		dc.TextOut(myleft+m_xsize+45, int(mytop+m_ysize-(1+i*256/5)),strStaff);
	}

}

void CDlgDrawImage::SetColorIndex(float *m_pcolor)
{
	for (int i = 0;i<256;i++)
	{
		for (int j = 0;j<4;j++)
		{
			m_IndexColor[i][j] = *(m_pcolor+i*4+j);
		}
	}
}

void CDlgDrawImage::OnNMReleasedcaptureSlideSpectralidx(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
	m_iSpectnum = m_SlideSpectIndes.GetPos();
	UpdateData(false);
	m_iSpectnum = m_iSpectnum-1;
	OnBnClickedButDraw();
}

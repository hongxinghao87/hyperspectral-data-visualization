// ElecEnvironmentDVRView.cpp : implementation of the CElecEnvironmentDVRView class
//

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"

#include "ElecEnvironmentDVRDoc.h"
#include "ElecEnvironmentDVRView.h"
#include "MainFrm.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CElecEnvironmentDVRView

IMPLEMENT_DYNCREATE(CElecEnvironmentDVRView, CView)

BEGIN_MESSAGE_MAP(CElecEnvironmentDVRView, CView)
	//{{AFX_MSG_MAP(CElecEnvironmentDVRView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_KEYDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_TOOL_BOX, OnToolDragBox)
	ON_UPDATE_COMMAND_UI(ID_TOOL_BOX, OnUpdateToolDragBox)
	ON_COMMAND(ID_B_RESET, OnBoxReset)
	ON_COMMAND(ID_B_PICK, OnPickPoint)
	ON_UPDATE_COMMAND_UI(ID_B_PICK, OnUpdatePickPoint)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_VISUAL_SPECT, OnVisSpect)
	ON_COMMAND(ID_VISUAL_DRAWSPACEIMAGE, OnDrawSpace)
	//}}AFX_MSG_MAP
	ON_WM_CONTEXTMENU()
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CElecEnvironmentDVRView construction/destruction

CElecEnvironmentDVRView::CElecEnvironmentDVRView()
{
	m_pGLRender = NULL;
	theApp.pView = this;
	m_bShowBack = false;
	m_bShowLitteBox = true;
	m_bShowET = true;
	m_dlgds = NULL;
	m_dlgdspace = NULL;
}

CElecEnvironmentDVRView::~CElecEnvironmentDVRView()
{
	if(m_pGLRender)
	{
		m_pGLRender->UnInitialize();
		delete m_pGLRender;
	}
	if (m_pVolume)
	{
		delete m_pVolume;
	}
	if(m_pET)
	{
		delete m_pET;
	}
	if (NULL != m_dlgds)
	{
		delete m_dlgds;
	}
	if (NULL != m_dlgdspace)
	{
		delete m_dlgdspace;
	}
}

BOOL CElecEnvironmentDVRView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CElecEnvironmentDVRView drawing

void CElecEnvironmentDVRView::OnDraw(CDC* pDC)
{
	CElecEnvironmentDVRDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);				// Clear Screen And Depth Buffer
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();												// Reset The Current Modelview Matrix
	Render();
	m_pGLRender->SwapBuffers();
}
void CElecEnvironmentDVRView::Render()
{
// 	double dLength = 0.01*tan(22.5*PI/180)*0.9;
// 	glTranslatef(0,0,-0.01);
// 	glColor3f(1,0,0);
// 	glBegin(GL_LINES);
// 	glVertex3f(dLength,0,0);
// 	glVertex3f(-dLength,0,0);
// 	glVertex3f(0,dLength,0);
// 	glVertex3f(0,-dLength,0);
// 	glVertex3f(0,0,dLength);
// 	glVertex3f(0,0,-dLength);
// 	glEnd();
	m_camera.SetCamera();
	m_pVolume->GetMaxtrix();
	if (m_bShowBack)
		m_geoLayer.Render();
	if (m_bShowET)
		m_pET->Render();
	m_radarData.DrawRadarFace();
	m_camera.Render();
	glPushMatrix();
	glScalef(1,1,1);
 	m_pVolume->Draw();
	glPopMatrix();

}
/////////////////////////////////////////////////////////////////////////////
// CElecEnvironmentDVRView printing

void CElecEnvironmentDVRView::OnFilePrintPreview() 
{
	BCGPPrintPreview (this);
}

BOOL CElecEnvironmentDVRView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CElecEnvironmentDVRView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CElecEnvironmentDVRView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CElecEnvironmentDVRView diagnostics

#ifdef _DEBUG
void CElecEnvironmentDVRView::AssertValid() const
{
	CView::AssertValid();
}

void CElecEnvironmentDVRView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CElecEnvironmentDVRDoc* CElecEnvironmentDVRView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CElecEnvironmentDVRDoc)));
	return (CElecEnvironmentDVRDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CElecEnvironmentDVRView message handlers

void CElecEnvironmentDVRView::OnContextMenu(CWnd*, CPoint point)
{
//	theApp.ShowPopupMenu (IDR_CONTEXT_MENU, point, this);
}

int CElecEnvironmentDVRView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_pGLRender=new CGLRender ;
	m_pGLRender->Initialize(GetDC()->GetSafeHdc());
	m_geoLayer.Init();
	m_geoLayer.SetCamera(&m_camera);
	m_pET = new CElecEquipments();
	m_pET->SetGeoLayer(&m_geoLayer);
	m_pET->InitLize();

	m_pET->SetVolumeBox(vec3d(-m_geoLayer.m_dMoveX,0,-m_geoLayer.m_dMoveZ),
		vec3d(m_geoLayer.m_dMoveX,2.1*m_geoLayer.m_dMoveY,m_geoLayer.m_dMoveZ),
		m_geoLayer.scale,m_geoLayer.h_scale,
		200,200,240);

	m_pVolume = new CVolumeRender("sdjfs");
	m_pVolume->SetGlRender(m_pGLRender);
	m_pVolume->SetVolumeBox(vec3d(-m_geoLayer.m_dMoveX,0,-m_geoLayer.m_dMoveZ),
		vec3d(m_geoLayer.m_dMoveX,2.1*m_geoLayer.m_dMoveY,m_geoLayer.m_dMoveZ),
		m_geoLayer.scale,m_geoLayer.h_scale,
		200,200,240);
	return 0;
}

void CElecEnvironmentDVRView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	if(m_pGLRender)
		m_pGLRender->OnSize(cx,cy);
	m_camera.OnSize(nType, cx, cy) ;
	if (m_pVolume)
	{
		m_pVolume->OnSize(nType,cx,cy);
	}
	Invalidate(false);
}

void CElecEnvironmentDVRView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	m_pET->OnKeyDown(nChar,nRepCnt,nFlags);
	switch(nChar)
	{
	case 'b':
	case 'B':
		m_bShowBack = !m_bShowBack;
		break;
	case 'e':
	case 'E':
		m_bShowET = !m_bShowET;
		break;
	case 'l':
	case 'L':
		m_bShowLitteBox = !m_bShowLitteBox;
		break;
	case 'c':
	case 'C':
		m_pET->ReadEleData("hyperdata.hyp");
		m_pVolume->SetVolumeData(m_pET->GetVolumeData(),m_pET->m_nX, m_pET->m_nY, m_pET->m_nZ);
 		//m_radarData.Init(m_pVolume->m_nX,m_pVolume->m_nY,m_pVolume->m_nZ);
 		//m_pVolume->SetVolumeData(m_radarData.GetVolumeData());
		break;
	case 'm':
	case 'M':
		m_pVolume->SaveColortoVhf();
		break;
	default:
	    break;
	}
	m_camera.OnKeyDown(nChar,nRepCnt,nFlags);
	Invalidate(false);
	CMainFrame* pMainFrame = (CMainFrame*) AfxGetMainWnd ();
	if (pMainFrame)
	{
		pMainFrame->m_wndResizableDlgBar.OnKeyDown(nChar,nRepCnt,nFlags);
	}
	m_geoLayer.OnKeyDown(nChar,nRepCnt,nFlags);
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CElecEnvironmentDVRView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_pVolume->GetDragBoxVisible()||m_pVolume->m_nSelect < 0)
	{
		m_camera.OnMouseMove(nFlags, point) ;	
	}else
	{
		m_pVolume->OnMouseMove(nFlags,point);
	}
	Invalidate(false);
	
	CView::OnMouseMove(nFlags, point);
}

BOOL CElecEnvironmentDVRView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	m_camera.OnMouseWheel(nFlags,zDelta,pt);	
	Invalidate(false);
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

void CElecEnvironmentDVRView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_camera.OnLButtonDown(nFlags, point) ;	
	m_pVolume->OnLButtonDown(nFlags,point);
	m_pET->OnLButtonDown(nFlags,point);
	Invalidate(false);
	CView::OnLButtonDown(nFlags, point);
}

void CElecEnvironmentDVRView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_camera.OnLButtonUp(nFlags, point) ;	
	m_pVolume->OnLButtonUp(nFlags,point);
	Invalidate(false);
	
	CView::OnLButtonUp(nFlags, point);
}

void CElecEnvironmentDVRView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnLButtonDblClk(nFlags, point);
}

void CElecEnvironmentDVRView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	m_camera.OnRButtonDown(nFlags, point) ;	
	m_pVolume->OnRButtonDown(nFlags,point);
	m_pET->OnRButtonDown(nFlags,point);
	Invalidate(false);
	
	CView::OnRButtonDown(nFlags, point);
}
void CElecEnvironmentDVRView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	m_camera.OnRButtonUp(nFlags, point) ;	
	m_pVolume->OnRButtonUp(nFlags,point);
	Invalidate(false);
	CView::OnRButtonUp(nFlags, point);
}

void CElecEnvironmentDVRView::OnToolDragBox() 
{
	m_pVolume->SetDragBoxVisible(!m_pVolume->GetDragBoxVisible());
	Invalidate(false);
}

void CElecEnvironmentDVRView::OnUpdateToolDragBox(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_pVolume->GetDragBoxVisible());
}

void CElecEnvironmentDVRView::OnBoxReset() 
{
	m_pVolume->ResetBox();
	Invalidate(false);
}

void CElecEnvironmentDVRView::OnPickPoint() 
{
	m_pET->m_bPickPoint = !m_pET->m_bPickPoint;	
}

void CElecEnvironmentDVRView::OnUpdatePickPoint(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_pET->m_bPickPoint);
}

void CElecEnvironmentDVRView::OnFileOpen() 
{
	CFileDialog dlg(TRUE,"�򿪸߹��������ļ�",NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,"(*.hyp)|*.hyp||");
	if (dlg.DoModal()==IDOK)
	{
		CString strFilePath = dlg.GetPathName();
		if (m_pET)
		{
			m_pET->ReadEleData(strFilePath);
			m_pVolume->SetVolumeData(m_pET->GetVolumeData(),m_pET->m_nX, m_pET->m_nY, m_pET->m_nZ);
			//vec3d dvecLBPos = vec3d(-0.05*(m_pET->m_nX-1),0,-0.05*(m_pET->m_nX-1));
			//vec3d dvecRTPos = vec3d(0.05*(m_pET->m_nX-1),2.0*0.05*(m_pET->m_nX-1),0.05*(m_pET->m_nX-1));
			/*m_pVolume->SetVolumeBox(vec3d(-0.05*(m_pET->m_nX-1),0,-0.05*(m_pET->m_nX-1)),
				vec3d(0.05*(m_pET->m_nX-1),2.0*0.05*(m_pET->m_nX-1),0.05*(m_pET->m_nX-1)),
				0.1*(m_pET->m_nX-1)/(m_geoLayer.dEast-m_geoLayer.dWest),0.1*(m_pET->m_nX-1)/(m_geoLayer.dEast-m_geoLayer.dWest),
				m_pET->m_nX,m_pET->m_nY,m_pET->m_nZ);*/
			//m_pVolume->CreateMesh();
		}
	}
	if (NULL != m_dlgds)
	{
		delete m_dlgds;
		m_dlgds = NULL;
	}
	if (NULL != m_dlgdspace)
	{
		delete m_dlgdspace;
		m_dlgdspace = NULL;
	}
}
void CElecEnvironmentDVRView::OnVisSpect() 
{
	if (NULL == m_dlgds)
	{
		m_dlgds = new CDlgDrawSpect;
		m_dlgds->Create(IDD_DLG_DRAWSPECT,this);
	}
	m_dlgds->ShowWindow(SW_SHOW);
	m_dlgds->SetActiveWindow();
	m_dlgds->SetSpecData(m_pET->GetVolumeData(),m_pET->m_nX, m_pET->m_nY, m_pET->m_nZ);
	
}
void CElecEnvironmentDVRView::OnDrawSpace() 
{
	if (NULL == m_dlgdspace)
	{
		m_dlgdspace = new CDlgDrawImage;
		m_dlgdspace->Create(IDD_DLG_DRAWIMAGE,this);
		int wiheight = max(m_pET->m_nY+250,400);
		int wiwidth = max(m_pET->m_nX+200,600);
		m_dlgdspace->SetWindowPos(this,100,100,wiwidth,wiheight,SWP_NOZORDER);
	}
	m_dlgdspace->ShowWindow(SW_SHOW);
	m_dlgdspace->SetActiveWindow();
	m_dlgdspace->SetImageData(m_pET->GetVolumeData(),m_pET->m_nX, m_pET->m_nY, m_pET->m_nZ);
	m_dlgdspace->SetColorIndex((float *)(m_pVolume->m_Color));
}
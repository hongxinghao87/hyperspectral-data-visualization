#pragma once


// CDlgDrawSpect �Ի���

class CDlgDrawSpect : public CDialog
{
	DECLARE_DYNAMIC(CDlgDrawSpect)

public:
	CDlgDrawSpect(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgDrawSpect();

// �Ի�������
	enum { IDD = IDD_DLG_DRAWSPECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	double *m_spectraldata;
	double *Xdatas;
	double *index;
	int m_datanumx;
	int m_datanumy;
	int m_datanumz;
	int m_ix;
	int m_iy;
	bool m_Isdraw;
	void SetSpecData(double * pData, int sizex, int sizey, int sizez);
	afx_msg void OnBnClickedBtnDraw();
	void Cleardraw(bool Isdraw);
};

// ElecEnvironmentDVRView.h : interface of the CElecEnvironmentDVRView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELECENVIRONMENTDVRVIEW_H__258C3889_90C1_4F10_BDC6_80BC6A2C8C29__INCLUDED_)
#define AFX_ELECENVIRONMENTDVRVIEW_H__258C3889_90C1_4F10_BDC6_80BC6A2C8C29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "GLRender.h"
#include "VolumeRender.h"
#include "Camera.h"
#include "GeoLayer.h"
#include "ElecEnvironmentDVRDoc.h"
#include "ElecEquipments.h"
#include "RadarData.h"
#include "DlgDrawSpect.h"
#include "DlgDrawImage.h"
class CElecEnvironmentDVRView : public CView
{
protected: // create from serialization only
	CElecEnvironmentDVRView();
	DECLARE_DYNCREATE(CElecEnvironmentDVRView)

// Attributes
public:
	CElecEnvironmentDVRDoc* GetDocument();

// Operations
public:
	CGLRender *m_pGLRender;
	CVolumeRender *m_pVolume;
	CCamera     m_camera;
	CGeoLayer   m_geoLayer;
	CElecEquipments *m_pET;
	bool  m_bShowBack;
	bool  m_bShowLitteBox;
	bool  m_bShowET;
	CRadarData m_radarData;
	CDlgDrawSpect *m_dlgds;
	CDlgDrawImage *m_dlgdspace;
public:
	void Render();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CElecEnvironmentDVRView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CElecEnvironmentDVRView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CElecEnvironmentDVRView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnToolDragBox();
	afx_msg void OnUpdateToolDragBox(CCmdUI* pCmdUI);
	afx_msg void OnBoxReset();
	afx_msg void OnPickPoint();
	afx_msg void OnUpdatePickPoint(CCmdUI* pCmdUI);
	afx_msg void OnFileOpen();
	afx_msg void OnVisSpect();
	afx_msg void OnDrawSpace();
	//}}AFX_MSG
	afx_msg void OnContextMenu(CWnd*, CPoint point);
	afx_msg void OnFilePrintPreview();
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ElecEnvironmentDVRView.cpp
inline CElecEnvironmentDVRDoc* CElecEnvironmentDVRView::GetDocument()
   { return (CElecEnvironmentDVRDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ELECENVIRONMENTDVRVIEW_H__258C3889_90C1_4F10_BDC6_80BC6A2C8C29__INCLUDED_)

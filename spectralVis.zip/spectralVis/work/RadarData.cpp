// RadarData.cpp: implementation of the CRadarData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ElecEnvironmentDVR.h"
#include "RadarData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRadarData::CRadarData()
{
	m_dRadarData = NULL;
	m_pData = NULL;
}

CRadarData::~CRadarData()
{
	if(m_dRadarData != NULL)
	{
		delete []m_dRadarData;
	}
}
double CRadarData::LossToProba(double dLoss)
{
	if(dLoss > dProba[0])
		return 0;
	if(dLoss <= dProba[99])
		return 100;
	for(int i=0;i<99;i++)
	{
		if(dLoss <= dProba[i]&&dLoss > dProba[i+1])
			return i + (dLoss - dProba[i+1])/(dProba[i]-dProba[i+1]);
	}
	return 0;
}
void CRadarData::LoadVolumData(CString strpath)
{
	int i,j,k;
	CStdioFile stdFile;
	if(stdFile.Open(strpath,CFile::modeRead))
	{
		m_pVolumData = new double[m_nX*m_nY*m_nZ];
		CString strInfo;
		CStringArray sDataArray;
		for(i=0;i<m_nZ;i++)
		{
			for(j=0;j<m_nY;j++)
			{
				for(k=0;k<m_nX;k++)
				{
					sDataArray.RemoveAll();
					stdFile.ReadString(strInfo);
					Separate(strInfo,sDataArray," ");
					m_pVolumData[i*m_nY*m_nX+j*m_nX + k] = atof(sDataArray.GetAt(3));				
				}
			}
		}
	}
	
}
void CRadarData::LoadRadarData(CString strpath)
{
	FILE *fp;
	fp = fopen("radar.txt", "w+");
	int i,j;
	CStdioFile stdFile;
	if(stdFile.Open(strpath,CFile::modeRead))
	{
		CString strInfo;
		CStringArray sDataArray;
		stdFile.ReadString(strInfo);
		Separate(strInfo,sDataArray," ");
		dMinRange = atof(sDataArray.GetAt(0));
		dMinHigh = atof(sDataArray.GetAt(1));
		dMaxRange = atof(sDataArray.GetAt(2));
		dMaxHigh = atof(sDataArray.GetAt(3));
		
		
		stdFile.ReadString(strInfo);
		sDataArray.RemoveAll();
		Separate(strInfo,sDataArray," ");
		
		nXNum = atoi(sDataArray.GetAt(0));
		nYNum = atoi(sDataArray.GetAt(1));
		fprintf(fp,"%d %d\n",nXNum,nYNum);

		stdFile.ReadString(strInfo);

		for(i = 0;i<10;i++)
		{
			stdFile.ReadString(strInfo);
			sDataArray.RemoveAll();
			Separate(strInfo,sDataArray," ");
			for(j = 0;j<10;j++)
			{
				dProba[i*10+j] = atof(sDataArray.GetAt(j));
			}
		}
		
		stdFile.ReadString(strInfo);
		
		if(m_dRadarData != NULL)
		{
			delete []m_dRadarData;
		}
		
		m_dRadarData = new double*[nYNum];
		for(i = 0;i<nYNum;i++)
		{
			m_dRadarData[i] = new double[nXNum];
		}
		for(i=0;i<nYNum;i++)
			for(j=0;j<nXNum;j++)
				m_dRadarData[i][j] = 0;
		for(i=0;i<nYNum;i++)
		{
			stdFile.ReadString(strInfo);
			for(j=0;j<nXNum/6;j++)
			{
				stdFile.ReadString(strInfo);
//				AfxMessageBox(strInfo);
				sDataArray.RemoveAll();
				Separate(strInfo,sDataArray," ");
				if(sDataArray.GetAt(1) != "Grnd")
					m_dRadarData[i][j*6] = LossToProba(atof(sDataArray.GetAt(1)));
				else
					m_dRadarData[i][j*6] = 0;

				if(sDataArray.GetAt(3) != "Grnd")
					m_dRadarData[i][j*6+1] = LossToProba(atof(sDataArray.GetAt(3)));
				else
					m_dRadarData[i][j*6+1] = 0;

				if(sDataArray.GetAt(5) != "Grnd")
					m_dRadarData[i][j*6+2] = LossToProba(atof(sDataArray.GetAt(5)));
				else
					m_dRadarData[i][j*6+2] = 0;

				if(sDataArray.GetAt(7) != "Grnd")
					m_dRadarData[i][j*6+3] = LossToProba(atof(sDataArray.GetAt(7)));
				else
					m_dRadarData[i][j*6+3] = 0;

				if(sDataArray.GetAt(9) != "Grnd")
					m_dRadarData[i][j*6+4] = LossToProba(atof(sDataArray.GetAt(9)));
				else
					m_dRadarData[i][j*6+4] = 0;

				if(sDataArray.GetAt(11) != "Grnd")
					m_dRadarData[i][j*6+5] = LossToProba(atof(sDataArray.GetAt(11)));
				else
					m_dRadarData[i][j*6+5] = 0;

				if(fp)
				{
					fprintf(fp,"%f %f %f %f %f %f\n"
						,m_dRadarData[i][j*6]
						,m_dRadarData[i][j*6+1]
						,m_dRadarData[i][j*6+2]
						,m_dRadarData[i][j*6+3]
						,m_dRadarData[i][j*6+4]
						,m_dRadarData[i][j*6+5]);
				}

			}

			stdFile.ReadString(strInfo);
			sDataArray.RemoveAll();
			Separate(strInfo,sDataArray," ");
			for(j=0;j<nXNum%6;j++)
			{
				if(sDataArray.GetAt(j*2+1) != "Grnd")
					m_dRadarData[i][(nXNum/6-1)*6+j] = LossToProba(atof(sDataArray.GetAt(j*2+1)));
				else
					m_dRadarData[i][(nXNum/6-1)*6+j] = 0; 
				fprintf(fp,"%f ",m_dRadarData[i][(nXNum/6-1)*6+j]);
			}
			stdFile.ReadString(strInfo);
			if(fp)
			{
				fprintf(fp,"\n");
			}
		}
	}
	if(fp)
	{
		fclose(fp);
	}
				
}
void CRadarData::DrawRadarFace()
{
//	return;
	int i,j;
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glLoadIdentity();
	glTranslatef(0,0,-0.02);
	double dLength = 0.008;
	//glBegin(GL_LINES);
	//glColor3f(0,0,0);
	//glVertex3f(0,0,0);
	//glVertex3f(dLength,0,0);
	//glVertex3f(0,0,0);
	//glVertex3f(0,dLength,0);
	//glEnd();

	double dXStep = dLength/nXNum;
	double dYStep = dLength/nYNum;
	for(i = 0;i<nYNum-1;i++)
	{
		for(j=0;j<nXNum-1;j++)
		{
			double r,g,b;
			glBegin(GL_QUADS);

			GetColor(m_dRadarData[i][j],r,g,b);
			glColor3f(r,g,b);
			glVertex3f(dXStep*j,dYStep*i,0);

			GetColor(m_dRadarData[i][j+1],r,g,b);
			glColor3f(r,g,b);
			glVertex3f(dXStep*(j+1),dYStep*i,0);

			GetColor(m_dRadarData[i+1][j+1],r,g,b);
			glColor3f(r,g,b);
			glVertex3f(dXStep*(j+1),dYStep*(i+1),0);

			GetColor(m_dRadarData[i+1][j],r,g,b);
			glColor3f(r,g,b);
			glVertex3f(dXStep*(j),dYStep*(i+1),0);

			glEnd();

/*			glColor3f(0,0,0);
			glBegin(GL_LINES);

			glVertex3f(dXStep*j,dYStep*i,0);

			glVertex3f(dXStep*(j+1),dYStep*i,0);

			glVertex3f(dXStep*j,dYStep*i,0);

			glVertex3f(dXStep*(j),dYStep*(i+1),0);

			glEnd();
			GetColor(m_dRadarData[i][j],r,g,b);
			glColor3f(r,g,b);
			glPushMatrix();
			glBegin(GL_POINTS);
			glVertex3f(dXStep*j,dYStep*i,0);
			glEnd();
			glPopMatrix();
*/
		}
	}

	glPopMatrix();
	glPopAttrib();
	
}
void CRadarData::GetColor(double dProb,double &r,double &g,double &b)
{
	if(dProb < 40)
	{
		r = 0;g=0;b=1;
	}else if(dProb < 60)
	{
		r=1;g=0;b=1;
	}else if(dProb < 80)
	{
		r=1;g=1;b=0;
	}else
	{
		r=1;g=0;b=0;
	}
}
void CRadarData::Init(int nX,int nY,int nZ)
{
	CString str;
	GetModuleFileName(NULL,str.GetBuffer(1024),1024);
	str.ReleaseBuffer();
	int nPos = str.ReverseFind('\\');
	str.Delete(nPos+1,str.GetLength()-nPos-1);
	m_nX = nX;
	m_nY = nY;
	m_nZ = nZ;
//	LoadRadarData(str + "data/radardata/1.txt");
	LoadVolumData(str + "data/radardata/Noterrain.txt");
// 	if(m_pData)
// 		delete []m_pData;
// 	m_pData = new double[m_nX*m_nY*m_nZ];
// 
// 	dRadarX = 0.3;
// 	dRadarZ = 0.3;
// 	dRadarHigh = 1.0;
// 	dRadarRange = 0.2;
// 
// 	dRadarX1 = 0.6;
// 	dRadarZ1 = 0.6;
// 	dRadarHigh1 = 1.0;
// 	dRadarRange1 = 0.25;
// 
// 	dRadarX2 = 0.8;
// 	dRadarZ2 = 0.8;
// 	dRadarHigh2 = 1.0;
// 	dRadarRange2 = 0.15;

//	CalculateVolumeData();
}
void CRadarData::CalculateVolumeData()
{
	double doriRadarRange = dRadarRange;
	double doriRadarRange1 = dRadarRange1;
	double doriRadarRange2 = dRadarRange2;
	int i,j,k;
	double dRand[360];
	for(i=0;i<360;i++)
		dRand[i] = rand()%100/100.0;
	for (k=0;k<m_nZ;k++)
	{
		for (i=0;i<m_nY;i++)
		{
			for (j=0;j<m_nX;j++)
			{
				double dx = (double)j/m_nX;
				double dy = (double)i/m_nY;
				double dz = (double)k/m_nZ;
				double dDis = sqrt((dx - dRadarX)*(dx - dRadarX) + (dz - dRadarZ)*(dz - dRadarZ));
				double pd1;
/*				double dAngle;
				if(dx != 0)
					dAngle = atan((dz-dRadarZ)/(dx-dRadarX));
				else
					dAngle = 0;
				if(dAngle*180/PI < 90&&dAngle*180/PI > 45)
					dRadarRange = doriRadarRange*dRand[int(dAngle*180/PI)];
				else
					dRadarRange = doriRadarRange;*/
				if(dDis < dRadarRange&&dy<dRadarHigh)
				{
					double dValue1,dValue2,dValue3,dValue4;
					int nRange = (nXNum-1)*dDis/dRadarRange;
					int nHigh = (nYNum-1)*dy/dRadarHigh;
					if(nRange < nXNum-1&&nHigh < nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh+1][nRange];
						dValue3 = m_dRadarData[nHigh][nRange+1];
						dValue4 = m_dRadarData[nHigh+1][nRange+1];
					}else if(nRange == nXNum-1&&nHigh == nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh][nRange];
						dValue3 = m_dRadarData[nHigh][nRange];
						dValue4 = m_dRadarData[nHigh][nRange];
					}
					else if(nRange == nXNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh+1][nRange];
						dValue3 = m_dRadarData[nHigh][nRange];
						dValue4 = m_dRadarData[nHigh+1][nRange];
					}else if(nHigh == nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh][nRange];
						dValue3 = m_dRadarData[nHigh][nRange+1];
						dValue4 = m_dRadarData[nHigh][nRange+1];
					}
					double dMidX1,dMidX2;
					dMidX1 = dValue1+(dValue2 - dValue1)*(dy - nHigh*dRadarHigh/(nYNum-1))/(dRadarHigh/(nYNum-1));
					dMidX2 = dValue3+(dValue4 - dValue3)*(dy - nHigh*dRadarHigh/(nYNum-1))/(dRadarHigh/(nYNum-1));

					pd1 = dMidX1 + (dMidX2 - dMidX1)*(dDis - nRange*dRadarRange/(nXNum-1))/(dRadarRange/(nXNum-1));
				}else if(dy<dRadarHigh)
				{
					int nHigh = (nYNum-1)*dy/dRadarHigh;
					pd1 = m_dRadarData[nHigh][199] - fabs((m_dRadarData[nHigh][199] - m_dRadarData[nHigh][198])*(dDis - dRadarRange)/(dRadarRange/(nXNum-1)));
					if(pd1 < 0)
						pd1 = 0;
				}

				dDis = sqrt((dx - dRadarX1)*(dx - dRadarX1) + (dz - dRadarZ1)*(dz - dRadarZ1));
				double pd2;
				if(dDis < dRadarRange1&&dy<dRadarHigh1)
				{
					double dValue1,dValue2,dValue3,dValue4;
					int nRange = (nXNum-1)*dDis/dRadarRange1;
					int nHigh = (nYNum-1)*dy/dRadarHigh1;
					if(nRange < nXNum-1&&nHigh < nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh+1][nRange];
						dValue3 = m_dRadarData[nHigh][nRange+1];
						dValue4 = m_dRadarData[nHigh+1][nRange+1];
					}else if(nRange == nXNum-1&&nHigh == nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh][nRange];
						dValue3 = m_dRadarData[nHigh][nRange];
						dValue4 = m_dRadarData[nHigh][nRange];
					}
					else if(nRange == nXNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh+1][nRange];
						dValue3 = m_dRadarData[nHigh][nRange];
						dValue4 = m_dRadarData[nHigh+1][nRange];
					}else if(nHigh == nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh][nRange];
						dValue3 = m_dRadarData[nHigh][nRange+1];
						dValue4 = m_dRadarData[nHigh][nRange+1];
					}
					double dMidX1,dMidX2;
					dMidX1 = dValue1+(dValue2 - dValue1)*(dy - nHigh*dRadarHigh1/(nYNum-1))/(dRadarHigh1/(nYNum-1));
					dMidX2 = dValue3+(dValue4 - dValue3)*(dy - nHigh*dRadarHigh1/(nYNum-1))/(dRadarHigh1/(nYNum-1));

					pd2 = dMidX1 + (dMidX2 - dMidX1)*(dDis - nRange*dRadarRange1/(nXNum-1))/(dRadarRange1/(nXNum-1));
				}else
				{
					int nHigh = (nYNum-1)*dy/dRadarHigh1;
					pd2 = m_dRadarData[nHigh][199] - fabs((m_dRadarData[nHigh][199] - m_dRadarData[nHigh][198])*(dDis - dRadarRange1)/(dRadarRange1/(nXNum-1)));
					if(pd2 < 0)
						pd2 = 0;
				}	
				

				dDis = sqrt((dx - dRadarX2)*(dx - dRadarX2) + (dz - dRadarZ2)*(dz - dRadarZ2));
				double pd3;
				if(dDis < dRadarRange2&&dy<dRadarHigh2)
				{
					double dValue1,dValue2,dValue3,dValue4;
					int nRange = (nXNum-1)*dDis/dRadarRange2;
					int nHigh = (nYNum-1)*dy/dRadarHigh2;
					if(nRange < nXNum-1&&nHigh < nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh+1][nRange];
						dValue3 = m_dRadarData[nHigh][nRange+1];
						dValue4 = m_dRadarData[nHigh+1][nRange+1];
					}else if(nRange == nXNum-1&&nHigh == nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh][nRange];
						dValue3 = m_dRadarData[nHigh][nRange];
						dValue4 = m_dRadarData[nHigh][nRange];
					}
					else if(nRange == nXNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh+1][nRange];
						dValue3 = m_dRadarData[nHigh][nRange];
						dValue4 = m_dRadarData[nHigh+1][nRange];
					}else if(nHigh == nYNum-1)
					{
						dValue1 = m_dRadarData[nHigh][nRange];
						dValue2 = m_dRadarData[nHigh][nRange];
						dValue3 = m_dRadarData[nHigh][nRange+1];
						dValue4 = m_dRadarData[nHigh][nRange+1];
					}
					double dMidX1,dMidX2;
					dMidX1 = dValue1+(dValue2 - dValue1)*(dy - nHigh*dRadarHigh2/(nYNum-1))/(dRadarHigh2/(nYNum-1));
					dMidX2 = dValue3+(dValue4 - dValue3)*(dy - nHigh*dRadarHigh2/(nYNum-1))/(dRadarHigh2/(nYNum-1));

					pd3 = dMidX1 + (dMidX2 - dMidX1)*(dDis - nRange*dRadarRange2/(nXNum-1))/(dRadarRange2/(nXNum-1));
				}else
				{
					int nHigh = (nYNum-1)*dy/dRadarHigh2;
					pd3 = m_dRadarData[nHigh][199] - fabs((m_dRadarData[nHigh][199] - m_dRadarData[nHigh][198])*(dDis - dRadarRange2)/(dRadarRange2/(nXNum-1)));
					if(pd3 < 0)
						pd3 = 0;
				}					
				
				m_pData[k*m_nX*m_nY + i*m_nX + j] = 1-(1-pd1/100.0)*(1-pd2/100.0)*(1-pd3/100.0);
			}
		}
	}
}
double *CRadarData::GetVolumeData()
{
	return m_pVolumData;//m_pData

}
bool CRadarData::Separate(const CString tParam, CStringArray& sAParam, CString strToken)
{
	//�������ֿ�,��tParam����strToken�ָ�
	
	int tStart = 0;
	int tEnd = 0; 
	if (tParam.IsEmpty()) 
	{
		return(false);
	}
	int i = 0;           //���ֲ����ĸ���
	int j = 0;           //����λ��
	int flag = false;    //����Ƿ����
	sAParam.RemoveAll();
	while (!flag) 
	{
		tEnd = tParam.Find((LPCTSTR)strToken, tStart);
		if (tEnd < 0) 
		{
			//�������Ĳ���
			tEnd = tParam.GetLength();
			flag = true;
		}
		sAParam.Add(_T(""));   //����һ���յ��ַ���
		if(tStart == tEnd)
		{
			tStart = tEnd + 1;  //������ǰ�ķָ��
			continue;
		}
		for(j = tStart; j < tEnd; j++)
		{
			sAParam[i] += tParam[j];  //�ҵ���i������
		}
		CString temp = sAParam[i];

		//����һ������
		tStart = tEnd + 1;  //������ǰ�ķָ��

		i++;
	}
	return(true);
}
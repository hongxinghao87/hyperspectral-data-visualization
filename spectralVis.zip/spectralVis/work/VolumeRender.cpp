#include "StdAfx.h"
#include "VolumeRender.h"
#include "./GLRender/GLFont.h"
#include "GLRender.h"
#include <fstream>
#include "ElecEnvironmentDVR.h"
#define BUFSIZE 512 

using namespace std;
CVolumeRender::CVolumeRender(void)
:TestDVRTexture3D(GL_LUMINANCE8, GL_LUMINANCE, GL_UNSIGNED_BYTE)
{
	m_pubVolumeData = 0;
	bNeedrefreshColormap = true;
	m_bInit = false;
	m_pGLSet = NULL;
	m_nSelect = -1;
	minsnb = 0;
	maxsnb = 0;
}

CVolumeRender::CVolumeRender(CString name)
:TestDVRTexture3D(GL_LUMINANCE8, GL_LUMINANCE, GL_UNSIGNED_BYTE)
{
	minsnb = 0;
	maxsnb = 0;

	m_nLeft = 10;
	m_nBottom = 30;
	bNeedrefreshColormap = true;
	m_bInit = false;

	m_pubVolumeData = 0;

	CColorPoint colorpoint;
	colorpoint.m_Color = vec3f(0,0,1);
	colorpoint.m_fPos = 0;	
	m_ColorPoint.Add(colorpoint);

	CColorPoint colorpoint1;
	colorpoint1.m_Color = vec3f(0,1,0);
	colorpoint1.m_fPos = 0.25;	
	m_ColorPoint.Add(colorpoint1);

	CColorPoint colorpoint2;
	colorpoint2.m_Color = vec3f(1,1,0);
	colorpoint2.m_fPos = 0.5;
	m_ColorPoint.Add(colorpoint2);

	CColorPoint colorpoint3;
	colorpoint3.m_Color = vec3f(1, 0,0);
	colorpoint3.m_fPos = 0.75;
	m_ColorPoint.Add(colorpoint3);

	CColorPoint colorpoint4;
	colorpoint4.m_Color = vec3f(1,0,1);
	colorpoint4.m_fPos = 1.0;
	m_ColorPoint.Add(colorpoint4);

	//////////////////////////////
	CAlphaPoint alphapoint;
	alphapoint.m_Alpha = 0.0;
	alphapoint.m_fAlphapos = 0;
	m_AlphaPoint.Add(alphapoint);

	CAlphaPoint alphapoint1;
	alphapoint1.m_Alpha = 0.3;
	alphapoint1.m_fAlphapos = 0.3;
	m_AlphaPoint.Add(alphapoint1);

	CAlphaPoint alphapoint2;
	alphapoint2.m_Alpha = 0.2;
	alphapoint2.m_fAlphapos = 0.6;
	m_AlphaPoint.Add(alphapoint2);

	CAlphaPoint alphapoint3;
	alphapoint3.m_Alpha = 0.5;
	alphapoint3.m_fAlphapos = 0.8;
	m_AlphaPoint.Add(alphapoint3);

	CAlphaPoint alphapoint4;
	alphapoint4.m_Alpha = 0.0;
	alphapoint4.m_fAlphapos = 0.9;
	m_AlphaPoint.Add(alphapoint4);

	CAlphaPoint alphapoint5;
	alphapoint5.m_Alpha = 0.0;
	alphapoint5.m_fAlphapos = 1;
	m_AlphaPoint.Add(alphapoint5);

	
	ZeroMemory(m_Color, sizeof(float) * 256 * 4);

	for (int i=0; i<256; i++) 
	{ 
		vec4f vcolor = GetMapColor(i);
		m_Color[i][0] = vcolor.r;
		m_Color[i][1] = vcolor.g;
		m_Color[i][2] = vcolor.b;
		m_Color[i][3] = vcolor.a;
	}
	m_dMaxScale = 0.001;
	m_ncx = 0;
	m_ncy = 0;
}

float CVolumeRender::GetColorAlpha(int nIndex)
{
	float fPos = nIndex / 255.0;
	for(int i = 0; i < m_AlphaPoint.GetSize(); i ++)
	{
		float fMin = m_AlphaPoint[i].m_fAlphapos;
		float alpha1 = m_AlphaPoint[i].m_Alpha;

		

		if(fMin == fPos)
			return alpha1;

		float fMax = m_AlphaPoint[i + 1].m_fAlphapos;
		float alpha2 = m_AlphaPoint[i + 1].m_Alpha;

		if(fMax == fPos)
			return alpha2;

		else if(fMin < fPos && fMax > fPos)
		{

			return (fPos - fMin) / (fMax - fMin) * (alpha2 - alpha1) + alpha1;

		}
	}
	return 0.0;

}

vec4f CVolumeRender::GetMapColor(int nIndex)
{
	float fPos = nIndex / 255.0;
	for(int i = 0; i < m_ColorPoint.GetSize(); i ++)
	{
		float fMin = m_ColorPoint[i].m_fPos;
		float fMax = m_ColorPoint[i + 1].m_fPos;

		vec3f color1 = m_ColorPoint[i].m_Color;
		vec3f color2 = m_ColorPoint[i + 1].m_Color;

		if(fMin == fPos)
		{			
			return vec4f(color1.x, color1.y, color1.z, GetColorAlpha(nIndex));
		}

		else if(fMax == fPos)
		{
			return vec4f(color2.x, color2.y, color2.z, GetColorAlpha(nIndex));
		}

		else if(fMin < fPos && fMax > fPos)
		{
			vec3f temp = (fPos - fMin) / (fMax - fMin) * (color2 - color1) + color1;
			return vec4f(temp.x, temp.y, temp.z, GetColorAlpha(nIndex));

		}
	}
	return vec4f(0, 0, 0, 0);
}

CVolumeRender::~CVolumeRender(void)
{
	if(m_pubVolumeData) delete[] m_pubVolumeData;
}

inline vec4f GetColor(double snb)
{
	float alpha = 0.5;
	if(snb >= 100) return vec4f(1, 0, 0, alpha);
	else if(snb >= 80) return vec4f(1, 1, 0, alpha);
	else if(snb >= 60) return vec4f(1, 0, 1, alpha);
	else if(snb >= 40) return vec4f(0, 0, 1, alpha);
	else if(snb >= 20) return vec4f(0, 1, 0, alpha);
	else if(snb >= 0) return vec4f(1, 0.5, 0, alpha);
	else if(snb >= -20) return vec4f(0, 0.5, 0.5, alpha);
	else if(snb >= -40) return vec4f(0, 0.5, 0, alpha);
	else if(snb >= -60) return vec4f(0, 0, 0.5, alpha);
	else if(snb >= -80) return vec4f(0.8, 0.8, 0.8, alpha);
	else if(snb >= -100) return vec4f(0, 1, 1, alpha);
	else if(snb < -100) return vec4f(0.5, 0, 0.5, alpha);
}

void CVolumeRender::CreateVolumeData(vec3d& volumeboxpos, vec3d& volumebox, vec3d& volumestep)
{
	vec3d volumePosMax = volumeboxpos + volumebox / 2.0;
	vec3d volumePosMin = volumeboxpos - volumebox / 2.0;

	m_nX = volumebox.x / volumestep.x;
	m_nY = volumebox.y / volumestep.y;
	m_nZ = volumebox.z / volumestep.z;

	m_Roi0 = vec3i(1, 1, 1);
	m_Roi1 = vec3i(m_nX - 2, m_nY - 2, m_nZ - 2);
	m_oriRoi0 = vec3i(1, 1, 1);
	m_oriRoi1 = vec3i(m_nX - 2, m_nY - 2, m_nZ - 2);



	int nX = m_nX;
	int nY = m_nY;
	int nZ = m_nZ;

	double *dTempData = new double[nX * nY * nZ];

	if(m_pubVolumeData) delete[] m_pubVolumeData;
	m_pubVolumeData = new GLubyte[nX * nY * nZ];

	minsnb = MaxFloatValue;
	maxsnb = MinFloatValue;
	maxrealsnb = MinFloatValue;

	int i,j,k;

	for( i = 0; i < nZ; i ++)
	{
		double z = volumePosMin.z + i * volumestep.z;
		for( j = 0; j < nY; j++)
		{
			double y = volumePosMin.y + j * volumestep.y;
			for (k = 0; k < nX; k++)
			{
				double x = volumePosMin.x + k * volumestep.x;
				//double dx = fabs(k - nX*0.6);
				//double dy = fabs(j - nY/2.0);
				//double dz = fabs(i - nZ*0.8);
				double dx = fabs(k - nX*0.6);
				double dy = fabs(j - nY*0.6);
				double dz = fabs(i - nZ*0.8);
				
				double dMaxDis = sqrt(float(nX*nX+nY*nY + nZ*nZ));
				double dDis = sqrt(dx*dx+dy*dy + dz*dz);
				double dMaxScale = 0.23*dMaxDis;
				// 				if (dDis > dMaxScale)
				// 				{
				// 					dDis = 0;
				// 				}else
				// 				{
				dDis = dMaxScale - dDis;
				// 				}
				if (dDis <0)
				{
					dDis = 0;
				}
				dTempData[i * nY * nX + j * nX + k] = dDis;
				
				dx = fabs(k - nX*0.3);
				dy = fabs(j - nY/2.0);
				dz = fabs(i - nZ*0.2);
				/*dx = fabs(k - nX*0.6);
				dy = fabs(j - nY*0.6);
				dz = fabs(i - nZ*0.8);*/
				dDis = sqrt(dx*dx+dy*dy + dz*dz);
// 				if (dDis > dMaxScale)
// 				{
// 					dDis = 0;
// 				}else
// 				{
					dDis = dMaxScale - dDis;
// 				}
					if (dDis <0)
					{
						dDis = 0;
					}
				
				dTempData[i * nY * nX + j * nX + k] += dDis;
				dTempData[i * nY * nX + j * nX + k] /= 2.0;


				if (dTempData[i * nY * nX + j * nX + k] < minsnb)
				{
					minsnb = dTempData[i * nY * nX + j * nX + k];
				}
				if (dTempData[i * nY * nX + j * nX + k] > maxsnb)
				{
					maxsnb = dTempData[i * nY * nX + j * nX + k];
				}
			}
		}
	}
	maxrealsnb = maxsnb;
	//���ŵ�0~255
	double dTemp;
	int nIndex;
	m_nMaxHist = -10;

	ZeroMemory(m_nDataHist, sizeof(int) * HIST_NUM);

	for( i = 0; i < nZ; i ++)
	{		
		for( j = 0; j < nY; j++)
		{
			for ( k = 0; k < nX; k++)
			{
				nIndex = i * nY * nX + j * nX + k;
				if(dTempData[nIndex] == 1000)
					dTemp = maxrealsnb + 1;
				else
					dTemp = dTempData[nIndex];
				m_pubVolumeData[nIndex] = (dTemp - minsnb) / (maxrealsnb + 1 - minsnb) * 255;
				int nHistIndex = HIST_NUM*(dTemp - minsnb) / (maxrealsnb + 1 - minsnb);
				m_nDataHist[nHistIndex]++;
			}
		}
	}
	for(i = 0; i < HIST_NUM; i++)
	{
		if(m_nMaxHist < m_nDataHist[i])
			m_nMaxHist = m_nDataHist[i];
	}

	delete[]dTempData;
}
void CVolumeRender::SaveColortoVhf()
{
	FILE *fp = fopen("Sanfrancisco.raw.vhf", "w+");
	
	if(fp)
	{
		fprintf(fp,"w=%d\r\n",m_nX);
		fprintf(fp,"h=%d\r\n",m_nY);
		fprintf(fp,"d=%d\r\n",m_nZ);
		fprintf(fp,"wScale=%d\r\n",1);
		fprintf(fp,"hScale=%d\r\n",1);
		fprintf(fp,"dScale=%d\r\n",1);
		fprintf(fp,"TF:\r\n");
		fprintf(fp,"size=%d\r\n",256);
		double dStep = 1.0/255;
		int i,j;
		unsigned short  r,g,b,a;
		for (i=0;i<256;i++)
		{
			double dCurPos = i*dStep;
			for(j = 0;j<m_ColorPoint.GetSize()-1;j++)
			{
				if (dCurPos >= m_ColorPoint[j].m_fPos&&dCurPos <= m_ColorPoint[j+1].m_fPos)
				{
					double dbl = (dCurPos - m_ColorPoint[j].m_fPos)/(m_ColorPoint[j+1].m_fPos - m_ColorPoint[j].m_fPos);
					r = 255*(m_ColorPoint[j].m_Color[0] + dbl*(m_ColorPoint[j+1].m_Color[0]-m_ColorPoint[j].m_Color[0]));
					g = 255*(m_ColorPoint[j].m_Color[1] + dbl*(m_ColorPoint[j+1].m_Color[1]-m_ColorPoint[j].m_Color[1]));
					b = 255*(m_ColorPoint[j].m_Color[2] + dbl*(m_ColorPoint[j+1].m_Color[2]-m_ColorPoint[j].m_Color[2]));
				}
			}
			for(j=0;j<m_AlphaPoint.GetSize()-1;j++)
			{
				if (dCurPos >= m_AlphaPoint[j].m_fAlphapos&&dCurPos <= m_AlphaPoint[j+1].m_fAlphapos)
				{
					double dbl = (dCurPos - m_AlphaPoint[j].m_fAlphapos)/(m_AlphaPoint[j+1].m_fAlphapos - m_AlphaPoint[j].m_fAlphapos);
					a = 255*(m_AlphaPoint[j].m_Alpha + dbl*(m_AlphaPoint[j+1].m_Alpha - m_AlphaPoint[j].m_Alpha));
				}
			}
			if (a == 0)
			{
				r=0;
				g=0;
				b=0;
			}
			fprintf(fp,"r=%d\r\n",r);
			fprintf(fp,"g=%d\r\n",g);
			fprintf(fp,"b=%d\r\n",b);
			fprintf(fp,"a=%d\r\n",a);
		}

		fclose(fp);
	}

}
void CVolumeRender::SetVolumeData(double *pData,int m_nX1, int m_nY1, int m_nZ1)
{
	int nX = m_nX1;
	int nY = m_nY1;
	int nZ = m_nZ1;
	m_nX = m_nX1;
	m_nY = m_nY1;
	m_nZ = m_nZ1;

	m_Roi0 = vec3i(1, 1, 1);
	m_Roi1 = vec3i(m_nX - 2, m_nY - 2, m_nZ - 2);
	m_oriRoi0 = vec3i(1, 1, 1);
	m_oriRoi1 = vec3i(m_nX - 2, m_nY - 2, m_nZ - 2);

	double *dTempData = new double[nX * nY * nZ];

	if(m_pubVolumeData) delete[] m_pubVolumeData;
	m_pubVolumeData = new GLubyte[nX * nY * nZ];

	minsnb = MaxFloatValue;
	maxsnb = MinFloatValue;
	maxrealsnb = MinFloatValue;

	int i;
	
	for( i = 0; i < nX*nY*nZ; i ++)
	{
		
		dTempData[i] = pData[i];
		
		if (dTempData[i] < minsnb)
		{
			minsnb = dTempData[i];
		}
		if (dTempData[i] > maxsnb)
		{
			maxsnb = dTempData[i];
		}
		
	}
	maxrealsnb = maxsnb;
	//���ŵ�0~255
	double dTemp;
	int nIndex;
	m_nMaxHist = -10;

	ZeroMemory(m_nDataHist, sizeof(int) * HIST_NUM);
	
	for( i = 0; i <  nX*nY*nZ; i ++)
	{		
		nIndex = i;
		if(dTempData[nIndex] == 1000)
			dTemp = maxrealsnb + 1;
		else
			dTemp = dTempData[nIndex];

		m_pubVolumeData[nIndex] = (dTemp - minsnb) / (maxrealsnb - minsnb) * 255;
		int nHistIndex = HIST_NUM*(dTemp - minsnb) / (maxrealsnb - minsnb);
		m_nDataHist[nHistIndex]++;
	}
	for(i = 0; i < HIST_NUM; i++)
	{
		if(m_nMaxHist < m_nDataHist[i])
			m_nMaxHist = m_nDataHist[i];
	}
	delete[]dTempData;	
}
void CVolumeRender::CreateMesh()
{
	volumeboxpos = vec3d(m_vecLBPos[0]/m_dMaxScale, 0 ,m_vecLBPos[2]/m_dMaxScale);
	volumebox = vec3d((m_vecRTPos[0]-m_vecLBPos[0])/m_dMaxScale,(m_vecRTPos[1]-m_vecLBPos[1])/m_dMaxScale,(m_vecRTPos[2]-m_vecLBPos[2])/m_dMaxScale);
	volumestep = vec3d((m_vecRTPos[0]-m_vecLBPos[0])/(m_dMaxScale*m_nX), (m_vecRTPos[1]-m_vecLBPos[1])/(m_dMaxScale*m_nY) , (m_vecRTPos[2]-m_vecLBPos[2])/(m_dMaxScale*m_nZ));
	if(! m_bInit)
	{
		TestDVRTexture3D.GraphicsInit();
		m_bInit = true;
	}

	CreateVolumeData(volumeboxpos, volumebox, volumestep);
}
void CVolumeRender::SetVolumeBox(vec3d vecLBPos,vec3d vecRTPos,double dScale,double dH_Scale,int nx,int ny,int nz)
{
	m_vecLBPos = vecLBPos;
	m_vecRTPos = vecRTPos;
	m_dScale = dScale;
	m_dH_Scale = dH_Scale;
	m_nX = nx;
	m_nY = ny;
	m_nZ = nz;
}

void CVolumeRender::Draw()
{
	if(!m_bInit)
		CreateMesh();
	glPushMatrix();
	RenderVolume();
	glPopMatrix();
}


#define EPSILON 5.960464478e-8
#define FLTEQ(a,b) (fabs(a-b) < fabs(a*EPSILON) && fabs(a-b) < fabs(b*EPSILON))

void CVolumeRender::RenderVolume()
{
	double nx = m_nX*1111/200;
	vec3d dvecLBPos = vec3d(-0.05*(nx-1),-0.05*(nx-1),-0.05*(nx-1));
	vec3d dvecRTPos = vec3d(0.05*(nx-1),1.0*0.05*(nx-1),0.05*(nx-1));
	volumeboxpos = vec3d(dvecLBPos[0]/m_dMaxScale, dvecLBPos[1]/m_dMaxScale ,dvecLBPos[2]/m_dMaxScale);
	volumebox = vec3d((dvecRTPos[0]-dvecLBPos[0])/m_dMaxScale,(dvecRTPos[1]-dvecLBPos[1])/m_dMaxScale,(dvecRTPos[2]-dvecLBPos[2])/m_dMaxScale);
	volumestep = vec3d((dvecRTPos[0]-dvecLBPos[0])/(m_dMaxScale*m_nX), (dvecRTPos[1]-dvecLBPos[1])/(m_dMaxScale*m_nY) , (dvecRTPos[2]-dvecLBPos[2])/(m_dMaxScale*m_nZ));
	//m_Roi0 = vec3i(1,1,1);
	//m_Roi1 = vec3i(m_nX-2, m_nY-2, m_nZ-2);
	glPushMatrix();
	glTranslatef(volumeboxpos.x*m_dMaxScale,volumeboxpos.y*m_dMaxScale,volumeboxpos.z*m_dMaxScale);
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	{

		vec3d vb0 = volumebox * m_dMaxScale;
		const int data_roi[6] = {m_Roi0.x,m_Roi0.y,m_Roi0.z, m_Roi1.x,m_Roi1.y,m_Roi1.z};
		const float extents[6] = {
			0 + vb0.x * (m_Roi0.x - 1.0) / (m_nX - 3.0), 
			0 + vb0.y * (m_Roi0.y - 1.0) / (m_nY - 3.0),
			0 + vb0.z * (m_Roi0.z - 1.0) / (m_nZ - 3.0),
			0 + vb0.x * (m_Roi1.x - 1.0) / (m_nX - 3.0), 
			0 + vb0.y * (m_Roi1.y - 1.0) / (m_nY - 3.0),
			0 + vb0.z * (m_Roi1.z - 1.0) / (m_nZ - 3.0)};//���ƿ��С

			const int data_box[6] = {0,0,0, m_nX - 1, m_nY - 1, m_nZ - 1};//�����ݴ�С
			

			int nx = m_nX, ny = m_nY, nz = m_nZ;//����ά��

			int level = 1;
			double vscale[3] = {vb0.x, vb0.y, vb0.z};

			TestDVRTexture3D.SetRegion(m_pubVolumeData, nx, ny, nz,
				data_roi, 
				extents,
				data_box,
				level,
				vscale);

			vec3f minP = vec3f(extents[0], extents[1], extents[2]);
			vec3f maxP = vec3f(extents[3], extents[4], extents[5]);

			glDisable(GL_LIGHTING);
			glDisable(GL_DEPTH_TEST);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}

	if(bNeedrefreshColormap)
	{
		for (int i=0; i<256; i++) 
		{ 
			vec4f vcolor = GetMapColor(i);
			m_Color[i][0] = vcolor.r;
			m_Color[i][1] = vcolor.g;
			m_Color[i][2] = vcolor.b;
			m_Color[i][3] = vcolor.a;
		}
		bNeedrefreshColormap = false;
	}

	matrix4f modelviewInverse;

	if(TestDVRTexture3D.bEye && TestDVRTexture3D.GetPreintegrationOnOff())
	{
		glGetFloatv(GL_MODELVIEW_MATRIX, modelviewInverse);

		modelviewInverse.invert();
		TestDVRTexture3D.SetView(modelviewInverse.M + 12, modelviewInverse.M + 8);
	}

	
	TestDVRTexture3D.SetOLUT(m_Color, 1);
	
	glEnable(GL_DEPTH_TEST);
	TestDVRTexture3D.Render();
	glPopAttrib();
	glPopMatrix();
}
void CVolumeRender::SetDragBoxVisible(bool bVisible)
{
	TestDVRTexture3D.m_bDrawDragBox = bVisible;
}
bool CVolumeRender::GetDragBoxVisible()
{
	return TestDVRTexture3D.m_bDrawDragBox;
}
void CVolumeRender::OnLButtonDown(UINT nFlags, CPoint point)
{
	int nID = PickModel(point.x,point.y);
	if (nID > 0)
	{
		m_nSelect = TestDVRTexture3D.SetSelect(nID);
	}else
	{
		if (m_nSelect > -1&&m_nSelect < 6)
		{
			TestDVRTexture3D.dragbox[m_nSelect].bSelect = false;
			m_nSelect = -1;
		}else
			m_nSelect = -1;
	}
}
void CVolumeRender::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_nSelect > -1&&m_nSelect < 6)
	{
		TestDVRTexture3D.dragbox[m_nSelect].bSelect = false;
		m_nSelect = -1;
	}else
		m_nSelect = -1;
}
void CVolumeRender::OnRButtonDown(UINT nFlags, CPoint point)
{
	int nID = PickModel(point.x,point.y);
	if (nID > 0)
	{
		m_nSelect = TestDVRTexture3D.SetSelect(nID);
	}else
	{
		if (m_nSelect > -1&&m_nSelect < 6)
		{
			TestDVRTexture3D.dragbox[m_nSelect].bSelect = false;
			m_nSelect = -1;
		}else
			m_nSelect = -1;
	}
}
void CVolumeRender::OnRButtonUp(UINT nFlags, CPoint point)
{
	if (m_nSelect > -1&&m_nSelect < 6)
	{
		TestDVRTexture3D.dragbox[m_nSelect].bSelect = false;
		m_nSelect = -1;
	}else
		m_nSelect = -1;
}
void CVolumeRender::OnSize(UINT nType, int cx, int cy)
{
	m_ncx = cx;
	m_ncy = cy;	
}
void CVolumeRender::GetMaxtrix()
{
 	glGetDoublev(GL_MODELVIEW_MATRIX, modelviewInverse);
 	glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
	glGetIntegerv(GL_VIEWPORT,viewportmatrix);
	
}
void CVolumeRender::OnMouseMove(UINT nFlags, CPoint point)
{
	if (m_nSelect > -1&&m_nSelect < 6)
	{
		if (nFlags&MK_LBUTTON)
		{
			vec3d point3D,point3D1;
			gluUnProject((GLdouble)point.x,(GLdouble)(m_ncy - point.y),1.0,modelviewInverse,projmatrix,viewportmatrix,&point3D.x,&point3D.y,&point3D.z);
			gluUnProject((GLdouble)point.x,(GLdouble)(m_ncy - point.y),0.1,modelviewInverse,projmatrix,viewportmatrix,&point3D1.x,&point3D1.y,&point3D1.z);		
			vec3d vecMove;
			vecMove[0] = volumeboxpos.x*m_dMaxScale;
			vecMove[1] = volumeboxpos.y*m_dMaxScale;
			vecMove[2] = volumeboxpos.z*m_dMaxScale;
			point3D -= vecMove;
			point3D1 -= vecMove;
			vec3d dir = point3D-point3D1;
			dir.Normalize();
			vec3d vb0 = volumebox * m_dMaxScale;
			if (m_nSelect < 2)
			{
				double t = (volumebox.y*m_dMaxScale/2-point3D1.y)/dir.y;
				double dx = point3D1.x + dir.x*t;
				if (m_nSelect == 0)
				{
					double dl = dx + LEGHT_TO_DRAGBOX;
					if (dl < TestDVRTexture3D.dragbox[1].dMove - LEGHT_TO_DRAGBOX&&dl >= 0)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dx;
						m_Roi0.x = m_oriRoi0.x + dl*(m_oriRoi1.x - m_oriRoi0.x)/vb0.x;
					}
				}else if (m_nSelect == 1)
				{
					double dl = dx - LEGHT_TO_DRAGBOX;
					if (dl > TestDVRTexture3D.dragbox[0].dMove + LEGHT_TO_DRAGBOX&&dl <= vb0.x)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dx;
						m_Roi1.x = m_oriRoi0.x + dl*(m_oriRoi1.x - m_oriRoi0.x)/vb0.x;
					}
				}
			}else if (m_nSelect < 4)
			{
				double t = (volumebox.z*m_dMaxScale/2-point3D1.z)/dir.z;
				double dy = point3D1.y + dir.y*t;
				if (m_nSelect == 2)
				{
					double dl = dy + LEGHT_TO_DRAGBOX;
					if (dl < TestDVRTexture3D.dragbox[3].dMove - LEGHT_TO_DRAGBOX&&dl >= 0)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dy;
						m_Roi0.y = m_oriRoi0.y + dl*(m_oriRoi1.y - m_oriRoi0.y)/vb0.y;
					}
				}else if (m_nSelect == 3)
				{
					double dl = dy - LEGHT_TO_DRAGBOX;
					if (dl > TestDVRTexture3D.dragbox[2].dMove + LEGHT_TO_DRAGBOX&&dl <= vb0.y)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dy;
						m_Roi1.y = m_oriRoi0.y + dl*(m_oriRoi1.y - m_oriRoi0.y)/vb0.y;
					}
				}
			}else
			{
				double t = (volumebox.y*m_dMaxScale/2-point3D1.y)/dir.y;
				double dz = point3D1.z + dir.z*t;
				if (m_nSelect == 4)
				{
					double dl = dz + LEGHT_TO_DRAGBOX;
					if (dl < TestDVRTexture3D.dragbox[5].dMove - LEGHT_TO_DRAGBOX&&dl >= 0)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dz;
						m_Roi0.z = m_oriRoi0.z + dl*(m_oriRoi1.z - m_oriRoi0.z)/vb0.z;
					}
				}else if (m_nSelect == 5)
				{
					double dl = dz - LEGHT_TO_DRAGBOX;
					if (dl > TestDVRTexture3D.dragbox[4].dMove + LEGHT_TO_DRAGBOX&&dl <= vb0.z)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dz;
						m_Roi1.z = m_oriRoi0.z + dl*(m_oriRoi1.z - m_oriRoi0.z)/vb0.z;
					}
				}
			}
		}else if (nFlags&MK_RBUTTON)
		{
			vec3d point3D,point3D1;
			gluUnProject((GLdouble)point.x,(GLdouble)(m_ncy - point.y),1.0,modelviewInverse,projmatrix,viewportmatrix,&point3D.x,&point3D.y,&point3D.z);
			gluUnProject((GLdouble)point.x,(GLdouble)(m_ncy - point.y),0.1,modelviewInverse,projmatrix,viewportmatrix,&point3D1.x,&point3D1.y,&point3D1.z);		
			vec3d vecMove;
			vecMove[0] = volumeboxpos.x*m_dMaxScale;
			vecMove[1] = volumeboxpos.y*m_dMaxScale;
			vecMove[2] = volumeboxpos.z*m_dMaxScale;
			point3D -= vecMove;
			point3D1 -= vecMove;
			vec3d dir = point3D-point3D1;
			dir.Normalize();
			vec3d vb0 = volumebox * m_dMaxScale;
			if (m_nSelect < 2)
			{
				double t = (volumebox.y*m_dMaxScale/2-point3D1.y)/dir.y;
				double dx = point3D1.x + dir.x*t;
				if (m_nSelect == 0)
				{
					double dl = dx + LEGHT_TO_DRAGBOX;
					double dLength = TestDVRTexture3D.dragbox[1].dMove - LEGHT_TO_DRAGBOX - (TestDVRTexture3D.dragbox[0].dMove + LEGHT_TO_DRAGBOX);
					if (dl + dLength <= vb0.x&&dl >= 0)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dx;
						TestDVRTexture3D.dragbox[1].dMove = dl + dLength + LEGHT_TO_DRAGBOX;
						m_Roi0.x = m_oriRoi0.x + dl*(m_oriRoi1.x - m_oriRoi0.x)/vb0.x;
						m_Roi1.x = m_oriRoi0.x + (dl+dLength)*(m_oriRoi1.x - m_oriRoi0.x)/vb0.x;

					}
				}else if (m_nSelect == 1)
				{
					double dl = dx - LEGHT_TO_DRAGBOX;
					double dLength = TestDVRTexture3D.dragbox[1].dMove - LEGHT_TO_DRAGBOX - (TestDVRTexture3D.dragbox[0].dMove + LEGHT_TO_DRAGBOX);
					if (dl-dLength >= 0&&dl <= vb0.x)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dx;
						TestDVRTexture3D.dragbox[0].dMove = dl - dLength - LEGHT_TO_DRAGBOX;
						m_Roi0.x = m_oriRoi0.x + (dl-dLength)*(m_oriRoi1.x - m_oriRoi0.x)/vb0.x;
						m_Roi1.x = m_oriRoi0.x + dl*(m_oriRoi1.x - m_oriRoi0.x)/vb0.x;

					}
				}
			}else if (m_nSelect < 4)
			{
				double t =(volumebox.z*m_dMaxScale/2-point3D1.z)/dir.z;
				double dy = point3D1.y + dir.y*t;
				if (m_nSelect == 2)
				{
					double dl = dy + LEGHT_TO_DRAGBOX;
					double dLength = TestDVRTexture3D.dragbox[3].dMove - LEGHT_TO_DRAGBOX - (TestDVRTexture3D.dragbox[2].dMove + LEGHT_TO_DRAGBOX);
					if (dl + dLength <= vb0.y&&dl >= 0)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dy;
						TestDVRTexture3D.dragbox[3].dMove = dl + dLength + LEGHT_TO_DRAGBOX;
						m_Roi0.y = m_oriRoi0.y + dl*(m_oriRoi1.y - m_oriRoi0.y)/vb0.y;
						m_Roi1.y = m_oriRoi0.y + (dl+dLength)*(m_oriRoi1.y - m_oriRoi0.y)/vb0.y;

					}
				}else if (m_nSelect == 3)
				{
					double dl = dy - LEGHT_TO_DRAGBOX;
					double dLength = TestDVRTexture3D.dragbox[3].dMove - LEGHT_TO_DRAGBOX - (TestDVRTexture3D.dragbox[2].dMove + LEGHT_TO_DRAGBOX);
					if (dl-dLength >= 0&&dl <= vb0.y)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dy;
						TestDVRTexture3D.dragbox[2].dMove = dl - dLength - LEGHT_TO_DRAGBOX;
						m_Roi0.y = m_oriRoi0.y + (dl-dLength)*(m_oriRoi1.y - m_oriRoi0.y)/vb0.y;
						m_Roi1.y = m_oriRoi0.y + dl*(m_oriRoi1.y - m_oriRoi0.y)/vb0.y;
					}
				}
			}else
			{
				double t = (volumebox.y*m_dMaxScale/2-point3D1.y)/dir.y;
				double dz = point3D1.z + dir.z*t;
				if (m_nSelect == 4)
				{
					double dl = dz + LEGHT_TO_DRAGBOX;
					double dLength = TestDVRTexture3D.dragbox[5].dMove - LEGHT_TO_DRAGBOX - (TestDVRTexture3D.dragbox[4].dMove + LEGHT_TO_DRAGBOX);
					if (dl + dLength <= vb0.z&&dl >= 0)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dz;
						TestDVRTexture3D.dragbox[5].dMove = dl + dLength + LEGHT_TO_DRAGBOX;
						m_Roi0.z = m_oriRoi0.z + dl*(m_oriRoi1.z - m_oriRoi0.y)/vb0.z;
						m_Roi1.z = m_oriRoi0.z + (dl+dLength)*(m_oriRoi1.z - m_oriRoi0.z)/vb0.z;

					}
				}else if (m_nSelect == 5)
				{
					double dl = dz - LEGHT_TO_DRAGBOX;
					double dLength = TestDVRTexture3D.dragbox[5].dMove - LEGHT_TO_DRAGBOX - (TestDVRTexture3D.dragbox[4].dMove + LEGHT_TO_DRAGBOX);
					if (dl-dLength >= 0&&dl <= vb0.z)
					{
						TestDVRTexture3D.dragbox[m_nSelect].dMove = dz;
						TestDVRTexture3D.dragbox[4].dMove = dl - dLength - LEGHT_TO_DRAGBOX;
						m_Roi0.z = m_oriRoi0.z + (dl-dLength)*(m_oriRoi1.z - m_oriRoi0.z)/vb0.z;
						m_Roi1.z = m_oriRoi0.z+ dl*(m_oriRoi1.z - m_oriRoi0.z)/vb0.z;
					}
				}
			}
		}
	}
}
int CVolumeRender::PickModel(int x, int y)
{
	if (!m_pGLSet)
	{
		return -1;
	}
	GLuint selectBuf[BUFSIZE];
	GLint hits=0;
	GLint viewport[4];
	int m_pick_model=0;
	glGetIntegerv(GL_VIEWPORT,viewport);
	glSelectBuffer(BUFSIZE,selectBuf);
	glRenderMode(GL_SELECT);

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluPickMatrix((GLdouble)x,(GLdouble)(viewport[3]-y),1.0,1.0,viewport);
	gluPerspective (45.0f, (GLfloat)(m_pGLSet->scrwidth)/(GLfloat)(m_pGLSet->scrheight),ZNEAR, ZFAR);		


    glMatrixMode(GL_MODELVIEW);
	RenderVolume();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glFlush();

	hits=glRenderMode(GL_RENDER);
	////
	if (hits>0)
	{
		m_pick_model=selectBuf[3];
	}
  glMatrixMode(GL_MODELVIEW);
  return m_pick_model;
}
void CVolumeRender::SetGlRender(CGLRender *pGLSet)
{
	m_pGLSet = pGLSet;
}
void CVolumeRender::ResetBox()
{
	m_Roi0 = vec3i(1, 1, 1);
	m_Roi1 = vec3i(m_nX - 2, m_nY - 2, m_nZ - 2);	

	TestDVRTexture3D.dragbox[0].dMove = TestDVRTexture3D._vorimin.x - LEGHT_TO_DRAGBOX;
	TestDVRTexture3D.dragbox[1].dMove = TestDVRTexture3D._vorimax.x + LEGHT_TO_DRAGBOX;
	TestDVRTexture3D.dragbox[2].dMove = TestDVRTexture3D._vorimin.y - LEGHT_TO_DRAGBOX;
	TestDVRTexture3D.dragbox[3].dMove = TestDVRTexture3D._vorimax.y + LEGHT_TO_DRAGBOX;
	TestDVRTexture3D.dragbox[4].dMove = TestDVRTexture3D._vorimin.z - LEGHT_TO_DRAGBOX;
	TestDVRTexture3D.dragbox[5].dMove = TestDVRTexture3D._vorimax.z + LEGHT_TO_DRAGBOX;
}
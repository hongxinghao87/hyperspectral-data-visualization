#pragma once
#define ZNEAR 0.01f
#define ZFAR 1000.0f

class CGLRender
{
public:
	CGLRender(void);
public:
	~CGLRender(void);
protected:
	HDC	m_hDC;
	HGLRC	m_hRC;	
	void InitExtensions();
public:
	static bool m_bsupportMultiTex,m_bsupportDrawRangeElements;
	static bool m_bsupportCompression,m_bsupportVBO,m_bsupportPointSprites;
	char *vendor,*version,*renderer;
	static int scrwidth,scrheight;
	static double dOrthoHeight,dOrthoWidth;
public:
	void Initialize(HDC hDC);
	void UnInitialize();
	void OnSize(int cx, int cy);
	void SwapBuffers();
public:
	static void Set3DMode(void);
	static void Set3DOrthoMode();
	static void Set2DMode(void);
	static void Restore();
};
#include "StdAfx.h"
#include "GLArcBall.h"

CGLArcBall::CGLArcBall(void)
{
	//Clear initial values
	this->StVec.x     =
		this->StVec.y     = 
		this->StVec.z     = 

		this->EnVec.x     =
		this->EnVec.y     = 
		this->EnVec.z     = 0.0f;

	Matrix4Identity(&Transform);
	
	Matrix3Identity(&LastRot);
	
	Matrix3Identity(&ThisRot);

	//Set initial bounds
	this->setBounds(800, 600);
}

void CGLArcBall::Reset()
{
	this->StVec.x     =
		this->StVec.y     = 
		this->StVec.z     = 
		
		this->EnVec.x     =
		this->EnVec.y     = 
		this->EnVec.z     = 0.0f;
	
	Matrix4Identity(&Transform);
	
	Matrix3Identity(&LastRot);
	
	Matrix3Identity(&ThisRot);
}

//Create/Destroy
CGLArcBall::CGLArcBall(GLfloat NewWidth, GLfloat NewHeight)
{
	//Clear initial values
	this->StVec.x     =
		this->StVec.y     = 
		this->StVec.z     = 

		this->EnVec.x     =
		this->EnVec.y     = 
		this->EnVec.z     = 0.0f;

	Matrix4Identity(&Transform);
	
	Matrix3Identity(&LastRot);
	
	Matrix3Identity(&ThisRot);

	//Set initial bounds
	this->setBounds(NewWidth, NewHeight);
}

CGLArcBall::~CGLArcBall(void)
{
}

void CGLArcBall::_mapToSphere(const vec2f* NewPt, vec3f* NewVec) const
{
	vec2f TempPt;
	GLfloat length;

	//Copy paramter into temp point
	TempPt = *NewPt;

	//Adjust point coords and scale down to range of [-1 ... 1]
	TempPt.x  =        (TempPt.x * this->AdjustWidth)  - 1.0f;
	TempPt.y  = 1.0f - (TempPt.y * this->AdjustHeight);

	//Compute the square of the length of the vector to the point from the center
	length      = (TempPt.x * TempPt.x) + (TempPt.y * TempPt.y);

	//If the point is mapped outside of the sphere... (length > radius squared)
	if (length > 1.0f)
	{
		GLfloat norm;

		//Compute a normalizing factor (radius / sqrt(length))
		norm    = 1.0f / sqrtf(length);

		//Return the "normalized" vector, a point on the sphere
		NewVec->x = TempPt.x * norm;
		NewVec->y = TempPt.y * norm;
		NewVec->z = 0.0f;
	}
	else    //Else it's on the inside
	{
		//Return a vector to a point mapped inside the sphere sqrt(radius squared - length)
		NewVec->x = TempPt.x;
		NewVec->y = TempPt.y;
		NewVec->z = sqrtf(1.0f - length);
	}
}

//Mouse down
void    CGLArcBall::click(const vec2f* NewPt)
{
	LastRot = ThisRot;
	//Map the point to the sphere
	this->_mapToSphere(NewPt, &this->StVec);
}

//Mouse drag, calculate rotation
void    CGLArcBall::drag(const vec2f* NewPt)
{
	vec4f NewRot;
	//Map the point to the sphere
	this->_mapToSphere(NewPt, &this->EnVec);

	//Return the quaternion equivalent to the rotation
	//if (NewRot)
	{
		vec3f  Perp;

		//Compute the vector perpendicular to the begin and end vectors
		glVec3Cross(&Perp, &this->StVec, &this->EnVec);

		//Compute the length of the perpendicular vector
		if (glVec3Length(&Perp) > GLEpsilon)    //if its non-zero
		{
			//We're ok, so return the perpendicular vector as the transform after all
			NewRot.x = Perp.x;
			NewRot.y = Perp.y;
			NewRot.z = Perp.z;
			//In the quaternion values, w is cosine (theta / 2), where theta is rotation angle
			NewRot.w= glVec3Dot(&this->StVec, &this->EnVec);
		}
		else                                    //if its zero
		{
			//The begin and end vectors coincide, so return an identity transform
			NewRot.x = 
				NewRot.y = 
				NewRot.z = 
				NewRot.w = 0.0f;
		}
	}

	Matrix3fSetRotationFromQuat4f(&ThisRot, &NewRot);	
	Matrix3fMulMatrix3f(&ThisRot, &LastRot);			
	Matrix4fSetRotationFromMatrix3f(&Transform, &ThisRot);
    //////////////////////////////////////////////////////////////////////
	
	matrix4f  mCameraRot = Transform;
	mCameraRot.invert();

	vec3f vLocalUp (0,1,0);
	vec3f vLocalAhead(0,0,-1);
	vLocalUp.TransformCoord(mCameraRot);
	vLocalAhead.TransformCoord(mCameraRot);

	////////////////////////////////////////////////////////////////////
}
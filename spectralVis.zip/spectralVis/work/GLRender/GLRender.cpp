#include "StdAfx.h"
#include "glmvmath.h"
#include "GLRender.h"

bool CGLRender::m_bsupportMultiTex=false;
bool CGLRender::m_bsupportDrawRangeElements=false;
bool CGLRender::m_bsupportCompression=false;
bool CGLRender::m_bsupportVBO=false;
bool CGLRender::m_bsupportPointSprites=false;
int CGLRender::scrwidth=400,CGLRender::scrheight=300;
double CGLRender::dOrthoHeight=400,CGLRender::dOrthoWidth=300;

CGLRender::CGLRender(void)
{
	scrwidth=400;
	scrheight=300;
}

CGLRender::~CGLRender(void)
{
}

void CGLRender::InitExtensions()
{
	int glewErr = glewInit();
	if (glewErr != GLEW_OK) 
	{
	}  
	vendor = ((char *)glGetString(GL_VENDOR));
	version = ((char *)glGetString(GL_VERSION));
	renderer = ((char *)glGetString(GL_RENDERER));

	m_bsupportDrawRangeElements = glewIsSupported("GL_EXT_draw_range_elements") == GL_TRUE ? true : false;
	m_bsupportMultiTex = glewIsSupported("GL_ARB_multitexture") == GL_TRUE ? true : false;
	m_bsupportVBO = glewIsSupported("GL_ARB_vertex_buffer_object") == GL_TRUE ? true : false;
	m_bsupportCompression = glewIsSupported("GL_ARB_texture_compression GL_ARB_texture_cube_map GL_EXT_texture_compression_s3tc") == GL_TRUE ? true : false;
	m_bsupportPointSprites = glewIsSupported("GL_ARB_point_sprite GL_ARB_point_parameters") == GL_TRUE ? true : false;
}

void CGLRender::Initialize(HDC hDC)
{
	m_hDC=hDC;
	PIXELFORMATDESCRIPTOR pfd = { 
		sizeof(PIXELFORMATDESCRIPTOR),    // pfd�ṹ�Ĵ�С 
		1,                                // �汾�� 
		PFD_DRAW_TO_WINDOW |              // ֧���ڴ����л�ͼ 
		PFD_SUPPORT_OPENGL |              // ֧�� OpenGL 
		PFD_DOUBLEBUFFER,                 // ˫����ģʽ 
		PFD_TYPE_RGBA,                    // RGBA ��ɫģʽ 
		24,                               // 24 λ��ɫ��� 
		0, 0, 0, 0, 0, 0,                 // ������ɫλ 
		8,                                // û�з�͸���Ȼ��� 
		0,                                // ������λλ 
		0,                                // ���ۼӻ��� 
		0, 0, 0, 0,                       // �����ۼ�λ 
		32,                               // 32 λ��Ȼ���     
		24,                                // 24λģ�建�� 
		0,                                // �޸������� 
		PFD_MAIN_PLANE,                   // ���� 
		0,                                // ���� 
		0, 0, 0                           // ���Բ�,�ɼ��Ժ������ģ 
	}; 	
	int pixelformat;
	pixelformat = ::ChoosePixelFormat(m_hDC, &pfd);//ѡ�����ظ�ʽ
	::SetPixelFormat(m_hDC, pixelformat, &pfd);	//�������ظ�ʽ
	//���ɻ���������
	m_hRC = ::wglCreateContext(m_hDC);
	//�õ�ǰ����������
	::wglMakeCurrent(m_hDC, m_hRC);

	InitExtensions();

	if (m_bsupportDrawRangeElements && m_bsupportVBO) 
	{
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_NORMAL_ARRAY);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	} 
	else 
	{
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	//glEnable(GL_COLOR_MATERIAL);
	//glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT);
	//glColorMaterial(GL_FRONT_AND_BACK, GL_DIFFUSE);
	//glColorMaterial(GL_FRONT_AND_BACK, GL_EMISSION);
	//glColorMaterial(GL_FRONT_AND_BACK, GL_SPECULAR);

	// For environmental mapped meshes
	//glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 18.0f);

	//glClearColor(0,0,0,0);
	glClearColor (0,0,0,1);//158.0f/255, 184.0f/255, 211.0f/255, 1.0f							// Black Background
	glClearStencil(0);
	glClearDepth (1.0f);											// Depth Buffer Setup
	glDepthFunc (GL_LEQUAL);										// The Type Of Depth Testing (Less Or Equal)
	glEnable (GL_DEPTH_TEST);										// Enable Depth Testing
	glShadeModel (GL_SMOOTH);											// Select Flat Shading (Nice Definition Of Objects)
	glHint (GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);				// Set Perspective Calculations To Most Accurate

	/*float ambientLight[] = {1.0f, 1.0f, 1.0f, 1.0f};
	float diffuseLight[] = {1.0, 1.0, 1.0, 1.0}; 
	float specularLight[] = {1.0, 1.0, 1.0, 1.0};

	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specularLight);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);*/
	glEnable(GL_LIGHT0);
	glDisable(GL_LIGHT1);// Enable Default Light
	glEnable(GL_LIGHTING);											// Enable Lighting


}

void CGLRender::UnInitialize()
{
	::wglMakeCurrent(0,0);
	::wglDeleteContext( m_hRC);
}
void CGLRender::SwapBuffers()
{
	::SwapBuffers(m_hDC);	
}

void CGLRender::OnSize(int width, int height)
{
	scrwidth=width;
	scrheight=height;
	glViewport (0, 0, (GLsizei)(width), (GLsizei)(height));				// Reset The Current Viewport
	glMatrixMode (GL_PROJECTION);										// Select The Projection Matrix
	glLoadIdentity ();													// Reset The Projection Matrix
	gluPerspective (45.0f, (GLfloat)(width)/(GLfloat)(height),			// Calculate The Aspect Ratio Of The Window
		ZNEAR, ZFAR);		
	glMatrixMode (GL_MODELVIEW);										// Select The Modelview Matrix
	glLoadIdentity ();	
	dOrthoHeight = 2.0 * tan(PI/8);
	
	dOrthoWidth = width * dOrthoHeight /height;
}
void CGLRender::Set3DMode(void)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)scrwidth/(GLfloat)scrheight, ZNEAR, ZFAR);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
}
void CGLRender::Set3DOrthoMode()
{

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(-dOrthoWidth, dOrthoWidth, -dOrthoHeight, dOrthoHeight,  ZNEAR, ZFAR);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
}

void CGLRender::Set2DMode(void)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, scrwidth, 0, scrheight,  -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
}

void CGLRender::Restore()
{
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

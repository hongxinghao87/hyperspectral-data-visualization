#pragma once
#include "math.h"
#include "glmvmath.h"

#define GLEpsilon 1.0e-5

class CGLArcBall
{
public:
	CGLArcBall(void);
public:
	~CGLArcBall(void);

protected:
	inline
		void _mapToSphere(const vec2f* NewPt, vec3f* NewVec) const;

public:
	//Create/Destroy
	CGLArcBall(GLfloat NewWidth, GLfloat NewHeight);

	matrix4f   Transform  ;

	//Set new bounds
	inline
		void    setBounds(GLfloat NewWidth, GLfloat NewHeight)
	{
		assert((NewWidth > 1.0f) && (NewHeight > 1.0f));

		//Set adjustment factor for width/height
		this->AdjustWidth  = 1.0f / ((NewWidth  - 1.0f) * 0.5f);
		this->AdjustHeight = 1.0f / ((NewHeight - 1.0f) * 0.5f);
	}

	//Mouse down
	void    click(const vec2f* NewPt);

	//Mouse drag, calculate rotation
	void    drag(const vec2f* NewPt);

	void Reset();

protected:
	vec3f   StVec;          //Saved click vector
	vec3f   EnVec;          //Saved drag vector
	GLfloat     AdjustWidth;    //Mouse bounds width
	GLfloat     AdjustHeight;   //Mouse bounds height

	
	matrix3f   LastRot   ;
	
	matrix3f   ThisRot ;
};
